CREATE FUNCTION rep_repair_dws_overview_agg(p_session_id character varying, p_period integer, p_fact_flag integer DEFAULT 1, p_customer_id bigint DEFAULT NULL::bigint, p_performer_id bigint DEFAULT NULL::bigint, p_driveway_category_id bigint DEFAULT NULL::bigint, p_agreement_group_id bigint DEFAULT NULL::bigint, p_driveway_segment_id bigint DEFAULT NULL::bigint, p_driveway_segment_name character varying DEFAULT NULL::character varying, p_period_from date DEFAULT NULL::date, p_period_to date DEFAULT NULL::date)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Интерактивная витрина «Общие сведения о ремонте автомобильных дорог Московской области»
     Сводная информация по участкам ремонта

     %param p_session_id             - Ид сессии
     %param p_period integer         - Период
                                       1 - За сегодня
                                       2 - За прошлую неделю
                                       3 - За прошлый месяц
                                       4 - Конкретный период (p_period_from - p_period_to)
     %param p_fact_flag              - 1 - Факт по валу
                                       2 - Факт по плану
     %param p_customer_id            - Ид заказчика
     %param p_performer_id           - Ид исполнителя
     %param p_driveway_category_id   - Ид балансовой принадлежности
     %param p_agreement_group_id     - Ид группы контрактов
     %param p_driveway_segment_id    - Ид участка ремонта
     %param p_driveway_segment_name  - Наименование участка ремонта
     %param p_period_from            - Дата с
     %param p_period_to              - Дата по

     %return driveway_category             - Сеть
     %return total_driveway_segment_qty    - Всего

     %return asphalt_finished_plan_qty     - Завершена укладка асфальта(план) количество
     %return asphalt_finished_fact_qty     - Завершена укладка асфальта(факт) количество
     %return deviation_from_plan_qty       - % отклонения от плана            количество

     %return asphalt_finished_plan_area    - Завершена укладка асфальта(план) протяженность
     %return asphalt_finished_fact_area    - Завершена укладка асфальта(факт) протяженность
     %return deviation_from_plan_area      - % отклонения от плана            протяженность

     %return asphalt_finished_plan_cost    - Завершена укладка асфальта(план) деньги
     %return asphalt_finished_fact_cost    - Завершена укладка асфальта(факт) деньги
     %return deviation_from_plan_cost      - % отклонения от плана            деньги

     %return total_finished_plan_qty       - Завершено в полном объеме(план) количество
     %return total_finished_fact_qty       - Завершено в полном объеме(факт) количество
     %return deviation_from_total_plan_qty - % отклонения от плана            количество

     %return total_finished_plan_area       - Завершено в полном объеме(план) протяженность
     %return total_finished_fact_area       - Завершено в полном объеме(факт) протяженность
     %return deviation_from_total_plan_area - % отклонения от плана           протяженность

     %return total_finished_plan_cost       - Завершено в полном объеме(план) деньги
     %return total_finished_fact_cost       - Завершено в полном объеме(факт) деньги
     %return deviation_from_total_plan_cost - % отклонения от плана           деньги
  */

  l_period_from_year integer;
  l_period_to_year integer;
begin
  l_period_from_year:=extract(year from p_period_from);
  l_period_to_year  :=extract(year from p_period_to);

   delete from msnow.fdc_rep_repair_dws_overview_agg where session_id=p_session_id;
   delete from msnow.fdc_rep_repair_dws_overview_agg where set_date < current_date -2;

with calend as(select t.cd as current_date
                     ,extract(year from t.cd)::integer as current_year
                     ,extract(year from date_trunc('week',t.cd)::date - 7) as last_week_from_year
                     ,extract(year from date_trunc('month',t.cd)::date - interval '1' month) as last_month_from_year
                     ,to_date('01.01.'||extract(year from t.cd),'dd.mm.yyyy') as current_year_start_date
                     ,date_trunc('week',t.cd)::date - 7 as last_week_from
                     ,date_trunc('week',t.cd)::date -1 as last_week_to
                     ,date_trunc('month',t.cd)::date - interval '1' month as last_month_from
                     ,date_trunc('month',t.cd)::date - interval '1' day as last_month_to
                from (select current_date as cd) t
              )
    ,period_dws as(select dws.id as driveway_segment_id
                     from msnow.fdc_driveway_segment dws
                     join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
                     join calend on true
                    where extract(year from sch.start_date_plan)=calend.current_year
                      and p_period=1
                   union all
                   select dws.id as driveway_segment_id
                     from msnow.fdc_driveway_segment dws
                     join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
                     join calend on true
                    where extract(year from sch.start_date_plan)=calend.last_week_from_year
                      and p_period=2
                   union all
                   select dws.id as driveway_segment_id
                     from msnow.fdc_driveway_segment dws
                     join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
                     join calend on true
                    where extract(year from sch.start_date_plan)=calend.last_month_from_year
                      and p_period=3
                   union all
                   select dws.id as driveway_segment_id
                     from msnow.fdc_driveway_segment dws
                     join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
                    where extract(year from sch.start_date_plan) in(l_period_from_year,l_period_to_year)
                      and p_period=4
                  )
    ,custorg as(select cust.root_id as customer_root_id
                  from nsi.fdc_legal_person cust
                 where cust.id=p_customer_id
               )
    ,perforg as(select perf.root_id as performer_root_id
                  from nsi.fdc_legal_person perf
                 where perf.id=p_performer_id
               )

    ,asph as(select distinct sagre.driveway_segment_id
                   ,sagre.agreement_id
               from msnow.fdc_agreement sagr
               join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
               join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
              where swt.is_asphalt
                and sagre.driveway_segment_id is not null
                and not swt.is_additional_work
            )

    ,levelling as(select distinct sagre.driveway_segment_id
                        ,sagre.agreement_id
                    from msnow.fdc_agreement sagr
                    join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                    join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                   where swt.is_levelling
                     and sagre.driveway_segment_id is not null
                     and not swt.is_additional_work
                 )
    ,rside as(select distinct sagre.driveway_segment_id
                    ,sagre.agreement_id
                from msnow.fdc_agreement sagr
                join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
               where swt.is_roadside
                 and sagre.driveway_segment_id is not null
                 and not swt.is_additional_work
             )

    ,milling as(select distinct sagre.driveway_segment_id
                      ,sagre.agreement_id
                  from msnow.fdc_agreement sagr
                  join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                  join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                 where swt.is_milling
                   and sagre.driveway_segment_id is not null
                   and not swt.is_additional_work
               )
    ,edp_asph as(select distinct ssch.driveway_segment_id
                       ,sdws.agreement_id
                       ,case
                          when asph.driveway_segment_id is not null then true
                          else false
                        end asphalt_work_present
                       ,case
                          when rside.driveway_segment_id is not null then
                            ssch.start_date_plan +
                            case
                              when milling.driveway_segment_id is not null then
                                coalesce(round(ssch.end_date_plan+1-ssch.start_date_plan),0) -
                                case
                                  when asph.driveway_segment_id is not null then
                                    coalesce(round((ssch.end_date_plan+1-ssch.start_date_plan)*50/100.0),0)
                                  else 0
                                end -
                                case
                                  when levelling.driveway_segment_id is not null then
                                    coalesce(round((ssch.end_date_plan+1-ssch.start_date_plan)*20/100.0),0)
                                  else 0
                                end -
                                case
                                  when rside.driveway_segment_id is not null then
                                    coalesce(round((ssch.end_date_plan+1-ssch.start_date_plan)*15/100.0),0)
                                  else 0
                                end
                              else 0
                            end::integer /*e*/ +
                            case
                              when levelling.driveway_segment_id is not null then
                                coalesce(round((ssch.end_date_plan+1-ssch.start_date_plan)*20/100.0),0)
                              else 0
                            end::integer/*f*/ +
                            case
                              when asph.driveway_segment_id is not null then
                                coalesce(round((ssch.end_date_plan+1-ssch.start_date_plan)*50/100.0),0)
                              else 0
                            end::integer/*b*/ - 1
                          else
                            ssch.end_date_plan
                        end as end_date_plan_asph
                   from msnow.fdc_driveway_segment sdws
                   join msnow.fdc_work_schedule ssch on sdws.id=ssch.driveway_segment_id
                   left join asph on sdws.agreement_id=asph.agreement_id
                                     and sdws.id=asph.driveway_segment_id
                   left join levelling on sdws.agreement_id=levelling.agreement_id
                                          and sdws.id=levelling.driveway_segment_id
                   left join rside on sdws.agreement_id=rside.agreement_id
                                      and sdws.id=rside.driveway_segment_id
                   left join milling on sdws.agreement_id=milling.agreement_id
                                        and sdws.id=milling.driveway_segment_id
               )
    ,edf_asph as(select ajrn.driveway_segment_id
                       ,max(ajrn.work_date) as max_work_date
                   from msnow.fdc_asphalt_journal ajrn
                  where ajrn.is_last_work
                  group by ajrn.driveway_segment_id
                )
    ,ks2 as(select ea.driveway_segment_id
                  ,sum(case
                         when p_period=1 and ea.execute_act_date+10 between calend.current_year_start_date and calend.current_date then 1
                         when p_period=2 and ea.execute_act_date+10 between calend.last_week_from and calend.last_week_to then 1
                         when p_period=3 and ea.execute_act_date+10 between calend.last_month_from and calend.last_month_to then 1
                         when p_period=4 and ea.execute_act_date+10 between p_period_from and p_period_to then 1
                         else 0
                       end
                      ) as available_cnt
              from msnow.fdc_execute_act ea
              join msnow.fdc_execute_act_status eas on ea.status_id=eas.id
              join calend on true
             where eas.code='APPROVED'
               and ea.act_file_id is not null
               and ea.driveway_segment_id is not null
             group by ea.driveway_segment_id
           )
    ,pay as(select p.driveway_segment_id
                  ,sum(case
                         when p_period=1 and p.payment_date between calend.current_year_start_date and calend.current_date then 1
                         when p_period=2 and p.payment_date between calend.last_week_from and calend.last_week_to then 1
                         when p_period=3 and p.payment_date between calend.last_month_from and calend.last_month_to then 1
                         when p_period=4 and p.payment_date between p_period_from and p_period_to then 1
                         else 0
                       end
                      ) as available_cnt
              from msnow.fdc_payment p
              join calend on true
             where p.driveway_segment_id is not null
             group by p.driveway_segment_id
           )
 insert into msnow.fdc_rep_repair_dws_overview_agg(session_id
                                                  ,set_date
                                                  ,id
                                                  ,driveway_category
                                                  ,total_driveway_segment_qty
                                                  ---
                                                  ,total_driveway_segment_area
                                                  ,total_driveway_segment_cost
                                                  ---
                                                  ,asphalt_finished_plan_qty
                                                  ,asphalt_finished_fact_qty--F
                                                  ,deviation_from_plan_qty
                                                  ,asphalt_finished_plan_area
                                                  ,asphalt_finished_fact_area
                                                  ,deviation_from_plan_area
                                                  ,asphalt_finished_plan_cost
                                                  ,asphalt_finished_fact_cost
                                                  ,deviation_from_plan_cost
                                                  ,total_finished_plan_qty
                                                  ,total_finished_fact_qty
                                                  ,deviation_from_total_plan_qty
                                                  ,total_finished_plan_area
                                                  ,total_finished_fact_area
                                                  ,deviation_from_total_plan_area
                                                  ,total_finished_plan_cost
                                                  ,total_finished_fact_cost
                                                  ,deviation_from_total_plan_cost

                                                  ,paid_plan_qty
                                                  ,paid_fact_qty
                                                  ,deviation_from_paid_qty

                                                  ,paid_plan_area
                                                  ,paid_fact_area
                                                  ,deviation_from_paid_area

                                                  ,paid_plan_cost
                                                  ,paid_fact_cost
                                                  ,deviation_from_paid_cost
                                                  )
        select p_session_id
              ,current_date
              ,agg.driveway_segment_id
              ,agg.driveway_category
              ,agg.total_driveway_segment_qty
              ,agg.total_driveway_segment_area
              ,agg.total_driveway_segment_cost
              ,agg.asphalt_finished_plan_qty
              ,agg.asphalt_finished_fact_qty
              ,(100.0 - case
                          when agg.asphalt_finished_plan_qty <> 0 then
                            ((agg.asphalt_finished_fact_qty*100.0) / agg.asphalt_finished_plan_qty)
                          else 0
                        end
               )::double precision as deviation_from_plan_qty

              ,agg.asphalt_finished_plan_area
              ,agg.asphalt_finished_fact_area
              ,(100.0 - case
                          when agg.asphalt_finished_plan_area <> 0 then
                            ((agg.asphalt_finished_fact_area*100.0) / agg.asphalt_finished_plan_area)
                          else 0
                        end
               )::double precision as deviation_from_plan_area

              ,agg.asphalt_finished_plan_cost
              ,agg.asphalt_finished_fact_cost
              ,(100.0 - case
                          when agg.asphalt_finished_plan_cost <> 0 then
                            ((agg.asphalt_finished_fact_cost*100.0) / agg.asphalt_finished_plan_cost)
                          else 0
                        end
               )::double precision  as deviation_from_plan_cost
              ------------
              ,agg.total_finished_plan_qty
              ,agg.total_finished_fact_qty
              ,(100.0 - case
                          when agg.total_finished_plan_qty <> 0 then
                            ((agg.total_finished_fact_qty*100.0) / agg.total_finished_plan_qty)
                          else 0
                        end
               )::double precision  as deviation_from_total_plan_qty

              ,agg.total_finished_plan_area
              ,agg.total_finished_fact_area
              ,(100.0 - case
                          when agg.total_finished_plan_area <> 0 then
                            ((agg.total_finished_fact_area*100.0) / agg.total_finished_plan_area)
                          else 0
                        end
               )::double precision  as deviation_from_total_plan_area
              ,agg.total_finished_plan_cost
              ,agg.total_finished_fact_cost
              ,(100.0 - case
                          when agg.total_finished_plan_cost <> 0 then
                            ((agg.total_finished_fact_cost*100.0) / agg.total_finished_plan_cost)
                          else 0
                        end
               )::double precision  as deviation_from_total_plan_cost
               --------
              ,agg.paid_plan_qty
              ,agg.paid_fact_qty
              ,(100.0 - case
                          when agg.paid_plan_qty <> 0 then
                            ((agg.paid_fact_qty*100.0) / agg.paid_plan_qty)
                          else 0
                        end
               )::double precision as deviation_from_paid_qty

              ,agg.paid_plan_area
              ,agg.paid_fact_area
              ,(100.0 - case
                          when agg.paid_plan_area <> 0 then
                            ((agg.paid_fact_area*100.0) / agg.paid_plan_area)
                          else 0
                        end
               )::double precision as deviation_from_paid_area

              ,agg.paid_plan_cost
              ,agg.paid_fact_cost
              ,(100.0 - case
                          when agg.paid_plan_cost <> 0 then
                            ((agg.paid_fact_cost*100.0) / agg.paid_plan_cost)
                          else 0
                        end
               )::double precision as deviation_from_paid_cost
          from(select dws.id as driveway_segment_id
                     ,dwc.name as driveway_category

                     ,dws.id as total_driveway_segment_qty
                     ,dws.asphalt_area / 7000.0 as total_driveway_segment_area
                     ,dws.plan_cost as total_driveway_segment_cost

                     ,case
                        when p_period=1 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.current_year_start_date and calend.current_date then dws.id
                        when p_period=2 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_week_from and calend.last_week_to then dws.id
                        when p_period=3 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_month_from and calend.last_month_to then dws.id
                        when p_period=4 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between p_period_from and p_period_to then dws.id
                      end as asphalt_finished_plan_qty
                     ,case
                        when p_period=1 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.current_year_start_date and calend.current_date then dws.asphalt_area / 7000.0
                        when p_period=2 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_week_from and calend.last_week_to then dws.asphalt_area / 7000.0
                        when p_period=3 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_month_from and calend.last_month_to then dws.asphalt_area / 7000.0
                        when p_period=4 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between p_period_from and p_period_to then dws.asphalt_area / 7000.0
                      end as asphalt_finished_plan_area
                     ,case
                        when p_period=1 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.current_year_start_date and calend.current_date then dws.plan_cost
                        when p_period=2 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_week_from and calend.last_week_to then dws.plan_cost
                        when p_period=3 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_month_from and calend.last_month_to then dws.plan_cost
                        when p_period=4 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between p_period_from and p_period_to then dws.plan_cost
                      end as asphalt_finished_plan_cost
                     ,case
                        when p_fact_flag=2 then
                          case
                            when p_period=1 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.current_year_start_date and calend.current_date
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.current_year_start_date and calend.current_date then dws.id
                            when p_period=2 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_week_from and calend.last_week_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_week_from and calend.last_week_to then dws.id
                            when p_period=3 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_month_from and calend.last_month_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_month_from and calend.last_month_to then dws.id
                            when p_period=4 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between p_period_from and p_period_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between p_period_from and p_period_to then dws.id
                          end
                        else
                          case
                            when p_period=1 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.current_year_start_date and calend.current_date then dws.id
                            when p_period=2 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_week_from and calend.last_week_to then dws.id
                            when p_period=3 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_month_from and calend.last_month_to then dws.id
                            when p_period=4 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between p_period_from and p_period_to then dws.id
                          end
                      end as asphalt_finished_fact_qty--F
                     ,case
                        when p_fact_flag=2 then
                          case
                            when p_period=1 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.current_year_start_date and calend.current_date
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.current_year_start_date and calend.current_date then dws.asphalt_area / 7000.0
                            when p_period=2 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_week_from and calend.last_week_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_week_from and calend.last_week_to then dws.asphalt_area / 7000.0
                            when p_period=3 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_month_from and calend.last_month_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_month_from and calend.last_month_to then dws.asphalt_area / 7000.0
                            when p_period=4 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between p_period_from and p_period_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between p_period_from and p_period_to then dws.asphalt_area / 7000.0
                          end
                        else
                          case
                            when p_period=1 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.current_year_start_date and calend.current_date then dws.asphalt_area / 7000.0
                            when p_period=2 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_week_from and calend.last_week_to then dws.asphalt_area / 7000.0
                            when p_period=3 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_month_from and calend.last_month_to then dws.asphalt_area / 7000.0
                            when p_period=4 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between p_period_from and p_period_to then dws.asphalt_area / 7000.0
                          end
                      end as asphalt_finished_fact_area--F
                     ,case
                        when p_fact_flag=2 then
                          case
                            when p_period=1 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.current_year_start_date and calend.current_date
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.current_year_start_date and calend.current_date then dws.plan_cost
                            when p_period=2 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_week_from and calend.last_week_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_week_from and calend.last_week_to then dws.plan_cost
                            when p_period=3 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between calend.last_month_from and calend.last_month_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_month_from and calend.last_month_to then dws.plan_cost
                            when p_period=4 and edp_asph.asphalt_work_present and coalesce(edp_asph.end_date_plan_asph,sch.end_date_plan) between p_period_from and p_period_to
                                            and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between p_period_from and p_period_to then dws.plan_cost
                          end
                        else
                          case
                            when p_period=1 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.current_year_start_date and calend.current_date then dws.plan_cost
                            when p_period=2 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_week_from and calend.last_week_to then dws.plan_cost
                            when p_period=3 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between calend.last_month_from and calend.last_month_to then dws.plan_cost
                            when p_period=4 and edp_asph.asphalt_work_present and dwss.code in ('ASPHALT_COMPLETED','COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and edf_asph.max_work_date between p_period_from and p_period_to then dws.plan_cost
                          end
                      end as asphalt_finished_fact_cost--F
                     ,case
                        when p_period=1 and sch.end_date_plan between calend.current_year_start_date and calend.current_date then dws.id
                        when p_period=2 and sch.end_date_plan between calend.last_week_from and calend.last_week_to then dws.id
                        when p_period=3 and sch.end_date_plan between calend.last_month_from and calend.last_month_to then dws.id
                        when p_period=4 and sch.end_date_plan between p_period_from and p_period_to then dws.id
                      end as total_finished_plan_qty
                     ,case
                        when p_period=1 and sch.end_date_plan between calend.current_year_start_date and calend.current_date then dws.asphalt_area / 7000.0
                        when p_period=2 and sch.end_date_plan between calend.last_week_from and calend.last_week_to then dws.asphalt_area / 7000.0
                        when p_period=3 and sch.end_date_plan between calend.last_month_from and calend.last_month_to then dws.asphalt_area / 7000.0
                        when p_period=4 and sch.end_date_plan between p_period_from and p_period_to then dws.asphalt_area / 7000.0
                      end as total_finished_plan_area
                     ,case
                        when p_period=1 and sch.end_date_plan between calend.current_year_start_date and calend.current_date then dws.plan_cost
                        when p_period=2 and sch.end_date_plan between calend.last_week_from and calend.last_week_to then dws.plan_cost
                        when p_period=3 and sch.end_date_plan between calend.last_month_from and calend.last_month_to then dws.plan_cost
                        when p_period=4 and sch.end_date_plan between p_period_from and p_period_to then dws.plan_cost
                      end as total_finished_plan_cost
                     ,case
                        when p_fact_flag=2 then
                          case
                            when p_period=1 and sch.end_date_plan between calend.current_year_start_date and calend.current_date
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.current_year_start_date and calend.current_date then dws.id
                            when p_period=2 and sch.end_date_plan between calend.last_week_from and calend.last_week_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_week_from and calend.last_week_to then dws.id
                            when p_period=3 and sch.end_date_plan between calend.last_month_from and calend.last_month_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_month_from and calend.last_month_to then dws.id
                            when p_period=4 and sch.end_date_plan between p_period_from and p_period_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between p_period_from and p_period_to then dws.id
                          end
                        else
                          case
                            when p_period=1 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.current_year_start_date and calend.current_date then dws.id
                            when p_period=2 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_week_from and calend.last_week_to then dws.id
                            when p_period=3 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_month_from and calend.last_month_to then dws.id
                            when p_period=4 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between p_period_from and p_period_to then dws.id
                          end
                      end as total_finished_fact_qty--F
                     ,case
                        when p_fact_flag=2 then
                          case
                            when p_period=1 and sch.end_date_plan between calend.current_year_start_date and calend.current_date
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.current_year_start_date and calend.current_date then dws.asphalt_area / 7000.0
                            when p_period=2 and sch.end_date_plan between calend.last_week_from and calend.last_week_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_week_from and calend.last_week_to then dws.asphalt_area / 7000.0
                            when p_period=3 and sch.end_date_plan between calend.last_month_from and calend.last_month_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_month_from and calend.last_month_to then dws.asphalt_area / 7000.0
                            when p_period=4 and sch.end_date_plan between p_period_from and p_period_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between p_period_from and p_period_to then dws.asphalt_area / 7000.0
                          end
                        else
                          case
                            when p_period=1 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.current_year_start_date and calend.current_date then dws.asphalt_area / 7000.0
                            when p_period=2 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_week_from and calend.last_week_to then dws.asphalt_area / 7000.0
                            when p_period=3 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_month_from and calend.last_month_to then dws.asphalt_area / 7000.0
                            when p_period=4 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between p_period_from and p_period_to then dws.asphalt_area / 7000.0
                          end
                      end as total_finished_fact_area--F
                     ,case
                        when p_fact_flag=2 then
                          case
                            when p_period=1 and sch.end_date_plan between calend.current_year_start_date and calend.current_date
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.current_year_start_date and calend.current_date then dws.plan_cost
                            when p_period=2 and sch.end_date_plan between calend.last_week_from and calend.last_week_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_week_from and calend.last_week_to then dws.plan_cost
                            when p_period=3 and sch.end_date_plan between calend.last_month_from and calend.last_month_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_month_from and calend.last_month_to then dws.plan_cost
                            when p_period=4 and sch.end_date_plan between p_period_from and p_period_to
                                            and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between p_period_from and p_period_to then dws.plan_cost
                          end
                        else
                          case
                            when p_period=1 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.current_year_start_date and calend.current_date then dws.plan_cost
                            when p_period=2 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_week_from and calend.last_week_to then dws.plan_cost
                            when p_period=3 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between calend.last_month_from and calend.last_month_to then dws.plan_cost
                            when p_period=4 and dwss.code in ('COMPLETED','INSPECTION_ACT','WORK_END_NOTIFY','ANALYSIS','ACCEPTED','PAID') and sch.end_date_fact between p_period_from and p_period_to then dws.plan_cost
                          end
                      end as total_finished_fact_cost--F
                      ---
                     ,case
                        when dwss.code in('ACCEPTED','PAID') and coalesce(ks2.available_cnt,0)>0 then dws.id
                      end as paid_plan_qty
                     ,case
                        when dwss.code in('ACCEPTED','PAID') and coalesce(ks2.available_cnt,0)>0 then dws.asphalt_area / 7000.0
                      end as paid_plan_area
                     ,case
                        when dwss.code in('ACCEPTED','PAID') and coalesce(ks2.available_cnt,0)>0 then dws.plan_cost
                      end as paid_plan_cost
                     ,case
                        when p_fact_flag=2 then
                          case
                            when dwss.code in('ACCEPTED','PAID') and coalesce(ks2.available_cnt,0)>0
                                 and coalesce(pay.available_cnt,0)>0 then dws.id
                          end
                        else
                          case
                            when dwss.code in('ACCEPTED','PAID') and coalesce(pay.available_cnt,0)>0 then dws.id
                          end
                      end as paid_fact_qty
                     ,case
                        when p_fact_flag=2 then
                          case
                            when dwss.code in('ACCEPTED','PAID') and coalesce(ks2.available_cnt,0)>0
                                 and coalesce(pay.available_cnt,0)>0 then dws.asphalt_area / 7000.0
                          end
                        else
                          case
                            when dwss.code in('ACCEPTED','PAID') and coalesce(pay.available_cnt,0)>0 then dws.asphalt_area / 7000.0
                          end
                      end as paid_fact_area
                     ,case
                        when p_fact_flag=2 then
                          case
                            when dwss.code in('ACCEPTED','PAID') and coalesce(ks2.available_cnt,0)>0
                                 and coalesce(pay.available_cnt,0)>0 then dws.plan_cost
                          end
                        else
                          case
                            when dwss.code in('ACCEPTED','PAID') and coalesce(pay.available_cnt,0)>0 then dws.plan_cost
                          end
                      end as paid_fact_cost
                 from msnow.fdc_driveway_segment dws
                 join msnow.fdc_segment rem on dws.id=rem.id
                 join period_dws pdws on dws.id=pdws.driveway_segment_id
                 --join ods.fdc_odh odh on dws.driveway_id=odh.id
                 join ods.fdc_driveway odw on dws.driveway_id=odw.id
                 join ods.fdc_object odwobj on odw.id=odwobj.id
                 join msnow.fdc_driveway_category dwc on /*odh*/odwobj.driveway_category_id=dwc.id
                 join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
                 join msnow.fdc_dw_segment_status dwss on dws.status_id=dwss.id
                 join calend on true

                 left join msnow.fdc_agreement agr on dws.agreement_id=agr.id
                 left join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
                 left join custorg on agr.customer_id=custorg.customer_root_id
                 left join perforg on agr.performer_id=perforg.performer_root_id
                 left join edp_asph on dws.id=edp_asph.driveway_segment_id
                                       and dws.agreement_id=edp_asph.agreement_id
                 left join edf_asph on dws.id=edf_asph.driveway_segment_id
                 left join ks2 on sch.driveway_segment_id = ks2.driveway_segment_id
                 left join pay on dws.id=pay.driveway_segment_id
                where sch.start_date_plan is not null
                  and sch.end_date_plan is not null
                  and dwss.code not in('FUTURE_PLANNED','ON_VOTE','ESTIMATED_RESULT')
                  and (p_driveway_category_id is null or /*odh*/odwobj.driveway_category_id=p_driveway_category_id)
                  and (p_driveway_segment_id is null or dws.id=p_driveway_segment_id)
                  and (p_driveway_segment_name is null or lower(dws.name) like '%'||lower(p_driveway_segment_name)||'%')
                  and (p_agreement_group_id is null or agrt.agreement_group_id=p_agreement_group_id)
                  and (p_customer_id is null or custorg.customer_root_id is not null)
                  and (p_performer_id is null or perforg.performer_root_id is not null)
              ) agg;

  return;
end
$$;

