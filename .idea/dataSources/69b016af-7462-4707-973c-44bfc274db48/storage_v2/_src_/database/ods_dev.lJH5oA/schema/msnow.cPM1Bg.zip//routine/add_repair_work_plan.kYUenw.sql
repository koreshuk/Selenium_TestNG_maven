CREATE FUNCTION add_repair_work_plan(p_driveway_segment_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Расчет плана работ по ремонту
  %param p_driveway_segment_id - Ид участка ремонта
  */
  rec record;
begin
  for rec in(with last_agr as(select distinct on(lagr.agr_root_id)
                                     lagr.agr_root_id
                                    ,lagr.id as agreement_id
                                 from msnow.fdc_agreement lagr
                                order by lagr.agr_root_id
                                        ,lagr.version_date_from desc
                                        ,lagr.version_date_to desc
                             )
                 ,work_stage as(select distinct wsch.id as work_schedule_id
                                      ,rws.id as repair_work_stage_id
                                      ,rws.code as repair_work_stage_code
                                      ,wsch.end_date_plan
                                      ,wsch.start_date_plan
                                  from msnow.fdc_driveway_segment dws
                                  join msnow.fdc_work_schedule wsch on dws.id=wsch.driveway_segment_id
                                  join msnow.fdc_agreement agr on dws.agreement_id=agr.id
                                  join last_agr on agr.agr_root_id=last_agr.agr_root_id
                                  join msnow.fdc_agreement lagr on last_agr.agreement_id=lagr.id
                                  join msnow.fdc_agr_estimate lagre on lagr.id=lagre.agreement_id
                                                                       and dws.id=lagre.driveway_segment_id
                                  join msnow.fdc_work_type wt on lagre.work_type_id=wt.id
                                  join msnow.fdc_repair_work_stage rws on wt.repair_work_stage_id=rws.id
                                 where dws.id=p_driveway_segment_id
                                   and wt.repair_work_stage_id is not null
                                   and wsch.start_date_plan is not null
                                   and wsch.end_date_plan is not null
                               )
                 ,b as(select max(coalesce(round((end_date_plan+1-start_date_plan)*50/100.0),0))::integer as b
                         from work_stage
                        where repair_work_stage_code in ('IS_ASPHALT','IS_TRANSIT')
                      )
                 ,f as (select max(coalesce(round((end_date_plan+1-start_date_plan)*20/100.0),0))::integer as f
                          from work_stage
                         where repair_work_stage_code='IS_LEVELLING'
                       )
                 ,a as(select max(coalesce(round((end_date_plan+1-start_date_plan)*15/100.0),0))::integer as a
                             ,1 as roadside_flag
                         from work_stage
                        where repair_work_stage_code='IS_ROADSIDE'
                      )
                 ,e as (select max(coalesce(round(end_date_plan+1-start_date_plan),0) -
                                            coalesce(a.a,0) -
                                            coalesce(f.f,0) -
                                            coalesce(b.b,0)
                                  )::integer as e
                          from work_stage
                          left join a on true
                          left join b on true
                          left join f on true
                         where repair_work_stage_code='IS_MILLING'
                       )

               select stg.work_schedule_id
                     ,stg.repair_work_stage_id
                     ,case
                        when stg.repair_work_stage_code='IS_LEVELLING' then
                          least(stg.start_date_plan + coalesce(e.e,0),stg.end_date_plan)
                        when stg.repair_work_stage_code in ('IS_ASPHALT','IS_TRANSIT') then
                          least(stg.start_date_plan+coalesce(e.e,0)+coalesce(f.f,0),stg.end_date_plan)
                        when stg.repair_work_stage_code='IS_ROADSIDE' then
                          least(stg.start_date_plan+coalesce(e.e,0)+coalesce(f.f,0)+coalesce(b.b,0),stg.end_date_plan)
                        when stg.repair_work_stage_code in('IS_MILLING','IS_ADDITIONAL_WORK','IS_BINDING') then
                          stg.start_date_plan
                      end as start_date_plan
                     ,case
                        when stg.repair_work_stage_code='IS_MILLING' then
                          greatest(stg.start_date_plan + coalesce(e.e,0) -1,stg.start_date_plan)
                        when stg.repair_work_stage_code='IS_LEVELLING' then
                          least(greatest(stg.start_date_plan+coalesce(e.e,0)+coalesce(f.f,0)-1,stg.start_date_plan),stg.end_date_plan)
                        when stg.repair_work_stage_code in ('IS_ASPHALT','IS_TRANSIT') then
                          case
                            when coalesce(a.roadside_flag,0)=0 then
                              stg.end_date_plan
                            else
                              stg.start_date_plan+coalesce(e.e,0)+coalesce(f.f,0)+coalesce(b.b,0)-1
                          end
                        when repair_work_stage_code in ('IS_ROADSIDE','IS_ADDITIONAL_WORK','IS_BINDING') then
                          stg.end_date_plan
                      end as end_date_plan
                 from work_stage stg
                 left join e on true
                 left join b on true
                 left join f on true
                 left join a on true
            ) loop

    insert into msnow.fdc_repair_work_plan(id
                                          ,work_schedule_id
                                          ,repair_work_stage_id
                                          ,start_date_plan
                                          ,end_date_plan
                                          ) values
        (nextval('ods.fdc_common_seq')
        ,rec.work_schedule_id
        ,rec.repair_work_stage_id
        ,rec.start_date_plan
        ,rec.end_date_plan
        )
      on conflict(work_schedule_id,repair_work_stage_id) do update
        set start_date_plan = excluded.start_date_plan
           ,end_date_plan   = excluded.end_date_plan;
  end loop;
end;
$$;

