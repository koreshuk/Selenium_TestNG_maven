CREATE VIEW fdc_person_v AS
  SELECT l.id,
    l.root_id,
    l.person_type_id,
    p.code,
    l.name,
    l.short_name,
    l.inn,
    l.kpp,
    l.ogrn,
    l.okpo,
    l.account,
    l.postal_address,
    l.legal_address,
    l.email,
    l.phone,
    l.fax,
    l.off_post,
    l.off_name,
    COALESCE(b.bik, l.bik) AS bik,
    COALESCE(b.name, l.bank) AS bank,
    COALESCE(b.corr_account, l.corr_account) AS corr_account,
    l.person_code,
    l.person_code_name,
    l.occupation_id,
    l.okved,
    l.reg_date,
    l.gender,
    l.patronymic,
    l.snils,
    l.birth_date,
    l.birth_place,
    l.birth_country_id,
    l.identity_doctype_id,
    l.docseries,
    l.docnumber,
    l.issue_date,
    l.issue_dept AS issue_department,
    l.issue_dept_code AS department_code,
    l.work_length,
    l.parent_id,
    l.parent_root_id,
    l.bank_id AS cbr_bank_id,
    l.is_small_medium,
    l.sro_flag,
    l.sro_org_id,
    l.sro_regnum,
    l.is_local_version,
    p.asur_sync_date,
    p.asur_sync_status,
    p.fns_sync_date,
    p.fns_validate,
    p.suppress_asur_sync,
    p.last_changed,
    p.username,
    p.person_state,
    l.ver_start_date,
    l.ver_end_date,
    l.closing_date,
    l.okonh_id,
    l.okopf_id,
    l.okved_id,
    l.okfs_id,
    l.crc,
    l.bind_person_id
   FROM ((nsi.fdc_person p
     JOIN nsi.fdc_legal_person l ON ((l.root_id = p.id)))
     LEFT JOIN nsi.fdc_bank b ON ((b.id = l.bank_id)));

COMMENT ON VIEW fdc_person_v IS 'Классификатор субъектов (включая фиктивные организации)';

COMMENT ON COLUMN fdc_person_v.id IS 'ИД субъекта';

COMMENT ON COLUMN fdc_person_v.root_id IS 'ИД организации';

COMMENT ON COLUMN fdc_person_v.person_type_id IS 'Ид типа субъекта права';

COMMENT ON COLUMN fdc_person_v.code IS 'Код в АС Управления Реестрами';

COMMENT ON COLUMN fdc_person_v.name IS 'Полное наименование/Фамилия';

COMMENT ON COLUMN fdc_person_v.short_name IS 'Краткое наименование/Имя';

COMMENT ON COLUMN fdc_person_v.inn IS 'Идентификационный номер налогоплательщика';

COMMENT ON COLUMN fdc_person_v.kpp IS 'Код причины постановки на учёт';

COMMENT ON COLUMN fdc_person_v.ogrn IS 'Основной государственный регистрационный номер';

COMMENT ON COLUMN fdc_person_v.okpo IS 'Общероссийский классификатор предприятий и организаций';

COMMENT ON COLUMN fdc_person_v.account IS 'Расчётный счёт (текущий счёт)';

COMMENT ON COLUMN fdc_person_v.postal_address IS 'Почтовый адрес/Адрес';

COMMENT ON COLUMN fdc_person_v.legal_address IS 'Юридический адрес';

COMMENT ON COLUMN fdc_person_v.email IS 'Электронная почта';

COMMENT ON COLUMN fdc_person_v.phone IS 'Телефон организации или ответственного лица';

COMMENT ON COLUMN fdc_person_v.fax IS 'Факс организации';

COMMENT ON COLUMN fdc_person_v.off_post IS 'Должность руководителя';

COMMENT ON COLUMN fdc_person_v.off_name IS 'ФИО руководителя';

COMMENT ON COLUMN fdc_person_v.bik IS 'БИК';

COMMENT ON COLUMN fdc_person_v.bank IS 'Банк';

COMMENT ON COLUMN fdc_person_v.corr_account IS 'Корреспондентский счет';

COMMENT ON COLUMN fdc_person_v.person_code IS 'Код подразделения/Табельный номер';

COMMENT ON COLUMN fdc_person_v.person_code_name IS 'Вид подразделения';

COMMENT ON COLUMN fdc_person_v.occupation_id IS 'Ид должности';

COMMENT ON COLUMN fdc_person_v.okved IS 'Общероссийский классификатор видов экономической деятельности';

COMMENT ON COLUMN fdc_person_v.reg_date IS 'Дата регистрации';

COMMENT ON COLUMN fdc_person_v.gender IS 'Пол (0 - Ж, 1 - М)';

COMMENT ON COLUMN fdc_person_v.patronymic IS 'Отчество';

COMMENT ON COLUMN fdc_person_v.snils IS 'Страховой номер индивидуального лицевого счета';

COMMENT ON COLUMN fdc_person_v.birth_date IS 'Дата рождения (для физ. лиц)';

COMMENT ON COLUMN fdc_person_v.birth_place IS 'Место рождения';

COMMENT ON COLUMN fdc_person_v.birth_country_id IS 'Ид страны рождения (пока заглушка до создания справочника)';

COMMENT ON COLUMN fdc_person_v.identity_doctype_id IS 'Ид типа документа';

COMMENT ON COLUMN fdc_person_v.docseries IS 'Серия документа';

COMMENT ON COLUMN fdc_person_v.docnumber IS 'Номер документа';

COMMENT ON COLUMN fdc_person_v.issue_date IS 'Дата выдачи';

COMMENT ON COLUMN fdc_person_v.issue_department IS 'Кем выдан документ';

COMMENT ON COLUMN fdc_person_v.department_code IS 'Код подразделения';

COMMENT ON COLUMN fdc_person_v.work_length IS 'Стаж работы';

COMMENT ON COLUMN fdc_person_v.parent_id IS 'Ид головной организации';

COMMENT ON COLUMN fdc_person_v.cbr_bank_id IS 'Ид банк';

COMMENT ON COLUMN fdc_person_v.is_small_medium IS 'Признак малого или среднего бизнеса';

COMMENT ON COLUMN fdc_person_v.sro_flag IS 'Признак СРО';

COMMENT ON COLUMN fdc_person_v.sro_org_id IS 'Ид СРО';

COMMENT ON COLUMN fdc_person_v.sro_regnum IS 'Оегистрационный номер СРО';

COMMENT ON COLUMN fdc_person_v.asur_sync_date IS 'Дата последней успешной синхронизации с АСУР';

COMMENT ON COLUMN fdc_person_v.asur_sync_status IS 'Статус синхронизации с АСУР (0-запрос не отправлялся, 1- ожидает ответа, 2- данные актуальны, 3 - не удалось синхронизировать)';

COMMENT ON COLUMN fdc_person_v.fns_sync_date IS 'Дата синхронизации с ФНС';

COMMENT ON COLUMN fdc_person_v.fns_validate IS 'Признак того, обновлены сведения о ЮЛ данными из ФНС';

COMMENT ON COLUMN fdc_person_v.suppress_asur_sync IS 'Запретить синхронизацию с АСУР (0 - не запрещать, 1 - запретить)';

COMMENT ON COLUMN fdc_person_v.last_changed IS 'Дата последних изменении';

COMMENT ON COLUMN fdc_person_v.username IS 'Пользователь внесший изменение';

COMMENT ON COLUMN fdc_person_v.person_state IS 'Состояние субъекта 1 - Отсутствует в НСИ 2 - Не проверена 3 - Данные устарели 4 - Данные актуальны';

COMMENT ON COLUMN fdc_person_v.ver_start_date IS 'Дата начала действия версии (min = дата появления орг. в системе (ред. пользов.))';

COMMENT ON COLUMN fdc_person_v.ver_end_date IS 'Дата окончания действия версии (NULL - вресия актуальна)';

COMMENT ON COLUMN fdc_person_v.closing_date IS 'Дата закрытия организации';

COMMENT ON COLUMN fdc_person_v.okonh_id IS 'Ид ОКОНХ';

COMMENT ON COLUMN fdc_person_v.okopf_id IS 'Ид ОКОПФ';

COMMENT ON COLUMN fdc_person_v.okved_id IS 'Ид ОКВЕД';

COMMENT ON COLUMN fdc_person_v.okfs_id IS 'Ид ОКФС';

COMMENT ON COLUMN fdc_person_v.crc IS 'Контрольная сумма';

COMMENT ON COLUMN fdc_person_v.bind_person_id IS 'ИД связанного субъекта';

