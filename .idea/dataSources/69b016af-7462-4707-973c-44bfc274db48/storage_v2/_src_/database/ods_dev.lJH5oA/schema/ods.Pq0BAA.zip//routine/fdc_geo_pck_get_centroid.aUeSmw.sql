CREATE FUNCTION fdc_geo_pck_get_centroid(p_geometry geometry)
  RETURNS geometry
LANGUAGE plpgsql
AS $$
declare
  /* Вычисляет геометрический центр объекта p_geometry
  */
begin
  return st_centroid(p_geometry);
end
$$;

