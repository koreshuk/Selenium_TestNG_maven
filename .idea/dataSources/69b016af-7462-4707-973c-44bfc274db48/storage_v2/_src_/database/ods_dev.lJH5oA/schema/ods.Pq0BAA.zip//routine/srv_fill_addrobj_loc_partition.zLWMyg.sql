CREATE FUNCTION srv_fill_addrobj_loc_partition(p_region_code character varying, p_partition_schema character varying, p_partition_name character varying)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Заполняет новосозданную или новоприсоединенную секцию (по region_code)
     таблицы ods.fdc_as_addrobj_loc. Все добавленные строки помечаются как измененные в ods.srv_address_reference_changes
     Вызывается из функции ods.srv_handle_addrobj_loc_partitions
  */
begin
  execute
    format('delete from %I.%I'
          ,p_partition_schema
          ,p_partition_name
          );

  execute
    format('insert into %I.%I(ID
                             ,AO_ID
                             ,AO_GUID
                             ,FORMAL_NAME
                             ,REGION_CODE
                             ,AUTO_CODE
                             ,AREA_CODE
                             ,CITY_CODE
                             ,CTAR_CODE
                             ,PLACE_CODE
                             ,STREET_CODE
                             ,EXTR_CODE
                             ,SEXT_CODE
                             ,OFF_NAME
                             ,POSTAL_CODE
                             ,IFNS_FL
                             ,TERR_IFNS_FL
                             ,IFNS_UL
                             ,TERR_IFNS_UL
                             ,OKATO
                             ,OKTMO
                             ,UPDATE_DATE
                             ,SHORT_NAME
                             ,AO_LEVEL
                             ,PARENT_GUID
                             ,PREV_ID
                             ,NEXT_ID
                             ,CODE
                             ,PLAIN_CODE
                             ,ACT_STATUS
                             ,CENT_STATUS
                             ,OPER_STATUS
                             ,CURR_STATUS
                             ,START_DATE
                             ,END_DATE
                             ,NORM_DOC
                             ,LIVE_STATUS
                             )
              select ID
                    ,AO_ID
                    ,AO_GUID
                    ,FORMAL_NAME
                    ,REGION_CODE
                    ,AUTO_CODE
                    ,AREA_CODE
                    ,CITY_CODE
                    ,CTAR_CODE
                    ,PLACE_CODE
                    ,STREET_CODE
                    ,EXTR_CODE
                    ,SEXT_CODE
                    ,OFF_NAME
                    ,POSTAL_CODE
                    ,IFNS_FL
                    ,TERR_IFNS_FL
                    ,IFNS_UL
                    ,TERR_IFNS_UL
                    ,OKATO
                    ,OKTMO
                    ,UPDATE_DATE
                    ,SHORT_NAME
                    ,AO_LEVEL
                    ,PARENT_GUID
                    ,PREV_ID
                    ,NEXT_ID
                    ,CODE
                    ,PLAIN_CODE
                    ,ACT_STATUS
                    ,CENT_STATUS
                    ,OPER_STATUS
                    ,CURR_STATUS
                    ,START_DATE
                    ,END_DATE
                    ,NORM_DOC
                    ,LIVE_STATUS
                from ods.fdc_as_addrobj
               where region_code=$1'
            ,p_partition_schema
            ,p_partition_name
          )
    using p_region_code::integer;

    update ods.fdc_as_addrobj
       set SEXT_CODE = SEXT_CODE
     where region_code=p_region_code::integer;
  return;
end;
$$;

