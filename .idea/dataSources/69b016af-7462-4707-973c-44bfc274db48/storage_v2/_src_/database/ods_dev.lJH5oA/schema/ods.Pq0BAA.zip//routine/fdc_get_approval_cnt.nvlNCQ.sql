CREATE FUNCTION fdc_get_approval_cnt(p_official_id bigint, OUT approval_cnt integer, OUT approved_object_cnt integer, OUT rejected_object_cnt integer, OUT onapproval_object_cnt integer, OUT approval_tl_cnt integer, OUT approved_tl_cnt integer, OUT rejected_tl_cnt integer, OUT onapproval_tl_cnt integer, OUT approval_obl_cnt integer, OUT approved_obl_cnt integer, OUT rejected_obl_cnt integer, OUT onapproval_obl_cnt integer, OUT approval_agr_cnt integer, OUT approved_agr_cnt integer, OUT rejected_agr_cnt integer, OUT onapproval_agr_cnt integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает количество объектов ОДХ/ТС/Бюджетов для блока Обратите внимание

    %param p_official_id          -- Ид текущего пользователя

    %return approval_cnt          -- Согласовать паспорта: <Количество паспортов ОДХ>
    %return approved_object_cnt   -- Согласовано за последние 3 дня: <Количество паспортов ОДХ>
    %return rejected_object_cnt   -- Отклонено: <Количество паспортов ОДХ>
    %return onapproval_object_cnt -- На согласовании: <Количество паспортов ОДХ>

    %return approval_tl_cnt       -- Согласовать ТС: <Количество ТС>
    %return approved_tl_cnt       -- Согласовано за последние 3 дня: <Количество ТС>
    %return rejected_tl_cnt       -- Отклонено: <Количество ТС>
    %return onapproval_tl_cnt     -- На согласовании: <Количество ТС>

    %return approval_obl_cnt      -- Согласовать паспорта: <Количество Бюджетов>
    %return approved_obl_cnt      -- Согласовано за последние 3 дня: <Количество Бюджетов>
    %return rejected_obl_cnt      -- Отклонено: <Количество Бюджетов>
    %return onapproval_obl_cnt    -- На согласовании: <Количество Бюджетов>

    %return approval_agr_cnt      -- Согласовать контракты: <Количество контрактов>
    %return approved_agr_cnt      -- Согласовано за последние 3 дня: <Количество контрактов>
    %return rejected_agr_cnt      -- Отклонено: <Количество контрактов>
    %return onapproval_agr_cnt    -- На согласовании: <Количество контрактов>
  */
begin
  select t.approval_cnt
        ,t.approved_object_cnt
        ,t.rejected_object_cnt
        ,t.onapproval_object_cnt
    into approval_cnt
        ,approved_object_cnt
        ,rejected_object_cnt
        ,onapproval_object_cnt
    from ods.fdc_get_approval_odh_cnt(p_official_id => p_official_id) t;

  select t.approval_cnt
        ,t.approved_tl_cnt
        ,t.rejected_tl_cnt
        ,t.onapproval_tl_cnt
    into approval_tl_cnt
        ,approved_tl_cnt
        ,rejected_tl_cnt
        ,onapproval_tl_cnt
    from ods.fdc_get_approval_tl_cnt(p_official_id => p_official_id) t;

  select t.approval_cnt
        ,t.approved_obl_cnt
        ,t.rejected_obl_cnt
        ,t.onapproval_obl_cnt
    into approval_obl_cnt
        ,approved_obl_cnt
        ,rejected_obl_cnt
        ,onapproval_obl_cnt
    from ods.fdc_get_approval_obl_cnt(p_official_id => p_official_id) t;

  select t.approval_cnt
        ,t.approved_agr_cnt
        ,t.rejected_agr_cnt
        ,t.onapproval_agr_cnt
    into approval_agr_cnt
        ,approved_agr_cnt
        ,rejected_agr_cnt
        ,onapproval_agr_cnt
    from ods.fdc_get_approval_agr_cnt(p_official_id => p_official_id) t;

 return;
end
$$;

