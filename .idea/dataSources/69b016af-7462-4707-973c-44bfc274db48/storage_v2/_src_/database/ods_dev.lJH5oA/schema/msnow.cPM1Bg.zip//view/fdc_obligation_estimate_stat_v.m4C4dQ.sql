CREATE VIEW fdc_obligation_estimate_stat_v AS
  SELECT oble.id,
    obl.obligation_year,
    orgt.id AS organization_type_id,
    orgt.code AS organization_type_code,
        CASE
            WHEN (wt.organization_id IS NULL) THEN wt.id
            ELSE wt.work_type_uni_id
        END AS work_type_id,
        CASE
            WHEN (wt.organization_id IS NULL) THEN wt.name
            ELSE ( SELECT awt.name
               FROM msnow.fdc_work_type awt
              WHERE (awt.id = wt.work_type_uni_id))
        END AS work_type_name,
        CASE
            WHEN (wt.organization_id IS NULL) THEN wt.measure_unit_id
            ELSE ( SELECT awt.measure_unit_id
               FROM msnow.fdc_work_type awt
              WHERE (awt.id = wt.work_type_uni_id))
        END AS measure_unit_id,
        CASE
            WHEN (wt.organization_id IS NULL) THEN msr.name
            ELSE ( SELECT amsr.name
               FROM msnow.fdc_work_type awt,
                msnow.fdc_measure_unit amsr
              WHERE ((awt.id = wt.work_type_uni_id) AND (awt.measure_unit_id = amsr.id)))
        END AS measure_unit_name,
    COALESCE(dw.reduced_distance, (0.0)::double precision) AS reduced_distance,
    COALESCE(oble.work_volume, (0.0)::double precision) AS work_volume,
    COALESCE(oble.work_cost, (0.0)::double precision) AS work_cost
   FROM ((((((msnow.fdc_obligation obl
     JOIN msnow.fdc_obligation_estimate oble ON ((oble.obligation_id = obl.id)))
     JOIN msnow.fdc_ods_organization org ON ((org.id = obl.authority_org_id)))
     JOIN msnow.fdc_org_type orgt ON ((orgt.id = org.org_type_id)))
     JOIN msnow.fdc_driveway dw ON ((dw.id = oble.driveway_id)))
     JOIN msnow.fdc_work_type wt ON ((wt.id = oble.work_type_id)))
     JOIN msnow.fdc_measure_unit msr ON ((msr.id = wt.measure_unit_id)))
  WHERE (oble.driveway_id IS NOT NULL);

COMMENT ON VIEW fdc_obligation_estimate_stat_v IS 'Данные для отчета Сведения о запланированных бюджетных средствах';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.id IS 'Ид сметы бюджетного обязательства';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.obligation_year IS 'Год бюджетного планирования';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.organization_type_id IS 'Ид типа организации';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.organization_type_code IS 'Код типа организации';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.work_type_id IS 'Ид вида работ';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.work_type_name IS 'Наименование типа работ';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.measure_unit_id IS 'Ид единицы изменрения';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.measure_unit_name IS 'Наименование единицы измерения';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.reduced_distance IS 'Протяженность дорог';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.work_volume IS 'Объем работ';

COMMENT ON COLUMN fdc_obligation_estimate_stat_v.work_cost IS 'Бюджетные средства';

