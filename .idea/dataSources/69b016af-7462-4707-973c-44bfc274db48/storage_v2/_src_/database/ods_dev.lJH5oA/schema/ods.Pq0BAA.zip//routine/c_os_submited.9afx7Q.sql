CREATE FUNCTION c_os_submited()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 2::bigint;
$$;

