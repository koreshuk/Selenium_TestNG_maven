CREATE FUNCTION fdc_odh_pck_create_project(p_object_id bigint, p_project_date date)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция создания проекта
  %param    p_object_id         Ид утвержденной версии, на основе которой создается проект
  %param   p_project_date       Дата, с которой создается проект
  %return                       Ид созданного проекта
  */
  l_object_id ods.fdc_object.id%type;
  l_odh_row ods.fdc_odh;
  --l_attribute t_barrier;
begin
  l_object_id := ods.fdc_object_pck_create_project(p_object_id    => p_object_id
                                                  ,p_project_date => p_project_date
                                                  );

  select r.*
    into l_odh_row
    from ods.fdc_odh r
   where r.id = p_object_id;

  perform ods.fdc_odh_pck_update_obj_attribute_list(p_object_id      => l_object_id
                                                   ,p_attribute_tab  => l_odh_row
                                                   ,p_prev_object_id => p_object_id
                                                   );
  return l_object_id;
end
$$;

