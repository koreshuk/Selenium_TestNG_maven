CREATE FUNCTION fdc_ods_pck_get_tc_date(p_object_id bigint, p_project_date timestamp without time zone)
  RETURNS timestamp without time zone
LANGUAGE plpgsql
AS $$
declare
  /** Функция для получения даты ТС куда входит объект или его верхнеуровневый объект по дереву
      *** !!!! * ЗАГЛУШКА для ods.fdc_ods_pck.get_tc_date() * !!!! ***
  */
  l_date_from_tc timestamp;
begin
  select to_date('01.01.1900','dd.mm.yyyy')::timestamp into strict l_date_from_tc;
  return l_date_from_tc;
end
$$;

