CREATE VIEW fdc_clean_category_v AS
  SELECT t1.code,
    t1.date_from,
    t1.date_to,
    t1.history_id,
    t2.code AS history_code,
    t2.name AS history_name,
    t1.id,
    t1.name,
    t1.parent_id,
    t3.code AS parent_code,
    t3.name AS parent_name
   FROM ((fdc_clean_category t1
     LEFT JOIN fdc_clean_category t2 ON ((t2.id = t1.history_id)))
     LEFT JOIN fdc_clean_category t3 ON ((t3.id = t1.parent_id)));

COMMENT ON VIEW fdc_clean_category_v IS 'Справочник Категория объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.code IS 'Код категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_clean_category_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_clean_category_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_clean_category_v.history_code IS 'Код категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.history_name IS 'Наименование категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.id IS 'Ид категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.name IS 'Наименование категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.parent_id IS 'Ид категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.parent_code IS 'Код категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_v.parent_name IS 'Наименование категории объекта по уборке';

