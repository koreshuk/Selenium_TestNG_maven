CREATE FUNCTION rep_lsr_form_omsu_summary(p_summary_type integer, p_year integer, p_driveway_category_id bigint, p_title_type_id bigint DEFAULT NULL::bigint, OUT customer_root_id bigint, OUT customer_short_name character varying, OUT approved_driveway_qty bigint, OUT title_list_qty bigint, OUT title_driveway_qty bigint, OUT missing_title_qty bigint, OUT missing_driveway_qty bigint, OUT missing_orph_driveway_qty bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт "Сводка по согласованию Локальных сметных расчетов на <текущая дата>" в разрезе ОМСУ

  %param p_summary_type          - Тип сметы
                                   1 - бюджет
                                   2 - контракт/задание
  %param p_year                  - Год
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_title_id              - Тип списка

  %return customer_root_id            - ROOT_ID ОМСУ
  %return customer_short_name         - ОМСУ
  %return approved_driveway_qty       - Всего дорог
  %return title_list_qty              - Всего ТС
  %return title_driveway_qty          - Всего дорог в ТС
  %return missing_title_qty           - ТС, по которым отсутствует ЛСР
  %return missing_driveway_qty        - Дороги без ЛСР. Всего
  %return missing_orph_driveway_qty   - Дороги из ТС, по которым отсутствуют ЛСР

  */
  l_year_start_date date;

  C_TYPE_OBLIGATION constant integer:=1;
  C_TYPE_AGREEMENT constant integer:=2;
begin
  l_year_start_date=to_date('01.01.'||p_year::varchar,'dd.mm.yyyy');

  if p_summary_type = C_TYPE_OBLIGATION then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_year_start_date between lp.ver_start_date and lp.ver_end_date
                      and l_year_start_date  between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )

          ,rcust as(select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                   )

          ,total_drw as(select rcust.omsu_root_id
                              ,count(distinct obj.root_id) as approved_driveway_id
                          from ods.fdc_object obj
                          join ods.fdc_odh odh on obj.id=odh.id
                          join ods.fdc_object_state objs on obj.object_state_id=objs.id
                          join rcust on obj.customer_id=rcust.customer_id
                         where objs.code='APPROVED'
                           and p_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                         group by rcust.omsu_root_id
                       )

          ,total_tl as(select rcust.omsu_root_id
                             ,count(distinct tl.id) as title_id
                             ,count(distinct obj.root_id) as driveway_root_id
                         from ods.fdc_title tl
                         join ods.fdc_title_status tls on tl.title_status_id=tls.id
                         join msnow.fdc_work_category wc on tl.work_category_id=wc.id
                         join rcust on tl.customer_id=rcust.customer_id
                         join ods.fdc_title_odh todh on tl.id=todh.title_id
                         join ods.fdc_odh odh on todh.odh_id=odh.id
                         join ods.fdc_object obj on odh.id=obj.id
                        where tls.code='APPROVED'
                          and wc.code='MAINTAIN'
                          and (p_title_type_id is null or tl.title_type_id=p_title_type_id)
                          and p_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                         group by rcust.omsu_root_id
                      )
          ,est_lvl_1 as(select distinct obje.root_id
                          from msnow.fdc_obligation_estimate oe
                          join msnow.fdc_obligation o on oe.obligation_id=o.id
                          join msnow.fdc_agreement_obligation_status ost on o.obligation_status_id=ost.id
                          join msnow.fdc_work_category wc on o.work_category_id=wc.id
                          join ods.fdc_odh odhe on oe.driveway_id=odhe.id
                          join ods.fdc_object obje on odhe.id=obje.id
                         where ost.code='APPROVED'
                           and wc.code='MAINTAIN'
                           and o.obligation_year=p_year::varchar
                     )
          ,est_lvl_2 as(select distinct oe.odh_group_id
                          from msnow.fdc_obligation_estimate oe
                          join msnow.fdc_obligation o on oe.obligation_id=o.id
                          join msnow.fdc_agreement_obligation_status ost on o.obligation_status_id=ost.id
                          join msnow.fdc_work_category wc on o.work_category_id=wc.id
                         where ost.code='APPROVED'
                           and wc.code='MAINTAIN'
                           and o.obligation_year=p_year::varchar
                       )
          ,missed_drw as(select n.omsu_root_id
                               ,count(distinct case
                                                 when n.missing_flag then n.driveway_root_id
                                               end
                                     ) as missing_driveway_qty
                           from(select rcust.omsu_root_id
                                      ,obj.root_id as driveway_root_id
                                      ,case
                                         when l1.root_id is null then
                                           case
                                             when l2.odh_group_id is null then true
                                             else false
                                           end
                                         else false
                                       end as missing_flag
                                  from ods.fdc_object obj
                                  join ods.fdc_odh odh on obj.id=odh.id
                                  join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                  join rcust on obj.customer_id=rcust.customer_id
                                  left join est_lvl_1 l1 on obj.root_id=l1.root_id
                                  left join est_lvl_2 l2 on odh.object_group_id=l2.odh_group_id
                                 where objs.code='APPROVED'
                                   and p_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                               ) n
                          group by n.omsu_root_id
                        )
          ,missed_tl as(select m.omsu_root_id
                           ,count(distinct case
                                             when m.missing_flag then m.title_id
                                           end
                                 ) as missing_title_qty
                          -- ,count(distinct case
                          --                   when m.missing_flag then m.driveway_root_id
                          --                 end
                          --       ) as missing_driveway_qty
                           ,count(distinct case
                                             when /*(not m.is_orphan_object) and*/ m.missing_flag then m.driveway_root_id
                                           end
                                 ) as missing_orph_driveway_qty
                       from(select rcust.omsu_root_id
                                  ,tl.id as title_id
                                  ,obj.root_id as driveway_root_id
                                  ,odh.is_orphan_object
                                  ,case
                                     when l1.root_id is null then
                                       case
                                         when l2.odh_group_id is null then true
                                         else false
                                       end
                                     else false
                                   end as missing_flag
                              from ods.fdc_title tl
                              join ods.fdc_title_status tls on tl.title_status_id=tls.id
                              join msnow.fdc_work_category wc on tl.work_category_id=wc.id
                              --join rcust on tl.customer_id=rcust.customer_id
                              join ods.fdc_title_odh todh on tl.id=todh.title_id
                              join ods.fdc_odh odh on todh.odh_id=odh.id
                              join ods.fdc_object obj on odh.id=obj.id
                              join rcust on obj.customer_id=rcust.customer_id
                              left join est_lvl_1 l1 on obj.root_id=l1.root_id
                              left join est_lvl_2 l2 on odh.object_group_id=l2.odh_group_id
                             where tls.code='APPROVED'
                               and wc.code='MAINTAIN'
                               and (p_title_type_id is null or tl.title_type_id=p_title_type_id)
                               and p_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                           ) m
                      group by m.omsu_root_id
                    )

          select omsu.customer_root_id
                ,omsu.customer_short_name

                ,coalesce(total_drw.approved_driveway_id,0) as approved_driveway_qty
                ,coalesce(total_tl.title_id,0) as title_list_qty
                ,coalesce(total_tl.driveway_root_id,0) as title_driveway_qty
                ,coalesce(missed_tl.missing_title_qty,0) as missing_title_qty
                ,coalesce(missed_drw.missing_driveway_qty,0) as missing_driveway_qty
                ,coalesce(missed_tl.missing_orph_driveway_qty,0) as missing_orph_driveway_qty
            from omsu
            left join total_drw on omsu.omsu_root_id=total_drw.omsu_root_id
            left join total_tl on omsu.omsu_root_id=total_tl.omsu_root_id
            left join missed_tl on omsu.omsu_root_id=missed_tl.omsu_root_id
            left join missed_drw on omsu.omsu_root_id=missed_drw.omsu_root_id;
  elsif p_summary_type = C_TYPE_AGREEMENT then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_year_start_date between lp.ver_start_date and lp.ver_end_date
                      and l_year_start_date  between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )

          ,rcust as(select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                   )

          ,total_drw as(select rcust.omsu_root_id
                              ,count(distinct obj.root_id) as approved_driveway_id
                          from ods.fdc_object obj
                          join ods.fdc_odh odh on obj.id=odh.id
                          join ods.fdc_object_state objs on obj.object_state_id=objs.id
                          join rcust on obj.customer_id=rcust.customer_id
                         where objs.code='APPROVED'
                           and p_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                         group by rcust.omsu_root_id
                       )

          ,total_tl as(select rcust.omsu_root_id
                             ,count(distinct tl.id) as title_id
                             ,count(distinct obj.root_id) as driveway_root_id
                         from ods.fdc_title tl
                         join ods.fdc_title_status tls on tl.title_status_id=tls.id
                         join msnow.fdc_work_category wc on tl.work_category_id=wc.id
                         join rcust on tl.customer_id=rcust.customer_id
                         join ods.fdc_title_odh todh on tl.id=todh.title_id
                         join ods.fdc_odh odh on todh.odh_id=odh.id
                         join ods.fdc_object obj on odh.id=obj.id
                        where tls.code='APPROVED'
                          and wc.code='MAINTAIN'
                          and (p_title_type_id is null or tl.title_type_id=p_title_type_id)
                          and p_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                         group by rcust.omsu_root_id
                      )
          ,missed_drw as(select n.omsu_root_id
                               ,count(distinct case
                                                 when n.missing_flag then n.driveway_root_id
                                               end
                                     ) as missing_driveway_qty
                           from(select rcust.omsu_root_id
                                      ,obj.root_id as driveway_root_id
                                      ,case
                                         when not exists(select null
                                                           from msnow.fdc_agr_estimate oe
                                                           join msnow.fdc_agreement ag on oe.agreement_id=ag.id
                                                           join msnow.fdc_agreement_obligation_status ost on ag.agreement_status_id=ost.id
                                                           join msnow.fdc_work_category wc on ag.work_category_id=wc.id
                                                           join ods.fdc_odh odhe on oe.driveway_id=odhe.id
                                                           join ods.fdc_object obje on odhe.id=obje.id
                                                          where obje.root_id=obj.root_id
                                                            and ost.code='APPROVED'
                                                            and wc.code='MAINTAIN'
                                                            and p_year=extract(year from ag.version_date_from)
                                                        ) then
                                           case
                                             when not exists(select null
                                                               from msnow.fdc_agr_estimate oe
                                                               join msnow.fdc_agreement ag on oe.agreement_id=ag.id
                                                               join msnow.fdc_agreement_obligation_status ost on ag.agreement_status_id=ost.id
                                                               join msnow.fdc_work_category wc on ag.work_category_id=wc.id
                                                              where oe.odh_group_id=odh.object_group_id
                                                                and ost.code='APPROVED'
                                                                and wc.code='MAINTAIN'
                                                                and p_year=extract(year from ag.version_date_from)
                                                            ) then true
                                             else false
                                           end
                                         else false
                                      end as missing_flag
                                 from ods.fdc_object obj
                                 join ods.fdc_odh odh on obj.id=odh.id
                                 join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                 join rcust on obj.customer_id=rcust.customer_id
                                where objs.code='APPROVED'
                                  and p_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                               ) n
                          group by n.omsu_root_id
                        )
          ,missed_tl as(select m.omsu_root_id
                           ,count(distinct case
                                             when m.missing_flag then m.title_id
                                           end
                                 ) as missing_title_qty
                          -- ,count(distinct case
                          --                   when m.missing_flag then m.driveway_root_id
                          --                 end
                          --       ) as missing_driveway_qty
                           ,count(distinct case
                                             when /*(not m.is_orphan_object) and*/ m.missing_flag then m.driveway_root_id
                                           end
                                 ) as missing_orph_driveway_qty
                       from(select rcust.omsu_root_id
                                  ,tl.id as title_id
                                  ,obj.root_id as driveway_root_id
                                  ,odh.is_orphan_object
                                  ,case
                                     when not exists (select null
                                                        from msnow.fdc_agr_estimate oe
                                                        join msnow.fdc_agreement ag on oe.agreement_id=ag.id
                                                        join msnow.fdc_agreement_obligation_status ost on ag.agreement_status_id=ost.id
                                                        join msnow.fdc_work_category wc on ag.work_category_id=wc.id
                                                        join ods.fdc_odh odhe on oe.driveway_id=odhe.id
                                                        join ods.fdc_object obje on odhe.id=obje.id
                                                       where obje.root_id=obj.root_id
                                                         and ost.code='APPROVED'
                                                         and wc.code='MAINTAIN'
                                                         and p_year=extract(year from ag.version_date_from)
                                                     ) then
                                       case
                                         when not exists(select null
                                                           from msnow.fdc_agr_estimate oe
                                                           join msnow.fdc_agreement ag on oe.agreement_id=ag.id
                                                           join msnow.fdc_agreement_obligation_status ost on ag.agreement_status_id=ost.id
                                                           join msnow.fdc_work_category wc on ag.work_category_id=wc.id
                                                          where oe.odh_group_id=odh.object_group_id
                                                            and ost.code='APPROVED'
                                                            and wc.code='MAINTAIN'
                                                            and p_year=extract(year from ag.version_date_from)
                                                        ) then true
                                         else false
                                       end
                                     else false
                                   end as missing_flag
                              from ods.fdc_title tl
                              join ods.fdc_title_status tls on tl.title_status_id=tls.id
                              join msnow.fdc_work_category wc on tl.work_category_id=wc.id
                             -- join rcust on tl.customer_id=rcust.customer_id
                              join ods.fdc_title_odh todh on tl.id=todh.title_id
                              join ods.fdc_odh odh on todh.odh_id=odh.id
                              join ods.fdc_object obj on odh.id=obj.id
                              join rcust on obj.customer_id=rcust.customer_id
                             where tls.code='APPROVED'
                               and wc.code='MAINTAIN'
                               and (p_title_type_id is null or tl.title_type_id=p_title_type_id)
                               and p_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                           ) m
                      group by m.omsu_root_id
                    )

          select omsu.customer_root_id
                ,omsu.customer_short_name

                ,coalesce(total_drw.approved_driveway_id,0) as approved_driveway_qty
                ,coalesce(total_tl.title_id,0) as title_list_qty
                ,coalesce(total_tl.driveway_root_id,0) as title_driveway_qty
                ,coalesce(missed_tl.missing_title_qty,0) as missing_title_qty
                ,coalesce(missed_drw.missing_driveway_qty,0) as missing_driveway_qty
                ,coalesce(missed_tl.missing_orph_driveway_qty,0) as missing_orph_driveway_qty
            from omsu
            left join total_drw on omsu.omsu_root_id=total_drw.omsu_root_id
            left join total_tl on omsu.omsu_root_id=total_tl.omsu_root_id
            left join missed_tl on omsu.omsu_root_id=missed_tl.omsu_root_id
            left join missed_drw on omsu.omsu_root_id=missed_drw.omsu_root_id;
  end if;
  return;
end
$$;

