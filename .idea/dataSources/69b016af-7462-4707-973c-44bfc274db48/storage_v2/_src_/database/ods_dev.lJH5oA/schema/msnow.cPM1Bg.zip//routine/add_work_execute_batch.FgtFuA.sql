CREATE FUNCTION add_work_execute_batch(p_agreement_id bigint, p_work_type_id bigint, p_odh_group_id bigint, p_cover_type_id bigint, p_route_code text, p_work_date timestamp without time zone, OUT p_rep_deleted_cnt integer, OUT p_rep_recreated_cnt integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
/** Процедура пакетного добавления отчетов о выполнении работ.
  %param p_agreement_id   Ид обязательства
  %param p_work_type_id   Ид вида работы
  %param p_odh_group_id   Ид группы дорог по содержанию
  %param p_cover_type_id  Ид типа покрытия
  %param p_route_code     Код маршрута
  %param p_work_date      Дата и время завершения работ

  %return p_rep_deleted_cnt Количество удаленных отчетов
  %return p_rep_recreated   Количество созданных заново отчетов
*/
  l_driveway_id_list bigint[];
begin
  l_driveway_id_list:=array(select distinct dw.id
                              from msnow.fdc_agreement_object ao
                                  ,msnow.fdc_driveway dw
                             where ao.argeement_id=p_agreement_id
                               and ao.driveway_id=dw.id
                               and (p_odh_group_id is null or dw.odh_group_id=p_odh_group_id)
                               and (p_cover_type_id is null or dw.cover_type_id=p_cover_type_id)
                               and (p_route_code is null or lower(dw.route_code)=lower(p_route_code))
                           );

  delete from msnow.fdc_work_execute
   where agreement_id=p_agreement_id
     and work_type_id=p_work_type_id
     and date_trunc('day',work_date)=date_trunc('day',p_work_date)
     and driveway_id IN(select unnest(l_driveway_id_list));

  get diagnostics p_rep_deleted_cnt = row_count;

  insert into msnow.fdc_work_execute(id
                                  ,agreement_id
                                  ,work_type_id
                                  ,driveway_id
                                  ,work_date
                                  ,work_volume
                                  ,measure_unit_id
                                  ,work_status_id
                                  )
    select nextval('ods.fdc_common_seq')
          ,p_agreement_id
          ,p_work_type_id
          ,dw
          ,p_work_date
          ,msnow.get_work_volume(p_work_type_id => p_work_type_id
                              ,p_driveway_id  => dw
                              )
          ,(select measure_unit_id from msnow.fdc_work_type where id=p_work_type_id)
          ,(select id from msnow.fdc_work_status where code='DONE')
      from unnest(l_driveway_id_list) as dw;

  get diagnostics p_rep_recreated_cnt = row_count;
end
$$;

