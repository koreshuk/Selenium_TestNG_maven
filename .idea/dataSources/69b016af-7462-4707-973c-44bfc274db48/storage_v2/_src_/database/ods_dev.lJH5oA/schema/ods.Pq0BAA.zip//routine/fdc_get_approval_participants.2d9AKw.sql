CREATE FUNCTION fdc_get_approval_participants(p_approval_template_id bigint, p_object_type integer, p_object_id bigint, p_condition_obligatory_id bigint, OUT num_stage bigint, OUT num_part bigint, OUT participant_id bigint, OUT organization_id bigint, OUT has_user boolean)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Список должностных лиц, участвующих в согласовании.
    %param p_approval_template_id     -- Ид шаблона согласования

    %param p_object_type              -- Тип согласуемого объекта
                                         1 - ОДХ
                                         2 - Титульный список
                                         3 - Бюджет
                                         4 - Контракт

    %param p_object_id                -- Ид согласуемой версии объекта
                                         Если p_object_type = 1 => ods.fdc_odh.id
                                         Если p_object_type = 2 => ods.fdc_title.id
                                         Если p_object_type = 3 => msnow.fdc_obligation.id
                                         Если p_object_type = 4 => msnow.fdc_agreement.id

    %param p_condition_obligatory_id  -- Ид причины изменения

    %return num_stage                 -- Номер этапа
    %return num_part                  -- Номер участника
    %return participant_id            -- Ид участника
    %return organization_id           -- Ид организации
    %return has_user                  -- Признак Наличие пользователя в участнике
  */
  rec record;
begin
  if p_object_type=1 then -- ODH
    return query
      select t.num_stage
            ,t.num_part
            ,t.participant_id
            ,t.organization_id
            ,t.has_user
        from ods.fdc_get_approval_participants_odh(p_approval_template_id    => p_approval_template_id
                                                  ,p_odh_id                  => p_object_id
                                                  ,p_condition_obligatory_id => p_condition_obligatory_id
                                                  ) t;
  elsif p_object_type=2 then -- ТС
    return query
      select t.num_stage
            ,t.num_part
            ,t.participant_id
            ,t.organization_id
            ,t.has_user
        from ods.fdc_get_approval_participants_ts(p_approval_template_id    => p_approval_template_id
                                                 ,p_title_id                => p_object_id
                                                 ,p_condition_obligatory_id => p_condition_obligatory_id
                                                 ) t;
  elsif p_object_type=3 then -- Бюджет
    return query
      select t.num_stage
            ,t.num_part
            ,t.participant_id
            ,t.organization_id
            ,t.has_user
        from ods.fdc_get_approval_participants_obl(p_approval_template_id    => p_approval_template_id
                                                  ,p_obligation_id           => p_object_id
                                                  ,p_condition_obligatory_id => p_condition_obligatory_id
                                                  ) t;
  elsif p_object_type=4 then -- Контракт
    return query
      select t.num_stage
            ,t.num_part
            ,t.participant_id
            ,t.organization_id
            ,t.has_user
        from ods.fdc_get_approval_participants_agrm(p_approval_template_id    => p_approval_template_id
                                                   ,p_agreement_id            => p_object_id
                                                   ,p_condition_obligatory_id => p_condition_obligatory_id
                                                   ) t;
  end if;
  return;
end
$$;

