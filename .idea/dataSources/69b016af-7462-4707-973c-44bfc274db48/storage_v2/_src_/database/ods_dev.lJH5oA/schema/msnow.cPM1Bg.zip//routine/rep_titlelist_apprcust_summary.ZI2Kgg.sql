CREATE FUNCTION rep_titlelist_apprcust_summary(p_driveway_category_id bigint, p_work_category_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, OUT customer_root_id bigint, OUT customer_short_name character varying, OUT approved_last3days_qty bigint, OUT rejected_qty bigint, OUT sent_qty bigint, OUT expired_qty bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт "Сводка по согласованию Титульных списков на <текущая дата>" в разрезе заказчиков

  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_work_category_id      - Категория ТС (Ид категории работ)
  %param p_customer_id           - Заказчик (Ид актуальной на начало выбранного года версии заказчика)

  %return customer_root_id        - ROOT_ID заказчика
  %return customer_short_name     - Заказчик
  %return approved_last3days_qty  - Согласовано ТС за последние 3 дня
  %return rejected_qty            - Отклонено ТС
  %return sent_qty                - Всего ТС на согласовании
  %return expired_qty             - Просрочено ТС на согласовании
  */
  l_summary_date date;
  l_workdays_lag_3 date;
begin
  l_summary_date :=current_date;
  l_workdays_lag_3:=msnow.srv_workdays_back(p_workdays_qty   => 3
                                           ,p_date_from      => l_summary_date
                                           );
--raise notice 'p_driveway_category_id = %',p_driveway_category_id ;
--raise notice 'p_work_category_id = %',p_work_category_id;
--raise notice 'p_customer_id = %',p_customer_id;

  return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                      and exists (select 1
                                    from ods.fdc_title tl
                                   where tl.customer_id = lp.id
                                   and (p_work_category_id is null or tl.work_category_id = p_work_category_id)
                                   )
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where p_customer_id is not null
                   )
          ,lasttl as(select tl.id as title_id
                           ,tl.customer_id
                           ,cst.root_id as customer_root_id
                           ,tls.code as title_status_code
                           ,tl.agree_date as title_agree_date
                       from ods.fdc_title tl
                       join ods.fdc_title_status tls on tl.title_status_id=tls.id
                       join nsi.fdc_legal_person cst on tl.customer_id=cst.id
                      where (p_work_category_id is null or tl.work_category_id = p_work_category_id)
                    )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as title_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='TS'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select maxiter.title_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )
     select rcust.customer_root_id
           ,rcust.customer_short_name::varchar
           ,count(distinct case
                             when lasttl.title_status_code ='APPROVED' and lasttl.title_agree_date between l_workdays_lag_3 and l_summary_date then lasttl.title_id
                           end
                 )::bigint as approved_last3days_qty
           ,count(distinct case
                             when lasttl.title_status_code='PROJECT' and maxiter.approval_iteration_status_code='REJECTED' then lasttl.title_id
                           end
                 )::bigint as rejected_qty
           ,count(distinct case
                             when lasttl.title_status_code='ON_APPROVAL' then lasttl.title_id
                           end
                 )::bigint as sent_qty
           ,count(distinct case
                             when lasttl.title_status_code='ON_APPROVAL' and expired.title_id is not null then lasttl.title_id
                           end
                 )::bigint as expired_qty
       from rcust
       left join lasttl on rcust.customer_root_id=lasttl.customer_root_id
       left join maxiter on lasttl.title_id=maxiter.title_id
       left join expired on maxiter.title_id=expired.title_id
      group by rcust.customer_root_id
              ,rcust.customer_short_name;
  return;
end
$$;

