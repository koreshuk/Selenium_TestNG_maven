CREATE FUNCTION fdc_object_pck_insert_object(p_object fdc_object)
  RETURNS fdc_object
LANGUAGE plpgsql
AS $$
declare
  /** Вставка записи в FDC_OBJECT */
begin
  p_object.id:= COALESCE(p_object.id,nextval('ods.fdc_object_seq'));
  p_object.root_id := coalesce(p_object.root_id, p_object.id);

  /* Геометрию пока не изпользуем */
  --> Длина (протяженность)
  --p_object.geometry_length := get_object_length (p_geometry => p_object.geometry);
  --> Центроид
  --p_object.centroid := fdc_geo_pck.get_centroid(p_object.geometry);
  --> Центроид wgs
  --p_object.centroid_wgs := fdc_geo_pck.get_centroid(p_object.geometry_wgs)
  insert into ods.fdc_object(id
                            ,parent_version_id
                            ,root_id
                            ,version_date_from
                            ,version_date_to
                            ,customer_id
                            ,object_type_id
                            ,object_state_id
                            ,owner_id
                            ,object_sub_type_id
                            ,geometry
                            ,description
                            ,okrug_id
                            ,district_id
                            ,inventory_id
                            ,reason_type_id
                            ,tree_name
                            ,root_owner_id
                            ,update_date
                            ,hash_sum
                            ,name
                            ,total_area
                            ,number_doc
                            ,snapshot_date
                            ,accounting_address
                            ,inventory_num
                            ,egip_sync_date
                            ,global_id
                            ,centroid
                            ,approval_id
                            ,reason_type_del_id
                            ,centroid_wgs
                            ,current_status_id
                            ,dismantling_date
                            ,geometry_length
                            ,geometry_wgs
                            ,install_date
                            ,reason_comment
                            ,reason_del_comment
                            ,approval_iteration_id
                            ,approval_date
                            )
        select p_object.id
              ,p_object.parent_version_id
              ,p_object.root_id
              ,p_object.version_date_from
              ,p_object.version_date_to
              ,p_object.customer_id
              ,p_object.object_type_id
              ,p_object.object_state_id
              ,p_object.owner_id
              ,p_object.object_sub_type_id
              ,p_object.geometry
              ,p_object.description
              ,p_object.okrug_id
              ,p_object.district_id
              ,p_object.inventory_id
              ,p_object.reason_type_id
              ,p_object.tree_name
              ,p_object.root_owner_id
              ,p_object.update_date
              ,p_object.hash_sum
              ,p_object.name
              ,p_object.total_area
              ,p_object.number_doc
              ,p_object.snapshot_date
              ,p_object.accounting_address
              ,p_object.inventory_num
              ,p_object.egip_sync_date
              ,p_object.global_id
              ,p_object.centroid
              ,p_object.approval_id
              ,p_object.reason_type_del_id
              ,p_object.centroid_wgs
              ,p_object.current_status_id
              ,p_object.dismantling_date
              ,p_object.geometry_length
              ,p_object.geometry_wgs
              ,p_object.install_date
              ,p_object.reason_comment
              ,p_object.reason_del_comment
              ,p_object.approval_iteration_id
              ,p_object.approval_date;
  return p_object;
end;
$$;

