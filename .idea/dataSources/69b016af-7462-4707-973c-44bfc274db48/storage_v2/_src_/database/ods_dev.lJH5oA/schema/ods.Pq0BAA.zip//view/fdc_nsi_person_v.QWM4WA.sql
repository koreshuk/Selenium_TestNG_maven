CREATE VIEW fdc_nsi_person_v AS
  SELECT lp.id,
    lp.root_id,
    lp.person_type_id,
    lp.code,
        CASE
            WHEN ((lp.person_type_id = 4) OR (lp.person_type_id = 5)) THEN ((((lp.name)::text ||
            CASE
                WHEN ((lp.short_name IS NOT NULL) AND ((lp.short_name)::text <> ''::text)) THEN (' '::text || (lp.short_name)::text)
                ELSE NULL::text
            END) ||
            CASE
                WHEN ((lp.patronymic IS NOT NULL) AND ((lp.patronymic)::text <> ''::text)) THEN (' '::text || (lp.patronymic)::text)
                ELSE NULL::text
            END))::character varying
            ELSE lp.name
        END AS name,
        CASE
            WHEN ((lp.person_type_id = 4) OR (lp.person_type_id = 5)) THEN ((((lp.name)::text ||
            CASE
                WHEN ((lp.short_name IS NOT NULL) AND ((lp.short_name)::text <> ''::text)) THEN ((' '::text || substr((lp.short_name)::text, 1, 1)) || '.'::text)
                ELSE NULL::text
            END) ||
            CASE
                WHEN ((lp.patronymic IS NOT NULL) AND ((lp.patronymic)::text <> ''::text)) THEN ((' '::text || substr((lp.patronymic)::text, 1, 1)) || '.'::text)
                ELSE NULL::text
            END))::character varying
            ELSE lp.short_name
        END AS short_name,
    lp.inn,
    lp.kpp,
    lp.ogrn,
    lp.okpo,
    lp.account,
    lp.postal_address,
    lp.legal_address,
    lp.email,
    lp.phone,
    lp.fax,
    lp.off_post,
    lp.off_name,
    lp.bik,
    lp.bank,
    lp.corr_account,
    lp.person_code,
    lp.person_code_name,
    lp.occupation_id,
    lp.okved,
    lp.reg_date,
    lp.gender,
        CASE
            WHEN ((lp.person_type_id = 4) OR (lp.person_type_id = 5)) THEN lp.name
            ELSE NULL::character varying
        END AS family,
        CASE
            WHEN ((lp.person_type_id = 4) OR (lp.person_type_id = 5)) THEN lp.short_name
            ELSE NULL::character varying
        END AS first_name,
    lp.patronymic,
    lp.snils,
    lp.birth_date,
    lp.birth_place,
    lp.birth_country_id,
    lp.identity_doctype_id,
    lp.docseries,
    lp.docnumber,
    lp.issue_date,
    lp.issue_department,
    lp.department_code,
    lp.work_length,
    lp.parent_id,
    lp.parent_root_id,
    lp.cbr_bank_id,
    lp.is_small_medium,
    lp.sro_flag,
    lp.sro_org_id,
    lp.sro_regnum,
    lp.is_local_version,
    lp.asur_sync_date,
    lp.asur_sync_status,
    lp.fns_sync_date,
    lp.fns_validate,
    lp.suppress_asur_sync,
    lp.last_changed,
    lp.username,
    lp.person_state,
    lp.ver_start_date,
    lp.ver_end_date,
    lp.closing_date,
    lp.okonh_id,
    lp.okopf_id,
    lp.okved_id,
    lp.okfs_id,
    lp.crc,
    false AS is_history,
        CASE
            WHEN (lp.ver_end_date IS NOT NULL) THEN false
            ELSE true
        END AS is_actual,
    rtrim(replace((((((COALESCE(lp.postal_address, '^^'::character varying))::text || ', '::text) ||
        CASE
            WHEN (lp.phone IS NOT NULL) THEN ('тел.: '::text || (lp.phone)::text)
            ELSE '^^'::text
        END) || ', '::text) ||
        CASE
            WHEN (lp.email IS NOT NULL) THEN ('E-mail: '::text || (lp.email)::text)
            ELSE NULL::text
        END), '^^, '::text, ''::text), ', '::text) AS address_phone_email
   FROM nsi.fdc_person_v lp;

COMMENT ON VIEW fdc_nsi_person_v IS 'Классификатор субъектов (включая фиктивные организации)';

COMMENT ON COLUMN fdc_nsi_person_v.id IS 'ИД субъекта';

COMMENT ON COLUMN fdc_nsi_person_v.root_id IS 'ИД организации';

COMMENT ON COLUMN fdc_nsi_person_v.person_type_id IS 'Ид типа субъекта права';

COMMENT ON COLUMN fdc_nsi_person_v.code IS 'Код в АС Управления Реестрами';

COMMENT ON COLUMN fdc_nsi_person_v.name IS 'Полное наименование/Фамилия';

COMMENT ON COLUMN fdc_nsi_person_v.short_name IS 'Краткое наименование/Имя';

COMMENT ON COLUMN fdc_nsi_person_v.inn IS 'Идентификационный номер налогоплательщика';

COMMENT ON COLUMN fdc_nsi_person_v.kpp IS 'Код причины постановки на учёт';

COMMENT ON COLUMN fdc_nsi_person_v.ogrn IS 'Основной государственный регистрационный номер';

COMMENT ON COLUMN fdc_nsi_person_v.okpo IS 'Общероссийский классификатор предприятий и организаций';

COMMENT ON COLUMN fdc_nsi_person_v.account IS 'Расчётный счёт (текущий счёт)';

COMMENT ON COLUMN fdc_nsi_person_v.postal_address IS 'Почтовый адрес/Адрес';

COMMENT ON COLUMN fdc_nsi_person_v.legal_address IS 'Юридический адрес';

COMMENT ON COLUMN fdc_nsi_person_v.email IS 'Электронная почта';

COMMENT ON COLUMN fdc_nsi_person_v.phone IS 'Телефон организации или ответственного лица';

COMMENT ON COLUMN fdc_nsi_person_v.fax IS 'Факс организации';

COMMENT ON COLUMN fdc_nsi_person_v.off_post IS 'Должность руководителя';

COMMENT ON COLUMN fdc_nsi_person_v.off_name IS 'ФИО руководителя';

COMMENT ON COLUMN fdc_nsi_person_v.bik IS 'БИК';

COMMENT ON COLUMN fdc_nsi_person_v.bank IS 'Банк';

COMMENT ON COLUMN fdc_nsi_person_v.corr_account IS 'Корреспондентский счет';

COMMENT ON COLUMN fdc_nsi_person_v.person_code IS 'Код подразделения/Табельный номер';

COMMENT ON COLUMN fdc_nsi_person_v.person_code_name IS 'Наименование кода подразделения';

COMMENT ON COLUMN fdc_nsi_person_v.occupation_id IS 'Ид должности';

COMMENT ON COLUMN fdc_nsi_person_v.okved IS 'Общероссийский классификатор видов экономической деятельности';

COMMENT ON COLUMN fdc_nsi_person_v.reg_date IS 'Дата регистрации';

COMMENT ON COLUMN fdc_nsi_person_v.gender IS 'Пол (0 - Ж, 1 - М)';

COMMENT ON COLUMN fdc_nsi_person_v.patronymic IS 'Отчество';

COMMENT ON COLUMN fdc_nsi_person_v.snils IS 'Страховой номер индивидуального лицевого счета';

COMMENT ON COLUMN fdc_nsi_person_v.birth_date IS 'Дата рождения (для физ. лиц)';

COMMENT ON COLUMN fdc_nsi_person_v.birth_place IS 'Место рождения';

COMMENT ON COLUMN fdc_nsi_person_v.birth_country_id IS 'Ид страны рождения (пока заглушка до создания справочника)';

COMMENT ON COLUMN fdc_nsi_person_v.identity_doctype_id IS 'Ид типа документа';

COMMENT ON COLUMN fdc_nsi_person_v.docseries IS 'Серия документа';

COMMENT ON COLUMN fdc_nsi_person_v.docnumber IS 'Номер документа';

COMMENT ON COLUMN fdc_nsi_person_v.issue_date IS 'Дата выдачи';

COMMENT ON COLUMN fdc_nsi_person_v.issue_department IS 'Кем выдан документ';

COMMENT ON COLUMN fdc_nsi_person_v.department_code IS 'Код подразделения';

COMMENT ON COLUMN fdc_nsi_person_v.work_length IS 'Стаж работы';

COMMENT ON COLUMN fdc_nsi_person_v.parent_id IS 'Ид головной организации';

COMMENT ON COLUMN fdc_nsi_person_v.cbr_bank_id IS 'Ид банк';

COMMENT ON COLUMN fdc_nsi_person_v.is_small_medium IS 'Признак малого или среднего бизнеса';

COMMENT ON COLUMN fdc_nsi_person_v.sro_flag IS 'Признак СРО';

COMMENT ON COLUMN fdc_nsi_person_v.sro_org_id IS 'Ид СРО';

COMMENT ON COLUMN fdc_nsi_person_v.sro_regnum IS 'Оегистрационный номер СРО';

COMMENT ON COLUMN fdc_nsi_person_v.asur_sync_date IS 'Дата последней успешной синхронизации с АСУР';

COMMENT ON COLUMN fdc_nsi_person_v.asur_sync_status IS 'Статус синхронизации с АСУР (0-запрос не отправлялся, 1- ожидает ответа, 2- данные актуальны, 3 - не удалось синхронизировать)';

COMMENT ON COLUMN fdc_nsi_person_v.fns_sync_date IS 'Дата синхронизации с ФНС';

COMMENT ON COLUMN fdc_nsi_person_v.fns_validate IS 'Признак того, обновлены сведения о ЮЛ данными из ФНС';

COMMENT ON COLUMN fdc_nsi_person_v.suppress_asur_sync IS 'Запретить синхронизацию с АСУР (0 - не запрещать, 1 - запретить)';

COMMENT ON COLUMN fdc_nsi_person_v.last_changed IS 'Дата последних изменении';

COMMENT ON COLUMN fdc_nsi_person_v.username IS 'Пользователь внесший изменение';

COMMENT ON COLUMN fdc_nsi_person_v.person_state IS 'Состояние субъекта 1 - Отсутствует в НСИ 2 - Не проверена 3 - Данные устарели 4 - Данные актуальны';

COMMENT ON COLUMN fdc_nsi_person_v.ver_start_date IS 'Дата начала действия версии (min = дата появления орг. в системе (ред. пользов.))';

COMMENT ON COLUMN fdc_nsi_person_v.ver_end_date IS 'Дата окончания действия версии (NULL - вресия актуальна)';

COMMENT ON COLUMN fdc_nsi_person_v.closing_date IS 'Дата закрытия организации';

COMMENT ON COLUMN fdc_nsi_person_v.okonh_id IS 'Ид ОКОНХ';

COMMENT ON COLUMN fdc_nsi_person_v.okopf_id IS 'Ид ОКОПФ';

COMMENT ON COLUMN fdc_nsi_person_v.okved_id IS 'Ид ОКВЕД';

COMMENT ON COLUMN fdc_nsi_person_v.okfs_id IS 'Ид ОКФС';

COMMENT ON COLUMN fdc_nsi_person_v.crc IS 'Контрольная сумма';

COMMENT ON COLUMN fdc_nsi_person_v.is_history IS 'Признак исторических данных: 0 - нет; 1 - да';

COMMENT ON COLUMN fdc_nsi_person_v.address_phone_email IS 'Адрес с телефоном и e-mailом ';

