CREATE VIEW fdc_dw_repairplan_rate_v AS
  WITH def AS (
         SELECT d.driveway_id,
            count(d.id) AS dw_defect_qty,
            sum(d.defect_area) AS dw_defect_area,
            sum(d.penetration) AS dw_defect_penetration
           FROM msnow.fdc_defect d
          WHERE (d.agreement_id IS NULL)
          GROUP BY d.driveway_id
        )
 SELECT
        CASE
            WHEN (obj.as_area_id IS NOT NULL) THEN farea.municipality_name
            WHEN (obj.as_place_id IS NOT NULL) THEN fplace.municipality_name
            ELSE NULL::character varying
        END AS municipality_name,
    obj.root_id AS odh_root_id,
    obj.name AS odh_name,
    cust.short_name AS customer_name,
        CASE oprop.belongs_to_backbone
            WHEN true THEN 'Да'::text
            ELSE 'Нет'::text
        END AS belongs_to_backbone,
        CASE oprop.morning_traffic_present
            WHEN true THEN 'Да'::text
            ELSE 'Нет'::text
        END AS morning_traffic_present,
    dwgc.name AS driveway_gost_category_name,
    oprop.repair_year,
    rdr.name AS revetment_destruct_rate,
    trf.name AS traffic_name,
    oprop.emerg_segment_count,
    emcat.name AS emerg_category_name,
    oprop.emerg_segm_distance,
    COALESCE(def.dw_defect_qty, (0)::bigint) AS dw_defect_qty,
    COALESCE(def.dw_defect_area, (0.0)::double precision) AS dw_defect_area,
    COALESCE(def.dw_defect_penetration, (0.0)::double precision) AS dw_defect_penetration,
    oprop.repair_amount,
    oprop.odh_rate,
    oprop.traffic_id,
    oprop.emerg_cat_id,
    obj.version_date_from,
    obj.version_date_to,
    opropo.start_date AS object_prop_link_start_date,
    opropo.end_date AS object_prop_link_end_date,
        CASE
            WHEN (obj.as_area_id IS NOT NULL) THEN farea.municipality_id
            WHEN (obj.as_place_id IS NOT NULL) THEN fplace.municipality_id
            ELSE NULL::bigint
        END AS municipality_id,
    obj.driveway_category_id,
    obj.owner_id,
    obj.customer_id,
    ownr.root_id AS owner_root_id,
    cust.root_id AS customer_root_id
   FROM (((((((((((((fdc_object obj
     JOIN fdc_odh odh ON ((obj.id = odh.id)))
     JOIN fdc_object_state objs ON ((obj.object_state_id = objs.id)))
     JOIN msnow.fdc_driveway_gost_category dwgc ON ((odh.driveway_gost_category_id = dwgc.id)))
     LEFT JOIN nsi.fdc_fias_address_reference_v farea ON ((obj.as_area_id = farea.id)))
     LEFT JOIN nsi.fdc_fias_address_reference_v fplace ON ((obj.as_place_id = fplace.id)))
     LEFT JOIN nsi.fdc_legal_person cust ON ((obj.customer_id = cust.id)))
     LEFT JOIN nsi.fdc_legal_person ownr ON ((obj.owner_id = ownr.id)))
     LEFT JOIN fdc_object_prop_odh opropo ON ((odh.id = opropo.odh_id)))
     LEFT JOIN fdc_object_prop oprop ON ((opropo.object_prop_id = oprop.id)))
     LEFT JOIN fdc_revetment_destruct_rate rdr ON ((oprop.revetment_destruct_rate_id = rdr.id)))
     LEFT JOIN fdc_traffic trf ON ((oprop.traffic_id = trf.id)))
     LEFT JOIN fdc_emerg_category emcat ON ((oprop.emerg_cat_id = emcat.id)))
     LEFT JOIN def ON ((odh.id = def.driveway_id)))
  WHERE ((objs.code)::text = 'APPROVED'::text);

COMMENT ON VIEW fdc_dw_repairplan_rate_v IS 'Отчёт Рейтинг автомобильных дорог для ремонта/текущего ремонта.';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.municipality_name IS 'Муниципальное образование';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.odh_root_id IS 'Ид участка дороги';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.odh_name IS 'Участок дороги';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.customer_name IS 'Заказчик';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.belongs_to_backbone IS 'Принадлежность к опорной сети';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.morning_traffic_present IS 'Наличие пробок по состоянию на 8:30 утра рабочего дня';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.driveway_gost_category_name IS 'Категория по ГОСТ';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.repair_year IS 'Год последнего ремонта';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.revetment_destruct_rate IS '% разрушения дорожной одежды';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.traffic_name IS 'Характеристика трафика';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.emerg_segment_count IS 'Число аварийных участков';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.emerg_category_name IS 'Категория аварийности';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.emerg_segm_distance IS 'Протяженность аварийных участков, км';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.dw_defect_qty IS 'Количество дефектов';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.dw_defect_area IS 'Площадь дефектов';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.dw_defect_penetration IS 'Глубина дефектов';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.repair_amount IS 'Ориентировочная стоимость, руб';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.odh_rate IS 'Рейтинг';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.traffic_id IS 'Ид характеристики трафика';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.emerg_cat_id IS 'Ид категории аварийности';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.version_date_from IS 'Дата начала действия участка';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.version_date_to IS 'Дата оконцчания действия участка';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.object_prop_link_start_date IS 'Дата начала действия привязки участка и досье';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.object_prop_link_end_date IS 'Дата окончания действия привязки участка и досье';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.municipality_id IS 'Ид муниципального образования';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.driveway_category_id IS 'Ид балансовой принадлежности';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.owner_id IS 'Ид балансодержателя';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.customer_id IS 'Ид заказчика';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.owner_root_id IS 'Сквозной ид балансодержателя';

COMMENT ON COLUMN fdc_dw_repairplan_rate_v.customer_root_id IS 'Сквозной ид заказчика';

