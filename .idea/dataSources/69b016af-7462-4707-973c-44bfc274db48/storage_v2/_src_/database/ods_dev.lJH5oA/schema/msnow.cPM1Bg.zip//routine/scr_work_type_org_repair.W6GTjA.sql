CREATE FUNCTION scr_work_type_org_repair()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  rec record;
  l_new_work_type_id msnow.fdc_work_type.id%type;
begin  
  for rec in(select oe.work_type_id
                   ,wt.organization_id as work_type_organization_id
                   ,o.authority_org_id as customer_id
                   ,wt.code as work_type_code
               from msnow.fdc_obligation_estimate oe
               join msnow.fdc_work_type wt on oe.work_type_id=wt.id
               join msnow.fdc_ods_organization wto on wt.organization_id=wto.id
               join msnow.fdc_obligation o on oe.obligation_id=o.id
               join msnow.fdc_ods_organization oo on o.authority_org_id=oo.id
              where wto.municipality_id<>oo.municipality_id 
             union
             select ae.work_type_id
                   ,awt.organization_id as work_type_organization_id
                   ,a.customer_id as customer_id
                   ,awt.code as work_type_code
               from msnow.fdc_agr_estimate ae
               join msnow.fdc_work_type awt on ae.work_type_id=awt.id
               join msnow.fdc_ods_organization awto on awt.organization_id=awto.id
               join msnow.fdc_agreement a on ae.agreement_id=a.id
               join msnow.fdc_ods_organization aoo on a.customer_id=aoo.id
              where awto.municipality_id<>aoo.municipality_id 
             union
             select pe.work_type_id
                   ,pwt.organization_id as work_type_organization_id
                   ,p.customer_id as customer_id
                   ,pwt.code as work_type_code
               from msnow.fdc_purchase_estimate pe
               join msnow.fdc_work_type pwt on pe.work_type_id=pwt.id
               join msnow.fdc_ods_organization pwto on pwt.organization_id=pwto.id
               join msnow.fdc_purchase p on pe.purchase_lot_id=p.id
               join msnow.fdc_ods_organization poo on p.customer_id=poo.id
              where pwto.municipality_id<>poo.municipality_id     
            ) loop   
    begin
      select wt.id
        into strict l_new_work_type_id
        from msnow.fdc_work_type wt
       where wt.code=rec.work_type_code||'_'||rec.customer_id
         and wt.organization_id=rec.customer_id; 
    exception
      when NO_DATA_FOUND then
        l_new_work_type_id:=null;
    end;   
    if l_new_work_type_id is null then
      insert into msnow.fdc_work_type(id,code,name,work_type_uni_id,work_category_id,season_id,measure_unit_id,organization_id,season_date_from,season_date_to)
        select nextval('ods.fdc_common_seq')
              ,wtb.code||'_'||rec.customer_id
              ,wtb.name
              ,wtb.work_type_uni_id
              ,wtb.work_category_id
              ,wtb.season_id
              ,wtb.measure_unit_id
              ,rec.customer_id
              ,wtb.season_date_from
              ,wtb.season_date_to
          from msnow.fdc_work_type wtb
         where id=rec.work_type_id
          returning id into l_new_work_type_id; 
    end if;
    
    update msnow.fdc_obligation_estimate
       set work_type_id=l_new_work_type_id
     where id in(select oe.id
                   from msnow.fdc_obligation_estimate oe
                   join msnow.fdc_obligation o on oe.obligation_id=o.id
                  where oe.work_type_id=rec.work_type_id
                    and o.authority_org_id=rec.customer_id
                );  
 
    update msnow.fdc_agr_estimate
       set work_type_id=l_new_work_type_id
     where id in(select oe.id
                   from msnow.fdc_agr_estimate oe
                   join msnow.fdc_agreement o on oe.agreement_id=o.id
                  where oe.work_type_id=rec.work_type_id
                    and o.customer_id=rec.customer_id
                );  
 
    update msnow.fdc_purchase_estimate
       set work_type_id=l_new_work_type_id
     where id in(select oe.id
                   from msnow.fdc_purchase_estimate oe
                   join msnow.fdc_purchase o on oe.purchase_lot_id=o.id
                  where oe.work_type_id=rec.work_type_id
                    and o.customer_id=rec.customer_id
                );  
  end loop;  
end
$$;

