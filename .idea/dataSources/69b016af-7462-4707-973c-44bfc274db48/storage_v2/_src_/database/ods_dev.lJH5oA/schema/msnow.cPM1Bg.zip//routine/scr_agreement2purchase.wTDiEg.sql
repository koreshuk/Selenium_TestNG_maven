CREATE FUNCTION scr_agreement2purchase(p_agreement_id bigint, p_purchase_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Скрипт по переносу дорог и смет из обязательства(контракта) в закупку
  %param p_agreement_id  - Ид обязательства
  %param p_purchase_id   - Ид закупки
  */
  l_agreement_id msnow.fdc_agreement.id%type;
  l_purchase_id msnow.fdc_purchase.id%type;
begin
  begin
    select id
      into strict l_agreement_id
      from msnow.fdc_agreement
     where id=p_agreement_id;
  exception
    when NO_DATA_FOUND then
      raise exception 'Не найдено обязательство с идентификатором %',p_agreement_id;
  end;
  begin
    select id
      into strict l_purchase_id
      from msnow.fdc_purchase
     where id=p_purchase_id;
  exception
    when NO_DATA_FOUND then
      raise exception 'Не найдена закупка с идентификатором %',p_purchase_id;
  end;

  delete from msnow.fdc_purchase_estimate where purchase_lot_id=l_purchase_id;
  delete from msnow.fdc_purchase_object where purchase_lot_id=l_purchase_id;

  insert into msnow.fdc_purchase_object(id,purchase_lot_id,driveway_id)
    select nextval('ods.fdc_common_seq')
          ,l_purchase_id
          ,oo.driveway_id
      from msnow.fdc_agreement_object oo
     where oo.argeement_id=l_agreement_id;

  insert into msnow.fdc_purchase_estimate(id,purchase_lot_id,driveway_id,work_type_id,work_volume
                                         ,measure_unit_id,work_cost,is_estimate_sum,odh_group_id)
    select nextval('ods.fdc_common_seq')
          ,l_purchase_id
          ,oe.driveway_id
          ,oe.work_type_id
          ,oe.work_volume
          ,oe.measure_unit_id
          ,oe.work_cost
          ,oe.is_estimate_sum
          ,oe.odh_group_id
      from msnow.fdc_agr_estimate oe
     where oe.agreement_id=l_agreement_id;
end
$$;

