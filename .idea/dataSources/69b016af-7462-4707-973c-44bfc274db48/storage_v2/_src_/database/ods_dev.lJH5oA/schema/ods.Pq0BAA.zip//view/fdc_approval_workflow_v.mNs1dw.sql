CREATE VIEW fdc_approval_workflow_v AS
  SELECT w.id,
    w.approval_iteration_id,
    i.iteration_number,
    i.approval_id,
    w.date_plan,
    w.date_fact,
    w.comments,
    w.approval_status_id,
    s.code AS approval_status_code,
    s.name AS approval_status_name,
    w.approval_template_detail_id,
    w.official_id,
    w.division_id,
    w.organization_id,
    w.organization_group_id,
    w.occupation_id,
    w.approval_stage,
    w.is_obligatory,
    w.send_by_user_id,
    w.send_by_person_id
   FROM fdc_approval_workflow w,
    fdc_approval_status s,
    fdc_approval_iteration i
  WHERE ((s.id = w.approval_status_id) AND (i.id = w.approval_iteration_id));

