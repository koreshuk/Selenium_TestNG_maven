CREATE FUNCTION fdc_estimate_volume_calculate(p_obligation_id bigint DEFAULT NULL::bigint, p_purchase_lot_id bigint DEFAULT NULL::bigint, p_agreement_id bigint DEFAULT NULL::bigint, OUT driveway_qty integer, OUT driveway_with_estimate_qty integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
/** Расчет объемов работ сметы бюджетного обязательства/закупки/обязательства.
  %param p_obligation_id   -- Ид бюджетного обязательства
  %param p_purchase_lot_id -- Ид закупки
  %param p_agreement_id    -- Ид обязательства

  %return  driveway_qty               -- число дорог, включенных в объект
  %return  driveway_with_estimate_qty -- число дорог объекта, для которых рассчитаны объемы работ
*/
  l_sql text;
  l_seasondays_coef double precision;
  l_days_N integer;
  l_days_M integer;
  l_period_intersection boolean;
  l_work_volume double precision;

  rec record;

  l_pholder1 text;
  l_pholder3 text;
  l_pholder7 text;
  l_pholder8 text;
  l_pholder2 text;

  l_object_work_days date[];
  l_work_date_from date;
  l_work_date_to date;
begin
  if p_obligation_id is not null or p_purchase_lot_id is not null or p_agreement_id is not null then
    l_pholder1:=case
                  when p_obligation_id is not null then 'fdc_obligation_estimate'
                  when p_agreement_id is not null then 'fdc_agr_estimate'
                  when p_purchase_lot_id is not null then 'fdc_purchase_estimate'
                end;
    l_pholder2:=case
                  when p_obligation_id is not null then 'fdc_obligation'
                  when p_agreement_id is not null then 'fdc_agreement'
                  when p_purchase_lot_id is not null then 'fdc_purchase'
                end;
    l_pholder3:=case
                  when p_obligation_id is not null then 'obligation_id'
                  when p_agreement_id is not null then 'agreement_id'
                  when p_purchase_lot_id is not null then 'purchase_lot_id'
                end;

    l_pholder7:=case
                  when p_obligation_id is not null then 'fdc_obligation_object'
                  when p_agreement_id is not null then 'fdc_agreement_object'
                  when p_purchase_lot_id is not null then 'fdc_purchase_object'
                end;
    l_pholder8:=case
                  when p_obligation_id is not null then 'obligation_id'
                  when p_agreement_id is not null then 'argeement_id'
                  when p_purchase_lot_id is not null then 'purchase_lot_id'
                end;

    -- 1
    l_sql:=format('delete from msnow.%I where %I=$1',l_pholder1,l_pholder3);
    execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
    -- 2
    if p_obligation_id is not null then
      insert into msnow.fdc_obligation_estimate(id
                                             ,obligation_id
                                             ,driveway_id
                                             ,work_type_id
                                             ,work_volume
                                             ,is_estimate_sum
                                             ,measure_unit_id
                                             )
  with wpi as(select o.id as obligation_id
                    ,lp.parent_root_id as wr_person_id
                    ,o.work_category_id
                    ,owc.code as work_category_code
                from msnow.fdc_obligation o
                join nsi.fdc_legal_person lp on o.authority_org_id=lp.root_id
                join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                join nsi.fdc_role r on pr.role_id=r.id
                join msnow.fdc_work_category owc on o.work_category_id=owc.id
               where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                 and statement_timestamp() between pr.begin_date and pr.end_date
                 and r.code='RUAD'
              union
              select distinct o.id as obligation_id
                             ,o.authority_org_id as wr_person_id
                             ,o.work_category_id
                             ,owc.code as work_category_code
                from msnow.fdc_obligation o
                join nsi.fdc_legal_person lp on o.authority_org_id=lp.root_id
                join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                join nsi.fdc_role r on pr.role_id=r.id
                join msnow.fdc_work_category owc on o.work_category_id=owc.id
               where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                 and statement_timestamp() between pr.begin_date and pr.end_date
                 and r.code in('OMSU','MA')
              union
              select distinct o.id as obligation_id
                    ,o.authority_org_id as wr_person_id
                    ,o.work_category_id
                    ,owc.code as work_category_code
                from msnow.fdc_obligation o
                join nsi.fdc_legal_person lp on o.authority_org_id=lp.root_id
                join msnow.fdc_work_category owc on o.work_category_id=owc.id
               where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                 and lp.fias_district_id is not null
                 and not exists(select null
                                  from nsi.fdc_person_role pr
                                  join nsi.fdc_role r on pr.role_id=r.id
                                 where pr.person_id=o.authority_org_id
                                   and r.code in('OMSU','TO','KO','RUAD','MA')
                               )
             )

        select nextval('ods.fdc_common_seq')
              ,vlm.obligation_id
              ,vlm.driveway_id
              ,vlm.work_type_id
              ,round(vlm.work_volume::numeric,3)
              ,false
              ,vlm.measure_unit_id
          from(select oo.obligation_id
                     ,oo.driveway_id
                     ,wr.work_type_id
                     ,wt.measure_unit_id
                     ,case
                        when dwp.code='DISTANCE' then dw.distance
                        when dwp.code='REDUCED_DISTANCE' then dw.reduced_distance
                        when dwp.code='STOP_COUNT' then dw.stop_count::double precision
                        when dwp.code='ROADWAY_AREA' then dw.roadway_area
                        when dwp.code='HARD_SHOULDER_DISTANCE' then dw.stop_count
                        when dwp.code='EARTH_SHOULDER_DISTANCE' then dw.earth_shoulder_distance
                        when dwp.code='FOOTWAY_AREA' then dw.footway_area
                        when dwp.code='FOOTWAY_DISTANCE' then dw.footway_distance
                        when dwp.code='BOUND_STONE_LENGTH' then dw.bound_stone_length
                        when dwp.code='SIGN_QTY' then dw.sign_qty
                        when dwp.code='TRAFF_LIGHT_QTY' then dw.traff_light_qty
                        when dwp.code='GUIDES_QTY' then dw.guides_qty
                        when dwp.code='PEDESTRIAN_BARRIER_DISTANCE' then dw.pedestrian_barrier_distance
                        when dwp.code='CABLE_BARRIER_DISTANCE' then dw.cable_barrier_distance
                        when dwp.code='PARAPET_BARRIER_DISTANCE' then dw.parapet_barrier_distance
                        when dwp.code='WARNING_SIGN_QTY' then dw.warning_sign_qty
                        when dwp.code='GUIDES_QTY_PCS' then dw.guides_qty_pcs
                        when dwp.code='TUBE_DISTANCE' then dw.tube_distance
                        when dwp.code='TUBE_QTY' then dw.tube_qty
                        when dwp.code='ENCLOSED BUS_STOP_QTY' then dw.enclosed_bus_stop_qty
                        when dwp.code='CROSSING_AREA' then dw.crossing_area
                        when dwp.code='CROSSING_QTY' then dw.crossing_qty
                        when dwp.code='ROAD_RAMP_QTY' then dw.road_ramp_qty
                        when dwp.code='STAND_QTY' then dw.stand_qty
                        when dwp.code='LIGHTING_DISTANCE' then dw.lighting_distance
                        when dwp.code='PLATFORM_QTY' then dw.platform_qty
                        when dwp.code='PLATFORM_AREA' then dw.platform_area
                        when dwp.code='CLEANING_AREA' then dw.cleaning_area
                        when dwp.code='ROADWAY_NOPRKG_CLEAN_AREA' then dw.roadway_noprkg_clean_area
                        when dwp.code='ROADWAY_PRKG_CLEAN_AREA' then dw.roadway_prkg_clean_area
                        when dwp.code='SNOW_AREA' then dw.snow_area
                        when dwp.code='AUTO_FOOTWAY_AREA' then dw.auto_footway_area
                        when dwp.code='MANUAL_FOOTWAY_AREA' then dw.manual_footway_area
                        when dwp.code='STATION_NUMBER' then dw.station_number
                        when dwp.code='STATION_AREA' then dw.station_area
                        when dwp.code='ASPERITY' then dw.asperity
                        when dwp.code='ASPERITY_DISTANCE' then dw.asperity_distance
                        when dwp.code='INFO_QTY' then dw.info_qty
                        when dwp.code='POINTER_QTY' then dw.pointer_qty
                        when dwp.code='STAT_AXES_LENGTH' then dw.stat_axes_length
                        when dwp.code='GUTTERS_LENGTH' then dw.gutters_length
                        when dwp.code='MARGIN_AREA' then dw.margin_area
                        when dwp.code='TRAM_ROAD_LENGTH' then dw.tram_road_length
                        when dwp.code='BICYCLE_AREA' then dw.bicycle_area
                        when dwp.code='BICYCLE_LENGTH' then dw.bicycle_length
                        when dwp.code='BOUND_STONE_LENGTH15' then dw.bound_stone_length / 15.0
                        when dwp.code='ENCLOSED BUS_STOP_QTY100' then dw.enclosed_bus_stop_qty / 100.0
                        when dwp.code='STATION_AREA100' then dw.station_area / 100.0
                      end * wr.cycle_season as work_volume
                 from msnow.fdc_obligation_object oo
                 join wpi on oo.obligation_id=wpi.obligation_id
                 join msnow.fdc_driveway dw on dw.id=oo.driveway_id
                 join msnow.fdc_work_rule wr on wr.odh_group_id=dw.odh_group_id
                                              and (wr.cover_type_id=dw.cover_type_id or wr.cover_type_id is null)
                                              and wr.person_id=wpi.wr_person_id
                 join msnow.fdc_driveway_prop dwp on dwp.id=wr.driveway_prop_id
                 join msnow.fdc_work_type wt on wt.id=wr.work_type_id
                 join msnow.fdc_work_category wtwc on wt.work_category_id=wtwc.id
                where oo.obligation_id=p_obligation_id
                  and (wpi.work_category_code<>'MAINTAIN' or wtwc.code in('MAINTAIN','REPAIR'))
              ) vlm
         where vlm.work_volume>0;
    else
      l_sql:=format('select work_date_from,work_date_to from msnow.%I where id=$1',l_pholder2);
      execute l_sql into l_work_date_from,l_work_date_to using COALESCE(p_purchase_lot_id,p_agreement_id);

      l_object_work_days:=array(select object_work_days
                                  from msnow.fdc_util_get_dates(p_date_from => l_work_date_from
                                                               ,p_date_to   => l_work_date_to
                                                               ) object_work_days
                               );

      l_sql:=format('with wpi as(select o.id as object_id
                                       ,lp.parent_root_id as wr_person_id
                                       ,o.work_category_id
                                       ,owc.code as work_category_code
                                   from msnow.%I o --1
                                   join nsi.fdc_legal_person lp on o.customer_id=lp.root_id
                                   join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                                   join nsi.fdc_role r on pr.role_id=r.id
                                   join msnow.fdc_work_category owc on o.work_category_id=owc.id
                                  where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                                    and statement_timestamp() between pr.begin_date and pr.end_date
                                    and r.code=''RUAD''
                                 union
                                 select distinct o.id as object_id
                                       ,o.customer_id as wr_person_id
                                       ,o.work_category_id
                                       ,owc.code as work_category_code
                                   from msnow.%I o -- 2
                                   join nsi.fdc_legal_person lp on o.customer_id=lp.root_id
                                   join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                                   join nsi.fdc_role r on pr.role_id=r.id
                                   join msnow.fdc_work_category owc on o.work_category_id=owc.id
                                  where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                                    and statement_timestamp() between pr.begin_date and pr.end_date
                                    and r.code in(''OMSU'',''MA'')
                                 union
                                 select distinct o.id as object_id
                                       ,o.customer_id as wr_person_id
                                       ,o.work_category_id
                                       ,owc.code as work_category_code
                                   from msnow.%I o -- 3
                                   join nsi.fdc_legal_person lp on o.customer_id=lp.root_id
                                   join msnow.fdc_work_category owc on o.work_category_id=owc.id
                                  where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                                    and lp.fias_district_id is not null
                                    and not exists(select null
                                                     from nsi.fdc_person_role pr
                                                     join nsi.fdc_role r on pr.role_id=r.id
                                                    where pr.person_id=o.customer_id
                                                      and r.code in(''OMSU'',''TO'',''KO'',''RUAD'',''MA'')
                                                  )
                              )

                     select oo.%I -- A
                           ,oo.driveway_id
                           ,wr.work_type_id
                           ,wt.measure_unit_id
                           ,case
                              when dwp.code=''DISTANCE'' then dw.distance
                              when dwp.code=''REDUCED_DISTANCE'' then dw.reduced_distance
                              when dwp.code=''STOP_COUNT'' then dw.stop_count::double precision
                              when dwp.code=''ROADWAY_AREA'' then dw.roadway_area
                              when dwp.code=''HARD_SHOULDER_DISTANCE'' then dw.stop_count
                              when dwp.code=''EARTH_SHOULDER_DISTANCE'' then dw.earth_shoulder_distance
                              when dwp.code=''FOOTWAY_AREA'' then dw.footway_area
                              when dwp.code=''FOOTWAY_DISTANCE'' then dw.footway_distance
                              when dwp.code=''BOUND_STONE_LENGTH'' then dw.bound_stone_length
                              when dwp.code=''SIGN_QTY'' then dw.sign_qty
                              when dwp.code=''TRAFF_LIGHT_QTY'' then dw.traff_light_qty
                              when dwp.code=''GUIDES_QTY'' then dw.guides_qty
                              when dwp.code=''PEDESTRIAN_BARRIER_DISTANCE'' then dw.pedestrian_barrier_distance
                              when dwp.code=''CABLE_BARRIER_DISTANCE'' then dw.cable_barrier_distance
                              when dwp.code=''PARAPET_BARRIER_DISTANCE'' then dw.parapet_barrier_distance
                              when dwp.code=''WARNING_SIGN_QTY'' then dw.warning_sign_qty
                              when dwp.code=''GUIDES_QTY_PCS'' then dw.guides_qty_pcs
                              when dwp.code=''TUBE_DISTANCE'' then dw.tube_distance
                              when dwp.code=''TUBE_QTY'' then dw.tube_qty
                              when dwp.code=''ENCLOSED BUS_STOP_QTY'' then dw.enclosed_bus_stop_qty
                              when dwp.code=''CROSSING_AREA'' then dw.crossing_area
                              when dwp.code=''CROSSING_QTY'' then dw.crossing_qty
                              when dwp.code=''ROAD_RAMP_QTY'' then dw.road_ramp_qty
                              when dwp.code=''STAND_QTY'' then dw.stand_qty
                              when dwp.code=''LIGHTING_DISTANCE'' then dw.lighting_distance
                              when dwp.code=''PLATFORM_QTY'' then dw.platform_qty
                              when dwp.code=''PLATFORM_AREA'' then dw.platform_area
                              when dwp.code=''CLEANING_AREA'' then dw.cleaning_area
                              when dwp.code=''ROADWAY_NOPRKG_CLEAN_AREA'' then dw.roadway_noprkg_clean_area
                              when dwp.code=''ROADWAY_PRKG_CLEAN_AREA'' then dw.roadway_prkg_clean_area
                              when dwp.code=''SNOW_AREA'' then dw.snow_area
                              when dwp.code=''AUTO_FOOTWAY_AREA'' then dw.auto_footway_area
                              when dwp.code=''MANUAL_FOOTWAY_AREA'' then dw.manual_footway_area
                              when dwp.code=''STATION_NUMBER'' then dw.station_number
                              when dwp.code=''STATION_AREA'' then dw.station_area
                              when dwp.code=''ASPERITY'' then dw.asperity
                              when dwp.code=''ASPERITY_DISTANCE'' then dw.asperity_distance
                              when dwp.code=''INFO_QTY'' then dw.info_qty
                              when dwp.code=''POINTER_QTY'' then dw.pointer_qty
                              when dwp.code=''STAT_AXES_LENGTH'' then dw.stat_axes_length
                              when dwp.code=''GUTTERS_LENGTH'' then dw.gutters_length
                              when dwp.code=''MARGIN_AREA'' then dw.margin_area
                              when dwp.code=''TRAM_ROAD_LENGTH'' then dw.tram_road_length
                              when dwp.code=''BICYCLE_AREA'' then dw.bicycle_area
                              when dwp.code=''BICYCLE_LENGTH'' then dw.bicycle_length
                              when dwp.code=''BOUND_STONE_LENGTH15'' then dw.bound_stone_length / 15.0
                              when dwp.code=''ENCLOSED BUS_STOP_QTY100'' then dw.enclosed_bus_stop_qty / 100.0
                              when dwp.code=''STATION_AREA100'' then dw.station_area / 100.0
                            end driveway_distance
                           ,wr.cycle_season
                           ,wt.season_date_from wt_date_from
                           ,wt.season_date_to   wt_date_to
                           ,o.work_date_from    object_date_from
                           ,o.work_date_to      object_date_to
                           ,array(select work_type_days
                                    from msnow.fdc_util_get_dates(p_date_from => wt.season_date_from
                                                                 ,p_date_to   => wt.season_date_to
                                                                 ) work_type_days
                            ) as wt_date_interval
                       from msnow.%I oo--B
                       join msnow.%I o on o.id=oo.%I -- C, D
                       join wpi on o.id=wpi.object_id
                       join msnow.fdc_driveway dw on dw.id=oo.driveway_id
                       join msnow.fdc_work_rule wr on wr.odh_group_id=dw.odh_group_id
                                                    and (wr.cover_type_id=dw.cover_type_id or wr.cover_type_id is null)
                                                    and wr.person_id=wpi.wr_person_id
                       join msnow.fdc_driveway_prop dwp on dwp.id=wr.driveway_prop_id
                       join msnow.fdc_work_type wt on wt.id=wr.work_type_id
                       join msnow.fdc_work_category wtwc on wt.work_category_id=wtwc.id
                      where oo.%I = $1 -- E
                        and o.work_date_from is not null
                        and o.work_date_to is not null
                        and (wpi.work_category_code<>''MAINTAIN'' or wtwc.code in(''MAINTAIN'',''REPAIR''))'
                    ,l_pholder2,l_pholder2,l_pholder2,l_pholder8,l_pholder7,l_pholder2,l_pholder8,l_pholder8
                   );
      for rec in execute l_sql using COALESCE(p_purchase_lot_id,p_agreement_id) loop
        if rec.wt_date_from is null and rec.wt_date_to is null then
          l_period_intersection:=true;
        elsif rec.wt_date_from > rec.wt_date_to then
          l_period_intersection:=false;
        else
          l_period_intersection:=l_object_work_days&&rec.wt_date_interval;
        end if;

        continue when not coalesce(l_period_intersection,false);

        if rec.wt_date_from is null or rec.wt_date_to is null or rec.object_date_from is null or rec.object_date_to is null then
          l_seasondays_coef:=1.0;
        else
          l_days_N:=cardinality(rec.wt_date_interval);

          select count(1)
            into l_days_M
            from unnest(rec.wt_date_interval) i1
            join unnest(l_object_work_days) i2 on i1=i2;

          l_seasondays_coef:= l_days_M::double precision/l_days_N;
        end if;
        l_work_volume:= rec.driveway_distance * round(rec.cycle_season * l_seasondays_coef);
        continue when not l_work_volume > 0;
        l_sql:=format('insert into msnow.%I(id
                                         ,%I
                                         ,driveway_id
                                         ,work_type_id
                                         ,work_volume
                                         ,measure_unit_id
                                         ,is_estimate_sum
                                         ) values
                            ($1,$2,$3,$4,$5,$6,$7)'
                      ,l_pholder1,l_pholder3
                     );
        execute l_sql using nextval('ods.fdc_common_seq')
                           ,COALESCE(p_purchase_lot_id,p_agreement_id)
                           ,rec.driveway_id
                           ,rec.work_type_id
                           ,round(l_work_volume::numeric,3)
                           ,rec.measure_unit_id
                           ,false;
      end loop;
    end if;
    -- 3,4:
    l_sql:=format('insert into msnow.%I(id,%I,odh_group_id,work_type_id,measure_unit_id,work_volume,is_estimate_sum)
                    select nextval(''ods.fdc_common_seq'')
                          ,oe.%I --A
                          ,dw.odh_group_id
                          ,oe.work_type_id
                          ,wt.measure_unit_id
                          ,round(sum(oe.work_volume)::numeric,3) work_volume
                          ,false
                      from msnow.%I oe--B
                      join msnow.fdc_driveway dw on oe.driveway_id=dw.id
                      join msnow.fdc_work_type wt on oe.work_type_id=wt.id
                     where oe.%I=$1 -- C
                       and oe.driveway_id is not null
                       and not oe.is_estimate_sum
                     group by oe.%I --D
                             ,dw.odh_group_id
                             ,oe.work_type_id
                             ,wt.measure_unit_id'
                  ,l_pholder1,l_pholder3,l_pholder3,l_pholder1,l_pholder3,l_pholder3
                 );
    execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
    -- 5:
    l_sql:=format('insert into msnow.%I(id,%I,work_type_id,measure_unit_id,work_volume,is_estimate_sum)
                     select nextval(''ods.fdc_common_seq'')
                           ,oe.%I
                           ,oe.work_type_id
                           ,wt.measure_unit_id
                           ,round(sum(oe.work_volume)::numeric,3) work_volume
                           ,true
                       from msnow.%I oe
                       join msnow.fdc_work_type wt on oe.work_type_id=wt.id
                      where oe.%I=$1
                        and oe.driveway_id is null
                        and oe.odh_group_id is not null
                        and not oe.is_estimate_sum
                      group by oe.%I
                              ,oe.work_type_id
                              ,wt.measure_unit_id'
                  ,l_pholder1,l_pholder3,l_pholder3,l_pholder1,l_pholder3,l_pholder3
                 );
    execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);

    -- 6:
    l_sql:=format('select count(distinct oo.driveway_id) N
                         ,count(distinct oe.driveway_id) M
                     from msnow.%I oo
                     left join msnow.%I oe on oe.%I=oo.%I
                                            and oe.driveway_id=oo.driveway_id
                    where oo.%I=$1'
                  ,l_pholder7,l_pholder1,l_pholder3,l_pholder8,l_pholder8
                 );
    execute l_sql into driveway_qty,driveway_with_estimate_qty using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
  end if;
end
$$;

