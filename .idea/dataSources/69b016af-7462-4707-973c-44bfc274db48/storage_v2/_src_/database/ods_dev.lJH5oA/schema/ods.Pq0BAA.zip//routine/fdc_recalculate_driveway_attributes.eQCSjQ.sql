CREATE FUNCTION fdc_recalculate_driveway_attributes(p_driveway_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /*  Процедура расчета атрибутов дороги на основании подобъектов дороги
    %param p_driveway_id - Ид версии дороги
  */
  l_object ods.fdc_object%rowtype;
  l_odh ods.fdc_odh%rowtype;
  l_odh_calculation ods.fdc_odh_calculation%rowtype;

  l_geometry_json text;
begin
  select ST_asgeojson((ST_Multi(ST_Union(sobj.geometry))))
    into l_geometry_json
    from ods.fdc_object_link ol
    join ods.fdc_object sobj on ol.object_id_2=sobj.id
   where ol.object_id_1=p_driveway_id
     and geometrytype(sobj.geometry)='LINESTRING';

  select clc.distance --odh
        ,clc.total_area --obj
        ,clc.internal_area --calc
        ,clc.total_area_calc--calc
        ,clc.roadway_area--calc
        ,clc.stat_axes_length--calc
        ,clc.margin_area--calc
        ,clc.footway_area--calc
        ,clc.other_flat_area--calc
        ,clc.tram_road_length--calc
        ,clc.gutters_length--calc
        ,clc.bound_stone_area_plan--calc
        ,clc.bound_stone_area--calc
        ,clc.planting_area--calc
        ,clc.engin_constr_qty--calc
        ,clc.bus_stop_qty--calc
        ,clc.sign_qty--calc
        ,clc.pointer_qty--calc
        ,clc.traff_light_qty--calc
        ,clc.guides_qty_pcs--calc
        ,clc.guides_qty--calc
        ,clc.guides_qty_sqr--calc
        ,clc.bicycle_area--calc
        ,clc.bicycle_length--calc
        ,clc.tpu_area --calc
        ,clc.cleaning_area --calc
        ,clc.roadway_noprkg_clean_area--calc
        ,clc.roadway_prkg_clean_area--calc
        ,clc.auto_footway_area--calc
        ,clc.manual_footway_area--calc
        ,clc.snow_area--calc
        ,clc.rotor_area--calc
        ,clc.station_area--calc
        ,clc.bar_new_jersey--calc
        ,clc.station_number--calc
        ,clc.protective_wall--calc
        ,clc.buffer--calc
        ,clc.asperity--calc
        ,clc.bound_stone_length--calc
        ,clc.info_qty--calc
        ,clc.hard_shoulder_distance--calc
        ,clc.earth_shoulder_distance--calc
        ,clc.footway_distance--calc
        ,clc.sign_design_qty--calc
        ,clc.sign_design_sqr--calc
        ,clc.pedestrian_barrier_distance --calc
        ,clc.cable_barrier_distance --calc
        ,clc.parapet_barrier_distance--calc
        ,clc.warning_sign_qty --calc
        ,clc.tube_distance--calc
        ,clc.tube_qty--calc
        ,clc.enclosed_bus_stop_qty--calc
        ,clc.crossing_area--calc
        ,clc.crossing_qty--calc
        ,clc.road_ramp_qty--calc
        ,clc.stand_qty--calc
        ,clc.lighting_distance--calc
        ,clc.platform_qty--calc
        ,clc.platform_area--calc
        ,clc.asperity_distance--calc
        ,clc.roadway_width_min
        ,clc.roadway_width_max
        ,clc.traffic_lane_qty_min
        ,clc.traffic_lane_qty_max
        ---
        ,case
           when clc.customer_id_qty=1 then pobj.customer_id
         end --obj
        ,case
           when clc.owner_id_qty=1 then pobj.owner_id--obj
         end
        ,case
           when clc.as_area_id_qty=1 then pobj.as_area_id --obj
         end
        ,case
           when clc.as_place_id_qty=1 then pobj.as_place_id  --obj
         end
        ,case
           when clc.as_street_id_qty=1 then pobj.as_street_id  --obj
         end
        ,case
           when clc.is_orphan_object_qty=1 then podh.is_orphan_object  --sodh
         end
        ,case
           when clc.register_code_qty=1 then podh.register_code --sodh
         end
        ,case
           when clc.edit_reason_id_qty=1 then podh.edit_reason_id --sodh
         end
        ,case
          when clc.driveway_category_id_qty=1 then pobj.driveway_category_id  --sodh
         end
        ,case
           when clc.driveway_gost_category_id_qty=1 then podh.driveway_gost_category_id --sodh
         end
        ,case
           when clc.cover_type_id_qty=1 then podh.cover_type_id  --sodh
         end
        ,case
           when clc.maintain_group_id_qty=1 then podh.maintain_group_id --sodh
         end
        ,case
           when clc.manufacturing_complex_id_qty=1 then podh.manufacturing_complex_id --sodh
         end
    into l_odh.distance --odh
        ,l_object.total_area --obj
        ,l_odh_calculation.internal_area --calc
        ,l_odh_calculation.total_area--calc
        ,l_odh_calculation.roadway_area--calc
        ,l_odh_calculation.stat_axes_length--calc
        ,l_odh_calculation.margin_area--calc
        ,l_odh_calculation.footway_area--calc
        ,l_odh_calculation.other_flat_area--calc
        ,l_odh_calculation.tram_road_length--calc
        ,l_odh_calculation.gutters_length--calc
        ,l_odh_calculation.bound_stone_area_plan--calc
        ,l_odh_calculation.bound_stone_area--calc
        ,l_odh_calculation.planting_area--calc
        ,l_odh_calculation.engin_constr_qty--calc
        ,l_odh_calculation.bus_stop_qty--calc
        ,l_odh_calculation.sign_qty--calc
        ,l_odh_calculation.pointer_qty--calc
        ,l_odh_calculation.traff_light_qty--calc
        ,l_odh_calculation.guides_qty_pcs--calc
        ,l_odh_calculation.guides_qty--calc
        ,l_odh_calculation.guides_qty_sqr--calc
        ,l_odh_calculation.bicycle_area--calc
        ,l_odh_calculation.bicycle_length--calc
        ,l_odh_calculation.tpu_area --calc
        ,l_odh_calculation.cleaning_area --calc
        ,l_odh_calculation.roadway_noprkg_clean_area--calc
        ,l_odh_calculation.roadway_prkg_clean_area--calc
        ,l_odh_calculation.auto_footway_area--calc
        ,l_odh_calculation.manual_footway_area--calc
        ,l_odh_calculation.snow_area--calc
        ,l_odh_calculation.rotor_area--calc
        ,l_odh_calculation.station_area--calc
        ,l_odh_calculation.bar_new_jersey--calc
        ,l_odh_calculation.station_number--calc
        ,l_odh_calculation.protective_wall--calc
        ,l_odh_calculation.buffer--calc
        ,l_odh_calculation.asperity--calc
        ,l_odh_calculation.bound_stone_length--calc
        ,l_odh_calculation.info_qty--calc
        ,l_odh_calculation.hard_shoulder_distance--calc
        ,l_odh_calculation.earth_shoulder_distance--calc
        ,l_odh_calculation.footway_distance--calc
        ,l_odh_calculation.sign_design_qty--calc
        ,l_odh_calculation.sign_design_sqr--calc
        ,l_odh_calculation.pedestrian_barrier_distance --calc
        ,l_odh_calculation.cable_barrier_distance --calc
        ,l_odh_calculation.parapet_barrier_distance--calc
        ,l_odh_calculation.warning_sign_qty --calc
        ,l_odh_calculation.tube_distance--calc
        ,l_odh_calculation.tube_qty--calc
        ,l_odh_calculation.enclosed_bus_stop_qty--calc
        ,l_odh_calculation.crossing_area--calc
        ,l_odh_calculation.crossing_qty--calc
        ,l_odh_calculation.road_ramp_qty--calc
        ,l_odh_calculation.stand_qty--calc
        ,l_odh_calculation.lighting_distance--calc
        ,l_odh_calculation.platform_qty--calc
        ,l_odh_calculation.platform_area--calc
        ,l_odh_calculation.asperity_distance--calc
        -----
        ,l_odh_calculation.roadway_width_min
        ,l_odh_calculation.roadway_width_max
        ,l_odh_calculation.traffic_lane_qty_min
        ,l_odh_calculation.traffic_lane_qty_max
        -----
        ,l_object.customer_id
        ,l_object.owner_id
        ,l_object.as_area_id
        ,l_object.as_place_id
        ,l_object.as_street_id

        ,l_odh.is_orphan_object
        ,l_odh.register_code
        ,l_odh.edit_reason_id
        ,l_object.driveway_category_id
        ,l_odh.driveway_gost_category_id
        ,l_odh.cover_type_id
        ,l_odh.maintain_group_id
        ,l_odh.manufacturing_complex_id
    from(select sum(sodh.distance) as distance
               ,sum(sobj.total_area) as total_area
               ,sum(scalc.internal_area) as internal_area
               ,sum(scalc.total_area) as total_area_calc
               ,sum(scalc.roadway_area) as roadway_area
               ,sum(scalc.stat_axes_length) as stat_axes_length
               ,sum(scalc.margin_area) as margin_area
               ,sum(scalc.footway_area) as footway_area
               ,sum(scalc.other_flat_area) as other_flat_area
               ,sum(scalc.tram_road_length) as tram_road_length
               ,sum(scalc.gutters_length) as gutters_length
               ,sum(scalc.bound_stone_area_plan) as bound_stone_area_plan
               ,sum(scalc.bound_stone_area) as bound_stone_area
               ,sum(scalc.planting_area) as planting_area
               ,sum(scalc.engin_constr_qty) as engin_constr_qty
               ,sum(scalc.bus_stop_qty) as bus_stop_qty
               ,sum(scalc.sign_qty) as sign_qty
               ,sum(scalc.pointer_qty) as pointer_qty
               ,sum(scalc.traff_light_qty) as traff_light_qty
               ,sum(scalc.guides_qty_pcs) as guides_qty_pcs
               ,sum(scalc.guides_qty) as guides_qty
               ,sum(scalc.guides_qty_sqr) as guides_qty_sqr
               ,sum(scalc.bicycle_area) as bicycle_area
               ,sum(scalc.bicycle_length) as bicycle_length
               ,sum(scalc.tpu_area) as tpu_area
               ,sum(scalc.cleaning_area) as cleaning_area
               ,sum(scalc.roadway_noprkg_clean_area) as roadway_noprkg_clean_area
               ,sum(scalc.roadway_prkg_clean_area) as roadway_prkg_clean_area
               ,sum(scalc.auto_footway_area) as auto_footway_area
               ,sum(scalc.manual_footway_area) as manual_footway_area
               ,sum(scalc.snow_area) as snow_area
               ,sum(scalc.rotor_area) as rotor_area
               ,sum(scalc.station_area) as station_area
               ,sum(scalc.bar_new_jersey) as bar_new_jersey
               ,sum(scalc.station_number) as station_number
               ,sum(scalc.protective_wall) as protective_wall
               ,sum(scalc.buffer) as buffer
               ,sum(scalc.asperity) as asperity
               ,sum(scalc.bound_stone_length) as bound_stone_length
               ,sum(scalc.info_qty) as info_qty
               ,sum(scalc.hard_shoulder_distance) as hard_shoulder_distance
               ,sum(scalc.earth_shoulder_distance) as earth_shoulder_distance
               ,sum(scalc.footway_distance) as footway_distance
               ,sum(scalc.sign_design_qty) as sign_design_qty
               ,sum(scalc.sign_design_sqr) as sign_design_sqr
               ,sum(scalc.pedestrian_barrier_distance) as pedestrian_barrier_distance
               ,sum(scalc.cable_barrier_distance) as cable_barrier_distance
               ,sum(scalc.parapet_barrier_distance) as parapet_barrier_distance
               ,sum(scalc.warning_sign_qty) as warning_sign_qty
               ,sum(scalc.tube_distance) as tube_distance
               ,sum(scalc.tube_qty) as tube_qty
               ,sum(scalc.enclosed_bus_stop_qty) as enclosed_bus_stop_qty
               ,sum(scalc.crossing_area) as crossing_area
               ,sum(scalc.crossing_qty) as crossing_qty
               ,sum(scalc.road_ramp_qty) as road_ramp_qty
               ,sum(scalc.stand_qty) as stand_qty
               ,sum(scalc.lighting_distance) as lighting_distance
               ,sum(scalc.platform_qty) as platform_qty
               ,sum(scalc.platform_area) as platform_area
               ,sum(scalc.asperity_distance) as asperity_distance
               --
               ,min(sodh.roadway_width) as roadway_width_min
               ,max(sodh.roadway_width) as roadway_width_max
               ,min(sodh.traffic_lane_qty) as traffic_lane_qty_min
               ,max(sodh.traffic_lane_qty) as traffic_lane_qty_max
               --
               ,count(distinct coalesce(sobj.customer_id,0)) as customer_id_qty
               ,count(distinct coalesce(sobj.owner_id,0)) as owner_id_qty
               ,count(distinct coalesce(sobj.as_area_id,0)) as as_area_id_qty
               ,count(distinct coalesce(sobj.as_place_id,0)) as as_place_id_qty
               ,count(distinct coalesce(sobj.as_street_id,0)) as as_street_id_qty
               ,count(distinct coalesce(sodh.is_orphan_object::integer,-1)) as is_orphan_object_qty
               ,count(distinct coalesce(sodh.register_code,'')) as register_code_qty
               ,count(distinct coalesce(sodh.edit_reason_id,0)) as edit_reason_id_qty
               ,count(distinct coalesce(sobj.driveway_category_id,0)) as driveway_category_id_qty
               ,count(distinct coalesce(sodh.driveway_gost_category_id,0)) as driveway_gost_category_id_qty
               ,count(distinct coalesce(sodh.cover_type_id,0)) as cover_type_id_qty
               ,count(distinct coalesce(sodh.maintain_group_id,0)) as maintain_group_id_qty
               ,count(distinct coalesce(sodh.manufacturing_complex_id,0)) as manufacturing_complex_id_qty
               ,max(sobj.id) as ptrn_object_id
           from ods.fdc_object_link ol
           join ods.fdc_object probj on ol.object_id_1=probj.id
           join ods.fdc_object sobj on ol.object_id_2=sobj.id
           join ods.fdc_odh sodh on sobj.id=sodh.id
           left join ods.fdc_odh_calculation scalc on sobj.id=scalc.id
          where ol.object_id_1=p_driveway_id
            --and probj.version_date_from between sobj.version_date_from and sobj.version_date_to
        ) clc
    join ods.fdc_object pobj on clc.ptrn_object_id=pobj.id
    join ods.fdc_odh podh on clc.ptrn_object_id=podh.id;

  update ods.fdc_object
     set total_area=l_object.total_area
        ,customer_id=l_object.customer_id
        ,owner_id=l_object.owner_id
        ,as_area_id=l_object.as_area_id
        ,as_place_id=l_object.as_place_id
        ,as_street_id=l_object.as_street_id
        ,geometry_json=l_geometry_json
        ,driveway_category_id      = l_object.driveway_category_id
   where id=p_driveway_id;

  update ods.fdc_driveway
     set driveway_length           = l_odh.distance
        ,is_orphan_object          = l_odh.is_orphan_object
        ,rgn                       = l_odh.register_code
        --,driveway_category_id      = l_odh.driveway_category_id
        ,driveway_gost_category_id = l_odh.driveway_gost_category_id
        ,cover_type_id             = l_odh.cover_type_id
        ,maintain_group_id         = l_odh.maintain_group_id
   where id=p_driveway_id;

  insert into ods.fdc_odh_calculation(id
                                     ,internal_area
                                     ,total_area
                                     ,roadway_area
                                     ,stat_axes_length
                                     ,margin_area
                                     ,footway_area
                                     ,other_flat_area
                                     ,tram_road_length
                                     ,gutters_length
                                     ,bound_stone_area_plan
                                     ,bound_stone_area
                                     ,planting_area
                                     ,engin_constr_qty
                                     ,bus_stop_qty
                                     ,sign_qty
                                     ,pointer_qty
                                     ,traff_light_qty
                                     ,guides_qty_pcs
                                     ,guides_qty
                                     ,guides_qty_sqr
                                     ,bicycle_area
                                     ,bicycle_length
                                     ,tpu_area
                                     ,cleaning_area
                                     ,roadway_noprkg_clean_area
                                     ,roadway_prkg_clean_area
                                     ,auto_footway_area
                                     ,manual_footway_area
                                     ,snow_area
                                     ,rotor_area
                                     ,station_area
                                     ,bar_new_jersey
                                     ,station_number
                                     ,protective_wall
                                     ,buffer
                                     ,asperity
                                     ,bound_stone_length
                                     ,info_qty
                                     ,hard_shoulder_distance
                                     ,earth_shoulder_distance
                                     ,footway_distance
                                     ,sign_design_qty
                                     ,sign_design_sqr
                                     ,pedestrian_barrier_distance
                                     ,cable_barrier_distance
                                     ,parapet_barrier_distance
                                     ,warning_sign_qty
                                     ,tube_distance
                                     ,tube_qty
                                     ,enclosed_bus_stop_qty
                                     ,crossing_area
                                     ,crossing_qty
                                     ,road_ramp_qty
                                     ,stand_qty
                                     ,lighting_distance
                                     ,platform_qty
                                     ,platform_area
                                     ,asperity_distance
                                     ,roadway_width_min
                                     ,roadway_width_max
                                     ,traffic_lane_qty_min
                                     ,traffic_lane_qty_max
                                     ) values
       (p_driveway_id
       ,l_odh_calculation.internal_area --calc
       ,l_odh_calculation.total_area--calc
       ,l_odh_calculation.roadway_area--calc
       ,l_odh_calculation.stat_axes_length--calc
       ,l_odh_calculation.margin_area--calc
       ,l_odh_calculation.footway_area--calc
       ,l_odh_calculation.other_flat_area--calc
       ,l_odh_calculation.tram_road_length--calc
       ,l_odh_calculation.gutters_length--calc
       ,l_odh_calculation.bound_stone_area_plan--calc
       ,l_odh_calculation.bound_stone_area--calc
       ,l_odh_calculation.planting_area--calc
       ,l_odh_calculation.engin_constr_qty--calc
       ,l_odh_calculation.bus_stop_qty--calc
       ,l_odh_calculation.sign_qty--calc
       ,l_odh_calculation.pointer_qty--calc
       ,l_odh_calculation.traff_light_qty--calc
       ,l_odh_calculation.guides_qty_pcs--calc
       ,l_odh_calculation.guides_qty--calc
       ,l_odh_calculation.guides_qty_sqr--calc
       ,l_odh_calculation.bicycle_area--calc
       ,l_odh_calculation.bicycle_length--calc
       ,l_odh_calculation.tpu_area --calc
       ,l_odh_calculation.cleaning_area --calc
       ,l_odh_calculation.roadway_noprkg_clean_area--calc
       ,l_odh_calculation.roadway_prkg_clean_area--calc
       ,l_odh_calculation.auto_footway_area--calc
       ,l_odh_calculation.manual_footway_area--calc
       ,l_odh_calculation.snow_area--calc
       ,l_odh_calculation.rotor_area--calc
       ,l_odh_calculation.station_area--calc
       ,l_odh_calculation.bar_new_jersey--calc
       ,l_odh_calculation.station_number--calc
       ,l_odh_calculation.protective_wall--calc
       ,l_odh_calculation.buffer--calc
       ,l_odh_calculation.asperity--calc
       ,l_odh_calculation.bound_stone_length--calc
       ,l_odh_calculation.info_qty--calc
       ,l_odh_calculation.hard_shoulder_distance--calc
       ,l_odh_calculation.earth_shoulder_distance--calc
       ,l_odh_calculation.footway_distance--calc
       ,l_odh_calculation.sign_design_qty--calc
       ,l_odh_calculation.sign_design_sqr--calc
       ,l_odh_calculation.pedestrian_barrier_distance --calc
       ,l_odh_calculation.cable_barrier_distance --calc
       ,l_odh_calculation.parapet_barrier_distance--calc
       ,l_odh_calculation.warning_sign_qty --calc
       ,l_odh_calculation.tube_distance--calc
       ,l_odh_calculation.tube_qty--calc
       ,l_odh_calculation.enclosed_bus_stop_qty--calc
       ,l_odh_calculation.crossing_area--calc
       ,l_odh_calculation.crossing_qty--calc
       ,l_odh_calculation.road_ramp_qty--calc
       ,l_odh_calculation.stand_qty--calc
       ,l_odh_calculation.lighting_distance--calc
       ,l_odh_calculation.platform_qty--calc
       ,l_odh_calculation.platform_area--calc
       ,l_odh_calculation.asperity_distance
       ,l_odh_calculation.roadway_width_min
       ,l_odh_calculation.roadway_width_max
       ,l_odh_calculation.traffic_lane_qty_min
       ,l_odh_calculation.traffic_lane_qty_max
       )
    on conflict(id) do update
     set internal_area=excluded.internal_area --calc
        ,total_area=excluded.total_area--calc
        ,roadway_area=excluded.roadway_area--calc
        ,stat_axes_length=excluded.stat_axes_length--calc
        ,margin_area=excluded.margin_area--calc
        ,footway_area=excluded.footway_area--calc
        ,other_flat_area=excluded.other_flat_area--calc
        ,tram_road_length=excluded.tram_road_length--calc
        ,gutters_length=excluded.gutters_length--calc
        ,bound_stone_area_plan=excluded.bound_stone_area_plan--calc
        ,bound_stone_area=excluded.bound_stone_area--calc
        ,planting_area=excluded.planting_area--calc
        ,engin_constr_qty=excluded.engin_constr_qty--calc
        ,bus_stop_qty=excluded.bus_stop_qty--calc
        ,sign_qty=excluded.sign_qty--calc
        ,pointer_qty=excluded.pointer_qty--calc
        ,traff_light_qty=excluded.traff_light_qty--calc
        ,guides_qty_pcs=excluded.guides_qty_pcs--calc
        ,guides_qty=excluded.guides_qty--calc
        ,guides_qty_sqr=excluded.guides_qty_sqr--calc
        ,bicycle_area=excluded.bicycle_area--calc
        ,bicycle_length=excluded.bicycle_length--calc
        ,tpu_area=excluded.tpu_area --calc
        ,cleaning_area=excluded.cleaning_area --calc
        ,roadway_noprkg_clean_area=excluded.roadway_noprkg_clean_area--calc
        ,roadway_prkg_clean_area=excluded.roadway_prkg_clean_area--calc
        ,auto_footway_area=excluded.auto_footway_area--calc
        ,manual_footway_area=excluded.manual_footway_area--calc
        ,snow_area=excluded.snow_area--calc
        ,rotor_area=excluded.rotor_area--calc
        ,station_area=excluded.station_area--calc
        ,bar_new_jersey=excluded.bar_new_jersey--calc
        ,station_number=excluded.station_number--calc
        ,protective_wall=excluded.protective_wall--calc
        ,buffer=excluded.buffer--calc
        ,asperity=excluded.asperity--calc
        ,bound_stone_length=excluded.bound_stone_length--calc
        ,info_qty=excluded.info_qty--calc
        ,hard_shoulder_distance=excluded.hard_shoulder_distance--calc
        ,earth_shoulder_distance=excluded.earth_shoulder_distance--calc
        ,footway_distance=excluded.footway_distance--calc
        ,sign_design_qty=excluded.sign_design_qty--calc
        ,sign_design_sqr=excluded.sign_design_sqr--calc
        ,pedestrian_barrier_distance=excluded.pedestrian_barrier_distance --calc
        ,cable_barrier_distance=excluded.cable_barrier_distance --calc
        ,parapet_barrier_distance=excluded.parapet_barrier_distance--calc
        ,warning_sign_qty=excluded.warning_sign_qty --calc
        ,tube_distance=excluded.tube_distance--calc
        ,tube_qty=excluded.tube_qty--calc
        ,enclosed_bus_stop_qty=excluded.enclosed_bus_stop_qty--calc
        ,crossing_area=excluded.crossing_area--calc
        ,crossing_qty=excluded.crossing_qty--calc
        ,road_ramp_qty=excluded.road_ramp_qty--calc
        ,stand_qty=excluded.stand_qty--calc
        ,lighting_distance=excluded.lighting_distance--calc
        ,platform_qty=excluded.platform_qty--calc
        ,platform_area=excluded.platform_area--calc
        ,asperity_distance=excluded.asperity_distance
        ,roadway_width_min=excluded.roadway_width_min
        ,roadway_width_max=excluded.roadway_width_max
        ,traffic_lane_qty_min=excluded.traffic_lane_qty_min
        ,traffic_lane_qty_max=excluded.traffic_lane_qty_max;
  return;
end
$$;

