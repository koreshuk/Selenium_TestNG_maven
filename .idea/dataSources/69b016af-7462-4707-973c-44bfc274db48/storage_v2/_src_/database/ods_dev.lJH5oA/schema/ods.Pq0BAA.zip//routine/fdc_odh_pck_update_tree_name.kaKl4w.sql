CREATE FUNCTION fdc_odh_pck_update_tree_name(p_object_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Устанавливает название ОГХ для отображения в дереве
  %param p_object_id      Ид ОГХ
  */
  l_tree_name ods.fdc_object.tree_name%type;
begin
  /* Обновляем название объекта в дереве*/
  select to_char(o.root_id,ods.c_bigint_format())||' '||o.name
    into l_tree_name
    from ods.fdc_object o
   where o.id = p_object_id;

  update ods.fdc_object
     set tree_name = l_tree_name
  where id = p_object_id;
end
$$;

