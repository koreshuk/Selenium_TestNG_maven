CREATE FUNCTION scr_purchase2agreement(p_purchase_id bigint, p_agreement_id bigint, p_driveway_list text DEFAULT NULL::text)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Скрипт по переносу дорог и смет из закупки в обязательств(контракт). Содержание
  %param p_purchase_id   - Ид закупки
  %param p_agreement_id  - Ид обязательства
  %param p_driveway_list - Список участков дорог из закупки
  */
  l_agreement_id msnow.fdc_agreement.id%type;
  l_purchase_id msnow.fdc_purchase.id%type;

  l_agreement_type_code msnow.fdc_agreement_type.code%type;
  l_agreement_work_date_from msnow.fdc_agreement.work_date_from%type;

  l_purchase_decrease msnow.fdc_purchase.decrease%type;

  l_driveway_list bigint[];

  l_purchase_object_qty integer;
  l_copy_all boolean;

  rec record;
begin
  if p_driveway_list is not null then
    begin
      l_driveway_list:=string_to_array(p_driveway_list,',');
    exception
      when others then
        raise exception 'Некорректный формат списка идентификаторов участков дорог.';
    end;
  end if;

  begin
    select agr.id
          ,agrt.code
          ,agr.work_date_from
      into strict l_agreement_id
          ,l_agreement_type_code
          ,l_agreement_work_date_from
      from msnow.fdc_agreement agr
      join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
     where agr.id=p_agreement_id;
  exception
    when NO_DATA_FOUND then
      raise exception 'Не найдено обязательство с идентификатором %',p_agreement_id;
  end;

  if l_agreement_type_code not in('CONTRACT','MUNICIPAL_CONTRACT') then
    raise exception 'Недопустимый тип обязательства %',l_agreement_type_code;
  end if;

  begin
    select id
          ,decrease
      into strict l_purchase_id
          ,l_purchase_decrease
      from msnow.fdc_purchase
     where id=p_purchase_id;
  exception
    when NO_DATA_FOUND then
      raise exception 'Не найдена закупка с идентификатором %',p_purchase_id;
  end;

  select count(distinct driveway_id)
    into l_purchase_object_qty
    from msnow.fdc_purchase_object
   where purchase_lot_id=l_purchase_id;

  l_copy_all:=case
                when p_driveway_list is null then true
                when l_purchase_object_qty = cardinality(l_driveway_list) then true
                else false
              end;

  delete from msnow.fdc_agr_estimate where agreement_id=l_agreement_id;
  delete from msnow.fdc_agreement_object where argeement_id=l_agreement_id;

  -- копируем участки
  insert into msnow.fdc_agreement_object(id,argeement_id,driveway_id)
    select nextval('ods.fdc_common_seq')
          ,l_agreement_id
          ,aobj.id
      from msnow.fdc_purchase_object oo
      join ods.fdc_odh odh on oo.driveway_id=odh.id
      join ods.fdc_object obj on odh.id=obj.id
      join ods.fdc_object aobj on obj.root_id=aobj.root_id
                                  and l_agreement_work_date_from between aobj.version_date_from and aobj.version_date_to
     where oo.purchase_lot_id=l_purchase_id
       and(l_copy_all or oo.driveway_id in(select unnest(l_driveway_list)));

  -- копируем все сметы на уровне участка:
  insert into msnow.fdc_agr_estimate(id,agreement_id,driveway_id,work_type_id,work_volume
                                    ,measure_unit_id,work_cost,is_estimate_sum,odh_group_id)
    select nextval('ods.fdc_common_seq')
          ,l_agreement_id
          ,aobj.id
          ,oe.work_type_id
          ,oe.work_volume
          ,oe.measure_unit_id
          ,case
             when l_purchase_decrease is null then
               oe.work_cost
             else
               oe.work_cost - ((l_purchase_decrease/100) * oe.work_cost)
           end
          ,oe.is_estimate_sum
          ,oe.odh_group_id
      from msnow.fdc_purchase_estimate oe
      join ods.fdc_odh odh on oe.driveway_id=odh.id
      join ods.fdc_object obj on odh.id=obj.id
      join ods.fdc_object aobj on obj.root_id=aobj.root_id
                                  and l_agreement_work_date_from between aobj.version_date_from and aobj.version_date_to
     where oe.purchase_lot_id=l_purchase_id
       and not oe.is_estimate_sum
       and ((l_copy_all and oe.driveway_id is not null) or
            ((not l_copy_all) and oe.driveway_id in(select unnest(l_driveway_list)))
           );
  -- копируем сметы на уровне группы:
  if l_copy_all then
    insert into msnow.fdc_agr_estimate(id
                                      ,agreement_id
                                      ,odh_group_id
                                      ,work_type_id
                                      ,work_volume
                                      ,measure_unit_id
                                      ,work_cost
                                      ,is_estimate_sum
                                      )
       select nextval('ods.fdc_common_seq')
             ,l_agreement_id
             ,pe.odh_group_id
             ,pe.work_type_id
             ,pe.work_volume
             ,pe.measure_unit_id
             ,case
                when (l_purchase_decrease is null or l_purchase_decrease = 0) then
                  pe.work_cost
                else
                  pe.work_cost - ((l_purchase_decrease/100) * pe.work_cost)
              end
             ,pe.is_estimate_sum
         from msnow.fdc_purchase_estimate pe
        where pe.purchase_lot_id=l_purchase_id
          and pe.odh_group_id is not null
          and not pe.is_estimate_sum;
  end if;
  for rec in(select tt.odh_group_id
                   ,count(distinct driveway_id) as objects_in_group
                   ,count(distinct list_driveway_id) as objects_in_list
               from(select odh.maintain_group_id as odh_group_id
                          ,oe.driveway_id
                          ,case
                             when l_copy_all then oe.driveway_id
                             else lst
                           end as list_driveway_id
                      from msnow.fdc_purchase_estimate oe
                      join ods.fdc_odh odh on oe.driveway_id=odh.id
                      join unnest(l_driveway_list) lst on oe.driveway_id=lst
                     where oe.purchase_lot_id=l_purchase_id
                       and not oe.is_estimate_sum
                       and oe.driveway_id is not null
                   ) tt
              group by tt.odh_group_id
            ) loop
    if rec.objects_in_group=rec.objects_in_list then
      insert into msnow.fdc_agr_estimate(id
                                        ,agreement_id
                                        ,odh_group_id
                                        ,work_type_id
                                        ,work_volume
                                        ,measure_unit_id
                                        ,work_cost
                                        ,is_estimate_sum
                                        )
         select nextval('ods.fdc_common_seq')
               ,l_agreement_id
               ,pe.odh_group_id
               ,pe.work_type_id
               ,pe.work_volume
               ,pe.measure_unit_id
               ,case
                  when (l_purchase_decrease is null or l_purchase_decrease = 0) then
                    pe.work_cost
                  else
                    pe.work_cost - ((l_purchase_decrease/100) * pe.work_cost)
                end
               ,pe.is_estimate_sum
           from msnow.fdc_purchase_estimate pe
          where pe.purchase_lot_id=l_purchase_id
            and pe.odh_group_id=rec.odh_group_id
            and not pe.is_estimate_sum;
    else
      insert into msnow.fdc_agr_estimate(id
                                        ,agreement_id
                                        ,odh_group_id
                                        ,work_type_id
                                        ,work_volume
                                        ,measure_unit_id
                                        ,work_cost
                                        ,is_estimate_sum
                                        )
         select nextval('ods.fdc_common_seq')
               ,l_agreement_id
               ,odh.maintain_group_id
               ,pe.work_type_id
               ,sum(pe.work_volume)
               ,pe.measure_unit_id
               ,sum(case
                      when l_purchase_decrease is null or l_purchase_decrease = 0  then
                        pe.work_cost
                      else
                        pe.work_cost - ((l_purchase_decrease/100) * pe.work_cost)
                    end
                   )
               ,pe.is_estimate_sum
           from msnow.fdc_purchase_estimate pe
           join ods.fdc_odh odh on pe.driveway_id=odh.id
          where pe.purchase_lot_id=l_purchase_id
            and pe.odh_group_id is null
            and not pe.is_estimate_sum
            and pe.driveway_id is not null
            and odh.maintain_group_id=rec.odh_group_id
          group by l_agreement_id
                  ,pe.odh_group_id
                  ,pe.work_type_id
                  ,pe.measure_unit_id
                  ,pe.is_estimate_sum;

    end if;
  end loop;
  -- вычисляем сводные сметы
  insert into msnow.fdc_agr_estimate(id,agreement_id,work_type_id
                                     ,measure_unit_id,work_volume,work_cost,is_estimate_sum)
    select nextval('ods.fdc_common_seq')
          ,oe.agreement_id
          ,oe.work_type_id
          ,wt.measure_unit_id
          ,round(sum(oe.work_volume)::numeric,3) work_volume
          ,round(sum(oe.work_cost)::numeric,2) work_cost
          ,true
      from msnow.fdc_agr_estimate oe
      join msnow.fdc_work_type wt on oe.work_type_id=wt.id
     where oe.agreement_id=l_agreement_id
       and oe.driveway_id is null
       and oe.odh_group_id is not null
       and not oe.is_estimate_sum
     group by oe.agreement_id
             ,oe.work_type_id
             ,wt.measure_unit_id;
end
$$;

