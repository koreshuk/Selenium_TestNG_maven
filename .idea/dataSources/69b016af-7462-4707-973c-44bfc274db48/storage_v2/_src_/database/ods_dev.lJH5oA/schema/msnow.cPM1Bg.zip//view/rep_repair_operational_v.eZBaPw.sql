CREATE VIEW rep_repair_operational_v AS
  WITH cdt AS (
         SELECT (date_part('YEAR'::text, t.cd))::integer AS year,
            (date_trunc('week'::text, (t.cd)::timestamp with time zone))::date AS this_week_from,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 6) AS this_week_to,
            t.cd AS today,
            (t.cd - 1) AS yesterday,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 7) AS next_week_from,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 13) AS next_week_to
           FROM ( SELECT ('now'::text)::date AS cd) t
        ), ingrs AS (
         SELECT irg.driveway_segment_id,
            count(irg.id) AS reg_qty
           FROM (msnow.fdc_ingress_registration irg
             JOIN cdt ON (true))
          WHERE ((irg.registration_date)::date = cdt.today)
          GROUP BY irg.driveway_segment_id
        ), monb AS (
         SELECT fdc_dw_segment_monitor_b_v.id AS driveway_segment_id,
            (date_part('year'::text, fdc_dw_segment_monitor_b_v.end_date_plan))::integer AS end_plan_year
           FROM msnow.fdc_dw_segment_monitor_b_v
          WHERE ((fdc_dw_segment_monitor_b_v.work_type_name)::text = 'Работы по укладке асфальтобетона'::text)
        ), wclosed AS (
         SELECT agrm.agr_root_id,
            ajrn.driveway_segment_id,
            sum(
                CASE
                    WHEN ((mu.code)::text = '100_MTK'::text) THEN (ajrn.work_volume / (10.0)::double precision)
                    WHEN ((mu.code)::text = '1000_MTK'::text) THEN ajrn.work_volume
                    WHEN ((mu.code)::text = 'MTK'::text) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume,
            max(
                CASE
                    WHEN ajrn.is_last_work THEN ajrn.work_date
                    ELSE NULL::date
                END) AS max_work_date
           FROM ((((msnow.fdc_agreement agrm
             JOIN msnow.fdc_agr_estimate agrme ON ((agrm.id = agrme.agreement_id)))
             JOIN msnow.fdc_work_type awt ON ((agrme.work_type_id = awt.id)))
             LEFT JOIN msnow.fdc_measure_unit mu ON ((awt.measure_unit_id = mu.id)))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((awt.id = ajrn.work_type_id) AND (agrme.driveway_segment_id = ajrn.driveway_segment_id))))
          WHERE awt.is_asphalt
          GROUP BY agrm.agr_root_id, ajrn.driveway_segment_id
         HAVING (count(
                CASE
                    WHEN ((ajrn.id IS NULL) OR (NOT ajrn.is_last_work)) THEN ajrn.work_type_id
                    ELSE NULL::bigint
                END) = 0)
        ), ajrnvol AS (
         SELECT ajrn.driveway_segment_id,
            sum(
                CASE
                    WHEN ((mu.code)::text = '100_MTK'::text) THEN (ajrn.work_volume / (10.0)::double precision)
                    WHEN ((mu.code)::text = '1000_MTK'::text) THEN ajrn.work_volume
                    WHEN ((mu.code)::text = 'MTK'::text) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume
           FROM ((msnow.fdc_asphalt_journal ajrn
             JOIN msnow.fdc_work_type wt ON ((ajrn.work_type_id = wt.id)))
             JOIN msnow.fdc_measure_unit mu ON ((wt.measure_unit_id = mu.id)))
          WHERE ((mu.code)::text = ANY ((ARRAY['100_MTK'::character varying, '1000_MTK'::character varying, 'MTK'::character varying])::text[]))
          GROUP BY ajrn.driveway_segment_id
        ), plwrk AS (
         SELECT pw.work_date,
            pw.driveway_category_id,
            sum(pw.object_quantity) AS object_quantity,
            sum((pw.asphalt_area / (1000.0)::double precision)) AS asphalt_area
           FROM (((msnow.fdc_planed_work pw
             JOIN msnow.fdc_plan_type pt ON ((pw.plan_type_id = pt.id)))
             JOIN msnow.fdc_work_category wct ON ((pw.work_category_id = wct.id)))
             JOIN cdt ON (((pw.work_date = cdt.today) OR (pw.work_date = cdt.yesterday))))
          WHERE (((pt.code)::text = 'TOTAL'::text) AND ((wct.code)::text = 'REPAIR_PROGRAM'::text))
          GROUP BY pw.work_date, pw.driveway_category_id
        )
 SELECT dwct.id AS driveway_category_id,
        CASE dwct.code
            WHEN 'LOCAL'::text THEN 'Муниципальная'::text
            WHEN 'REGION_INTERMUNICIPAL'::text THEN 'Региональная'::text
            ELSE NULL::text
        END AS driveway_category,
    dtl.planed_work_yesterday_qty,
    dtl.planed_work_yesterday_vol,
    dtl.planed_work_today_qty,
    dtl.planed_work_today_vol,
    dtl.driveway_segment_id,
    dtl.asphalt_area_vol,
    dtl.inwork_plan_qty,
    dtl.inwork_plan_vol,
    dtl.inwork_qty,
    dtl.inwork_vol,
    dtl.complete_plan_qty,
    dtl.complete_plan_vol,
    dtl.closed_works_qty,
    dtl.closed_works_vol,
    dtl.closed_yesterday_qty,
    dtl.closed_yesterday_vol,
    dtl.inwork_today_qty,
    dtl.inwork_today_vol
   FROM (msnow.fdc_driveway_category dwct
     LEFT JOIN ( SELECT dwc.id AS driveway_category_id,
            dws.id AS driveway_segment_id,
            (dws.asphalt_area / (1000.0)::double precision) AS asphalt_area_vol,
                CASE
                    WHEN ((cdt.today >= wsch.start_date_plan) AND (cdt.today <= wsch.end_date_plan)) THEN dws.id
                    ELSE NULL::bigint
                END AS inwork_plan_qty,
                CASE
                    WHEN ((cdt.today >= wsch.start_date_plan) AND (cdt.today <= wsch.end_date_plan)) THEN (dws.asphalt_area / (1000.0)::double precision)
                    ELSE NULL::double precision
                END AS inwork_plan_vol,
                CASE
                    WHEN ((wsch.start_date_fact <= cdt.today) AND (wsch.end_date_fact IS NULL)) THEN dws.id
                    ELSE NULL::bigint
                END AS inwork_qty,
                CASE
                    WHEN ((wsch.start_date_fact <= cdt.today) AND (wsch.end_date_fact IS NULL)) THEN ajrnvol.mtk_work_volume
                    ELSE NULL::double precision
                END AS inwork_vol,
                CASE
                    WHEN (monb.end_plan_year = cdt.year) THEN dws.id
                    ELSE NULL::bigint
                END AS complete_plan_qty,
                CASE
                    WHEN ((monb.end_plan_year = cdt.year) AND (monb.driveway_segment_id = ajrnvol.driveway_segment_id)) THEN ajrnvol.mtk_work_volume
                    ELSE NULL::double precision
                END AS complete_plan_vol,
                CASE
                    WHEN (wclosed.driveway_segment_id IS NOT NULL) THEN dws.id
                    ELSE NULL::bigint
                END AS closed_works_qty,
                CASE
                    WHEN (wclosed.driveway_segment_id IS NOT NULL) THEN wclosed.mtk_work_volume
                    ELSE NULL::double precision
                END AS closed_works_vol,
                CASE
                    WHEN ((row_number() OVER (PARTITION BY dwc.id ORDER BY dwc.id) = 1) AND (plwrk.work_date = cdt.yesterday)) THEN plwrk.object_quantity
                    ELSE NULL::bigint
                END AS planed_work_yesterday_qty,
                CASE
                    WHEN ((row_number() OVER (PARTITION BY dwc.id ORDER BY dwc.id) = 1) AND (plwrk.work_date = cdt.yesterday)) THEN plwrk.asphalt_area
                    ELSE NULL::double precision
                END AS planed_work_yesterday_vol,
                CASE
                    WHEN ((wclosed.driveway_segment_id IS NOT NULL) AND (wclosed.max_work_date = cdt.yesterday)) THEN dws.id
                    ELSE NULL::bigint
                END AS closed_yesterday_qty,
                CASE
                    WHEN ((wclosed.driveway_segment_id IS NOT NULL) AND (wclosed.max_work_date = cdt.yesterday)) THEN wclosed.mtk_work_volume
                    ELSE NULL::double precision
                END AS closed_yesterday_vol,
                CASE
                    WHEN ((row_number() OVER (PARTITION BY dwc.id ORDER BY dwc.id) = 1) AND (plwrk.work_date = cdt.today)) THEN plwrk.object_quantity
                    ELSE NULL::bigint
                END AS planed_work_today_qty,
                CASE
                    WHEN ((row_number() OVER (PARTITION BY dwc.id ORDER BY dwc.id) = 1) AND (plwrk.work_date = cdt.today)) THEN plwrk.asphalt_area
                    ELSE NULL::double precision
                END AS planed_work_today_vol,
                CASE
                    WHEN (ingrs.reg_qty > 0) THEN dws.id
                    ELSE NULL::bigint
                END AS inwork_today_qty,
                CASE
                    WHEN (ingrs.reg_qty > 0) THEN (dws.asphalt_area / (1000.0)::double precision)
                    ELSE NULL::double precision
                END AS inwork_today_vol
           FROM (((((((((((((msnow.fdc_segment s
             JOIN msnow.fdc_driveway_segment dws ON ((s.id = dws.id)))
             JOIN fdc_driveway dw ON ((dws.driveway_id = dw.id)))
             JOIN fdc_object dwobj ON ((dw.id = dwobj.id)))
             JOIN msnow.fdc_driveway_category dwc ON ((dwobj.driveway_category_id = dwc.id)))
             JOIN msnow.fdc_work_schedule wsch ON ((dws.id = wsch.driveway_segment_id)))
             JOIN msnow.fdc_dw_segment_status dwss ON ((dws.status_id = dwss.id)))
             JOIN cdt ON (true))
             LEFT JOIN msnow.fdc_agreement agr ON ((dws.agreement_id = agr.id)))
             LEFT JOIN wclosed ON (((agr.agr_root_id = wclosed.agr_root_id) AND (dws.id = wclosed.driveway_segment_id))))
             LEFT JOIN ajrnvol ON ((dws.id = ajrnvol.driveway_segment_id)))
             LEFT JOIN plwrk ON ((dwc.id = plwrk.driveway_category_id)))
             LEFT JOIN ingrs ON ((dws.id = ingrs.driveway_segment_id)))
             LEFT JOIN monb ON ((dws.id = monb.driveway_segment_id)))
          WHERE (((date_part('year'::text, wsch.start_date_plan))::integer = cdt.year) AND (wsch.start_date_plan IS NOT NULL) AND (wsch.end_date_plan IS NOT NULL) AND ((dwss.code)::text = ANY ((ARRAY['COMPLETED'::character varying, 'PLANNED'::character varying, 'IN_PROCESS'::character varying])::text[])))) dtl ON ((dwct.id = dtl.driveway_category_id)));

COMMENT ON VIEW rep_repair_operational_v IS 'Оперативная сводка по ремонту';

COMMENT ON COLUMN rep_repair_operational_v.driveway_category_id IS 'Сеть';

COMMENT ON COLUMN rep_repair_operational_v.driveway_category IS 'Ид категории дорог';

COMMENT ON COLUMN rep_repair_operational_v.planed_work_yesterday_qty IS 'План по завершенным на вчарашнюю дату, шт';

COMMENT ON COLUMN rep_repair_operational_v.planed_work_yesterday_vol IS 'План по завершенным на вчарашнюю дату, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.planed_work_today_qty IS 'В работе по плану на сегодня, шт';

COMMENT ON COLUMN rep_repair_operational_v.planed_work_today_vol IS 'В работе по плану на сегодня, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.driveway_segment_id IS 'Программа ремонта, шт';

COMMENT ON COLUMN rep_repair_operational_v.asphalt_area_vol IS 'Программа ремонта, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.inwork_plan_qty IS 'В работе по плану, шт';

COMMENT ON COLUMN rep_repair_operational_v.inwork_plan_vol IS 'В работе по плану, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.inwork_qty IS 'В работе, шт';

COMMENT ON COLUMN rep_repair_operational_v.inwork_vol IS 'В работе, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.complete_plan_qty IS 'План по завершенным, шт';

COMMENT ON COLUMN rep_repair_operational_v.complete_plan_vol IS 'План по завершенным, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.closed_works_qty IS 'Завершенные работы, шт';

COMMENT ON COLUMN rep_repair_operational_v.closed_works_vol IS 'Завершенные работы, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.closed_yesterday_qty IS 'Завершено вчера, шт';

COMMENT ON COLUMN rep_repair_operational_v.closed_yesterday_vol IS 'Завершено вчера, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_v.inwork_today_qty IS 'В работе сегодня, шт';

COMMENT ON COLUMN rep_repair_operational_v.inwork_today_vol IS 'В работе сегодня, тыс. кв. км';

