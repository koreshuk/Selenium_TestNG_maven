CREATE VIEW rep_repair_workflow_status_weekly_v AS
  WITH rootwt AS (
         SELECT DISTINCT agr.agr_root_id,
            agre.driveway_segment_id,
            agre.work_type_id,
            wt.is_asphalt,
            mu.code AS measure_unit_code
           FROM (((msnow.fdc_agreement agr
             JOIN msnow.fdc_agr_estimate agre ON ((agr.id = agre.agreement_id)))
             JOIN msnow.fdc_work_type wt ON ((agre.work_type_id = wt.id)))
             LEFT JOIN msnow.fdc_measure_unit mu ON ((wt.measure_unit_id = mu.id)))
        ), wclosed AS (
         SELECT sagr.agr_root_id,
            sdws.id AS driveway_segment_id,
            sum(
                CASE
                    WHEN ((rootwt.measure_unit_code)::text = 'MTK'::text) THEN (ajl.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume,
            max(ajl.work_date) AS max_work_date
           FROM (((msnow.fdc_driveway_segment sdws
             JOIN msnow.fdc_agreement sagr ON ((sdws.agreement_id = sagr.id)))
             JOIN rootwt ON (((sagr.agr_root_id = rootwt.agr_root_id) AND (sdws.id = rootwt.driveway_segment_id))))
             LEFT JOIN msnow.fdc_asphalt_journal ajl ON (((rootwt.work_type_id = ajl.work_type_id) AND (sdws.id = ajl.driveway_segment_id) AND ajl.is_last_work)))
          WHERE rootwt.is_asphalt
          GROUP BY sagr.agr_root_id, sdws.id
         HAVING (count(
                CASE
                    WHEN (ajl.id IS NULL) THEN rootwt.work_type_id
                    ELSE NULL::bigint
                END) = 0)
        ), milling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_milling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), levelling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_levelling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), asph AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_asphalt AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), rside AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_roadside AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), f AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(ceil((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 20))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN levelling ON ((ssch.driveway_segment_id = levelling.driveway_segment_id)))
        ), b AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(ceil((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 50))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN asph ON ((ssch.driveway_segment_id = asph.driveway_segment_id)))
        ), a AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(ceil((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 15))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN rside ON ((ssch.driveway_segment_id = rside.driveway_segment_id)))
        ), e AS (
         SELECT ssch.driveway_segment_id,
            (((COALESCE(ceil((((ssch.end_date_plan + 1) - ssch.start_date_plan))::double precision), (0)::double precision) - (COALESCE(a.day_cnt, (0)::numeric))::double precision) - (COALESCE(f.day_cnt, (0)::numeric))::double precision) - (COALESCE(b.day_cnt, (0)::numeric))::double precision) AS day_cnt
           FROM (((msnow.fdc_work_schedule ssch
             LEFT JOIN a ON ((ssch.driveway_segment_id = a.driveway_segment_id)))
             LEFT JOIN f ON ((ssch.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((ssch.driveway_segment_id = b.driveway_segment_id)))
        ), dates AS (
         SELECT sagr.agr_root_id,
            sagre.driveway_segment_id,
            max(
                CASE
                    WHEN swt.is_asphalt THEN ((((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer)
                    ELSE NULL::date
                END) AS end_date_plan,
            sum(
                CASE
                    WHEN ((mu.code)::text = 'MTK'::text) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume
           FROM ((((((((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
             LEFT JOIN msnow.fdc_measure_unit mu ON ((swt.measure_unit_id = mu.id)))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((ajrn.driveway_segment_id = sagre.driveway_segment_id) AND (ajrn.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_work_schedule sch ON ((sagre.driveway_segment_id = sch.driveway_segment_id)))
             LEFT JOIN e ON ((sagre.driveway_segment_id = e.driveway_segment_id)))
             LEFT JOIN f ON ((sagre.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((sagre.driveway_segment_id = b.driveway_segment_id)))
          WHERE swt.is_asphalt
          GROUP BY sagr.agr_root_id, sagre.driveway_segment_id
        ), cdt AS (
         SELECT (date_part('YEAR'::text, t.cd))::integer AS year,
            (date_trunc('week'::text, (t.cd)::timestamp with time zone))::date AS this_week_from,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 6) AS this_week_to,
            t.cd AS "current_date",
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 7) AS next_week_from,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 13) AS next_week_to
           FROM ( SELECT ('now'::text)::date AS cd) t
        ), ingrs AS (
         SELECT irgt.driveway_segment_id,
            irgt.file_id
           FROM ( SELECT irg.driveway_segment_id,
                    irg.file_id,
                    row_number() OVER (PARTITION BY irg.driveway_segment_id, ((irg.registration_date)::date) ORDER BY irg.registration_date DESC) AS rnk
                   FROM (msnow.fdc_ingress_registration irg
                     JOIN cdt ON (true))
                  WHERE ((irg.registration_date)::date = cdt."current_date")) irgt
          WHERE (irgt.rnk = 1)
        ), asphjrn AS (
         SELECT ajrn.driveway_segment_id,
            sum(
                CASE
                    WHEN ((mu.code)::text = 'MTK'::text) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume,
            sum(
                CASE
                    WHEN ((ajrn.work_date = ('now'::text)::date) AND ((mu.code)::text = 'MTK'::text)) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_today_work_volume
           FROM ((msnow.fdc_asphalt_journal ajrn
             JOIN msnow.fdc_work_type swt ON ((ajrn.work_type_id = swt.id)))
             JOIN msnow.fdc_measure_unit mu ON ((swt.measure_unit_id = mu.id)))
          GROUP BY ajrn.driveway_segment_id
        ), dwsgm AS (
         SELECT dws.id AS driveway_segment_id,
            dwc.id AS driveway_category_id,
                CASE
                    WHEN (ingrs.driveway_segment_id IS NOT NULL) THEN true
                    ELSE false
                END AS has_ingress_registration,
            ingrs.file_id AS ingress_registration_file_id,
            true AS driveway_segment_qty,
            true AS driveway_segment_volume,
                CASE
                    WHEN (wclosed.driveway_segment_id IS NOT NULL) THEN true
                    ELSE false
                END AS finished_qty,
                CASE
                    WHEN (wclosed.driveway_segment_id IS NOT NULL) THEN true
                    ELSE false
                END AS finished_volume,
                CASE
                    WHEN ((wsch.start_date_fact <= cdt."current_date") AND (wsch.end_date_fact IS NULL)) THEN true
                    ELSE false
                END AS inwork_year_qty,
                CASE
                    WHEN ((wsch.start_date_fact <= cdt."current_date") AND (wsch.end_date_fact IS NULL)) THEN true
                    ELSE false
                END AS inwork_year_volume,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.this_week_from) AND (clplan.end_date_plan <= cdt.this_week_to)) THEN true
                    ELSE false
                END AS finish_plan_qty,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.this_week_from) AND (clplan.end_date_plan <= cdt.this_week_to)) THEN true
                    ELSE false
                END AS finish_plan_volume,
                CASE
                    WHEN ((wclosed.max_work_date >= cdt.this_week_from) AND (wclosed.max_work_date <= cdt.this_week_to)) THEN true
                    ELSE false
                END AS finished_fact_qty,
                CASE
                    WHEN ((wclosed.max_work_date >= cdt.this_week_from) AND (wclosed.max_work_date <= cdt.this_week_to)) THEN true
                    ELSE false
                END AS finished_fact_volume,
                CASE
                    WHEN ((cdt."current_date" >= wsch.start_date_plan) AND (cdt."current_date" <= wsch.end_date_plan)) THEN true
                    ELSE false
                END AS inwork_year_plan_qty,
                CASE
                    WHEN ((cdt."current_date" >= wsch.start_date_plan) AND (cdt."current_date" <= wsch.end_date_plan)) THEN true
                    ELSE false
                END AS inwork_year_plan_volume,
                CASE
                    WHEN (ingrs.driveway_segment_id IS NOT NULL) THEN true
                    ELSE false
                END AS inwork_today_qty,
                CASE
                    WHEN (ingrs.driveway_segment_id IS NOT NULL) THEN true
                    ELSE false
                END AS inwork_today_volume,
                CASE
                    WHEN ((wsch.start_date_plan >= cdt.next_week_from) AND (wsch.start_date_plan <= cdt.next_week_to)) THEN true
                    ELSE false
                END AS planned_start_qty,
                CASE
                    WHEN ((wsch.start_date_plan >= cdt.next_week_from) AND (wsch.start_date_plan <= cdt.next_week_to)) THEN true
                    ELSE false
                END AS planned_start_volume,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.next_week_from) AND (clplan.end_date_plan <= cdt.next_week_to)) THEN true
                    ELSE false
                END AS planned_finish_qty,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.next_week_from) AND (clplan.end_date_plan <= cdt.next_week_to)) THEN true
                    ELSE false
                END AS planned_finish_volume
           FROM ((((((((((((msnow.fdc_segment s
             JOIN msnow.fdc_driveway_segment dws ON ((s.id = dws.id)))
             JOIN fdc_driveway dw ON ((dws.driveway_id = dw.id)))
             JOIN fdc_object dwobj ON ((dw.id = dwobj.id)))
             JOIN msnow.fdc_driveway_category dwc ON ((dwobj.driveway_category_id = dwc.id)))
             JOIN cdt ON (true))
             JOIN msnow.fdc_work_schedule wsch ON (((dws.id = wsch.driveway_segment_id) AND ((date_part('year'::text, wsch.start_date_plan))::integer = cdt.year))))
             JOIN msnow.fdc_dw_segment_status dwss ON ((dws.status_id = dwss.id)))
             LEFT JOIN asphjrn ON ((dws.id = asphjrn.driveway_segment_id)))
             LEFT JOIN msnow.fdc_agreement agr ON ((dws.agreement_id = agr.id)))
             LEFT JOIN wclosed ON (((agr.agr_root_id = wclosed.agr_root_id) AND (dws.id = wclosed.driveway_segment_id))))
             LEFT JOIN dates clplan ON (((agr.agr_root_id = clplan.agr_root_id) AND (dws.id = clplan.driveway_segment_id))))
             LEFT JOIN ingrs ON ((dws.id = ingrs.driveway_segment_id)))
          WHERE ((wsch.start_date_plan IS NOT NULL) AND (wsch.end_date_plan IS NOT NULL) AND ((dwss.code)::text <> ALL ((ARRAY['FUTURE_PLANNED'::character varying, 'ON_VOTE'::character varying, 'ESTIMATED_RESULT'::character varying])::text[])))
        )
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.driveway_segment_qty THEN 'driveway_segment_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.driveway_segment_volume THEN 'driveway_segment_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.finished_qty THEN 'finished_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.finished_volume THEN 'finished_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.inwork_year_qty THEN 'inwork_year_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.inwork_year_volume THEN 'inwork_year_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.finish_plan_qty THEN 'finish_plan_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.finish_plan_volume THEN 'finish_plan_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.finished_fact_qty THEN 'finished_fact_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.finished_fact_volume THEN 'finished_fact_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.inwork_year_plan_qty THEN 'inwork_year_plan_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.inwork_year_plan_volume THEN 'inwork_year_plan_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.inwork_today_qty THEN 'inwork_today_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.inwork_today_volume THEN 'inwork_today_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.planned_start_qty THEN 'planned_start_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.planned_start_volume THEN 'planned_start_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm
UNION ALL
 SELECT dwsgm.driveway_segment_id AS id,
    dwsgm.driveway_category_id,
    dwsgm.has_ingress_registration,
    dwsgm.ingress_registration_file_id,
        CASE
            WHEN dwsgm.planned_finish_qty THEN 'planned_finish_qty'::text
            ELSE ''::text
        END AS pquantity,
        CASE
            WHEN dwsgm.planned_finish_volume THEN 'planned_finish_volume'::text
            ELSE ''::text
        END AS pvolume
   FROM dwsgm;

