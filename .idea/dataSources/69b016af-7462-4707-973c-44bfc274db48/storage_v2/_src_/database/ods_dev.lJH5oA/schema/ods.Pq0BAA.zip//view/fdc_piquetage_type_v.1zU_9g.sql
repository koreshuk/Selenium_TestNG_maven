CREATE VIEW fdc_piquetage_type_v AS
  SELECT t1.id,
    t1.history_id,
    t2.code AS history_code,
    t2.name AS history_name,
    t1.code,
    t1.name,
    t1.date_from,
    t1.date_to,
        CASE
            WHEN ((t1.code)::text = 'SIDE'::text) THEN 1
            WHEN ((t1.code)::text = 'START'::text) THEN 2
            WHEN ((t1.code)::text = 'END'::text) THEN 3
            WHEN ((t1.code)::text = 'BY_AXES'::text) THEN 4
            WHEN ((t1.code)::text = 'AXES_TYPE'::text) THEN 5
            ELSE NULL::integer
        END AS sort_order
   FROM (fdc_piquetage_type t1
     LEFT JOIN fdc_piquetage_type t2 ON ((t2.id = t1.history_id)));

COMMENT ON VIEW fdc_piquetage_type_v IS 'Справочник Тип пикетажа';

COMMENT ON COLUMN fdc_piquetage_type_v.id IS 'Ид типа пикетажа';

COMMENT ON COLUMN fdc_piquetage_type_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_piquetage_type_v.history_code IS 'Код типа пикетажа';

COMMENT ON COLUMN fdc_piquetage_type_v.history_name IS 'Наименование типа пикетажа';

COMMENT ON COLUMN fdc_piquetage_type_v.code IS 'Код типа пикетажа';

COMMENT ON COLUMN fdc_piquetage_type_v.name IS 'Наименование типа пикетажа';

COMMENT ON COLUMN fdc_piquetage_type_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_piquetage_type_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_piquetage_type_v.sort_order IS 'Порядок сортировки';

