CREATE VIEW fdc_object_v AS
  SELECT o.id,
    o.parent_version_id,
    o.root_id,
    o.version_date_from,
    COALESCE(o.version_date_to, to_date('01.01.4000'::text, 'DD.MM.YYYY'::text)) AS version_date_to,
    o.customer_id,
    cust.name AS customer_name,
    cust.short_name AS customer_short_name,
    o.object_type_id,
    t.code AS object_type_code,
    t.name AS object_type_name,
    t.short_name AS object_type_short_name,
    o.object_state_id,
    s.code AS object_state_code,
    s.name AS object_state_name,
    o.owner_id,
    owner.name AS owner_name,
    owner.short_name AS owner_short_name,
    o.object_sub_type_id,
    subt.code AS object_sub_type_code,
    subt.name AS object_sub_type_name,
    subt.short_name AS object_sub_type_short_name,
    o.geometry,
    o.description,
    o.okrug_id,
    okr.name AS okrug_name,
    okr.short_name AS okrug_short_name,
    o.district_id,
    dst.name AS district_name,
    dst.code AS district_code,
    o.inventory_id,
    o.reason_type_id,
    rt.code AS reason_type_code,
    rt.name AS reason_type_name,
    o.tree_name,
    o.root_owner_id,
    o.update_date,
    o.hash_sum,
    o.name,
    o.total_area,
    o.number_doc,
    o.snapshot_date,
    o.accounting_address,
    o.inventory_num,
    o.egip_sync_date,
    o.global_id,
    o.approval_id,
    o.approval_iteration_id,
    o.reason_type_del_id,
    rt_del.code AS reason_type_code_del,
    rt_del.name AS reason_type_name_del,
    o.reason_comment,
    o.reason_del_comment,
    o.approval_date
   FROM (((((((((fdc_object o
     LEFT JOIN fdc_object_type t ON ((t.id = o.object_type_id)))
     LEFT JOIN fdc_object_state s ON ((s.id = o.object_state_id)))
     LEFT JOIN fdc_object_type subt ON (((subt.id = o.object_sub_type_id) AND (subt.parent_id IS NOT NULL))))
     LEFT JOIN nsi.fdc_bti_okrug_v okr ON ((okr.id = o.okrug_id)))
     LEFT JOIN nsi.fdc_bti_district_v dst ON ((dst.id = o.district_id)))
     LEFT JOIN nsi.fdc_legal_person_v owner ON ((owner.id = o.owner_id)))
     LEFT JOIN nsi.fdc_legal_person_v cust ON ((cust.id = o.customer_id)))
     LEFT JOIN fdc_reason_type rt ON ((rt.id = o.reason_type_id)))
     LEFT JOIN fdc_reason_type rt_del ON ((rt_del.id = o.reason_type_del_id)));

COMMENT ON VIEW fdc_object_v IS 'Объект городского хозяйства (ОГХ)';

COMMENT ON COLUMN fdc_object_v.id IS 'Ид ОГХ';

COMMENT ON COLUMN fdc_object_v.parent_version_id IS 'Ид предыдущей версии объекта';

COMMENT ON COLUMN fdc_object_v.root_id IS 'Ид объекта исторический';

COMMENT ON COLUMN fdc_object_v.version_date_from IS 'Дата версии с (дата начала действия версии)';

COMMENT ON COLUMN fdc_object_v.version_date_to IS 'Дата версии по';

COMMENT ON COLUMN fdc_object_v.customer_id IS 'Ид заказчика';

COMMENT ON COLUMN fdc_object_v.customer_name IS 'Наименование заказчика';

COMMENT ON COLUMN fdc_object_v.customer_short_name IS 'Краткое наименование заказчика';

COMMENT ON COLUMN fdc_object_v.object_type_id IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_type_code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_type_name IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_type_short_name IS 'Краткое наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_state_id IS 'Ид статуса ОГХ';

COMMENT ON COLUMN fdc_object_v.object_state_code IS 'Код статуса ОГХ';

COMMENT ON COLUMN fdc_object_v.object_state_name IS 'Наименование статуса ОГХ';

COMMENT ON COLUMN fdc_object_v.owner_id IS 'Ид балансодержателя';

COMMENT ON COLUMN fdc_object_v.owner_name IS 'Наименование балансодержателя';

COMMENT ON COLUMN fdc_object_v.owner_short_name IS 'Краткое наименование балансодержателя';

COMMENT ON COLUMN fdc_object_v.object_sub_type_id IS 'Ид подтипа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_sub_type_code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_sub_type_name IS 'Наименование подтипа ОГХ';

COMMENT ON COLUMN fdc_object_v.object_sub_type_short_name IS 'Краткое наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_v.geometry IS 'геометрия';

COMMENT ON COLUMN fdc_object_v.description IS 'Справка';

COMMENT ON COLUMN fdc_object_v.okrug_id IS 'Ид округа';

COMMENT ON COLUMN fdc_object_v.okrug_name IS 'Наименование округа';

COMMENT ON COLUMN fdc_object_v.okrug_short_name IS 'Краткое наименование округа';

COMMENT ON COLUMN fdc_object_v.district_id IS 'Ид района';

COMMENT ON COLUMN fdc_object_v.district_name IS 'Наименование района';

COMMENT ON COLUMN fdc_object_v.inventory_id IS 'ИД инвентаризации';

COMMENT ON COLUMN fdc_object_v.reason_type_id IS 'Ид причины изменения объекта';

COMMENT ON COLUMN fdc_object_v.reason_type_code IS 'Код причины изменения объекта';

COMMENT ON COLUMN fdc_object_v.reason_type_name IS 'Наименование причины изменения объекта';

COMMENT ON COLUMN fdc_object_v.name IS 'Наименование объекта';

COMMENT ON COLUMN fdc_object_v.number_doc IS 'Номер дела светофорного объекта';

COMMENT ON COLUMN fdc_object_v.snapshot_date IS 'Дата и время съемки';

COMMENT ON COLUMN fdc_object_v.accounting_address IS 'Адрес по бухгалтерскому учету';

COMMENT ON COLUMN fdc_object_v.inventory_num IS 'Инвентарный номер';

COMMENT ON COLUMN fdc_object_v.egip_sync_date IS 'Дата последней синхронизации с ЕГИП';

COMMENT ON COLUMN fdc_object_v.global_id IS 'Ид в ЕГАС ОДОПМ';

COMMENT ON COLUMN fdc_object_v.approval_id IS 'Ид запроса на согласование';

COMMENT ON COLUMN fdc_object_v.approval_iteration_id IS 'Ид итерации запроса на согласование';

COMMENT ON COLUMN fdc_object_v.reason_type_del_id IS 'Ид причины удаления объекта';

COMMENT ON COLUMN fdc_object_v.reason_type_code_del IS 'Код причины удаления  объекта';

COMMENT ON COLUMN fdc_object_v.reason_type_name_del IS 'Наименование причины удаления  объекта';

COMMENT ON COLUMN fdc_object_v.reason_comment IS 'Комментарии к причине создания / изменения версии объекта ОГХ';

COMMENT ON COLUMN fdc_object_v.reason_del_comment IS 'Комментарии к причине удаления версии объекта ОГХ';

COMMENT ON COLUMN fdc_object_v.approval_date IS 'Дата утверждения проекта объекта ОГХ';

