CREATE FUNCTION fdc_odh_pck_edit_odh(p_object t_object, p_attribute fdc_odh, p_object_address_tab t_object_address[], p_object_piquetage_tab t_object_piquetage[])
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция редактирования объекта Объект дорожного хозяйства
  %param     p_object                   Объект редактируемые атрибуты
  %param     p_attribute                Атрибуты Объект
  %param     p_object_address_tab       Список адресов
  %param     p_object_piquetage_tab     Список параметров пикетажа
  %return                              Ид версии объекта
  */

  l_object_id ods.fdc_object.id%type;
  l_object ods.t_object;
  l_tree_name ods.fdc_object.tree_name%type;
begin
  l_object := p_object;

  /* Геометрия приходит только в p_object*/
  p_attribute.geometry := p_object.geometry;

  /* Определение округа, если не указан, на основе геометрии */
  /* Геометрию пока не используем
  if l_object.okrug_id is null then
    l_object.okrug_id := fdc_geo_pck.get_okrug_id_by_geo( p_attribute.geometry );
  end if;
  */

  /* Определение района, если не указан, на основе геометрии */
  /* Геометрию пока не используем
  if l_object.district_id is null then
    l_object.district_id := fdc_geo_pck.get_district_id_by_geo( p_attribute.geometry );
  end if;
  */

  --> Попробуем обновить незначимые атрибуты объекта
  l_object_id := ods.fdc_object_pck_update_object(p_object => l_object);

  --> Обновим атрибуты
  perform ods.fdc_odh_pck_update_obj_attribute_list(p_object_id      => l_object_id
                                                   ,p_attribute_tab  => p_attribute
                                                   ,p_prev_object_id => l_object.id
                                                   );

  --> Обновим адреса
  l_object_id := ods.fdc_object_pck_update_object_address_list(p_object             => l_object
                                                              ,p_object_address_tab => p_object_address_tab
                                                              );

  --> Обновим параметры пикетажа
  l_object_id := ods.fdc_object_pck_update_object_piquetage_list(p_object               => l_object
                                                                ,p_object_piquetage_tab => p_object_piquetage_tab
                                                                );

  /* Обновляем название объекта в дереве*/
  perform ods.fdc_odh_pck_update_tree_name(p_object_id => l_object.id
                                          );

  /* Обновляем хэш-сумму объекта */
  /* Хэш пока не реализован
  fdc_object_pck.update_hash_sum( p_id => l_object.id, p_hash_sum => get_hash( l_object.id ) );
  */
  return l_object_id;
end
$$;

