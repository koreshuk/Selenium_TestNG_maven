CREATE MATERIALIZED VIEW fdc_fias_address_reference_mv AS WITH RECURSIVE adr(id, ao_id, ao_guid, top_ao_guid, name, ao_level, start_date, end_date, level, parent_guid, area_code, city_code, place_code) AS (
         WITH mo_guid AS (
                 SELECT DISTINCT fao.ao_guid
                   FROM (nsi.fdc_fias_municipality fm
                     JOIN fdc_as_addrobj fao ON ((fm.fias_id = fao.id)))
                ), ao_last_ver AS (
                 SELECT DISTINCT ON (ao.ao_guid) ao.ao_guid,
                    ao.start_date,
                    ao.end_date,
                    ao.id,
                    ao.ao_id,
                    ao.formal_name,
                    ao.short_name,
                    ao.ao_level,
                    ao.parent_guid,
                    ao.area_code,
                    ao.city_code,
                    ao.place_code
                   FROM fdc_as_addrobj ao
                  ORDER BY ao.ao_guid, ao.start_date DESC, ao.end_date DESC, ao.id DESC
                )
         SELECT ao.id,
            ao.ao_id,
            ao.ao_guid,
            ao.ao_guid,
            (((ao.formal_name)::text || ' '::text) || (ao.short_name)::text),
            ao.ao_level,
            ao.start_date,
            ao.end_date,
            1,
            ao.parent_guid,
            ao.area_code,
            ao.city_code,
            ao.place_code
           FROM (ao_last_ver ao
             JOIN mo_guid mg ON ((ao.ao_guid = mg.ao_guid)))
        UNION
         SELECT aoch.id,
            aoch.ao_id,
            aoch.ao_guid,
            adr.top_ao_guid,
            ((((adr.name || '/'::text) || (aoch.formal_name)::text) || ' '::text) || (aoch.short_name)::text),
            aoch.ao_level,
            aoch.start_date,
            aoch.end_date,
            (adr.level + 1),
            aoch.parent_guid,
            aoch.area_code,
            aoch.city_code,
            aoch.place_code
           FROM (adr
             JOIN ao_last_ver aoch ON ((adr.ao_guid = aoch.parent_guid)))
        ), mo_name AS (
         SELECT DISTINCT ao.ao_guid,
            fm.start_date,
            fm.end_date,
            m.short_name AS municipality_name,
            m.id AS municipality_id
           FROM ((nsi.fdc_fias_municipality fm
             JOIN nsi.fdc_municipality m ON ((fm.municipality_id = m.id)))
             JOIN fdc_as_addrobj ao ON ((fm.fias_id = ao.id)))
          WHERE ((fm.start_date IS NOT NULL) AND (fm.end_date IS NOT NULL))
        ), mo AS (
         SELECT adr.ao_guid,
            mo_name.municipality_id,
            mo_name.municipality_name,
            mo_name.start_date,
            mo_name.end_date
           FROM (adr
             JOIN mo_name ON ((adr.top_ao_guid = mo_name.ao_guid)))
        )
 SELECT DISTINCT tt.municipality_id,
    tt.municipality_name,
    tt.id,
    tt.ao_id,
    tt.ao_guid,
    tt.formal_name,
    tt.region_code,
    tt.auto_code,
    tt.area_code,
    tt.area_name,
    tt.city_code,
    tt.city_name,
    tt.ctar_code,
    tt.place_code,
    tt.place_name,
    tt.street_code,
    tt.extr_code,
    tt.sext_code,
    tt.off_name,
    tt.postal_code,
    tt.ifns_fl,
    tt.terr_ifns_fl,
    tt.ifns_ul,
    tt.terr_ifns_ul,
    tt.okato,
    tt.oktmo,
    tt.update_date,
    tt.short_name,
    tt.ao_level,
    tt.parent_guid,
    tt.prev_id,
    tt.next_id,
    tt.code,
    tt.plain_code,
    tt.act_status,
    tt.cent_status,
    tt.oper_status,
    tt.curr_status,
    tt.start_date,
    tt.end_date,
    tt.norm_doc,
    tt.live_status
   FROM ( SELECT mo.municipality_id,
            mo.municipality_name,
            row_number() OVER (PARTITION BY ao.id ORDER BY mo.end_date, mo.municipality_id DESC, l3.id DESC, l4.id DESC, l6.id DESC) AS rn,
            ao.id,
            ao.ao_id,
            ao.ao_guid,
            ao.formal_name,
            ao.region_code,
            ao.auto_code,
            ao.area_code,
            (((l3.formal_name)::text || ' '::text) || (l3.short_name)::text) AS area_name,
            ao.city_code,
            (((l4.formal_name)::text || ' '::text) || (l4.short_name)::text) AS city_name,
            ao.ctar_code,
            ao.place_code,
            (((l6.formal_name)::text || ' '::text) || (l6.short_name)::text) AS place_name,
            ao.street_code,
            ao.extr_code,
            ao.sext_code,
            ao.off_name,
            ao.postal_code,
            ao.ifns_fl,
            ao.terr_ifns_fl,
            ao.ifns_ul,
            ao.terr_ifns_ul,
            ao.okato,
            ao.oktmo,
            ao.update_date,
            ao.short_name,
            ao.ao_level,
            ao.parent_guid,
            ao.prev_id,
            ao.next_id,
            ao.code,
            ao.plain_code,
            ao.act_status,
            ao.cent_status,
            ao.oper_status,
            ao.curr_status,
            ao.start_date,
            ao.end_date,
            ao.norm_doc,
            ao.live_status
           FROM ((((fdc_as_addrobj ao
             LEFT JOIN mo ON (((ao.ao_guid = mo.ao_guid) AND (mo.start_date <= ao.end_date) AND (mo.end_date >= ao.start_date))))
             LEFT JOIN fdc_as_addrobj l3 ON (((l3.ao_level = 3) AND (ao.area_code = l3.area_code) AND ((l3.end_date >= ao.start_date) AND (l3.end_date <= ao.end_date)))))
             LEFT JOIN fdc_as_addrobj l4 ON (((l4.ao_level = 4) AND (ao.area_code = l4.area_code) AND (ao.city_code = l4.city_code) AND ((l4.end_date >= ao.start_date) AND (l4.end_date <= ao.end_date)))))
             LEFT JOIN fdc_as_addrobj l6 ON (((l6.ao_level = 6) AND (ao.area_code = l6.area_code) AND (ao.city_code = l6.city_code) AND (ao.place_code = l6.place_code) AND ((l6.end_date >= ao.start_date) AND (l6.end_date <= ao.end_date)))))) tt
  WHERE (tt.rn = 1);

CREATE UNIQUE INDEX fdc_fias_address_reference_mv_i
  ON fdc_fias_address_reference_mv (id);

