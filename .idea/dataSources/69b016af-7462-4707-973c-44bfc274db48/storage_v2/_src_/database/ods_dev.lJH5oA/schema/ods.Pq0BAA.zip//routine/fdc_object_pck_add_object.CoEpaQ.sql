CREATE FUNCTION fdc_object_pck_add_object(p_object t_object, p_biz_event_id bigint DEFAULT NULL::bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция добавления объекта
  %param     p_object           Объект
  %param     p_biz_event_id     Идентификатор бизнес события
  %return    p_object_id        Ид объекта
  */
  r_object ods.fdc_object;
  l_timestamp timestamp:=localtimestamp;
begin
/* В настоящий момент логирование не реализовано и не используется */
/*  fdc_event_pck.event_start(p_event_id        => l_event_id
                           ,p_event_type_code => const_core.c_et_add_obj
                           ,p_event_category  => const_core.c_ec_obj
                           ); */
  r_object.id                 := p_object.id;
  r_object.root_id            := null;
  r_object.version_date_from  := coalesce(p_object.version_date_from, (l_timestamp - interval '1' second));
  r_object.version_date_to    := coalesce(r_object.version_date_to, ods.c_end_date());

  r_object.update_date        := l_timestamp;
  r_object.object_type_id     := p_object.obj_type_id;
  r_object.object_sub_type_id := p_object.obj_sub_type_id;
  r_object.inventory_id       := p_object.inventory_id;
  r_object.owner_id           := case
                                   when p_object.owner_id = 0 then null
                                   else p_object.owner_id
                                 end;

  r_object.customer_id        := case
                                   when p_object.customer_id = -1 then null
                                   else p_object.customer_id
                                 end;
  r_object.name               := p_object.name;
  r_object.object_state_id    := ods.c_os_project();
  r_object.description        := p_object.description;
  r_object.reason_type_id     := p_object.reason_type_id;
  r_object.reason_comment     := p_object.reason_comment;

  r_object.snapshot_date      := p_object.snapshot_date;
  r_object.accounting_address := p_object.accounting_address;
  r_object.inventory_num      := p_object.inventory_num;

  r_object.okrug_id           := p_object.okrug_id;
  r_object.district_id        := p_object.district_id;
  --> геометрия объекта
  r_object.geometry           := p_object.geometry;

  /* Геометрия пока не реализована и не используется
  --> Определение округа, если не указан, на основе геометрии
  if r_object.okrug_id is null and r_object.geometry is not null then
    r_object.okrug_id := fdc_geo_pck.get_okrug_id_by_geo(r_object.geometry);
  end if;
  --> Определение района, если не указан, на основе геометрии
  if r_object.district_id is null and r_object.geometry is not null then
    r_object.district_id := fdc_geo_pck.get_district_id_by_geo(r_object.geometry);
  end if;
  if (r_object.geometry is not null and r_object.geometry.sdo_srid is null) then
    r_object.geometry.sdo_srid  := nvl(p_object.geometry.sdo_srid, fdc_geo_pck.msk_srid);
  end if;
  */
  r_object.geometry_wgs         := p_object.geometry_wgs;
  --> Дата постановки на учет/снятия с учета
  r_object.install_date         := p_object.install_date;
  r_object.dismantling_date     := p_object.dismantling_date;
  perform ods.fdc_object_pck_check_owner_cust(p_date_from   => r_object.version_date_from
                                             ,p_owner_id    => r_object.owner_id
                                             ,p_customer_id => r_object.customer_id
                                             );
  r_object:=ods.fdc_object_pck_insert_object(p_object => r_object);

  return r_object.id;
end
$$;

