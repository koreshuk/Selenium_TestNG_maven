CREATE FUNCTION rep_aggrepair_ondate_sum(p_date date, p_driveway_category_id bigint, OUT plan_volume_on_date double precision, OUT fact_volume_on_date double precision, OUT plan_done_on_date_prs double precision, OUT plan_volume_per_year double precision, OUT plan_done_on_year_prs double precision, OUT plan_remain_on_year_prs double precision, OUT slippage_on_date_prs double precision)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  /** Отчет по ремонту дорог по состоянию на дату (суммы)
    %param p_date date            - Дата
    %param p_driveway_category_id - Балансовая принадлежность

    %return plan_volume_on_date     - План на дату
    %return fact_volume_on_date     - Факт исполнения на дату
    %return plan_done_on_date_prs   - % исполнения от плана на дату
    %return plan_volume_per_year    - План общий на год
    %return plan_done_on_year_prs   - % исполнения общего плана на год
    %return plan_remain_on_year_prs - % осталось по плану на год
    %return slippage_on_date_prs    - % отставания на дату
  */
  l_driveway_category_code msnow.fdc_driveway_category.code%type;
  l_current_year text;

  --c_fake_plan_volume_per_year double precision:=9641317;
begin
  select code
    into strict l_driveway_category_code
    from msnow.fdc_driveway_category
   where id=p_driveway_category_id;

  l_current_year:=to_char(current_date,'YYYY');

  with org_ruad as(select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_role r on pr.role_id=r.id
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and r.code in('RUAD')
                      and l_driveway_category_code='REGION_INTERMUNICIPAL'
                   union all
                   select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and l_driveway_category_code='LOCAL'
                      and not exists(select null
                                       from nsi.fdc_role r
                                       join nsi.fdc_person_role prr on r.id=prr.role_id
                                      where prr.person_id=pr.person_id
                                        and statement_timestamp() between prr.begin_date and prr.end_date
                                        and r.code in('RUAD')
                                    )
                  )
      ,agrewt as(select agre.driveway_segment_id
                       ,agre.agreement_id
                       ,sum(agre.work_volume) as work_volume
                   from msnow.fdc_agr_estimate agre
                   join msnow.fdc_work_type agrewt on agre.work_type_id=agrewt.id
                   join msnow.fdc_measure_unit mu on agrewt.measure_unit_id=mu.id
                  where not agre.is_estimate_sum
                    and agrewt.is_asphalt
                    and mu.code='MTK'
                  group by agre.driveway_segment_id
                          ,agre.agreement_id
                )
      ,factwrk as(select aj.driveway_segment_id
                        ,sum(aj.work_volume) as work_volume
                    from msnow.fdc_asphalt_journal aj
                   where aj.work_date<p_date
                   group by aj.driveway_segment_id
                 )
   select round(rnd.plan_volume_per_year::numeric,2)::double precision
         ,round(rnd.fact_volume_on_date::numeric,2)::double precision
         ,round(rnd.plan_volume_on_date::numeric,2)::double precision
         ,round(rnd.r1::numeric,2)::double precision
         ,round(rnd.r2::numeric,2)::double precision
         ,round(100-(round(rnd.r2::numeric,2)+ case
                                                 when round(rnd.plan_volume_on_date::numeric,2) >= round(rnd.fact_volume_on_date::numeric,2) then
                                                   round(rnd.r4::numeric,2)
                                                 else 0.0::numeric
                                               end
                    ),2
               )::double precision --r3
         ,case
            when round(rnd.plan_volume_on_date::numeric,2) >= round(rnd.fact_volume_on_date::numeric,2) then
              round(rnd.r4::numeric,2)::double precision
            else 0.0
          end  -- r4
     into plan_volume_per_year
         ,fact_volume_on_date
         ,plan_volume_on_date
         ,plan_done_on_date_prs
         ,plan_done_on_year_prs
         ,plan_remain_on_year_prs
         ,slippage_on_date_prs
     from(
   select sum(tot.plan_volume_per_year)as plan_volume_per_year
         ,sum(tot.fact_volume_on_date) as fact_volume_on_date
         ,sum(tot.plan_volume_on_date) as plan_volume_on_date
         ---
         ,case
            when sum(tot.plan_volume_on_date)=0 then 0.0
            else
              (sum(tot.fact_volume_on_date) * 100) / sum(tot.plan_volume_on_date)
          end as R1
         ,case
            when sum(tot.plan_volume_per_year) = 0 then 0.0
            else (sum(tot.fact_volume_on_date) * 100) / sum(tot.plan_volume_per_year)
          end as R2
         ,case
            when sum(tot.plan_volume_per_year)=0 then 0.0
            else
              ((sum(tot.plan_volume_per_year) - sum(tot.plan_volume_on_date))*100) / sum(tot.plan_volume_per_year)
          end as R3--!
         ,case
            when sum(tot.plan_volume_per_year)=0 then 0.0
            else
              ((sum(tot.plan_volume_on_date) - sum(tot.fact_volume_on_date))*100) / sum(tot.plan_volume_per_year)
          end as R4   --!
     from(select agrewt.work_volume as plan_volume_per_year
                ,case
                   when sch.end_date_plan - sch.start_date_plan = 0 then 0.0
                   else
                     case
                       when sch.end_date_plan - sch.start_date_plan = 0 then 0.0
                       else
                         (case
                            when sch.start_date_plan<p_date then
                              agrewt.work_volume
                            else 0.0
                          end / ceiling((sch.end_date_plan - sch.start_date_plan) /2.0)
                         ) * case
                               when p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer) <0 then 0
                               else p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer)
                             end
                     end
                 end as plan_volume_on_date
                ,case
                   when sch.start_date_plan<p_date then
                     agrewt.work_volume
                   else 0.0
                 end as inter_A
                ,ceiling((sch.end_date_plan - sch.start_date_plan) /2.0) as inter_B
                ,case
                   when sch.end_date_plan - sch.start_date_plan =0 then 0.0
                   else
                     case
                       when sch.start_date_plan< p_date then
                         agrewt.work_volume
                       else 0.0
                     end / ceiling((sch.end_date_plan - sch.start_date_plan) /2.0)
                 end as inter_C
                ,case
                   when p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer) <0 then 0
                   else p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer)
                 end as inter_D
                ,factwrk.work_volume as fact_volume_on_date
            from msnow.fdc_driveway_segment dws --S
            join msnow.fdc_agreement agr on dws.agreement_id=agr.id --S
            join org_ruad on dws.org_ruad_id=org_ruad.org_ruad_id    --S
            join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id --S
            join agrewt on agr.id=agrewt.agreement_id
                           and dws.id=agrewt.driveway_segment_id
            left join factwrk on dws.id=factwrk.driveway_segment_id
           where to_char(sch.start_date_plan,'YYYY')=l_current_year
             and sch.start_date_plan is not null
             and sch.end_date_plan is not null
         ) tot
         ) rnd;

  return;
end
$$;

