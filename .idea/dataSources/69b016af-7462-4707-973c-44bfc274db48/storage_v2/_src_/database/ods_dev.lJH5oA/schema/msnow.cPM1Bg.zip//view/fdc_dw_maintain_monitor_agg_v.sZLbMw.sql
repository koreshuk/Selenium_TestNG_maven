CREATE VIEW fdc_dw_maintain_monitor_agg_v AS
  WITH mp_inwork AS (
         SELECT we.driveway_id,
            we.work_type_id
           FROM msnow.fdc_work_execute we
          WHERE ((we.external_id IS NOT NULL) AND (we.work_volume IS NOT NULL) AND (we.work_date = statement_timestamp()))
        ), mp_done AS (
         SELECT we.driveway_id,
            sum(we.work_volume) AS driveway_work_volume
           FROM msnow.fdc_work_execute we
          WHERE ((we.external_id IS NOT NULL) AND (we.work_volume IS NOT NULL) AND (we.work_date = statement_timestamp()))
          GROUP BY we.driveway_id
        ), mp_auto AS (
         SELECT we.driveway_id,
            we.work_type_id
           FROM msnow.fdc_work_execute we
          WHERE ((we.regnum_auto IS NOT NULL) AND (we.work_date = statement_timestamp()))
        ), agrgrp AS (
         SELECT DISTINCT odh.maintenance_route_id,
            agrt.agreement_group_id
           FROM (((((msnow.fdc_agreement_object ao
             JOIN fdc_odh odh ON ((ao.driveway_id = odh.id)))
             JOIN msnow.fdc_agreement agr ON ((ao.argeement_id = agr.id)))
             JOIN msnow.fdc_agreement_type agrt ON ((agr.agr_type_id = agrt.id)))
             JOIN msnow.fdc_agreement_group agrg ON ((agrt.agreement_group_id = agrg.id)))
             JOIN msnow.fdc_work_category awc ON ((agr.work_category_id = awc.id)))
          WHERE ((ao.driveway_id IS NOT NULL) AND ((awc.code)::text = 'MAINTAIN'::text) AND ((('now'::text)::date >= agr.version_date_from) AND (('now'::text)::date <= agr.version_date_to)))
        ), alldist AS (
         SELECT dist.id AS distance_id,
            sum(ocalc.stat_axes_length) AS dist_stat_axes_length
           FROM (((fdc_maintenance_route dist
             JOIN fdc_odh odh ON ((dist.id = odh.maintenance_route_id)))
             JOIN fdc_object obj ON ((odh.id = obj.id)))
             JOIN fdc_odh_calculation ocalc ON ((obj.id = ocalc.id)))
          GROUP BY dist.id
        )
 SELECT alldist.distance_id,
    tt.scheduled_work_plan_id,
    tt.driveway_category_id,
    tt.work_type_id,
    tt.driveway_id,
    tt.agreement_group_id,
        CASE row_number() OVER (PARTITION BY alldist.distance_id ORDER BY tt.driveway_id, tt.work_type_id)
            WHEN 1 THEN alldist.dist_stat_axes_length
            ELSE NULL::double precision
        END AS stat_axes_length,
    tt.plan_distance_id,
    tt.inwork_distance_id,
        CASE min(tt.done_distance_flag) OVER (PARTITION BY tt.distance_id)
            WHEN 0 THEN NULL::bigint
            ELSE tt.distance_id
        END AS done_distance_flag_id,
        CASE max(tt.auto_distance_flag) OVER (PARTITION BY tt.distance_id)
            WHEN 0 THEN NULL::bigint
            ELSE tt.distance_id
        END AS auto_distance_flag_id,
    tt.distance_id AS id
   FROM (alldist
     LEFT JOIN ( SELECT dist.id AS distance_id,
            swp.id AS scheduled_work_plan_id,
            obj.driveway_category_id,
            swp.work_type_id,
            obj.id AS driveway_id,
            agrgrp.agreement_group_id,
            ocalc.stat_axes_length,
            dist.id AS plan_distance_id,
                CASE
                    WHEN (EXISTS ( SELECT NULL::unknown
                       FROM mp_inwork mpa
                      WHERE ((mpa.driveway_id = obj.id) AND (mpa.work_type_id = swp.work_type_id)))) THEN dist.id
                    ELSE NULL::bigint
                END AS inwork_distance_id,
                CASE dense_rank() OVER (PARTITION BY dist.id, obj.id ORDER BY swp.id, swpd.id)
                    WHEN 1 THEN
                    CASE
                        WHEN (EXISTS ( SELECT NULL::unknown
                           FROM mp_done mpd
                          WHERE ((mpd.driveway_id = obj.id) AND (mpd.driveway_work_volume >= odh.distance)))) THEN 1
                        ELSE 0
                    END
                    ELSE NULL::integer
                END AS done_distance_flag,
                CASE dense_rank() OVER (PARTITION BY dist.id, obj.id ORDER BY swp.id, swpd.id)
                    WHEN 1 THEN
                    CASE
                        WHEN (EXISTS ( SELECT NULL::unknown
                           FROM mp_auto mpa
                          WHERE ((mpa.driveway_id = obj.id) AND (mpa.work_type_id = swp.work_type_id)))) THEN 1
                        ELSE 0
                    END
                    ELSE NULL::integer
                END AS auto_distance_flag
           FROM ((((((fdc_maintenance_route dist
             JOIN fdc_odh odh ON ((dist.id = odh.maintenance_route_id)))
             JOIN fdc_object obj ON ((odh.id = obj.id)))
             JOIN fdc_odh_calculation ocalc ON ((obj.id = ocalc.id)))
             JOIN msnow.fdc_scheduled_work_plan swp ON ((dist.id = swp.maintenance_route_id)))
             JOIN msnow.fdc_scheduled_work_plan_date swpd ON ((swp.id = swpd.scheduled_work_plan_id)))
             LEFT JOIN agrgrp ON ((dist.id = agrgrp.maintenance_route_id)))
          WHERE (swpd.performance_date = ('now'::text)::date)) tt ON ((alldist.distance_id = tt.distance_id)));

COMMENT ON VIEW fdc_dw_maintain_monitor_agg_v IS 'Отчет по мониторингу содержания. Агрегирующая таблица';

