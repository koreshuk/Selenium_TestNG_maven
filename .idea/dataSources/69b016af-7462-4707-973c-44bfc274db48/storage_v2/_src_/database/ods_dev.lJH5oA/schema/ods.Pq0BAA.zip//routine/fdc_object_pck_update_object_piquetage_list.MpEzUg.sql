CREATE FUNCTION fdc_object_pck_update_object_piquetage_list(p_object t_object, p_object_piquetage_tab t_object_piquetage[])
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Процедура обновления параметров Пикетажа
  %param     p_object_id              ИД Объекта
  %param     p_object_piquetage_tab   Коллекция параметров пикетажа
  */
begin
  delete from ods.fdc_object_piquetage
   where object_id = p_object.id
     and id not in (select id
                       from unnest(p_object_piquetage_tab)
                      where id is not null
                   );

  insert into ods.fdc_object_piquetage(id,object_id,odh_location_side_id,piquetage_type_id,value,axes_type_id)
    select nextval('ods.fdc_object_piquetage_seq') id
          ,p_object.id object_id
          ,s.odh_location_side_id
          ,s.piquetage_type_id
          ,s.value
          ,s.axes_type_id
      from unnest(p_object_piquetage_tab) s
     on conflict(id) do update set odh_location_side_id = excluded.odh_location_side_id
                                  ,piquetage_type_id    = excluded.piquetage_type_id
                                  ,value                = excluded.value
                                  ,axes_type_id         = excluded.axes_type_id
          where object_id=excluded.object_id;

  return p_object.id;
end
$$;

