CREATE FUNCTION scr_recalculate_estimate()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** ODSXP-825
      Пересчитает стоимость сводной сметы для всех обязательств
  */
  rec record;
  l_estimate_id bigint;
begin
  -- I. fdc_obligation_estimate
  raise notice 'fdc_obligation_estimate';
  delete from msnow.fdc_obligation_estimate
   where is_estimate_sum
     and obligation_id in(select distinct oe.obligation_id
                            from msnow.fdc_obligation_estimate oe
                           where oe.odh_group_id is not null
                             and oe.driveway_id is null
                             and not oe.is_estimate_sum
                         );
  for rec in(select tt.object_id
                   ,tt.work_type_id
                   ,tt.measure_unit_id
                   ,sum(tt.work_volume) as work_volume
                   ,sum(tt.work_cost) as work_cost
               from(select oe.obligation_id as object_id
                          ,oe.work_type_id
                          ,oe.measure_unit_id
                          ,coalesce(oe.work_volume,0) as work_volume
                          ,coalesce(oe.work_cost,0) as work_cost
                      from msnow.fdc_obligation_estimate oe
                     where oe.odh_group_id is not null
                       and oe.driveway_id is null
                       and not oe.is_estimate_sum
                   ) tt
              group by tt.object_id
                      ,tt.work_type_id
                      ,tt.measure_unit_id
            )loop

    insert into msnow.fdc_obligation_estimate(id
                                           ,obligation_id
                                           ,work_type_id
                                           ,work_volume
                                           ,work_cost
                                           ,is_estimate_sum
                                           ,measure_unit_id
                                           )
        values(nextval('ods.fdc_common_seq')
              ,rec.object_id
              ,rec.work_type_id
              ,rec.work_volume
              ,rec.work_cost
              ,true
              ,rec.measure_unit_id
              ) returning id into l_estimate_id;
      raise notice 'INSERTED ID=% work_volume=% work_cost=%',l_estimate_id,rec.work_volume,rec.work_cost;
  end loop;

  -- II. fdc_purchase_estimate
  raise notice 'fdc_purchase_estimate';
  delete from msnow.fdc_purchase_estimate
   where is_estimate_sum
     and purchase_lot_id in(select distinct oe.purchase_lot_id
                              from msnow.fdc_purchase_estimate oe
                             where oe.odh_group_id is not null
                               and oe.driveway_id is null
                               and not oe.is_estimate_sum
                           );

  for rec in(select tt.object_id
                   ,tt.work_type_id
                   ,tt.measure_unit_id
                   ,sum(tt.work_volume) as work_volume
                   ,sum(tt.work_cost) as work_cost
               from(select oe.purchase_lot_id as object_id
                          ,oe.work_type_id
                          ,oe.measure_unit_id
                          ,coalesce(oe.work_volume,0) as work_volume
                          ,coalesce(oe.work_cost,0) as work_cost
                      from msnow.fdc_purchase_estimate oe
                     where oe.odh_group_id is not null
                       and oe.driveway_id is null
                       and not oe.is_estimate_sum
                   ) tt
              group by tt.object_id
                      ,tt.work_type_id
                      ,tt.measure_unit_id
            )loop

    insert into msnow.fdc_purchase_estimate(id
                                         ,purchase_lot_id
                                         ,work_type_id
                                         ,work_volume
                                         ,work_cost
                                         ,is_estimate_sum
                                         ,measure_unit_id
                                         )
        values(nextval('ods.fdc_common_seq')
              ,rec.object_id
              ,rec.work_type_id
              ,rec.work_volume
              ,rec.work_cost
              ,true
              ,rec.measure_unit_id
              ) returning id into l_estimate_id;
      raise notice 'INSERTED ID=% work_volume=% work_cost=%',l_estimate_id,rec.work_volume,rec.work_cost;
  end loop;

  -- III. fdc_agr_estimate
  raise notice 'fdc_agr_estimate';
  delete from msnow.fdc_agr_estimate
   where is_estimate_sum
     and agreement_id in(select distinct oe.agreement_id
                           from msnow.fdc_agr_estimate oe
                          where oe.odh_group_id is not null
                            and oe.driveway_id is null
                            and not oe.is_estimate_sum
                        );
  for rec in(select tt.object_id
                   ,tt.work_type_id
                   ,tt.measure_unit_id
                   ,sum(tt.work_volume) as work_volume
                   ,sum(tt.work_cost) as work_cost
               from(select oe.agreement_id as object_id
                          ,oe.work_type_id
                          ,oe.measure_unit_id
                          ,coalesce(oe.work_volume,0) as work_volume
                          ,coalesce(oe.work_cost,0) as work_cost
                      from msnow.fdc_agr_estimate oe
                     where oe.odh_group_id is not null
                       and oe.driveway_id is null
                       and not oe.is_estimate_sum
                   ) tt
              group by tt.object_id
                      ,tt.work_type_id
                      ,tt.measure_unit_id
            )loop

    insert into msnow.fdc_agr_estimate(id
                                    ,agreement_id
                                    ,work_type_id
                                    ,work_volume
                                    ,work_cost
                                    ,is_estimate_sum
                                    ,measure_unit_id
                                    )
        values(nextval('ods.fdc_common_seq')
              ,rec.object_id
              ,rec.work_type_id
              ,rec.work_volume
              ,rec.work_cost
              ,true
              ,rec.measure_unit_id
              ) returning id into l_estimate_id;
      raise notice 'INSERTED ID=% work_volume=% work_cost=%',l_estimate_id,rec.work_volume,rec.work_cost;
  end loop;
end;
$$;

