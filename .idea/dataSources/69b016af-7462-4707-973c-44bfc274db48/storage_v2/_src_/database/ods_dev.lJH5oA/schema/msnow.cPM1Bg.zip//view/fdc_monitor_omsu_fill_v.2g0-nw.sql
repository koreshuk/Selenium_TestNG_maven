CREATE VIEW fdc_monitor_omsu_fill_v AS
  WITH preorg AS (
         SELECT DISTINCT ON (lp.root_id) lp.root_id AS id,
            lp.id AS version_id,
            fias.ao_guid AS fias_district_ao_guid,
            lp.short_name AS name
           FROM (nsi.fdc_legal_person lp
             LEFT JOIN fdc_as_addrobj fias ON ((lp.fias_district_id = fias.id)))
          ORDER BY lp.root_id, lp.ver_start_date DESC
        ), oomsu AS (
         SELECT preorg.version_id,
            preorg.id,
            preorg.name,
            preorg.fias_district_ao_guid,
            preorg.id AS omsu_root_id
           FROM ((preorg
             JOIN nsi.fdc_person_role pr ON ((preorg.id = pr.person_id)))
             JOIN nsi.fdc_role r ON ((pr.role_id = r.id)))
          WHERE (((r.code)::text = 'OMSU'::text) AND ((statement_timestamp() >= pr.begin_date) AND (statement_timestamp() <= pr.end_date)))
        ), org AS (
         SELECT oomsu.version_id,
            oomsu.id,
            oomsu.name,
            oomsu.omsu_root_id
           FROM oomsu
        UNION
         SELECT preorg.version_id,
            preorg.id,
            oomsu.name,
            oomsu.omsu_root_id
           FROM (preorg
             JOIN oomsu ON ((preorg.fias_district_ao_guid = oomsu.fias_district_ao_guid)))
          WHERE ((preorg.fias_district_ao_guid IS NOT NULL) AND (NOT (preorg.id IN ( SELECT pr.person_id
                   FROM (nsi.fdc_person_role pr
                     JOIN nsi.fdc_role r ON ((pr.role_id = r.id)))
                  WHERE (((r.code)::text = ANY ((ARRAY['OMSU'::character varying, 'RUAD'::character varying, 'MA'::character varying, 'TO'::character varying, 'KO'::character varying])::text[])) AND ((statement_timestamp() >= pr.begin_date) AND (statement_timestamp() <= pr.end_date)))))))
        )
 SELECT aggr.customer,
    aggr.col_2,
    aggr.col_3,
    aggr.col_4,
    aggr.col_5,
    aggr.col_6,
    aggr.col_7,
    aggr.col_8,
    aggr.col_9,
    aggr.col_10,
    aggr.col_11,
    aggr.col_12,
    aggr.col_13,
    aggr.col_14,
    aggr.col_15,
    aggr.col_16,
    aggr.col_17,
    aggr.col_18,
    aggr.col_19,
    aggr.col_20,
    aggr.col_21,
    aggr.col_22,
    aggr.col_23,
    aggr.col_24,
    aggr.col_25,
    aggr.col_26,
    aggr.col_27,
    aggr.col_28,
    aggr.col_29,
    aggr.col_30,
    aggr.col_31,
    aggr.col_32,
    aggr.col_33,
    aggr.col_34,
    aggr.col_35,
    aggr.col_36,
    aggr.col_37,
    aggr.col_38,
    aggr.col_39,
    aggr.col_40,
    aggr.col_41,
    aggr.col_42,
    aggr.col_43,
    aggr.col_44,
    aggr.col_45,
    aggr.col_46,
    aggr.col_47,
    aggr.col_48,
    aggr.col_49,
    aggr.col_50,
    aggr.col_51,
    aggr.col_52,
    aggr.col_53,
    aggr.col_54,
    aggr.col_55,
    aggr.col_56,
    aggr.col_57,
    aggr.col_58,
    aggr.col_59,
    aggr.col_60,
    aggr.col_61,
    aggr.col_62,
    aggr.col_63,
    aggr.col_64,
    aggr.col_65,
    aggr.col_66,
    aggr.col_67,
    aggr.col_68,
    aggr.col_69,
    aggr.col_70,
    aggr.col_71,
    aggr.col_72,
    aggr.col_73,
    aggr.col_74,
    aggr.col_75,
        CASE
            WHEN ((aggr.col_2)::numeric <> 0.0) THEN round(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((aggr.col_3 + aggr.col_4) + aggr.col_5) + aggr.col_6) + aggr.col_7) + aggr.col_8) + aggr.col_9) + aggr.col_10) + aggr.col_11) + aggr.col_12) + aggr.col_13) + aggr.col_14) + aggr.col_15) + aggr.col_16) + aggr.col_20) + aggr.col_21) + aggr.col_22) + aggr.col_23) + aggr.col_24) + aggr.col_25) + aggr.col_26) + aggr.col_27) + aggr.col_28) + aggr.col_29) + aggr.col_30) + aggr.col_31) + aggr.col_32) + aggr.col_33) + aggr.col_34) + aggr.col_35) + aggr.col_36) + aggr.col_37) + aggr.col_38) + aggr.col_39) + aggr.col_40) + aggr.col_41) + aggr.col_42) + aggr.col_43) + aggr.col_44) + aggr.col_45) + aggr.col_46) + aggr.col_47) + aggr.col_48) + aggr.col_49) + aggr.col_50) + aggr.col_51) + aggr.col_52) + aggr.col_53) + aggr.col_54) + aggr.col_55) + aggr.col_56) + aggr.col_57) + aggr.col_58) + aggr.col_59) + aggr.col_60) + aggr.col_61) + aggr.col_62) + aggr.col_63) + aggr.col_64) + aggr.col_65) + aggr.col_66) + aggr.col_67) + aggr.col_68) + aggr.col_69) + aggr.col_70) + aggr.col_71) + aggr.col_72) + aggr.col_73) + aggr.col_74) + aggr.col_75))::double precision / (aggr.col_2)::double precision) / (70.0)::double precision) * (100.0)::double precision))::numeric, 2)
            ELSE 0.0
        END AS rate
   FROM ( SELECT org.name AS customer,
            count(omsu.id) AS col_2,
            sum(
                CASE
                    WHEN (omsu.driveway_category_id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_3,
            sum(
                CASE
                    WHEN ((COALESCE(omsu.name, ''::character varying))::text <> ''::text) THEN 1
                    ELSE 0
                END) AS col_4,
            sum(
                CASE
                    WHEN ((omsu.object_asset_owner_id IS NOT NULL) OR omsu.is_orphan_object) THEN 1
                    ELSE 0
                END) AS col_5,
            sum(
                CASE
                    WHEN ((COALESCE(omsu.object_asset_owner_inn, ''::character varying))::text <> ''::text) THEN 1
                    ELSE 0
                END) AS col_6,
            sum(
                CASE
                    WHEN ((omsu.as_area_id IS NOT NULL) OR (omsu.as_place_id IS NOT NULL)) THEN 1
                    WHEN (omsu.id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_7,
            sum(
                CASE
                    WHEN (omsu.as_street_id IS NOT NULL) THEN 1
                    WHEN (omsu.id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_8,
            sum(
                CASE
                    WHEN (COALESCE(omsu.rgn, ''::text) <> ''::text) THEN 1
                    ELSE 0
                END) AS col_9,
            sum(
                CASE
                    WHEN (omsu.odh_group_id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_10,
            sum(
                CASE
                    WHEN (omsu.cover_type_id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_11,
            sum(
                CASE
                    WHEN (omsu.driveway_gost_category_id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_12,
            sum(
                CASE
                    WHEN (omsu.geometry IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_13,
            sum(
                CASE
                    WHEN (omsu.distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_14,
            sum(
                CASE
                    WHEN (omsu.roadway_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_15,
            sum(
                CASE
                    WHEN (omsu.stop_count IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_16,
            sum(
                CASE
                    WHEN (omsu.date_from IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_17,
            sum(
                CASE
                    WHEN (omsu.edit_reason_id IS NOT NULL) THEN 1
                    WHEN (omsu.id IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_18,
            sum(
                CASE
                    WHEN (COALESCE(omsu.passport_num, ''::text) <> ''::text) THEN 1
                    ELSE 0
                END) AS col_19,
            sum(
                CASE
                    WHEN (omsu.passport_date IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_20,
            sum(
                CASE
                    WHEN (omsu.internal_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_21,
            sum(
                CASE
                    WHEN (omsu.total_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_22,
            sum(
                CASE
                    WHEN (omsu.tpu_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_23,
            sum(
                CASE
                    WHEN (omsu.stat_axes_length IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_24,
            sum(
                CASE
                    WHEN (omsu.gutters_length IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_25,
            sum(
                CASE
                    WHEN (omsu.margin_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_26,
            sum(
                CASE
                    WHEN (omsu.hard_shoulder_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_27,
            sum(
                CASE
                    WHEN (omsu.earth_shoulder_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_28,
            sum(
                CASE
                    WHEN (omsu.footway_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_29,
            sum(
                CASE
                    WHEN (omsu.footway_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_30,
            sum(
                CASE
                    WHEN (omsu.bound_stone_length IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_31,
            sum(
                CASE
                    WHEN (omsu.bound_stone_area_plan IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_32,
            sum(
                CASE
                    WHEN (omsu.sign_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_33,
            sum(
                CASE
                    WHEN (omsu.sign_design_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_34,
            sum(
                CASE
                    WHEN (omsu.sign_design_sqr IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_35,
            sum(
                CASE
                    WHEN (omsu.traff_light_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_36,
            sum(
                CASE
                    WHEN (omsu.guides_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_37,
            sum(
                CASE
                    WHEN (omsu.guides_qty_sqr IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_38,
            sum(
                CASE
                    WHEN (omsu.guides_qty_pcs IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_39,
            sum(
                CASE
                    WHEN (omsu.pedestrian_barrier_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_40,
            sum(
                CASE
                    WHEN (omsu.cable_barrier_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_41,
            sum(
                CASE
                    WHEN (omsu.parapet_barrier_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_42,
            sum(
                CASE
                    WHEN (omsu.warning_sign_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_43,
            sum(
                CASE
                    WHEN (omsu.planting_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_44,
            sum(
                CASE
                    WHEN (omsu.tram_road_length IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_45,
            sum(
                CASE
                    WHEN (omsu.engin_constr_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_46,
            sum(
                CASE
                    WHEN (omsu.bicycle_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_47,
            sum(
                CASE
                    WHEN (omsu.bicycle_length IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_48,
            sum(
                CASE
                    WHEN (omsu.tube_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_49,
            sum(
                CASE
                    WHEN (omsu.tube_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_50,
            sum(
                CASE
                    WHEN (omsu.enclosed_bus_stop_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_51,
            sum(
                CASE
                    WHEN (omsu.crossing_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_52,
            sum(
                CASE
                    WHEN (omsu.crossing_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_53,
            sum(
                CASE
                    WHEN (omsu.road_ramp_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_54,
            sum(
                CASE
                    WHEN (omsu.stand_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_55,
            sum(
                CASE
                    WHEN (omsu.lighting_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_56,
            sum(
                CASE
                    WHEN (omsu.platform_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_57,
            sum(
                CASE
                    WHEN (omsu.platform_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_58,
            sum(
                CASE
                    WHEN (omsu.other_flat_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_59,
            sum(
                CASE
                    WHEN (omsu.cleaning_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_60,
            sum(
                CASE
                    WHEN (omsu.roadway_noprkg_clean_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_61,
            sum(
                CASE
                    WHEN (omsu.roadway_prkg_clean_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_62,
            sum(
                CASE
                    WHEN (omsu.snow_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_63,
            sum(
                CASE
                    WHEN (omsu.station_number IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_64,
            sum(
                CASE
                    WHEN (omsu.station_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_65,
            sum(
                CASE
                    WHEN (omsu.auto_footway_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_66,
            sum(
                CASE
                    WHEN (omsu.manual_footway_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_67,
            sum(
                CASE
                    WHEN (omsu.rotor_area IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_68,
            sum(
                CASE
                    WHEN (omsu.bar_new_jersey IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_69,
            sum(
                CASE
                    WHEN (omsu.protective_wall IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_70,
            sum(
                CASE
                    WHEN (omsu.buffer IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_71,
            sum(
                CASE
                    WHEN (omsu.info_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_72,
            sum(
                CASE
                    WHEN (omsu.pointer_qty IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_73,
            sum(
                CASE
                    WHEN (omsu.asperity IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_74,
            sum(
                CASE
                    WHEN (omsu.asperity_distance IS NOT NULL) THEN 1
                    ELSE 0
                END) AS col_75
           FROM (org
             LEFT JOIN msnow.fdc_driveway omsu ON (((org.id = omsu.owner_id) AND (omsu.driveway_category_id = 1))))
          GROUP BY org.name) aggr;

COMMENT ON VIEW fdc_monitor_omsu_fill_v IS 'Мониторинг заполнения местных дорог';

