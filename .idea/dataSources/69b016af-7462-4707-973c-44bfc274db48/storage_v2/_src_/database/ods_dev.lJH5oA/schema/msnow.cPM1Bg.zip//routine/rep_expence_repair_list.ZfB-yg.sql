CREATE FUNCTION rep_expence_repair_list(p_driveway_category_id bigint, OUT segment_name character varying)
  RETURNS SETOF character varying
LANGUAGE plpgsql
AS $$
declare
  /** Отчет о финансовых затратах на ремонт(список)
      %param p_driveway_category_id - Ид балансовой принадлежности

      %return segment_name          - Наименование сегмента

  */
  l_driveway_category_code msnow.fdc_driveway_category.code%type;
  l_current_year text;
begin
  select code
    into strict l_driveway_category_code
    from msnow.fdc_driveway_category
   where id=p_driveway_category_id;

   l_current_year:=to_char(current_date,'YYYY');

  return query
  with org_ruad as(select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_role r on pr.role_id=r.id
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and r.code in('RUAD')
                      and l_driveway_category_code='REGION_INTERMUNICIPAL'
                   union all
                   select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and l_driveway_category_code='LOCAL'
                      and not exists(select null
                                       from nsi.fdc_role r
                                       join nsi.fdc_person_role prr on r.id=prr.role_id
                                      where prr.person_id=pr.person_id
                                        and statement_timestamp() between prr.begin_date and prr.end_date
                                        and r.code in('RUAD')
                                    )
                  )
          select dws.name as segment_name
            from msnow.fdc_driveway_segment dws
            join msnow.fdc_agreement agr on dws.agreement_id=agr.id
            join org_ruad on dws.org_ruad_id=org_ruad.org_ruad_id
            join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
           where to_char(sch.start_date_plan,'YYYY')=l_current_year
             and sch.end_date_fact is null;

  return;
end
$$;

