CREATE VIEW fdc_odh_group_v AS
  SELECT t1.code,
    t1.date_from,
    t1.date_to,
    t1.history_id,
    t2.code AS history_code,
    t2.name AS history_name,
    t1.id,
    t1.name
   FROM (fdc_odh_group t1
     LEFT JOIN fdc_odh_group t2 ON ((t2.id = t1.history_id)));

COMMENT ON VIEW fdc_odh_group_v IS 'Справочник Группа объекта ОДХ';

COMMENT ON COLUMN fdc_odh_group_v.code IS 'Код группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_group_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_odh_group_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_odh_group_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_odh_group_v.history_code IS 'Код группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_group_v.history_name IS 'Наименование группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_group_v.id IS 'Ид группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_group_v.name IS 'Наименование группы объекта ОДХ';

