CREATE FUNCTION calculate_odh_rate(p_object_prop_id bigint)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
  l_odh_rate ods.fdc_object_prop.odh_rate%type;
begin
  begin
    select coalesce(gcg.grade,0) +
           coalesce(ryg.grade,0) +
           case
             when op.belongs_to_backbone then 5
             else 0
           end +
           case
             when op.morning_traffic_present then 5
             else 0
           end +
           coalesce(tg.grade,0) +
           coalesce(drg.grade,0)
      into strict l_odh_rate
      from ods.fdc_object_prop op
      join ods.fdc_object_prop_odh opodh on op.id=opodh.object_prop_id
      join ods.fdc_odh odh on opodh.odh_id=odh.id
      left join msnow.fdc_drw_gost_category_grade gcg on odh.driveway_gost_category_id=gcg.driveway_gost_category_id
                                                         and op.date_from between gcg.start_date and gcg.end_date
      left join ods.fdc_last_repair_year ry on ry.code=case
                                                         when extract(year from current_date) - op.repair_year between 0 and 5 then '1'
                                                         when extract(year from current_date) - op.repair_year between 6 and 9 then '2'
                                                         when extract(year from current_date) - op.repair_year between 10 and 11 then '3'
                                                         when extract(year from current_date) - op.repair_year between 12 and 19 then '4'
                                                         when extract(year from current_date) - op.repair_year >=20 then '5'
                                                       end
      left join ods.fdc_last_repair_year_grade ryg on ry.id=ryg.last_repair_year_id
                                                      and op.date_from between ryg.start_date and ryg.end_date
      left join ods.fdc_traffic_grade tg on op.traffic_id=tg.traffic_id
                                            and op.date_from between tg.start_date and tg.end_date
      left join ods.fdc_destruct_rate_grade drg on op.revetment_destruct_rate_id=drg.revetment_destruct_rate_id
                                                   and op.date_from between drg.start_date and drg.end_date
     where op.id=p_object_prop_id
       and current_date between opodh.start_date and opodh.end_date;
  exception
    when NO_DATA_FOUND then
      l_odh_rate:=0;
  end;
  return l_odh_rate;
end
$$;

