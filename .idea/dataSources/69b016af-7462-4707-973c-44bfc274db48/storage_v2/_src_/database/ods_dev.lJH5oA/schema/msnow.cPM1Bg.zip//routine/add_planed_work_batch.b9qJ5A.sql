CREATE FUNCTION add_planed_work_batch(p_work_date date, p_snowfall_period_code integer DEFAULT NULL::integer, p_rain_quantity double precision DEFAULT NULL::double precision)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Автоформирование плана работ.
     Параметров p_snowfall_period_code и p_rain_quantity можно не задавать, они вычисляются в ф-ции.
    %param p_work_date            - Дата - из фильтра Дата работ с
    %param p_snowfall_period_code - Код периода снегопада (см. msnow.fdc_workplan_get_snowfall_period_cd)
    %param p_rain_quantity        - Количество осадков
  */
  l_snowfall_period_code integer;
  l_rain_quantity double precision;

  l_planed_work_card msnow.t_srv_planed_work_card[];
  l_planed_work_row msnow.t_srv_planed_work_card;

  l_weekday_check boolean:=true;

  l_bitpad bit(7):='1111111';
  l_mo_th bit(7):='0001001'; /*ВсСбПтЧтСрВтПн*/

  l_work_type_row msnow.fdc_work_type%rowtype;

  agrrec record;
begin
  delete from msnow.fdc_planed_work where work_date=p_work_date;

  l_snowfall_period_code:=COALESCE(p_snowfall_period_code
                                  ,msnow.fdc_workplan_get_snowfall_period_cd(p_work_date => p_work_date)
                                  );
  l_rain_quantity:=coalesce(p_rain_quantity
                           ,msnow.fdc_workplan_get_snowinfall_qty(p_snowfall_period => l_snowfall_period_code
                                                               ,p_work_date       => p_work_date
                                                                )
                           );


  if l_snowfall_period_code = 22 then-- Таблица 1
    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_22();
  elsif l_snowfall_period_code = 21 then-- Таблица 2
    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_21();
  elsif l_snowfall_period_code = 31 then-- Таблица 3
    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_31();
  elsif l_snowfall_period_code = 32 then-- Таблица 4
    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_32();
  elsif l_snowfall_period_code = 33 then-- Таблица 5

    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_33();
  elsif l_snowfall_period_code = 1 then-- Таблица 6
    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_1();
  elsif l_snowfall_period_code = 34 then-- Таблица 7
    l_planed_work_card:=msnow.fdc_workplan_get_planed_work_card_34();
  end if;

  --raise notice 'l_snowfall_period_code %',l_snowfall_period_code;

  foreach l_planed_work_row in array l_planed_work_card loop
    select *
      into l_work_type_row
      from msnow.fdc_work_type
     where code=l_planed_work_row.work_type_code;

    --raise notice 'work_type_code=% odh_group_code=% cover_type_code=% active=%',l_planed_work_row.work_type_code,l_planed_work_row.odh_group_code,l_planed_work_row.cover_type_code,l_planed_work_row.is_active;
    if l_planed_work_row.is_active then
      -- Проверка условия День недели
      if l_planed_work_row.repeat_code::bit(7) & l_bitpad = l_mo_th then -- понедельник, четверг
        l_weekday_check:=case
                           when extract(dow from p_work_date) in(1,4) then TRUE
                           else false
                         end;
      elsif l_planed_work_row.repeat_code is null then -- нет указаний насчет дня недели
        l_weekday_check:=true;
      end if;
      --raise notice 'l_weekday_check %',l_weekday_check;
      -- Выбор обязательства и расчет объема работ. Создание плана работ, если доп. условия выполнены
      if l_weekday_check and
         (l_planed_work_row.rain_gt is null or coalesce(l_rain_quantity,-1) >= l_planed_work_row.rain_gt) and
         (l_planed_work_row.rain_lt is null or coalesce(l_rain_quantity,-1) <= l_planed_work_row.rain_lt) then
         --raise notice 'before for';
        for agrrec in(select agr.id agreement_id
                            ,dw.odh_group_id
                            ,dw.cover_type_id
                            ,round(sum(case
                                         when l_work_type_row.code in('ROAD_DEICING','SNOWPLUPH_CLN') then coalesce(dw.reduced_distance,0.0)
                                         when l_work_type_row.code = 'TRASHCAN_CLN' then coalesce(dw.stop_count,0)
                                         when l_work_type_row.code = 'LANDING_DEICING' then 0
                                         else 0
                                       end
                                      )::numeric,3
                                  ) work_volume
                        from msnow.fdc_agreement agr
                        join msnow.fdc_agreement_object agro on agro.argeement_id=agr.id
                        join msnow.fdc_driveway dw on dw.id=agro.driveway_id
                        join msnow.fdc_odh_group ogr on ogr.id=dw.odh_group_id
                   left join msnow.fdc_cover_type cvt on cvt.id=dw.cover_type_id
                       where p_work_date between agr.work_date_from and agr.work_date_to
                       and exists (select null
                                     from msnow.fdc_agr_estimate agre
                                    where agre.agreement_id=agr.id
                                      and agre.work_type_id in(with recursive wth(id
                                                                                 ,code
                                                                                 ,work_type_uni_id
                                                                                 ,level
                                                                                 ) as(select wtf.id
                                                                                            ,wtf.code
                                                                                            ,wtf.work_type_uni_id
                                                                                            ,1
                                                                                        from msnow.fdc_work_type wtf
                                                                                       where wtf.code=l_planed_work_row.work_type_code
                                                                                      union
                                                                                      select wtn.id
                                                                                            ,wtn.code
                                                                                            ,wtn.work_type_uni_id
                                                                                            ,level+1
                                                                                        from msnow.fdc_work_type wtn
                                                                                        join wth on wth.work_type_uni_id=wtn.id
                                                                                     )
                                                                        select id
                                                                          from wth
                                                            )
                                  )

                         and ogr.code=l_planed_work_row.odh_group_code
                         and (l_planed_work_row.cover_type_code is null  or cvt.code=l_planed_work_row.cover_type_code)
                       group by agr.id
                               ,dw.odh_group_id
                               ,dw.cover_type_id
                     ) loop
          --raise notice 'ADD ROW aggreement_id=%',agrrec.agreement_id;
          insert into msnow.fdc_planed_work(id
                                         ,agreement_id
                                         ,odh_group_id
                                         ,cover_type_id
                                         ,work_date
                                         ,work_type_id
                                         ,work_volume
                                         ,unit_id
                                         ) VALUES
              (nextval('ods.fdc_common_seq')
              ,agrrec.agreement_id
              ,agrrec.odh_group_id
              ,agrrec.cover_type_id
              ,p_work_date
              ,l_work_type_row.id
              ,agrrec.work_volume
              ,l_work_type_row.measure_unit_id
              );

        end loop;
      end if;
    end if;
  end loop;
end;
$$;

