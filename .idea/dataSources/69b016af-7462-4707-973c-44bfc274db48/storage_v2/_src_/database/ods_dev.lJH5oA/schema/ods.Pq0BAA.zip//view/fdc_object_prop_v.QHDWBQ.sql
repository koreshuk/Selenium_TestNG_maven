CREATE VIEW fdc_object_prop_v AS
  SELECT prop.id,
    obj.as_place_id,
    obj.as_street_id,
    obj.driveway_category_id,
    obj.version_date_from AS object_version_date_from,
    obj.version_date_to AS object_version_date_to,
    objpodh.start_date AS object_prop_odh_start_date,
    objpodh.end_date AS object_prop_odh_end_date,
    obj.root_id AS object_root_id,
    COALESCE(afias.municipality_id, pfias.municipality_id) AS municipality_id,
        CASE
            WHEN (afias.municipality_id IS NOT NULL) THEN afias.municipality_name
            ELSE pfias.municipality_name
        END AS municipality_name,
    odh.name AS object_name,
    obj.begin_distance,
    obj.end_distance,
    obj.customer_id,
    cust.short_name AS customer_name,
    obj.owner_id,
    ownr.short_name AS owner_name,
    prop.deleted,
    prop.date_from,
    prop.date_to,
    prop.odh_rate,
    prop.repair_amount,
    odh.id AS odh_id,
        CASE
            WHEN (((('now'::text)::date >= prop.date_from) AND (('now'::text)::date <= prop.date_to)) AND (NOT prop.deleted)) THEN true
            ELSE false
        END AS is_prop_last_version,
        CASE sign((COALESCE(sum(
            CASE
                WHEN (NOT prop.deleted) THEN 1
                ELSE NULL::integer
            END) OVER (PARTITION BY obj.root_id), (0)::bigint))::double precision)
            WHEN 1 THEN false
            ELSE true
        END AS all_deleted
   FROM ((((((((fdc_object obj
     JOIN fdc_odh odh ON ((obj.id = odh.id)))
     JOIN fdc_object_state objs ON ((obj.object_state_id = objs.id)))
     LEFT JOIN fdc_object_prop_odh objpodh ON ((odh.id = objpodh.odh_id)))
     LEFT JOIN fdc_object_prop prop ON ((objpodh.object_prop_id = prop.id)))
     LEFT JOIN nsi.fdc_legal_person ownr ON ((obj.owner_id = ownr.id)))
     LEFT JOIN nsi.fdc_legal_person cust ON ((obj.customer_id = cust.id)))
     LEFT JOIN nsi.fdc_fias_address_reference_v afias ON ((obj.as_area_id = afias.id)))
     LEFT JOIN nsi.fdc_fias_address_reference_v pfias ON ((obj.as_place_id = pfias.id)))
  WHERE ((objs.code)::text = 'APPROVED'::text);

COMMENT ON VIEW fdc_object_prop_v IS 'Реестр эксплоатационных досье';

COMMENT ON COLUMN fdc_object_prop_v.id IS 'Ид эксплоатационного досье';

COMMENT ON COLUMN fdc_object_prop_v.as_place_id IS 'Ид населенного пункта';

COMMENT ON COLUMN fdc_object_prop_v.as_street_id IS 'Ид улицы';

COMMENT ON COLUMN fdc_object_prop_v.driveway_category_id IS 'Ид балансовой принадлежности';

COMMENT ON COLUMN fdc_object_prop_v.object_version_date_from IS 'Дата начала версии объекта';

COMMENT ON COLUMN fdc_object_prop_v.object_version_date_to IS 'Дата окончания версии объекта';

COMMENT ON COLUMN fdc_object_prop_v.object_prop_odh_start_date IS 'Дата начала привязки версии объекта и версии досье';

COMMENT ON COLUMN fdc_object_prop_v.object_prop_odh_end_date IS 'Дата окончания привязки версии объекта и версии досье';

COMMENT ON COLUMN fdc_object_prop_v.object_root_id IS 'Сквозной Ид версии участка';

COMMENT ON COLUMN fdc_object_prop_v.municipality_id IS 'Ид муниципального образования';

COMMENT ON COLUMN fdc_object_prop_v.municipality_name IS 'Наименование муниципального образования';

COMMENT ON COLUMN fdc_object_prop_v.object_name IS 'Наименование участка дороги';

COMMENT ON COLUMN fdc_object_prop_v.begin_distance IS 'Начало участка дороги';

COMMENT ON COLUMN fdc_object_prop_v.end_distance IS 'Конец участка дороги';

COMMENT ON COLUMN fdc_object_prop_v.customer_id IS 'Ид заказчика';

COMMENT ON COLUMN fdc_object_prop_v.customer_name IS 'Наименование заказчика';

COMMENT ON COLUMN fdc_object_prop_v.owner_id IS 'Ид балансодержателя';

COMMENT ON COLUMN fdc_object_prop_v.owner_name IS 'Ид балансодержателя';

COMMENT ON COLUMN fdc_object_prop_v.deleted IS 'Состояние';

COMMENT ON COLUMN fdc_object_prop_v.date_from IS 'Дата с эксплуатационного досье';

COMMENT ON COLUMN fdc_object_prop_v.date_to IS 'Дата по эксплуатационного досье';

COMMENT ON COLUMN fdc_object_prop_v.odh_rate IS 'Рейтинг участка';

COMMENT ON COLUMN fdc_object_prop_v.repair_amount IS 'Стоимость ремонта';

COMMENT ON COLUMN fdc_object_prop_v.odh_id IS 'Ид версии участка дороги';

COMMENT ON COLUMN fdc_object_prop_v.is_prop_last_version IS 'Признак Последняя действующая версия досье';

COMMENT ON COLUMN fdc_object_prop_v.all_deleted IS 'Признак наличия неудаленных досье';

