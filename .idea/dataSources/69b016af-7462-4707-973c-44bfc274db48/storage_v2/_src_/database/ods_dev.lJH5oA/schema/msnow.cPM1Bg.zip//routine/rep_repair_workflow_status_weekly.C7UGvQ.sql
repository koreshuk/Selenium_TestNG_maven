CREATE FUNCTION rep_repair_workflow_status_weekly(p_current_date date DEFAULT ('now'::text)::date, OUT grouping_flag integer, OUT driveway_category text, OUT driveway_segment_qty integer, OUT driveway_segment_volume double precision, OUT finished_qty integer, OUT finished_volume double precision, OUT inwork_year_qty integer, OUT inwork_year_volume double precision, OUT finish_plan_qty integer, OUT finish_plan_volume double precision, OUT finished_fact_qty integer, OUT finished_fact_volume double precision, OUT inwork_year_plan_qty integer, OUT inwork_year_plan_volume double precision, OUT inwork_today_qty integer, OUT inwork_today_volume double precision, OUT planned_start_qty integer, OUT planned_start_volume double precision, OUT planned_finish_qty integer, OUT planned_finish_volume double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Отчет "Сведения о ходе работ по ремонту за неделю"
  %param p_current_date        - Текущая дата

  %return grouping_flag           -- Признак группировки (Итоговая строка)
  %return driveway_category       -- "Сеть"
  %return driveway_segment_qty    -- "Количество участков (план на 2017 год), шт."
  %return driveway_segment_volume -- "Количество участков (план на 2017 год), млн.кв.м"
  %return finished_qty            -- "Завершено работ, шт. (ВСЕГО)"
  %return finished_volume         -- "Завершено работ, тыс.кв.м (ВСЕГО)"
  inwork_year_qty
  inwork_year_volume
  %return finish_plan_qty         -- "План по завершенным с 26.06 по 02.07, шт. (неделя)"
  %return finish_plan_volume      -- "План по завершенным с 26.06 по 02.07, тыс.кв.м (неделя)"
  %return finished_fact_qty       -- "Завершено (факт) с 26.06 по 28.06, шт."
  %return finished_fact_volume    -- "Завершено (факт) с 26.06 по 28.06, тыс.кв.м"
  inwork_year_plan_qty
  inwork_year_plan_volume
  %return inwork_today_qty        -- "В работе (факт) на 28.06, шт."
  %return inwork_today_volume     -- "В работе (факт) на 28.06, тыс.кв.м"
  %return planned_start_qty       -- "Планируется начать с 03.07 по 09.07, шт. (неделя)"
  %return planned_start_volume    -- "Планируется начать с 03.07 по 09.07, тыс.кв.м (неделя)"
  %return planned_finish_qty      -- "Планируется завершить с 03.07 по 09.07, шт. (неделя)"
  %return planned_finish_volume   -- "Планируется завершить с 03.07 по 09.07, тыс.кв.м (неделя)"

  */

  l_year integer;             -- Год
  l_this_week_from date;      -- Понедельник текущей недели
  l_this_week_to date;        -- Воскресенье текущей недели
  l_current_date date;        -- Текущая дата
  l_next_week_from date;      -- Понедельник следующей недели
  l_next_week_to date;        -- Воскресенье сдудующей недели

  c_zero_i constant integer:=0;
  c_zero_f constant double precision:=0.0;
begin

  select extract('YEAR' from t.cd)::integer as year
        ,date_trunc('week',t.cd)::date as this_week_from
        ,date_trunc('week',t.cd)::date + 6 as this_week_to
        ,t.cd as current_date
        ,date_trunc('week',t.cd)::date + 7 as next_week_from
        ,date_trunc('week',t.cd)::date + 13 as next_week_to
    into l_year
        ,l_this_week_from
        ,l_this_week_to
        ,l_current_date
        ,l_next_week_from
        ,l_next_week_to
    from (select coalesce(p_current_date,current_date) cd
         ) t;

  return query
    with wclosed as(select agrm.agr_root_id
                          ,ajrn.driveway_segment_id
                          ,sum(case
                                 when mu.code='100_MTK' then ajrn.work_volume /10.0
                                 when mu.code='1000_MTK' then ajrn.work_volume
                                 when mu.code='MTK' then ajrn.work_volume/1000.0
                               end
                              ) as mtk_work_volume
                          ,max(ajrn.work_date) as max_work_date
                      from msnow.fdc_agreement agrm
                      join msnow.fdc_agr_estimate agrme on agrm.id=agrme.agreement_id
                      join msnow.fdc_work_type awt on agrme.work_type_id=awt.id
                      left join msnow.fdc_measure_unit mu on awt.measure_unit_id=mu.id
                      left join msnow.fdc_asphalt_journal ajrn on awt.id=ajrn.work_type_id
                     where awt.is_asphalt
                     group by agrm.agr_root_id
                             ,ajrn.driveway_segment_id
                    having count(case
                                   when ajrn.id is null or not ajrn.is_last_work then ajrn.work_type_id
                                 end
                                ) =0
                   )

        ,milling as(select distinct sagre.driveway_segment_id
                      from msnow.fdc_agreement sagr
                      join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                      join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                     where swt.is_milling
                       and sagre.driveway_segment_id is not null
                       and not swt.is_additional_work
                   )
        ,levelling as(select distinct sagre.driveway_segment_id
                        from msnow.fdc_agreement sagr
                        join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                        join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                       where swt.is_levelling
                         and sagre.driveway_segment_id is not null
                         and not swt.is_additional_work
                     )
        ,asph as(select distinct sagre.driveway_segment_id
                   from msnow.fdc_agreement sagr
                   join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                   join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                  where swt.is_asphalt
                    and sagre.driveway_segment_id is not null
                    and not swt.is_additional_work
                )
        ,rside as(select distinct sagre.driveway_segment_id
                    from msnow.fdc_agreement sagr
                    join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                    join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                   where swt.is_roadside
                     and sagre.driveway_segment_id is not null
                     and not swt.is_additional_work
                 )
        ,f as(select ssch.driveway_segment_id
                    ,coalesce(ceil((ssch.end_date_plan+1-ssch.start_date_plan)*20/100.0),0) as day_cnt
                from msnow.fdc_work_schedule ssch
                join levelling on ssch.driveway_segment_id=levelling.driveway_segment_id
             )
        ,b as(select ssch.driveway_segment_id
                    ,coalesce(ceil((ssch.end_date_plan+1-ssch.start_date_plan)*50/100.0),0) as day_cnt
                from msnow.fdc_work_schedule ssch
                join asph on ssch.driveway_segment_id=asph.driveway_segment_id
             )
        ,a as(select ssch.driveway_segment_id
                    ,coalesce(ceil((ssch.end_date_plan+1-ssch.start_date_plan)*15/100.0),0) as day_cnt
                from msnow.fdc_work_schedule ssch
                join rside on ssch.driveway_segment_id=rside.driveway_segment_id
             )
        ,e as(select ssch.driveway_segment_id
                    ,coalesce(ceil(ssch.end_date_plan+1-ssch.start_date_plan),0) -
                     coalesce(a.day_cnt,0) -
                     coalesce(f.day_cnt,0) -
                     coalesce(b.day_cnt,0) as day_cnt
                from msnow.fdc_work_schedule ssch
                left join a on ssch.driveway_segment_id=a.driveway_segment_id
                left join f on ssch.driveway_segment_id=f.driveway_segment_id
                left join b on ssch.driveway_segment_id=b.driveway_segment_id
             )

        ,dates as(select sagr.agr_root_id
                        ,sagre.driveway_segment_id
                        ,max(case
                               when swt.is_asphalt then sch.start_date_plan-1+coalesce(e.day_cnt,0)::integer+coalesce(f.day_cnt,0)::integer+coalesce(b.day_cnt,0)::integer
                             end
                            ) as end_date_plan
                        ,sum(case
                               when mu.code='100_MTK' then ajrn.work_volume /10.0
                               when mu.code='1000_MTK' then ajrn.work_volume
                               when mu.code='MTK' then ajrn.work_volume/1000.0
                             end
                            ) as mtk_work_volume
                    from msnow.fdc_agreement sagr
                    join msnow.fdc_agr_estimate sagre on sagr.id=sagre.agreement_id
                    join msnow.fdc_work_type swt on sagre.work_type_id=swt.id
                    left join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                    left join msnow.fdc_asphalt_journal ajrn on ajrn.driveway_segment_id=sagre.driveway_segment_id
                                                                and ajrn.work_type_id=swt.id
                    left join msnow.fdc_work_schedule sch on sagre.driveway_segment_id=sch.driveway_segment_id
                    left join e on sagre.driveway_segment_id=e.driveway_segment_id
                    left join f on sagre.driveway_segment_id=f.driveway_segment_id
                    left join b on sagre.driveway_segment_id=b.driveway_segment_id
                   where swt.is_asphalt
                   group by sagr.agr_root_id
                           ,sagre.driveway_segment_id
                 )
       ,ingrs as(select irg.driveway_segment_id
                       ,count(irg.id) reg_qty
                   from msnow.fdc_ingress_registration irg
                  where irg.registration_date::date=l_current_date
                  group by irg.driveway_segment_id
                )
      select grouping(dwct.code) as grouping_flag
            ,case grouping(dwct.code)
               when 0 then case dwct.code
                             when 'LOCAL' then 'Муниципальная'
                             when 'REGION_INTERMUNICIPAL' then 'Региональная'
                           end
               else 'ИТОГО:'
             end as driveway_category
            ,COALESCE(count(distinct dtl.driveway_segment_id)::integer,c_zero_i) as driveway_segment_qty
            ,round(COALESCE(sum(dtl.driveway_segment_volume)/1000.0,c_zero_f)::numeric,2)::double precision as driveway_segment_volume
            ,COALESCE(count(distinct dtl.closed_works_id)::integer,c_zero_i) as finished_qty
            ,round(COALESCE(sum(dtl.mtk_work_volume),c_zero_f)::numeric,2)::double precision as finished_volume
            ---
            ,COALESCE(count(distinct dtl.inwork_year_id)::integer,c_zero_i) as inwork_year_qty
            ,round(COALESCE(sum(dtl.inwork_year_volume),c_zero_f)::numeric,2)::double precision as inwork_year_volume
            ---
            ,COALESCE(count(distinct dtl.clplan_id)::integer,c_zero_i) as finish_plan_qty
            ,round(COALESCE(sum(dtl.clplan_work_volume),c_zero_f)::numeric,2)::double precision as finish_plan_volume
            ,COALESCE(count(distinct dtl.finished_fact_id)::integer,c_zero_i) as finished_fact_qty
            ,round(COALESCE(sum(dtl.finished_fact_volume),c_zero_f)::numeric,2)::double precision as finished_fact_volume
            ---
            ,COALESCE(count(distinct dtl.inwork_year_plan_id)::integer,c_zero_i) as inwork_year_plan_qty
            ,round(COALESCE(sum(dtl.inwork_year_plan_volume),c_zero_f)::numeric,2)::double precision as inwork_year_plan_volume
            ---
            ,COALESCE(count(distinct dtl.in_work_id)::integer,c_zero_i) as inwork_today_qty
            ,round(COALESCE(sum(dtl.in_work_volume),c_zero_f)::numeric,2)::double precision as inwork_today_volume
            ,COALESCE(count(dtl.planned_start_id)::integer,c_zero_i) as planned_start_qty
            ,round(COALESCE(sum(dtl.planned_start_volume)/1000.0,c_zero_f)::numeric,2)::double precision as planned_start_volume
            ,COALESCE(count(distinct dtl.planned_finish_id)::integer,c_zero_i) as planned_finish_qty
            ,round(COALESCE(sum(dtl.planned_finish_volume),c_zero_f)::numeric,2)::double precision as planned_finish_volume
        from msnow.fdc_driveway_category dwct
   left join(select dwc.id as driveway_category_id
                   ,dws.id as driveway_segment_id
                   ,dws.asphalt_area as driveway_segment_volume
                   ,case
                      when wclosed.driveway_segment_id is not null then dws.id
                    end as closed_works_id
                   ,wclosed.mtk_work_volume
                   ----
                   ,case
                      when wsch.start_date_fact<=l_current_date and wsch.end_date_fact is null then dws.id
                    end as inwork_year_id
                   ,case
                      when wsch.start_date_fact<=l_current_date and wsch.end_date_fact is null then clplan.mtk_work_volume
                    end as inwork_year_volume
                   ----
                   ,case
                      when clplan.end_date_plan between l_this_week_from and l_this_week_to then dws.id
                    end clplan_id
                   ,case
                      when clplan.end_date_plan between l_this_week_from and l_this_week_to then clplan.mtk_work_volume
                    end as clplan_work_volume
                   ,case
                      when wclosed.max_work_date between l_this_week_from and l_current_date then dws.id
                    end as finished_fact_id
                   ,case
                      when wclosed.max_work_date between l_this_week_from and l_current_date then clplan.mtk_work_volume
                    end as finished_fact_volume
                    -----------
                   ,case
                      when l_current_date between wsch.start_date_plan and wsch.end_date_plan then dws.id
                    end as inwork_year_plan_id
                   ,case
                      when l_current_date between wsch.start_date_plan and wsch.end_date_plan then clplan.mtk_work_volume
                    end as inwork_year_plan_volume
                    -----------
                   ,case
                      when ingrs.reg_qty > 0 then dws.id
                    end as in_work_id
                   ,case
                      when ingrs.reg_qty > 0 then clplan.mtk_work_volume
                    end as in_work_volume
                   ,case
                      when wsch.start_date_plan between l_next_week_from and l_next_week_to then dws.id
                    end as planned_start_id
                   ,case
                      when wsch.start_date_plan between l_next_week_from and l_next_week_to then dws.asphalt_area
                    end as planned_start_volume
                   ,case
                      when clplan.end_date_plan between l_next_week_from and l_next_week_to then dws.id
                    end planned_finish_id
                   ,case
                      when clplan.end_date_plan between l_next_week_from and l_next_week_to then clplan.mtk_work_volume
                    end as planned_finish_volume
               from msnow.fdc_segment s
               join msnow.fdc_driveway_segment dws on s.id=dws.id
               join ods.fdc_odh dw on dws.driveway_id=dw.id
               join ods.fdc_object dwobj on dw.id=dwobj.id
               join msnow.fdc_driveway_category dwc on dwobj.driveway_category_id=dwc.id
               join msnow.fdc_work_schedule wsch on dws.id=wsch.driveway_segment_id
               join msnow.fdc_dw_segment_status dwss on dws.status_id=dwss.id
               left join msnow.fdc_agreement agr on dws.agreement_id=agr.id
               left join wclosed on agr.agr_root_id=wclosed.agr_root_id
                                    and dws.id=wclosed.driveway_segment_id
               left join dates clplan on agr.agr_root_id=clplan.agr_root_id
                                         and dws.id=clplan.driveway_segment_id
               left join ingrs on dws.id=ingrs.driveway_segment_id
              where extract(year from wsch.start_date_plan)::integer = l_year
                and wsch.start_date_plan is not null
                and wsch.end_date_plan is not null
                and dwss.code in ('COMPLETED','PLANNED','IN_PROCESS')
            ) dtl on dwct.id=dtl.driveway_category_id
       group by rollup(dwct.code);
  return;
end
$$;

