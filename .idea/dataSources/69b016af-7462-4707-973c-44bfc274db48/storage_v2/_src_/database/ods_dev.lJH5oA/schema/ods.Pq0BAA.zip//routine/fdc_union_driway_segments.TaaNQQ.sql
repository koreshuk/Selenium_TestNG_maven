CREATE FUNCTION fdc_union_driway_segments(p_driveway_list text DEFAULT NULL::text)
  RETURNS geometry
LANGUAGE plpgsql
AS $$
declare
  /*Скрипт для клейки геометрий в единый трек дороги
    %p_driveway_list   - Список Ид сегментов
  */
  l_pused ods.t_road_points[];
  l_ptmp ods.t_road_points[];
  l_pfree ods.t_road_points[];

  --l_current ods.t_road_points;

  l_lstr geometry;
  l_road_segment_id bigint;

  l_f_road_segment_id bigint;
  l_f_point_type varchar(1);
  l_f_road_segment_geometry geometry;
  l_u_road_segment_id bigint;
  l_u_point_type varchar(1);
  l_point_distance double precision;
  l_f_lpoint geometry;
  l_u_lpoint geometry;
begin
  with params as(select unnest(string_to_array(p_driveway_list,','))::bigint as param_id
                )
      select array_agg(row(t.lpoint
                          ,t.point_type
                          ,t.road_segment_id
                          ,t.road_segment_geometry
                          )::ods.t_road_points
                      )
        into l_pfree
        from(select ST_StartPoint(ds.geometry) as lpoint
                   ,'S' as point_type
                   ,ds.id as road_segment_id
                   ,ds.geometry as road_segment_geometry
               from params p
               join ods.fdc_road_segment ds on ds.id = p.param_id
             union all
             select ST_EndPoint(ds.geometry) as lpoint
                  ,'E' as point_type
                  ,ds.id as road_segment_id
                  ,ds.geometry as road_segment_geometry
              from params p
              join ods.fdc_road_segment ds on ds.id = p.param_id
            ) t;

  --raise notice 'free rows = %',cardinality(l_pfree);

  select f.road_segment_id
    into l_road_segment_id
    from unnest(l_pfree) f
   limit 1;

  select road_segment_geometry
    into l_lstr
    from unnest(l_pfree) f
   where f.road_segment_id = l_road_segment_id
     and f.point_type='S';

  --raise notice 'cnt before = %',cardinality(l_pfree);
  --raise notice 'cnt new before = %',cardinality(l_pused);

  select array_agg(row(t.lpoint
                      ,t.point_type
                      ,t.road_segment_id
                      ,t.road_segment_geometry
                      )::ods.t_road_points
                  )
    into l_ptmp
    from unnest(l_pfree) t
   where t.road_segment_id = l_road_segment_id;

  l_pused:=array_cat(l_pused,l_ptmp);

  select array_agg(row(t.lpoint
                      ,t.point_type
                      ,t.road_segment_id
                      ,t.road_segment_geometry
                      )::ods.t_road_points
                  )
    into l_pfree
    from unnest(l_pfree) t
   where t.road_segment_id <> l_road_segment_id;

  -- 4:
  while cardinality(l_pfree)>0 loop
    with dist as(select f.road_segment_id as f_road_segment_id
                       ,f.point_type as f_point_type
                       ,f.road_segment_geometry as f_road_segment_geometry
                       ,u.road_segment_id as u_road_segment_id
                       ,u.point_type as u_point_type
                       ,f.lpoint as f_lpoint
                       ,u.lpoint as u_lpoint
                       ,ST_Distance(f.lpoint, u.lpoint) as point_distance
                   from unnest(l_pfree) f
                   join unnest(l_pused) u on true
                )
        select f_road_segment_id
              ,f_point_type
              ,f_road_segment_geometry
              ,u_road_segment_id
              ,u_point_type
              ,f_lpoint
              ,u_lpoint
              ,point_distance
          into l_f_road_segment_id
              ,l_f_point_type
              ,l_f_road_segment_geometry
              ,l_u_road_segment_id
              ,l_u_point_type
              ,l_f_lpoint
              ,l_u_lpoint
              ,l_point_distance
          from dist d1
         where d1.point_distance=(select min(d2.point_distance)
                                    from dist d2
                                 )
         limit 1;
    --raise notice 'l_f_road_segment_id=%',l_f_road_segment_id;
    --raise notice 'l_u_road_segment_id=%',l_u_road_segment_id;
    --raise notice 'l_point_distance=%',l_point_distance;

    --raise notice 'free % -> used %',l_f_point_type,l_u_point_type;

    if l_point_distance>0 then
      l_lstr := ST_Union(l_lstr, ST_MakeLine(l_u_lpoint, l_f_lpoint));
    end if;
    l_lstr := ST_Union(l_lstr,l_f_road_segment_geometry);
    -- 7:
    select array_agg(row(t.lpoint
                        ,t.point_type
                        ,t.road_segment_id
                        ,t.road_segment_geometry
                        )::ods.t_road_points
                    )
      into l_ptmp
      from unnest(l_pfree) t
     where t.road_segment_id = l_f_road_segment_id;

    l_pused:=array_cat(l_pused,l_ptmp);

    select array_agg(row(t.lpoint
                        ,t.point_type
                        ,t.road_segment_id
                        ,t.road_segment_geometry
                        )::ods.t_road_points
                    )
      into l_pfree
      from unnest(l_pfree) t
     where t.road_segment_id <> l_f_road_segment_id;
  end loop;


  --raise notice 'cnt after = %',cardinality(l_pfree);
  --raise notice 'cnt new after = %',cardinality(l_pused);

  return case geometrytype(l_lstr)
           when 'MULTILINESTRING' then st_linemerge(l_lstr)
           else l_lstr
         end;
end
$$;

