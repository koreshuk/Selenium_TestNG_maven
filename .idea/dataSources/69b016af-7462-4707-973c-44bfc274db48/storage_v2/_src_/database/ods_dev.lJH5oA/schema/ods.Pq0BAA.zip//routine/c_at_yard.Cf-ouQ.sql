CREATE FUNCTION c_at_yard()
  RETURNS character varying
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 'YARD'::varchar;
$$;

