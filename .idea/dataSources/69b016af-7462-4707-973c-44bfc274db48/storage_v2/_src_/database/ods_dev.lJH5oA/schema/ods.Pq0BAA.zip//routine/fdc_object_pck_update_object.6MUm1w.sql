CREATE FUNCTION fdc_object_pck_update_object(p_object t_object, p_biz_event_id bigint DEFAULT NULL::bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
   /** Функция обновления объекта
  Вызывается для обновления незначемых бизнес данных, к примеру - комментариев,
  автоматически вызовет edit_object если это условие нарушено
  %param     p_object           Объект редактируемые атрибуты
  %param    p_biz_event_id      Идентификатор бизнес события
  %return                       Ид версии объекта
  */
  l_current_version_date_from ods.fdc_object.version_date_from%type;
  l_root_id                   ods.fdc_object.root_id%type;
  r_object_before             ods.t_object;
  r_object_after              ods.t_object;

  l_approved_id               ods.fdc_object.id%type;
  l_approved_date_from        ods.fdc_object.version_date_from%type;
  l_approved_date_to          ods.fdc_object.version_date_to%type;

  l_prev_project_id           ods.fdc_object.id%type;
  l_prev_project_date_from    ods.fdc_object.version_date_to%type;

  l_min_date_from             ods.fdc_object.version_date_from%type;
  l_max_date_from             ods.fdc_object.version_date_from%type;

  l_okrug_id                  ods.fdc_object.okrug_id%type;
  l_district_id               ods.fdc_object.district_id%type;
begin
  /*fdc_event_pck.event_start( p_event_id        => l_event_id
                             , p_event_type_code => const_core.c_et_edit_obj
                             , p_event_category  => const_core.c_ec_obj
                             );
  */

  select root_id
        ,version_date_from
    into l_root_id
        ,l_current_version_date_from
    from ods.fdc_object
    where id = p_object.id;

  --> Получим версию объекта до изменениями для целей аудита
  r_object_before := ods.fdc_object_pck_get_object(p_object_id          => p_object.id
                                                  ,p_object_update_date => null
                                                   );


  -- Получаем согласованную версию, на основе которой создан проект
  select min(o.id)
         ,min(o.version_date_from)
         ,min(o.version_date_to)
     into l_approved_id
         ,l_approved_date_from
         ,l_approved_date_to
     from ods.fdc_object o
left join ods.fdc_object o1 on o1.version_date_from > o.version_date_from
                               and o1.root_id = o.root_id

 where o.root_id=l_root_id
   and o.version_date_from < l_current_version_date_from
   and o.object_state_id = ods.c_os_approved()
   and o1.version_date_from < l_current_version_date_from
   and o1.object_state_id = ods.c_os_approved()
   and o1.id is null;

  -- Получаем предыдущий проект/насогласование, если есть
  select min(o.id)
        ,min(o.version_date_from)
    into l_prev_project_id
        ,l_prev_project_date_from
      from ods.fdc_object o
 left join ods.fdc_object o1 on o1.root_id = o.root_id
                                and o1.version_date_from > o.version_date_from

     where o.root_id = l_root_id
       and o.version_date_from < l_current_version_date_from
       and o.object_state_id in (ods.c_os_project()
                                ,ods.c_os_submited()
                                )
       and o1.version_date_from < l_current_version_date_from
       and o1.object_state_id in (ods.c_os_project()
                                 ,ods.c_os_submited()
                                 )
       and o1.id is null;

  l_min_date_from := greatest(l_approved_date_from, coalesce(l_prev_project_date_from, l_approved_date_from)) + interval '1' day;
  l_max_date_from := p_object.version_date_to;

  if p_object.version_date_from < l_min_date_from or p_object.version_date_from > l_max_date_from then
    raise exception 'Дата начала действия выходит за допустимые пределы: % - %',to_char(l_min_date_from,'DD.MM.YYYY'),to_char(l_max_date_from,'DD.MM.YYYY');
  end if;

  perform ods.fdc_object_pck_check_owner_cust(p_date_from   => p_object.version_date_from
                                             ,p_owner_id    => p_object.owner_id
                                             ,p_customer_id => p_object.customer_id
                                             );

  /* Если округ или район не указан, определяем по геометрии */
  /* Геометрию пока не используем
  l_okrug_id :=    nvl(p_object.okrug_id, fdc_geo_pck.get_okrug_id_by_geo(p_object.geometry));
  l_district_id := nvl(p_object.district_id, fdc_geo_pck.get_district_id_by_geo(p_object.geometry));
  */

  --> Место обновления бизнес-атрибутов, не приводящих к созданию новой версии объекта
  update ods.fdc_object o
     set o.description        = p_object.description
        ,o.customer_id        = case
                                  when p_object.customer_id = -1 then null
                                  else p_object.customer_id
                                end
        ,o.district_id        = l_district_id
        ,o.geometry           = p_object.geometry
        ,o.geometry_wgs       = p_object.geometry_wgs
        ,o.object_sub_type_id = p_object.obj_sub_type_id
        ,o.object_type_id     = p_object.obj_type_id
        ,o.okrug_id           = l_okrug_id
        ,o.reason_type_id     = p_object.reason_type_id
        ,o.reason_comment     = p_object.reason_comment
        ,o.owner_id           = p_object.owner_id    -- ODSX-176 ikozlov 22.09.2015
        ,o.name               = p_object.name        -- ODSX-285 anton.tuflin 20.10.2015
        ,o.version_date_from  = p_object.version_date_from
   where o.id                 = p_object.id;

  -- Корректируем дату окончания предыдущего проекта/насогласования, если есть
  update ods.fdc_object
     set version_date_to = p_object.version_date_from - interval '1' day
   where id = l_prev_project_id;

  -- Разрываем связи, для которых, после обновления дат, версия нижнего уровня начинается позже версии верхнего
  -- Связи, для которых отредактированный объект вверху
  delete from ods.fdc_object_link
   where id in(select l.id
                 from ods.fdc_object_link l
                     ,ods.fdc_object o1
                     ,ods.fdc_object o2
                where l.object_id_1 = p_object.id
                  and o1.id = l.object_id_1
                  and o2.id = l.object_id_2
                  and o2.version_date_from > o1.version_date_from
              );
  -- Связи, для которых отредактированный объект внизу
  delete from fdc_object_link
   where id in(select l.id
                 from ods.fdc_object_link l
                     ,ods.fdc_object o1
                     ,ods.fdc_object o2
                where l.object_id_2 = p_object.id
                  and o1.id = l.object_id_1
                  and o2.id = l.object_id_2
                  and o2.version_date_from > o1.version_date_from
              );

  --> Получим версию объекта со всеми изменениями для целей аудита
  r_object_after := ods.fdc_object_pck_get_object(p_object_id          => p_object.id
                                                 ,p_object_update_date => null
                                                 );

  /* ЛОГИРОВАНИЕ ОТКЛЮЧЕНО
      --> Аудит изменений
      l_event_detail := get_object_event_detail( p_object_before => r_object_before
                                               , p_object_after  => r_object_after
                                               , p_operation     => const_core.c_op_update
                                               );

      fdc_event_pck.log_detail( p_event_id     => l_event_id
                              , p_comments     => 'Обновление данных объекта'
                              , p_event_detail => l_event_detail
                              );

      if fdc_get_system = const_core.c_sys_odti then
         fdc_event_pck.log_detail( p_event_id     => p_biz_event_id
                                 , p_comments     => 'Обновление данных объекта'
                                 , p_event_detail => l_event_detail
                                 );
      end if;

      fdc_event_pck.event_finish( p_event_id  => l_event_id
                                , p_comment   => 'package=fdc_object_pck' || chr(10) ||
                                                 'method=edit_object'  || chr(10) --||
                                , p_source_id => p_object.id
                                );
  */
end
$$;

