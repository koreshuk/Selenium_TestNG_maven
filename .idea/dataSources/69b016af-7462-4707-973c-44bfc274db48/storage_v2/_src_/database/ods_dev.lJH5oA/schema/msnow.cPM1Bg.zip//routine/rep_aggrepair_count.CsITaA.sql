CREATE FUNCTION rep_aggrepair_count(p_driveway_category_id bigint, OUT segment_cnt bigint, OUT segment_rep_plan_cnt bigint, OUT segment_rep_cnt bigint, OUT segment_rep_delay_cnt bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Сводный отчет по ремонтируемым участкам (количества)
      %param p_driveway_category_id - Ид балансовой принадлежности

      %return segment_cnt           - число участков в программе ремонта
      %return segment_rep_plan_cnt  - число участков ремонта в плане
      %return segment_rep_cnt       - число ремонтируемых участков ремонта
      %return segment_rep_delay_cnt - число участков ремонта, которые отстают от плана-графика
  */
  l_driveway_category_code msnow.fdc_driveway_category.code%type;
  l_current_year text;
begin
  select code
    into strict l_driveway_category_code
    from msnow.fdc_driveway_category
   where id=p_driveway_category_id;

   l_current_year:=to_char(current_date,'YYYY');

  return query
  with org_ruad as(select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_role r on pr.role_id=r.id
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and r.code in('RUAD')
                      and l_driveway_category_code='REGION_INTERMUNICIPAL'
                   union all
                   select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and l_driveway_category_code='LOCAL'
                      and not exists(select null
                                       from nsi.fdc_role r
                                       join nsi.fdc_person_role prr on r.id=prr.role_id
                                      where prr.person_id=pr.person_id
                                        and statement_timestamp() between prr.begin_date and prr.end_date
                                        and r.code in('RUAD')
                                    )
                  )

    select count(dws.id) as segment_cnt
          ,count(case
                   when sch.start_date_fact is null and sch.start_date_plan>=current_date then dws.id
                   else null::bigint
                 end
                ) as segment_rep_plan_cnt
          ,count(case
                   when sch.start_date_fact<=current_date then dws.id
                   else null::bigint
                 end
                ) as segment_rep_cnt
          ,count(case
                   when sch.start_date_plan<=current_date and sch.start_date_fact is null then dws.id
                   else null::bigint
                 end
                ) as segment_rep_delay_cnt
      from msnow.fdc_driveway_segment dws
      join msnow.fdc_agreement agr on dws.agreement_id=agr.id
      join org_ruad on dws.org_ruad_id=org_ruad.org_ruad_id
      join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
     where to_char(sch.start_date_plan,'YYYY')=l_current_year;

  return;
end
$$;

