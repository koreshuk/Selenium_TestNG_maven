CREATE FUNCTION c_sl_subdivision()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 6::bigint;
$$;

