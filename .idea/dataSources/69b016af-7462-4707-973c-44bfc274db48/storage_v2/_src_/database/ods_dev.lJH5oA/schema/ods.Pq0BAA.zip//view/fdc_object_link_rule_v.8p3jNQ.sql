CREATE VIEW fdc_object_link_rule_v AS
  SELECT t1.id,
    t1.object_type_id_1,
    t2.code AS object_type_code_1,
    t2.name AS object_type_name_1,
    t2.short_name AS object_type_short_name_1,
    t1.object_type_id_2,
    t3.code AS object_type_code_2,
    t3.name AS object_type_name_2,
    t3.short_name AS object_type_short_name_2,
    t1.date_from,
    t1.date_to,
    t1.link_name_id,
    t4.code AS link_name_code,
    t4.name AS link_name_name,
    t1.link_type_id,
    t5.code AS link_type_code,
    t5.name AS link_type_name,
    t1.comments,
    t1.for_parent_id,
    t_par.code AS for_parent_code,
    t_par.name AS for_parent_name,
    t1.sort_order
   FROM (((((fdc_object_link_rule t1
     LEFT JOIN fdc_object_type t2 ON ((t2.id = t1.object_type_id_1)))
     LEFT JOIN fdc_object_type t3 ON ((t3.id = t1.object_type_id_2)))
     LEFT JOIN fdc_link_name t4 ON ((t4.id = t1.link_name_id)))
     LEFT JOIN fdc_link_type t5 ON ((t5.id = t1.link_type_id)))
     LEFT JOIN fdc_object_type t_par ON ((t_par.id = t1.for_parent_id)));

COMMENT ON VIEW fdc_object_link_rule_v IS 'Справочник Сущность Связь';

COMMENT ON COLUMN fdc_object_link_rule_v.id IS 'Ид сущности Связь';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_id_1 IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_code_1 IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_name_1 IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_short_name_1 IS 'Краткое наименование типа объекта ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_id_2 IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_code_2 IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_name_2 IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.object_type_short_name_2 IS 'Краткое наименование типа объекта ОГХ';

COMMENT ON COLUMN fdc_object_link_rule_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_object_link_rule_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_object_link_rule_v.link_name_id IS 'Ид Имени связи';

COMMENT ON COLUMN fdc_object_link_rule_v.link_name_code IS 'Код Имени связи';

COMMENT ON COLUMN fdc_object_link_rule_v.link_name_name IS 'Наименование Имени связи';

COMMENT ON COLUMN fdc_object_link_rule_v.link_type_id IS 'Ид Типа связи';

COMMENT ON COLUMN fdc_object_link_rule_v.link_type_code IS 'Код Типа связи';

COMMENT ON COLUMN fdc_object_link_rule_v.link_type_name IS 'Наименование Типа связи';

COMMENT ON COLUMN fdc_object_link_rule_v.comments IS 'Комментарий';

COMMENT ON COLUMN fdc_object_link_rule_v.for_parent_id IS 'Ид типа родителя для OBJECT_TYPE_ID_1';

COMMENT ON COLUMN fdc_object_link_rule_v.for_parent_code IS 'Код типа родителя для OBJECT_TYPE_ID_1';

COMMENT ON COLUMN fdc_object_link_rule_v.for_parent_name IS 'Наименование типа родителя для OBJECT_TYPE_ID_1';

COMMENT ON COLUMN fdc_object_link_rule_v.sort_order IS 'Порядок сортировки в рамках родительского типа';

