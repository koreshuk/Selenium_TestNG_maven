CREATE FUNCTION c_lt_inclusion_full()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 1::bigint;
$$;

