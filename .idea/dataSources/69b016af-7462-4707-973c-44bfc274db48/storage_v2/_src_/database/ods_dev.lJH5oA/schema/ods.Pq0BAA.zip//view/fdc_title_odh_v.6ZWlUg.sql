CREATE VIEW fdc_title_odh_v AS
  SELECT fdc_title_odh.title_id,
    fdc_title_odh.odh_id
   FROM fdc_title_odh;

COMMENT ON VIEW fdc_title_odh_v IS 'Перечень объектов титульного списка';

COMMENT ON COLUMN fdc_title_odh_v.title_id IS 'Ид титульного списка';

COMMENT ON COLUMN fdc_title_odh_v.odh_id IS 'Ид версии объекта';

