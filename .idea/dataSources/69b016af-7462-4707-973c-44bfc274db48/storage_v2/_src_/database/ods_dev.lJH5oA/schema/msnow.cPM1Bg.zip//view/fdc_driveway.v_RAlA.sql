CREATE VIEW fdc_driveway AS
  SELECT obj.id,
    odh.name,
    obj.driveway_category_id,
    odh.maintain_group_id AS odh_group_id,
    lp.root_id AS owner_id,
    odh.latitude_start,
    odh.longitude_start,
    odh.latitude_end,
    odh.longitude_end,
    odh.distance,
    (calc.roadway_area / (7000.0)::double precision) AS reduced_distance,
    calc.roadway_area,
    odh.register_code AS rgn,
    calc.bus_stop_qty AS stop_count,
    odh.cover_type_id,
    NULL::text AS route_code,
    lp.name AS property_owner,
    lp.inn AS property_owner_inn,
    odh.driveway_gost_category_id,
    odh.is_orphan_object,
    obj.geometry,
    odh.date_from,
    odh.edit_reason_id,
    calc.margin_area,
    calc.footway_area,
    calc.bound_stone_length,
    calc.sign_qty,
    calc.traff_light_qty,
    calc.guides_qty,
    calc.planting_area,
    calc.roadway_noprkg_clean_area,
    calc.roadway_prkg_clean_area,
    calc.snow_area,
    calc.station_number,
    calc.station_area,
    calc.auto_footway_area,
    calc.manual_footway_area,
    calc.rotor_area,
    calc.asperity,
    calc.earth_shoulder_distance,
    calc.footway_distance,
    calc.pedestrian_barrier_distance,
    calc.cable_barrier_distance,
    calc.parapet_barrier_distance,
    calc.warning_sign_qty,
    calc.guides_qty_pcs,
    calc.tube_distance,
    calc.tube_qty,
    calc.enclosed_bus_stop_qty,
    calc.crossing_area,
    calc.crossing_qty,
    calc.road_ramp_qty,
    calc.stand_qty,
    calc.lighting_distance,
    calc.platform_qty,
    calc.platform_area,
    calc.cleaning_area,
    calc.asperity_distance,
    calc.info_qty,
    calc.pointer_qty,
    calc.stat_axes_length,
    calc.gutters_length,
    calc.tram_road_length,
    calc.bicycle_area,
    calc.bicycle_length,
    obj.as_area_id,
    obj.as_place_id,
    obj.as_street_id,
    odh.passport_num,
    odh.passport_date,
    calc.internal_area,
    calc.total_area,
    calc.tpu_area,
    calc.hard_shoulder_distance,
    calc.bound_stone_area_plan,
    calc.sign_design_qty,
    calc.sign_design_sqr,
    calc.guides_qty_sqr,
    calc.engin_constr_qty,
    calc.other_flat_area,
    calc.bar_new_jersey,
    calc.protective_wall,
    calc.buffer,
    obj.owner_id AS object_asset_owner_id,
    assowr.inn AS object_asset_owner_inn
   FROM ((((((fdc_object obj
     JOIN fdc_odh odh ON ((odh.id = obj.id)))
     JOIN fdc_object_state ost ON ((ost.id = obj.object_state_id)))
     JOIN fdc_object_type ot ON ((ot.id = obj.object_type_id)))
     LEFT JOIN fdc_odh_calculation calc ON ((calc.id = obj.id)))
     LEFT JOIN nsi.fdc_legal_person lp ON ((obj.customer_id = lp.id)))
     LEFT JOIN nsi.fdc_legal_person assowr ON ((obj.owner_id = assowr.id)))
  WHERE (((ost.code)::text = 'APPROVED'::text) AND (((now())::timestamp without time zone >= obj.version_date_from) AND ((now())::timestamp without time zone <= obj.version_date_to)) AND ((ot.code)::text = 'ODH'::text));

COMMENT ON VIEW fdc_driveway IS 'Дорога';

COMMENT ON COLUMN fdc_driveway.id IS 'Ид дороги';

COMMENT ON COLUMN fdc_driveway.name IS 'Наименование';

COMMENT ON COLUMN fdc_driveway.driveway_category_id IS 'Ид категории дороги';

COMMENT ON COLUMN fdc_driveway.odh_group_id IS 'Ид группы по содержанию';

COMMENT ON COLUMN fdc_driveway.owner_id IS 'Ид балансодержателя';

COMMENT ON COLUMN fdc_driveway.latitude_start IS 'Координата начала(широта)';

COMMENT ON COLUMN fdc_driveway.longitude_start IS 'Координата начала(долгота)';

COMMENT ON COLUMN fdc_driveway.latitude_end IS 'Координата окончания(широта)';

COMMENT ON COLUMN fdc_driveway.longitude_end IS 'Координата окончания(долгота)';

COMMENT ON COLUMN fdc_driveway.distance IS 'Линейная протяженность';

COMMENT ON COLUMN fdc_driveway.reduced_distance IS 'Приведенная протяженность';

COMMENT ON COLUMN fdc_driveway.rgn IS 'РГН';

COMMENT ON COLUMN fdc_driveway.stop_count IS 'Количество остановочных пунктов';

COMMENT ON COLUMN fdc_driveway.cover_type_id IS 'Ид типа покрытия';

COMMENT ON COLUMN fdc_driveway.route_code IS 'Код маршрута';

COMMENT ON COLUMN fdc_driveway.is_orphan_object IS 'признак Бесхоз';

COMMENT ON COLUMN fdc_driveway.geometry IS 'Геометрия';

COMMENT ON COLUMN fdc_driveway.date_from IS 'Дата ввода в эксплуатацию';

COMMENT ON COLUMN fdc_driveway.edit_reason_id IS 'Основание для регистрации данных';

COMMENT ON COLUMN fdc_driveway.margin_area IS 'Обочины';

COMMENT ON COLUMN fdc_driveway.footway_area IS 'Тротуары';

COMMENT ON COLUMN fdc_driveway.bound_stone_length IS 'Бортовой камент';

COMMENT ON COLUMN fdc_driveway.sign_qty IS 'Дорожные знаки';

COMMENT ON COLUMN fdc_driveway.traff_light_qty IS 'Светофорные объекты';

COMMENT ON COLUMN fdc_driveway.guides_qty IS 'Ограждающие и направляющие устройства';

COMMENT ON COLUMN fdc_driveway.planting_area IS 'Площадь уборки ПЧ, без парков. пр-ва';

COMMENT ON COLUMN fdc_driveway.roadway_noprkg_clean_area IS 'Площадь уборки проезжей части (без парковок), м2';

COMMENT ON COLUMN fdc_driveway.roadway_prkg_clean_area IS 'Площадь уборки парков. пр-ва';

COMMENT ON COLUMN fdc_driveway.snow_area IS 'Площадь вывоза снега';

COMMENT ON COLUMN fdc_driveway.station_number IS 'Кол-во убираемых остановок';

COMMENT ON COLUMN fdc_driveway.station_area IS 'Площадь убираемых остановок';

COMMENT ON COLUMN fdc_driveway.auto_footway_area IS 'Площадь уборки тротуаров мех';

COMMENT ON COLUMN fdc_driveway.manual_footway_area IS 'Площадь ручн. уборки тротуаров';

COMMENT ON COLUMN fdc_driveway.rotor_area IS 'Площадь роторной перекидки';

COMMENT ON COLUMN fdc_driveway.asperity IS 'ИДН';

COMMENT ON COLUMN fdc_driveway.earth_shoulder_distance IS 'Неукрепленные обочины, км';

COMMENT ON COLUMN fdc_driveway.footway_distance IS 'Тротуары, км';

COMMENT ON COLUMN fdc_driveway.pedestrian_barrier_distance IS 'Пешеходные ограждения, м';

COMMENT ON COLUMN fdc_driveway.cable_barrier_distance IS 'Тросовые ограждения, км';

COMMENT ON COLUMN fdc_driveway.parapet_barrier_distance IS 'Парапетные ограждения, км';

COMMENT ON COLUMN fdc_driveway.warning_sign_qty IS 'Сигнальные столбики, шт.';

COMMENT ON COLUMN fdc_driveway.guides_qty_pcs IS 'Ограждающие и направляющие устройства, шт';

COMMENT ON COLUMN fdc_driveway.tube_distance IS 'Трубы дорожные, м';

COMMENT ON COLUMN fdc_driveway.tube_qty IS 'Трубы дорожные, шт.';

COMMENT ON COLUMN fdc_driveway.enclosed_bus_stop_qty IS 'Автопавильоны, шт.';

COMMENT ON COLUMN fdc_driveway.crossing_area IS 'Пересечения и примыкания, м2';

COMMENT ON COLUMN fdc_driveway.crossing_qty IS 'Пересечения и примыкания, шт.';

COMMENT ON COLUMN fdc_driveway.road_ramp_qty IS 'Съезды, шт.';

COMMENT ON COLUMN fdc_driveway.stand_qty IS 'Тумбы, шт.';

COMMENT ON COLUMN fdc_driveway.lighting_distance IS 'Освещение, км';

COMMENT ON COLUMN fdc_driveway.platform_qty IS 'Площадки, шт.';

COMMENT ON COLUMN fdc_driveway.platform_area IS 'Площадки, м2';

COMMENT ON COLUMN fdc_driveway.cleaning_area IS 'Площадь уборки, м2';

COMMENT ON COLUMN fdc_driveway.asperity_distance IS 'Искусственные дорожные неровности (ИДН), м.';

COMMENT ON COLUMN fdc_driveway.info_qty IS 'Информационные щиты, шт';

COMMENT ON COLUMN fdc_driveway.pointer_qty IS 'Указатели, информационные указатели, шт';

COMMENT ON COLUMN fdc_driveway.stat_axes_length IS 'Протяженность по пикетажам, м2';

COMMENT ON COLUMN fdc_driveway.gutters_length IS 'Протяженность лотков, п.м.';

COMMENT ON COLUMN fdc_driveway.tram_road_length IS 'Трамвайные пути, м2';

COMMENT ON COLUMN fdc_driveway.bicycle_area IS 'Велодорожки, общая площадь, м2';

COMMENT ON COLUMN fdc_driveway.bicycle_length IS 'Велодорожки, протяженность по пикетажам, п.м.';

