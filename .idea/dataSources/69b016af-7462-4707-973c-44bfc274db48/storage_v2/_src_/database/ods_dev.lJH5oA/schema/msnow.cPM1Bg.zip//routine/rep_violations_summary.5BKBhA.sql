CREATE FUNCTION rep_violations_summary(p_summary_type integer, p_detect_date_from date, p_detect_date_to date, p_driveway_category_id bigint, p_violation_source_id bigint DEFAULT NULL::bigint, p_driveway_segment_id bigint DEFAULT NULL::bigint, p_driveway_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, p_fias_district_id bigint DEFAULT NULL::bigint, OUT name text, OUT violation_qty bigint, OUT inspected_qty bigint, OUT canceled_qty bigint, OUT found_qty bigint, OUT corrected_qty bigint, OUT accepted_qty bigint, OUT maintain_found_qty bigint, OUT maintain_corrected_qty bigint, OUT maintain_accepted_qty bigint, OUT maintain_penalty_sum double precision, OUT repair_found_qty bigint, OUT repair_corrected_qty bigint, OUT repair_accepted_qty bigint, OUT repair_penalty_sum double precision, OUT repair_program_found_qty bigint, OUT repair_program_corrected_qty bigint, OUT repair_program_accepted_qty bigint, OUT repair_program_penalty_sum double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет Справка о количестве и характере выявленных нарушений

  %param p_summary_type          - Тип отчета
                                   1 - по заказчикам
                                   2 - по районам
                                   3 - по источникам нарушения
  %param p_detect_date_from      - Дата выявления нарушения с
  %param p_detect_date_to        - Дата выявления нарушения по
  %param p_driveway_category_id  - Балансовая принадлежность
  %param p_violation_source_id   - Источник нарушения
  %param p_driveway_segment_id   - Участок ремонта
  %param p_driveway_id           - Дорога
  %param p_customer_id           - Заказчик
  %param p_fias_district_id      - Ид муниципального образования (fdc_municipality.id; название p_fias_district_id сохранено для совместимости)

  %return customer_short_name    - Заказчик/Муниц. район(городской округ)/Источник выявления нарушения
  %return violation_qty          - Всего нарушений
  %return inspected_qty          - На проверке
  %return canceled_qty           - Отменено
  %return found_qty              - Выявлено
  %return corrected_qty          - Исправлено
  %return accepted_qty           - Принято

  %return maintain_found_qty     - Содержание. Выявлено
  %return maintain_corrected_qty - Содержание. Исправлено
  %return maintain_accepted_qty  - Содержание. Принято
  %return maintain_penalty_sum   - Содержание. Сумма штрафа, руб.

  %return repair_found_qty       - Текущий ремонт. Выявлено
  %return repair_corrected_qty   - Текущий ремонт. Исправлено
  %return repair_accepted_qty    - Текущий ремонт. Принято
  %return repair_penalty_sum     - Текущий ремонт. Сумма штрафа, руб.

  %return repair_program_found_qty     - Ремонт. Выявлено
  %return repair_program_corrected_qty - Ремонт. Исправлено
  %return repair_program_accepted_qty  - Ремонт. Принято
  %return repair_program_penalty_sum   - Ремонт. Сумма штрафа, руб.
  */
  l_fias_district_id bigint[];

  C_CUSTOMER_TYPE constant INTEGER:=1;
  C_FIAS_TYPE constant INTEGER:=2;
  C_VIOLATION_SOURCE_TYPE constant INTEGER:=3;
begin
  select array_agg(lao.id)
    into l_fias_district_id
    from nsi.fdc_fias_municipality fm
    join ods.fdc_as_addrobj fao on fm.fias_id=fao.id
    join ods.fdc_as_addrobj lao on fao.ao_guid=lao.ao_guid
   where p_detect_date_from between fm.start_date and fm.end_date
     and fm.municipality_id=p_fias_district_id
     and lao.live_status;

  if p_summary_type = C_CUSTOMER_TYPE then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and p_detect_date_from between lp.ver_start_date and lp.ver_end_date
                      and p_detect_date_from between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'  
                      and (p_customer_id is null or lp.id=p_customer_id)
                      and (p_fias_district_id is null or lp.id in(select distinct obj.customer_id
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                  -- join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                  -- join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                   join unnest(l_fias_district_id) lf on true
                                                                   join ods.fdc_as_addrobj fias on fias.id=lf
                                                                                                   and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                                                        (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                                                       )
                                                                  where obj.driveway_category_id=p_driveway_category_id
                                                                    --and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                    --     (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                    --    )
                                                                 )
                          )
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          --,cust.customer_short_name
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id= 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,addro as(select aobj.id
                          ,aobj.ao_level
                      from ods.fdc_as_addrobj aobj
                      join unnest(l_fias_district_id) fd on aobj.id=fd
                   )
          ,vl as(select viol.id as violation_id
                       ,coalesce(dwscust.root_id,dwcust.root_id) as customer_root_id
                       ,case
                          when viols.code='INSPECTED' then viol.id
                        end as inspected_qty
                       ,case
                          when viols.code='CANCELED' then viol.id
                        end as canceled_qty
                       ,case
                          when viols.code='FOUND' then viol.id
                        end as found_qty
                       ,case
                          when viols.code='CORRECTED' then viol.id
                        end as corrected_qty
                       ,case
                          when viols.code='ACCEPTED' then viol.id
                        end as accepted_qty

                       ,case
                          when viols.code='FOUND' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_accepted_qty
                       ,case
                          when wwc.code='MAINTAIN' then viol.penalty
                        end as maintain_penalty_sum

                       ,case
                          when viols.code='FOUND' and wwc.code='REPAIR' then viol.id
                        end as repair_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='REPAIR' then viol.id
                        end as repair_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='REPAIR' then viol.id
                        end as repair_accepted_qty
                       ,case
                          when wwc.code='REPAIR' then viol.penalty
                        end as repair_penalty_sum

                       ,case
                          when viols.code='FOUND' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_accepted_qty
                       ,case
                          when wwc.code='REPAIR_PROGRAM' then viol.penalty
                        end as repair_program_penalty_sum
                   from msnow.fdc_work_assignment viol
                   join msnow.fdc_work_type wwt on viol.work_type_id=wwt.id
                   join msnow.fdc_work_category wwc on wwt.work_category_id=wwc.id
                   join msnow.fdc_violation_status viols on viol.violation_status_id=viols.id
                   --left join addro on true--?
                   left join msnow.fdc_driveway_segment dws on viol.driveway_segment_id=dws.id
                   left join ods.fdc_odh dwsdw on dws.driveway_id=dwsdw.id
                   left join ods.fdc_object dwsobj on dwsdw.id=dwsobj.id--
                   left join nsi.fdc_legal_person dwscust on dwsobj.customer_id=dwscust.id
                   left join ods.fdc_odh dw on viol.driveway_id=dw.id
                   left join ods.fdc_object dwobj on dw.id=dwobj.id--
                   left join nsi.fdc_legal_person dwcust on dwobj.customer_id=dwcust.id
                  where viol.detect_date between p_detect_date_from and p_detect_date_to
                    and (p_violation_source_id is null or viol.violation_source_id=p_violation_source_id)
                    and (p_driveway_segment_id is null or viol.driveway_segment_id=p_driveway_segment_id)
                    and (p_driveway_id is null or
                         dws.driveway_id =p_driveway_id or
                         dwsdw.id=p_driveway_id
                        )
                    and (dwsobj.driveway_category_id=p_driveway_category_id or
                         dwobj.driveway_category_id=p_driveway_category_id
                        )
                    -- and (p_fias_district_id is null or
                    --      (addro.ao_level = 3 and addro.id in(dwsobj.as_area_id,dwobj.as_area_id)) or
                    --      (addro.ao_level in(4,6) and addro.id in(dwsobj.as_place_id,dwobj.as_place_id))
                    --     )
                    and (p_fias_district_id is null or exists(select null
                                                                from addro
                                                               where ((addro.ao_level = 3 and addro.id in(dwsobj.as_area_id,dwobj.as_area_id)) or
                                                                      (addro.ao_level in(4,6) and addro.id in(dwsobj.as_place_id,dwobj.as_place_id))
                                                                     )
                                                             )
                        )
                )

    select rcust.customer_short_name::text
          ,count(distinct vl.violation_id) as violation_qty--Всего нарушений
          ,count(distinct vl.inspected_qty) as inspected_qty--На проверке
          ,count(distinct vl.canceled_qty) as canceled_qty--Отменено
          ,count(distinct vl.found_qty) as found_qty--Выявлено
          ,count(distinct vl.corrected_qty) as corrected_qty--Исправлено
          ,count(distinct vl.accepted_qty) as accepted_qty--Принято

          ,count(distinct vl.maintain_found_qty) as maintain_found_qty -- Содержание. Выявлено
          ,count(distinct vl.maintain_corrected_qty) as maintain_corrected_qty -- Содержание. Исправлено
          ,count(distinct vl.maintain_accepted_qty) as maintain_accepted_qty -- Содержание. Принято
          ,coalesce(round(sum(vl.maintain_penalty_sum)::numeric,2),0.0)::double precision as maintain_penalty_sum -- Содержание. Сумма штрафа, руб.

          ,count(distinct vl.repair_found_qty) as repair_found_qty-- Текущий ремонт. Выявлено
          ,count(distinct vl.repair_corrected_qty) as repair_corrected_qty -- Текущий ремонт. Исправлено
          ,count(distinct vl.repair_accepted_qty) as repair_accepted_qty -- Текущий ремонт. Принято
          ,coalesce(round(sum(vl.repair_penalty_sum)::numeric,2),0.0)::double precision as repair_penalty_sum -- Текущий ремонт. Сумма штрафа, руб.

          ,count(distinct vl.repair_program_found_qty) as repair_program_found_qty -- Ремонт. Выявлено
          ,count(distinct vl.repair_program_corrected_qty) as repair_program_corrected_qty-- Ремонт. Исправлено
          ,count(distinct vl.repair_program_accepted_qty) as repair_program_accepted_qty -- Ремонт. Принято
          ,coalesce(round(sum(vl.repair_program_penalty_sum)::numeric,2),0.0)::double precision as repair_program_penalty_sum -- Ремонт. Сумма штрафа, руб.
      from rcust
      left join vl on rcust.omsu_root_id=vl.customer_root_id
    group by rcust.customer_short_name;
  elsif p_summary_type = C_FIAS_TYPE then
    return query
      with fias_distr as(select fias.id as fias_district_id
                               ,fias.ao_level
                               ,fias.formal_name||case
                                                    when fias.short_name is not null then ' '||fias.short_name
                                                    else ''
                                                  end as fias_name
                           from ods.fdc_as_addrobj fias
                           join unnest(l_fias_district_id) fd on fias.id=fd
                          where /*fias.id=p_fias_district_id
                            and*/ fias.live_status
                            and (fias.ao_level=3 or (fias.ao_level in(4,6) and fias.area_code =0))
                         union
                         select fias.id as fias_district_id
                               ,fias.ao_level
                               ,fias.formal_name||case
                                                    when fias.short_name is not null then ' '||fias.short_name
                                                    else ''
                                                  end as fias_name
                           from ods.fdc_as_addrobj fias
                          where fias.live_status
                            and (fias.ao_level=3 or (fias.ao_level in(4,6) and fias.area_code =0))
                            and p_fias_district_id is null
                            and (p_customer_id is null or exists(select null
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                   join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                   join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                  where obj.driveway_category_id=p_driveway_category_id
                                                                    and obj.customer_id=p_customer_id
                                                                    and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                         (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                        )
                                                                )
                                )
                        )
          /*,addro as(select id
                          ,ao_level
                      from ods.fdc_as_addrobj
                     where id=p_fias_district_id
                   )*/
          ,addro as(select aobj.id
                          ,aobj.ao_level
                      from ods.fdc_as_addrobj aobj
                      join unnest(l_fias_district_id) fd on aobj.id=fd
                   )
          ,vl as(select viol.id as violation_id
                       --,coalesce(dwscust.root_id,dwcust.root_id) as customer_root_id
                       ,case
                          when dwsobj.id is not null then dwsobj.as_area_id
                          when dwobj.id is not null then dwobj.as_area_id
                        end as as_area_id
                       ,case
                          when dwsobj.id is not null then dwsobj.as_place_id
                          when dwobj.id is not null then dwobj.as_place_id
                        end as as_place_id
                       ,case
                          when viols.code='INSPECTED' then viol.id
                        end as inspected_qty
                       ,case
                          when viols.code='CANCELED' then viol.id
                        end as canceled_qty
                       ,case
                          when viols.code='FOUND' then viol.id
                        end as found_qty
                       ,case
                          when viols.code='CORRECTED' then viol.id
                        end as corrected_qty
                       ,case
                          when viols.code='ACCEPTED' then viol.id
                        end as accepted_qty

                       ,case
                          when viols.code='FOUND' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_accepted_qty
                       ,case
                          when wwc.code='MAINTAIN' then viol.penalty
                        end as maintain_penalty_sum

                       ,case
                          when viols.code='FOUND' and wwc.code='REPAIR' then viol.id
                        end as repair_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='REPAIR' then viol.id
                        end as repair_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='REPAIR' then viol.id
                        end as repair_accepted_qty
                       ,case
                          when wwc.code='REPAIR' then viol.penalty
                        end as repair_penalty_sum

                       ,case
                          when viols.code='FOUND' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_accepted_qty
                       ,case
                          when wwc.code='REPAIR_PROGRAM' then viol.penalty
                        end as repair_program_penalty_sum
                   from msnow.fdc_work_assignment viol
                   join msnow.fdc_work_type wwt on viol.work_type_id=wwt.id
                   join msnow.fdc_work_category wwc on wwt.work_category_id=wwc.id
                   join msnow.fdc_violation_status viols on viol.violation_status_id=viols.id
                   --left join addro on true
                   left join msnow.fdc_driveway_segment dws on viol.driveway_segment_id=dws.id
                   left join ods.fdc_odh dwsdw on dws.driveway_id=dwsdw.id
                   left join ods.fdc_object dwsobj on dwsdw.id=dwsobj.id--
                   left join nsi.fdc_legal_person dwscust on dwsobj.customer_id=dwscust.id
                   left join ods.fdc_odh dw on viol.driveway_id=dw.id
                   left join ods.fdc_object dwobj on dw.id=dwobj.id--
                   left join nsi.fdc_legal_person dwcust on dwobj.customer_id=dwcust.id
                  where viol.detect_date between p_detect_date_from and p_detect_date_to
                   and (p_violation_source_id is null or viol.violation_source_id=p_violation_source_id)
                   and (p_driveway_segment_id is null or viol.driveway_segment_id=p_driveway_segment_id)
                   and (p_driveway_id is null or
                        dws.driveway_id =p_driveway_id or
                        dwsdw.id=p_driveway_id
                       )
                   and (dwsobj.driveway_category_id=p_driveway_category_id or
                         dwobj.driveway_category_id=p_driveway_category_id
                       )
                   /*and (p_fias_district_id is null or
                         (addro.ao_level = 3 and addro.id in(dwsobj.as_area_id,dwobj.as_area_id)) or
                         (addro.ao_level in(4,6) and addro.id in(dwsobj.as_place_id,dwobj.as_place_id))
                       )*/
                   and (p_fias_district_id is null or exists(select null
                                                               from addro
                                                              where ((addro.ao_level = 3 and addro.id in(dwsobj.as_area_id,dwobj.as_area_id)) or
                                                                     (addro.ao_level in(4,6) and addro.id in(dwsobj.as_place_id,dwobj.as_place_id))
                                                                    )
                                                            )
                        )
                   and (p_customer_id is null or dwsobj.id is null or dwsobj.customer_id=p_customer_id)
                   and (p_customer_id is null or dwobj.id is null or dwobj.customer_id=p_customer_id)
                )
           select fds.fias_name
                 ,count(distinct fds.violation_id) as violation_qty--Всего нарушений
                 ,count(distinct fds.inspected_qty) as inspected_qty--На проверке
                 ,count(distinct fds.canceled_qty) as canceled_qty--Отменено
                 ,count(distinct fds.found_qty) as found_qty--Выявлено
                 ,count(distinct fds.corrected_qty) as corrected_qty--Исправлено
                 ,count(distinct fds.accepted_qty) as accepted_qty--Принято
                 ,count(distinct fds.maintain_found_qty) as maintain_found_qty -- Содержание. Выявлено
                 ,count(distinct fds.maintain_corrected_qty) as maintain_corrected_qty -- Содержание. Исправлено
                 ,count(distinct fds.maintain_accepted_qty) as maintain_accepted_qty -- Содержание. Принято
                 ,coalesce(round(sum(fds.maintain_penalty_sum)::numeric,2),0.0)::double precision as maintain_penalty_sum -- Содержание. Сумма штрафа, руб.
                 ,count(distinct fds.repair_found_qty) as repair_found_qty-- Текущий ремонт. Выявлено
                 ,count(distinct fds.repair_corrected_qty) as repair_corrected_qty -- Текущий ремонт. Исправлено
                 ,count(distinct fds.repair_accepted_qty) as repair_accepted_qty -- Текущий ремонт. Принято
                 ,coalesce(round(sum(fds.repair_penalty_sum)::numeric,2),0.0)::double precision as repair_penalty_sum -- Текущий ремонт. Сумма штрафа, руб.
                 ,count(distinct fds.repair_program_found_qty) as repair_program_found_qty -- Ремонт. Выявлено
                 ,count(distinct fds.repair_program_corrected_qty) as repair_program_corrected_qty-- Ремонт. Исправлено
                 ,count(distinct fds.repair_program_accepted_qty) as repair_program_accepted_qty -- Ремонт. Принято
                 ,coalesce(round(sum(fds.repair_program_penalty_sum)::numeric,2),0.0)::double precision as repair_program_penalty_sum -- Ремонт. Сумма штрафа, руб.
             from(select fias_distr.fias_district_id
                        ,fias_distr.fias_name
                        ,vl.violation_id
                        ,vl.inspected_qty
                        ,vl.canceled_qty
                        ,vl.found_qty
                        ,vl.corrected_qty
                        ,vl.accepted_qty
                        ,vl.maintain_found_qty
                        ,vl.maintain_corrected_qty
                        ,vl.maintain_accepted_qty
                        ,vl.maintain_penalty_sum
                        ,vl.repair_found_qty
                        ,vl.repair_corrected_qty
                        ,vl.repair_accepted_qty
                        ,vl.repair_penalty_sum
                        ,vl.repair_program_found_qty
                        ,vl.repair_program_corrected_qty
                        ,vl.repair_program_accepted_qty
                        ,vl.repair_program_penalty_sum
                    from fias_distr
                    left join vl on fias_distr.ao_level=3 and fias_distr.fias_district_id=vl.as_area_id
                  union
                  select fias_distr.fias_district_id
                        ,fias_distr.fias_name
                        ,vl.violation_id
                        ,vl.inspected_qty
                        ,vl.canceled_qty
                        ,vl.found_qty
                        ,vl.corrected_qty
                        ,vl.accepted_qty
                        ,vl.maintain_found_qty
                        ,vl.maintain_corrected_qty
                        ,vl.maintain_accepted_qty
                        ,vl.maintain_penalty_sum

                        ,vl.repair_found_qty
                        ,vl.repair_corrected_qty
                        ,vl.repair_accepted_qty
                        ,vl.repair_penalty_sum

                        ,vl.repair_program_found_qty
                        ,vl.repair_program_corrected_qty
                        ,vl.repair_program_accepted_qty
                        ,vl.repair_program_penalty_sum
                    from fias_distr
                    left join vl on fias_distr.ao_level in(4,6) and fias_distr.fias_district_id=vl.as_place_id
                 ) as fds
              group by fds.fias_name;
  elsif p_summary_type = C_VIOLATION_SOURCE_TYPE then
    return query
      with addro as(select aobj.id
                          ,aobj.ao_level
                      from ods.fdc_as_addrobj aobj
                      join unnest(l_fias_district_id) fd on aobj.id=fd
                   )
          ,vl as(select viol.violation_source_id
                       ,viol.id as violation_id
                       ,case
                          when dwsobj.id is not null then dwsobj.as_area_id
                          when dwobj.id is not null then dwobj.as_area_id
                        end as as_area_id
                       ,case
                          when dwsobj.id is not null then dwsobj.as_place_id
                          when dwobj.id is not null then dwobj.as_place_id
                        end as as_place_id
                       ,case
                          when viols.code='INSPECTED' then viol.id
                        end as inspected_qty
                       ,case
                          when viols.code='CANCELED' then viol.id
                        end as canceled_qty
                       ,case
                          when viols.code='FOUND' then viol.id
                        end as found_qty
                       ,case
                          when viols.code='CORRECTED' then viol.id
                        end as corrected_qty
                       ,case
                          when viols.code='ACCEPTED' then viol.id
                        end as accepted_qty

                       ,case
                          when viols.code='FOUND' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='MAINTAIN' then viol.id
                        end as maintain_accepted_qty
                       ,case
                          when wwc.code='MAINTAIN' then viol.penalty
                        end as maintain_penalty_sum

                       ,case
                          when viols.code='FOUND' and wwc.code='REPAIR' then viol.id
                        end as repair_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='REPAIR' then viol.id
                        end as repair_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='REPAIR' then viol.id
                        end as repair_accepted_qty
                       ,case
                          when wwc.code='REPAIR' then viol.penalty
                        end as repair_penalty_sum

                       ,case
                          when viols.code='FOUND' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_found_qty
                       ,case
                          when viols.code='CORRECTED' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_corrected_qty
                       ,case
                          when viols.code='ACCEPTED' and wwc.code='REPAIR_PROGRAM' then viol.id
                        end as repair_program_accepted_qty
                       ,case
                          when wwc.code='REPAIR_PROGRAM' then viol.penalty
                        end as repair_program_penalty_sum
                   from msnow.fdc_work_assignment viol
                   join msnow.fdc_work_type wwt on viol.work_type_id=wwt.id
                   join msnow.fdc_work_category wwc on wwt.work_category_id=wwc.id
                   join msnow.fdc_violation_status viols on viol.violation_status_id=viols.id
                   left join addro on true
                   left join msnow.fdc_driveway_segment dws on viol.driveway_segment_id=dws.id
                   left join ods.fdc_odh dwsdw on dws.driveway_id=dwsdw.id
                   left join ods.fdc_object dwsobj on dwsdw.id=dwsobj.id--
                   left join nsi.fdc_legal_person dwscust on dwsobj.customer_id=dwscust.id
                   left join ods.fdc_odh dw on viol.driveway_id=dw.id
                   left join ods.fdc_object dwobj on dw.id=dwobj.id--
                   left join nsi.fdc_legal_person dwcust on dwobj.customer_id=dwcust.id
                  where viol.detect_date between p_detect_date_from and p_detect_date_to
                   and (p_violation_source_id is null or viol.violation_source_id=p_violation_source_id)
                   and (p_driveway_segment_id is null or viol.driveway_segment_id=p_driveway_segment_id)
                   and (p_driveway_id is null or
                        dws.driveway_id =p_driveway_id or
                        dwsdw.id=p_driveway_id
                       )
                   and (dwsobj.driveway_category_id=p_driveway_category_id or
                         dwobj.driveway_category_id=p_driveway_category_id
                       )
                  /* and (p_fias_district_id is null or
                         (addro.ao_level = 3 and addro.id in(dwsobj.as_area_id,dwobj.as_area_id)) or
                         (addro.ao_level in(4,6) and addro.id in(dwsobj.as_place_id,dwobj.as_place_id))
                        )
                  */
                   and (p_fias_district_id is null or exists(select null
                                                               from addro
                                                              where ((addro.ao_level = 3 and addro.id in(dwsobj.as_area_id,dwobj.as_area_id)) or
                                                                     (addro.ao_level in(4,6) and addro.id in(dwsobj.as_place_id,dwobj.as_place_id))
                                                                    )
                                                            )
                        )
                   and (p_customer_id is null or dwsobj.id is null or dwsobj.customer_id=p_customer_id)
                   and (p_customer_id is null or dwobj.id is null or dwobj.customer_id=p_customer_id)
       )
      select vls.name::text
            ,count(distinct vl.violation_id) as violation_qty--Всего нарушений
            ,count(distinct vl.inspected_qty) as inspected_qty--На проверке
            ,count(distinct vl.canceled_qty) as canceled_qty--Отменено
            ,count(distinct vl.found_qty) as found_qty--Выявлено
            ,count(distinct vl.corrected_qty) as corrected_qty--Исправлено
            ,count(distinct vl.accepted_qty) as accepted_qty--Принято

            ,count(distinct vl.maintain_found_qty) as maintain_found_qty -- Содержание. Выявлено
            ,count(distinct vl.maintain_corrected_qty) as maintain_corrected_qty -- Содержание. Исправлено
            ,count(distinct vl.maintain_accepted_qty) as maintain_accepted_qty -- Содержание. Принято
            ,coalesce(round(sum(vl.maintain_penalty_sum)::numeric,2),0.0)::double precision as maintain_penalty_sum -- Содержание. Сумма штрафа, руб.

            ,count(distinct vl.repair_found_qty) as repair_found_qty-- Текущий ремонт. Выявлено
            ,count(distinct vl.repair_corrected_qty) as repair_corrected_qty -- Текущий ремонт. Исправлено
            ,count(distinct vl.repair_accepted_qty) as repair_accepted_qty -- Текущий ремонт. Принято
            ,coalesce(round(sum(vl.repair_penalty_sum)::numeric,2),0.0)::double precision as repair_penalty_sum -- Текущий ремонт. Сумма штрафа, руб.

            ,count(distinct vl.repair_program_found_qty) as repair_program_found_qty -- Ремонт. Выявлено
            ,count(distinct vl.repair_program_corrected_qty) as repair_program_corrected_qty-- Ремонт. Исправлено
            ,count(distinct vl.repair_program_accepted_qty) as repair_program_accepted_qty -- Ремонт. Принято
            ,coalesce(round(sum(vl.repair_program_penalty_sum)::numeric,2),0.0)::double precision as repair_program_penalty_sum -- Ремонт. Сумма штрафа, руб.
        from msnow.fdc_violation_source vls
        left join vl on vls.id=vl.violation_source_id
       where (p_violation_source_id is null or vls.id=p_violation_source_id)
       group by vls.name;
  end if;
  return;
end
$$;

