CREATE VIEW fdc_org_type AS
  SELECT fdc_role.id,
    fdc_role.code,
    fdc_role.name
   FROM nsi.fdc_role;

COMMENT ON VIEW fdc_org_type IS 'Справочник Виды организации';

COMMENT ON COLUMN fdc_org_type.id IS 'Ид';

COMMENT ON COLUMN fdc_org_type.code IS 'Код';

COMMENT ON COLUMN fdc_org_type.name IS 'Наименование';

