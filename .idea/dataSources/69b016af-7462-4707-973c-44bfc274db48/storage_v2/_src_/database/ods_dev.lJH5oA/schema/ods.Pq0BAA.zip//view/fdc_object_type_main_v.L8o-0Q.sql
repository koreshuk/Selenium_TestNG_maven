CREATE VIEW fdc_object_type_main_v AS
  SELECT t1.id,
    t1.history_id,
    t1.parent_id,
    t1.code,
    t1.name,
    t1.date_from,
    t1.date_to,
    t1.short_name,
    t1.is_upper_level
   FROM fdc_object_type t1
  WHERE ((t1.parent_id IS NULL) AND ((transaction_timestamp() >= t1.date_from) AND (transaction_timestamp() <= t1.date_to)));

COMMENT ON VIEW fdc_object_type_main_v IS 'Справочник Тип ОГХ';

COMMENT ON COLUMN fdc_object_type_main_v.id IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_type_main_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_object_type_main_v.code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_type_main_v.name IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_type_main_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_object_type_main_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_object_type_main_v.short_name IS 'Краткое наименование типа объекта ОГХ';

COMMENT ON COLUMN fdc_object_type_main_v.is_upper_level IS 'Признак, что объект верхнего уровня';

