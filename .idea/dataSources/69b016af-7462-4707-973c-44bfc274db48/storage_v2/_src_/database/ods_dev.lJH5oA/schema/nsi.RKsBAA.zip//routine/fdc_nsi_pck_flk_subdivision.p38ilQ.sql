CREATE FUNCTION fdc_nsi_pck_flk_subdivision(p_root_id bigint, p_code character varying, p_email character varying, p_parent_root_id bigint, p_event_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /**
  ФЛК для Структурных подразделений
  **/
  l_org_root_id  nsi.fdc_legal_person.root_id%type;
  l_exists boolean;
begin
  with recursive subd(root_id
                     ,parent_root_id
                     ,level
                     ) AS(select lp.root_id
                                ,lp.parent_root_id
                                ,1
                            from nsi.fdc_legal_person lp
                           where lp.root_id = p_parent_root_id
                             and lp.ver_end_date is null
                          union all
                          select lp2.root_id
                                ,lp2.parent_root_id
                                ,level+1
                            from nsi.fdc_legal_person lp2
                            join subd on subd.parent_root_id=lp2.root_id
                           where lp2.ver_end_date is null
                         )
    select max(root_id)
      into l_org_root_id
      from subd
     where parent_root_id is null;

  with recursive subd (root_id
                      ,level
                      ) as(select lp.root_id
                                 ,1
                             from nsi.fdc_legal_person lp
                            where lp.root_id=l_org_root_id
                              and lp.ver_end_date is null
                           union all
                           select lp2.root_id
                                 ,1+level
                             from nsi.fdc_legal_person lp2
                             join subd on subd.root_id=lp2.parent_root_id
                            where lp2.ver_end_date is null
                          )
    select case
             when count(1)>0 then true
             else false
           end
      into l_exists
      from subd t
          ,nsi.fdc_legal_person lpl
     where lpl.root_id = t.root_id
       and lpl.ver_end_date is null
       and (lpl.root_id <> p_root_id or p_root_id is null)
       and lpl.person_code = p_code;

  if l_exists then
    raise exception 'Подразделение с кодом <1> уже существует. Сохранение невозможно.';
  end if;

  if p_email is not null and not nsi.fdc_nsi_pck_is_email_correct(p_email => p_email) then
    raise exception 'Эл. почта не соответствует алгоритму проверки';
  end if;

end
$$;

