CREATE VIEW fdc_last_estimate_work_type_v AS
  SELECT tt.id,
    tt.driveway_segment_id,
    tt.work_type_id,
    tt.agr_root_id,
    tt.agreement_id,
    tt.work_volume
   FROM ( SELECT ae.id,
            ae.driveway_segment_id,
            ae.work_type_id,
            a.agr_root_id,
            ae.agreement_id,
            ae.work_volume,
            row_number() OVER (PARTITION BY ae.driveway_segment_id, a.agr_root_id, ae.work_type_id ORDER BY a.version_date_from DESC, a.version_date_to DESC) AS rnk
           FROM (msnow.fdc_agr_estimate ae
             JOIN msnow.fdc_agreement a ON ((ae.agreement_id = a.id)))
          WHERE (ae.driveway_segment_id IS NOT NULL)) tt
  WHERE (tt.rnk = 1);

COMMENT ON VIEW fdc_last_estimate_work_type_v IS 'Виды работ в последней сметы контракта';

