CREATE FUNCTION rep_lsr_form_list_summary(p_summary_type integer, p_year integer, p_driveway_category_id bigint, p_title_type_id bigint DEFAULT NULL::bigint, OUT driveway_root_id bigint, OUT driveway_name character varying, OUT customer_short_name character varying, OUT owner_short_name character varying, OUT area_name character varying, OUT place_name character varying, OUT maintain_group_name character varying, OUT cover_type_name character varying, OUT driveway_gost_category_name character varying, OUT title_name character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт "Сводка по согласованию Локальных сметных расчетов на <текущая дата>" в разрезе дорог из ТС

  %param p_summary_type          - Тип сметы
                                   1 - бюджет
                                   2 - контракт/задание
  %param p_year                  - Год
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_title_id              - Тип списка

  %return driveway_root_id             - ROOT_ID дороги
  %return driveway_name                - Наименование дороги
  %return customer_short_name          - Заказчик
  %return owner_short_name             - Балансодержатель
  %return area_name                    - Муниц. район/ГО
  %return place_name                   - Населенный пункт
  %return maintain_group_name          - Группа по содержанию
  %return cover_type_name              - Тип покрытия
  %return driveway_gost_category_name  - Категория по ГОСТ
  %return title_name                   - Наименование ТС

  */
  l_year_start_date date;

  C_TYPE_OBLIGATION constant integer:=1;
  C_TYPE_AGREEMENT constant integer:=2;
begin
  l_year_start_date=to_date('01.01.'||p_year::varchar,'dd.mm.yyyy');

  if p_summary_type = C_TYPE_OBLIGATION then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_year_start_date between lp.ver_start_date and lp.ver_end_date
                      and l_year_start_date  between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and p_driveway_category_id = 1
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                   )
          ,missed as(select distinct obj.customer_id
                             ,tl.id as title_id
                             ,tl.name as title_name
                             ,obj.root_id as driveway_root_id
                             ,obj.name as driveway_name
                             ,odh.is_orphan_object
                             ,ownr.short_name as owner_short_name
                             ,obj.as_area_id
                             ,obj.as_place_id
                             ,odh.maintain_group_id
                             ,odh.driveway_gost_category_id
                             ,odh.cover_type_id
                             ,case
                                when not exists (select null
                                                  from msnow.fdc_obligation_estimate oe
                                                   join msnow.fdc_obligation o on oe.obligation_id=o.id
                                                   join msnow.fdc_work_category wc on o.work_category_id=wc.id
                                                   join msnow.fdc_agreement_obligation_status ost on o.obligation_status_id=ost.id
                                                   join ods.fdc_odh odhe on oe.driveway_id=odhe.id
                                                   join ods.fdc_object obje on odhe.id=obje.id
                                                  where obje.root_id=obj.root_id
                                                    and ost.code='APPROVED'
                                                    and o.obligation_year=p_year::varchar
                                                    and wc.code='MAINTAIN'
                                               ) then
                                  case
                                    when not exists(select null
                                                      from msnow.fdc_obligation_estimate oe
                                                      join msnow.fdc_obligation o on oe.obligation_id=o.id
                                                      join msnow.fdc_work_category wc on o.work_category_id=wc.id
                                                      join msnow.fdc_agreement_obligation_status ost on o.obligation_status_id=ost.id
                                                     where oe.odh_group_id=odh.object_group_id
                                                       and ost.code='APPROVED'
                                                       and o.obligation_year=p_year::varchar
                                                       and wc.code='MAINTAIN'
                                                   ) then true
                                    else false
                                  end
                                else false
                              end as missing_flag
                         from ods.fdc_title tl
                         join ods.fdc_title_status tls on tl.title_status_id=tls.id
                         join msnow.fdc_work_category wc on tl.work_category_id=wc.id
                         join ods.fdc_title_odh todh on tl.id=todh.title_id
                         join ods.fdc_odh odh on todh.odh_id=odh.id
                         join ods.fdc_object obj on odh.id=obj.id
                         join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                         left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                        where tls.code='APPROVED'
                          and wc.code='MAINTAIN'
                          and (p_title_type_id is null or tl.title_type_id=p_title_type_id)
                          and p_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                    )

          select missed.driveway_root_id
                ,missed.driveway_name::varchar
                ,rcust.customer_short_name::varchar
                ,missed.owner_short_name::varchar
                ,(farea.formal_name||case
                                      when farea.short_name is not null then farea.short_name
                                      else ''
                                    end)::varchar  as area_name
                ,(fplace.formal_name||case
                                      when fplace.short_name is not null then fplace.short_name
                                      else ''
                                    end)::varchar  as place_name
                ,grp.name::varchar  as maintain_group_name
                ,ct.name::varchar  as cover_type_name
                ,gdc.name::varchar  as driveway_gost_category_name
                ,missed.title_name::varchar
            from missed
            join rcust on missed.customer_id=rcust.customer_id
            left join ods.fdc_as_addrobj farea on missed.as_area_id = farea.id
            left join ods.fdc_as_addrobj fplace on missed.as_place_id = fplace.id
            left join msnow.fdc_maintain_group grp on missed.maintain_group_id=grp.id
            left join msnow.fdc_driveway_gost_category gdc on missed.driveway_gost_category_id=gdc.id
            left join msnow.fdc_cover_type ct on missed.cover_type_id=ct.id
           where missing_flag;
  elsif p_summary_type = C_TYPE_AGREEMENT then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_year_start_date between lp.ver_start_date and lp.ver_end_date
                      and l_year_start_date  between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and p_driveway_category_id = 1
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                   )
          ,missed as(select distinct obj.customer_id
                             ,tl.id as title_id
                             ,tl.name as title_name
                             ,obj.root_id as driveway_root_id
                             ,obj.name as driveway_name
                             ,odh.is_orphan_object
                             ,ownr.short_name as owner_short_name
                             ,obj.as_area_id
                             ,obj.as_place_id
                             ,odh.maintain_group_id
                             ,odh.driveway_gost_category_id
                             ,odh.cover_type_id
                             ,case
                                when not exists (select null
                                                   from msnow.fdc_agr_estimate oe
                                                   join msnow.fdc_agreement ag on oe.agreement_id=ag.id
                                                   join msnow.fdc_agreement_obligation_status ost on ag.agreement_status_id=ost.id
                                                   join msnow.fdc_work_category wc on ag.work_category_id=wc.id
                                                   join ods.fdc_odh odhe on oe.driveway_id=odhe.id
                                                   join ods.fdc_object obje on odhe.id=obje.id
                                                  where obje.root_id=obj.root_id
                                                    and ost.code='APPROVED'
                                                    and wc.code='MAINTAIN'
                                                    and p_year=extract(year from ag.version_date_from)
                                                  ) then
                                  case
                                    when not exists(select null
                                                      from msnow.fdc_agr_estimate oe
                                                      join msnow.fdc_agreement ag on oe.agreement_id=ag.id
                                                      join msnow.fdc_agreement_obligation_status ost on ag.agreement_status_id=ost.id
                                                      join msnow.fdc_work_category wc on ag.work_category_id=wc.id
                                                     where oe.odh_group_id=odh.object_group_id
                                                       and ost.code='APPROVED'
                                                       and wc.code='MAINTAIN'
                                                       and p_year=extract(year from ag.version_date_from)
                                                   ) then true
                                     else false
                                  end
                                else false
                              end as missing_flag
                         from ods.fdc_title tl
                         join ods.fdc_title_status tls on tl.title_status_id=tls.id
                         join msnow.fdc_work_category wc on tl.work_category_id=wc.id
                         join ods.fdc_title_odh todh on tl.id=todh.title_id
                         join ods.fdc_odh odh on todh.odh_id=odh.id
                         join ods.fdc_object obj on odh.id=obj.id
                         join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                         left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                        where tls.code='APPROVED'
                          and wc.code='MAINTAIN'
                          and (p_title_type_id is null or tl.title_type_id=p_title_type_id)
                          and p_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                    )

          select missed.driveway_root_id
                ,missed.driveway_name::varchar
                ,rcust.customer_short_name::varchar
                ,missed.owner_short_name::varchar
                ,(farea.formal_name||case
                                      when farea.short_name is not null then farea.short_name
                                      else ''
                                    end)::varchar  as area_name
                ,(fplace.formal_name||case
                                      when fplace.short_name is not null then fplace.short_name
                                      else ''
                                    end)::varchar  as place_name
                ,grp.name::varchar  as maintain_group_name
                ,ct.name::varchar  as cover_type_name
                ,gdc.name::varchar  as driveway_gost_category_name
                ,missed.title_name::varchar
            from missed
            join rcust on missed.customer_id=rcust.customer_id
            left join ods.fdc_as_addrobj farea on missed.as_area_id = farea.id
            left join ods.fdc_as_addrobj fplace on missed.as_place_id = fplace.id
            left join msnow.fdc_maintain_group grp on missed.maintain_group_id=grp.id
            left join msnow.fdc_driveway_gost_category gdc on missed.driveway_gost_category_id=gdc.id
            left join msnow.fdc_cover_type ct on missed.cover_type_id=ct.id
           where missing_flag;
  end if;
  return;
end
$$;

