CREATE VIEW fdc_municipality AS
  SELECT ao.id,
    (
        CASE
            WHEN (ao.ao_level = 3) THEN ao.area_code
            ELSE ao.place_code
        END)::character varying(255) AS code,
    ao.formal_name AS name,
    (
        CASE
            WHEN (lower((ao.short_name)::text) = 'р-н'::text) THEN 1
            ELSE 2
        END)::bigint AS municipal_type_id,
    ao.okato,
    ao.oktmo
   FROM fdc_as_addrobj ao
  WHERE (ao.live_status AND (ao.ao_level = ANY (ARRAY[3, 4, 6])));

COMMENT ON VIEW fdc_municipality IS 'Справочник Муниципальные образования';

COMMENT ON COLUMN fdc_municipality.id IS 'Ид муниципального образования';

COMMENT ON COLUMN fdc_municipality.code IS 'Код';

COMMENT ON COLUMN fdc_municipality.name IS 'Наименование';

COMMENT ON COLUMN fdc_municipality.municipal_type_id IS 'Ид вида муниципального образования';

COMMENT ON COLUMN fdc_municipality.okato IS 'ОКАТО';

COMMENT ON COLUMN fdc_municipality.oktmo IS 'ОКТМО';

