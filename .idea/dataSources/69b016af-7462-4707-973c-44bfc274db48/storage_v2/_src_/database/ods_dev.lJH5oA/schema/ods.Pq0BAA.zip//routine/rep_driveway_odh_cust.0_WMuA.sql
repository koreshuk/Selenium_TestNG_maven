CREATE FUNCTION rep_driveway_odh_cust(p_report_date date, p_driveway_category_id bigint, OUT customer_name text, OUT object_id bigint, OUT stat_axes_length double precision, OUT internal_area double precision, OUT roadway_area double precision, OUT footway_area double precision, OUT cleaning_area double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Сводка по паспортам АД в разрезе заказчиков
    %param p_report_date            - Дата отчета
    %param p_driveway_category_id   - Ид балансовой принадлежности

    %return customer_name           - Наименование заказчика
    %return object_id               - Ид участка ОДХ
    %return stat_axes_length        - Протяженность по пикетажам
    %return internal_area           - Площадь дороги, тыс.м2
    %return roadway_area            - Площадь проезжей части, тыс.м2
    %return footway_area            - Площадь тротуаров, тыс.м2
    %return cleaning_area           - Площадь уборки, тыс.м2
  */
  l_report_date date;
begin
  l_report_date:=coalesce(p_report_date,current_date);

  return query
    with preorg as(select lp.root_id as id
                         ,lp.id as version_id
                         ,fias.ao_guid as fias_district_ao_guid
                         ,lp.short_name as name
                     from nsi.fdc_legal_person lp
                     left join ods.fdc_as_addrobj fias on lp.fias_district_id=fias.id
                    where l_report_date between lp.ver_start_date and lp.ver_end_date
                  )
          ,oomsu as(select preorg.version_id
                          ,preorg.id
                          ,preorg.name
                          ,preorg.fias_district_ao_guid
                          ,preorg.id as omsu_root_id
                      from preorg
                      join nsi.fdc_person_role pr on preorg.id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and statement_timestamp() between pr.begin_date and pr.end_date
                       and p_driveway_category_id = 1
                   )
          ,ruad as (select preorg.version_id
                          ,preorg.id
                          ,preorg.name
                      from preorg
                      join nsi.fdc_person_role pr on preorg.id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and statement_timestamp() between pr.begin_date and pr.end_date
                       and p_driveway_category_id = 2
                   )
          ,cust as(select ruad.version_id
                        ,ruad.id  -- это root-id
                        ,ruad.name
                    from ruad
                  union
                  select oomsu.version_id
                        ,oomsu.id
                        ,oomsu.name
                    from oomsu
                  union
                  select preorg.version_id
                        ,preorg.id
                        ,oomsu.name
                    from preorg
                    join oomsu on preorg.fias_district_ao_guid=oomsu.fias_district_ao_guid
                   where preorg.fias_district_ao_guid is not null
                     and preorg.id not in(select pr.person_id
                                            from nsi.fdc_person_role pr
                                            join nsi.fdc_role r on pr.role_id=r.id
                                           where r.code in('OMSU','RUAD','MA','TO','KO')
                                             and statement_timestamp() between pr.begin_date and pr.end_date
                                         )
                 )
          ,oodh as(select obj.id as object_id
                         ,cust.root_id as customer_root_id
                     from ods.fdc_object obj
                     join ods.fdc_object_type objt on obj.object_type_id=objt.id
                     join ods.fdc_object_state objs on obj.object_state_id=objs.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                    where objt.code='ODH'
                      and objs.code='APPROVED'
                      and l_report_date between obj.version_date_from and obj.version_date_to
                  )

             select cust.name::text as customer_name
                   ,oodh.object_id
                   ,calc.stat_axes_length
                   ,calc.internal_area/1000.0 as internal_area
                   ,calc.roadway_area/1000.0 as roadway_area
                   ,calc.footway_area/1000.0 as footway_area
                   ,calc.cleaning_area/1000.0 as cleaning_area
               from cust
               left join oodh on cust.id=oodh.customer_root_id
               left join ods.fdc_odh_calculation calc on oodh.object_id=calc.id;

  return;
end
$$;

