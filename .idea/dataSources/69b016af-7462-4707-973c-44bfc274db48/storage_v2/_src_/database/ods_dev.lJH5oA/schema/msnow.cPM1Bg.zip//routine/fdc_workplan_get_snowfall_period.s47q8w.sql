CREATE FUNCTION fdc_workplan_get_snowfall_period(p_work_date timestamp without time zone)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  /* Диагностика периода снегопада

  %param p_work_date - дата из фильтра Дата работ с

  %return - период снегопада(текст)
  */
  l_snowfall_period_code integer;
  l_snowfall_period_text text;
begin
  l_snowfall_period_code:=msnow.fdc_workplan_get_snowfall_period_cd(p_work_date => p_work_date);

  l_snowfall_period_text:=case l_snowfall_period_code
                            when 1 then 'Нет снегопада (более 48 часов после последнего)'
                            when 21 then 'Снегопад длительностью (или несколько снегопадов суммарной длительностью от начала первого до конца последнего) менее 10 часов'
                            when 22 then 'Снегопад длительностью (или несколько снегопадов суммарной длительностью от начала первого до конца последнего) более 10 часов'
                            when 31 then 'I период после снегопада'
                            when 32 then 'II период после снегопада'
                            when 33 then 'III период после снегопада'
                            when 34 then 'I и II период после снегопада'
                          end;

  return l_snowfall_period_text;
end
$$;

