CREATE FUNCTION fdc_workplan_get_rainfall(p_work_date timestamp without time zone)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
/* Расчет суммарного количества осадков на указанные сутки
  %param p_work_date дата из фильтра Дата работ с

  %return Количество осадков в сантиметрах
*/
  l_work_date_start timestamp;
  l_work_date_end timestamp;

  l_rainfall_qty double precision;
begin
  l_work_date_start:=date_trunc('day',p_work_date);
  l_work_date_end:=l_work_date_start+ interval '1' day - interval '1' second;

  select sum(case
               when t.snow_date_from <> work_day_from_part then (t.work_day_snowfall_hr/t.total_snowfall_hr)*t.rainfall
               else t.rainfall
             end
            ) / 10
    into l_rainfall_qty
    from(select w.id
               ,w.snow_date_from
               ,coalesce(w.snow_date_to,l_work_date_end) snow_date_to
               ,coalesce(w.rainfall,0) rainfall
               ,greatest(w.snow_date_from,l_work_date_start) work_day_from_part

               ,(extract(epoch from coalesce(w.snow_date_to,l_work_date_end)) -
                 extract(epoch from w.snow_date_from)
                )/60/60 total_snowfall_hr
               ,(extract(epoch from coalesce(w.snow_date_to,l_work_date_end)) -
                 extract(epoch from greatest(w.snow_date_from,l_work_date_start))
                )/60/60 work_day_snowfall_hr
           from msnow.fdc_weather w
          where w.snow_date_from<l_work_date_end
            and coalesce(w.snow_date_to,ods.c_infinity_plus())> l_work_date_start
        ) t;

  return coalesce(l_rainfall_qty,0);
end
$$;

