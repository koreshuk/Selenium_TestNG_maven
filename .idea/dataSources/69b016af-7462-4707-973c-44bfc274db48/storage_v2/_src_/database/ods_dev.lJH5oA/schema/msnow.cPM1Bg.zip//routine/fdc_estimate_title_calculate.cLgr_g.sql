CREATE FUNCTION fdc_estimate_title_calculate(p_obligation_id bigint DEFAULT NULL::bigint, p_purchase_lot_id bigint DEFAULT NULL::bigint, p_agreement_id bigint DEFAULT NULL::bigint, OUT driveway_vol_qty integer, OUT driveway_with_estimate_vol_qty integer, OUT driveway_cost_qty integer, OUT driveway_with_estimate_cost_qty integer, OUT estimate_qty integer, OUT estimate_calculated_qty integer, OUT work_type_qty integer, OUT work_type_norate_qty integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
/** Расчет объемов работ и стоимости сметы бюджетного обязательства/закупки/обязательства на основе ТС.
  %param p_obligation_id   -- Ид бюджетного обязательства
  %param p_purchase_lot_id -- Ид закупки
  %param p_agreement_id    -- Ид обязательства

  %return  driveway_vol_qty               -- число дорог, включенных в объект
  %return  driveway_with_estimate_vol_qty -- число дорог объекта, для которых рассчитаны объемы работ

  %return  driveway_cost_qty               -- число дорог объекта
  %return  driveway_with_estimate_cost_qty -- число дорог объекта, по которым есть сметы
  %return  estimate_qty               -- число работ объекта
  %return  estimate_calculated_qty    -- число рассчитанных работ
  %return  work_type_qty              -- число видов работ объекта
  %return  work_type_norate_qty       -- число видов работ без расценок
*/
  l_sql text;

  l_pholder1 text;
  l_pholder2 text;
  l_pholder3 text;
  l_pholder4 text;
  l_pholder5 text;
  l_pholder6 text;
  l_pholder7 text;

  l_title_id bigint;
  l_object_id bigint;
  l_rn integer;

  l_obligation_id bigint;
  l_purchase_lot_id bigint;
  l_agreement_id bigint;

  l_work_category_code msnow.fdc_work_category.code%type;
begin
  if p_obligation_id is not null or p_purchase_lot_id is not null or p_agreement_id is not null then
    l_obligation_id:=case
                       when p_obligation_id is not null then p_obligation_id
                       else NULL
                     end;
    l_purchase_lot_id:=case
                       when p_purchase_lot_id is not null then p_purchase_lot_id
                       else NULL
                     end;
    l_agreement_id:=case
                       when p_agreement_id is not null then p_agreement_id
                       else NULL
                     end;

    l_pholder1:=case
                  when p_obligation_id is not null then 'fdc_obligation'
                  when p_agreement_id is not null then 'fdc_agreement'
                  when p_purchase_lot_id is not null then 'fdc_purchase'
                end;

    l_pholder2:=case
                  when p_obligation_id is not null then 'authority_org_id'
                  when p_agreement_id is not null then 'customer_id'
                  when p_purchase_lot_id is not null then 'customer_id'
                end;

    l_pholder3:=case
                  when p_obligation_id is not null then 'fdc_obligation_object'
                  when p_agreement_id is not null then 'fdc_agreement_object'
                  when p_purchase_lot_id is not null then 'fdc_purchase_object'
                end;

    l_pholder4:=case
                  when p_obligation_id is not null then 'obligation_id'
                  when p_agreement_id is not null then 'argeement_id'
                  when p_purchase_lot_id is not null then 'purchase_lot_id'
                end;

    l_pholder5:=case
                  when p_obligation_id is not null then 'fdc_obligation_estimate'
                  when p_agreement_id is not null then 'fdc_agr_estimate'
                  when p_purchase_lot_id is not null then 'fdc_purchase_estimate'
                end;

    l_pholder6:=case
                  when p_obligation_id is not null then 'obligation_id'
                  when p_agreement_id is not null then 'agreement_id'
                  when p_purchase_lot_id is not null then 'purchase_lot_id'
                end;

    l_sql:=format('select t.id as title_id
                         ,o.id as object_id
                         ,wc.code as work_category_code
                         ,count(t.id) over(order by 1) rn
                     from ods.fdc_title t
                     join ods.fdc_title_status ts on t.title_status_id=ts.id
                     join nsi.fdc_legal_person lp on t.customer_id=lp.id
                     join msnow.%I o on lp.root_id=o.%I --1,2
                                        and t.work_category_id=o.work_category_id '||
                                        case
                                          when p_obligation_id is not null then
                                            --'and extract(year from t.date_from)::integer=o.obligation_year::integer '
                                            'and to_date(''01.01.''||o.obligation_year,''dd.mm.yyyy'') between t.date_from and t.date_to '
                                          else
                                            'and o.work_date_from between t.date_from and t.date_to '
                                        end||
                    'join ods.fdc_object_type objt on t.object_type_id=objt.id
                     join ods.fdc_title_type ttp on t.title_type_id=ttp.id
                     left join msnow.fdc_work_category wc on t.work_category_id=wc.id
                    where o.id=$1
                      and ts.code=$2
                      and objt.code=$3
                      and ttp.code=$4'
                 ,l_pholder1,l_pholder2
                 );
    -- raise notice '%',l_sql;
    execute l_sql into l_title_id,l_object_id,l_work_category_code,l_rn using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id),'APPROVED','ODH','1';

    if coalesce(l_rn,0)<>1 then
      raise exception 'Титульный список, действующий на дату начала выполнения работ не определен. Невозможно завершить операцию.';
    else
      l_pholder7:=case l_work_category_code
                    when 'MAINTAIN' then 'fdc_title_odh'
                    when 'REPAIR' then 'fdc_title_repair'
                  end;
      --raise notice 'found title_id=%',l_title_id;
      -- Очистка списка объектов
      l_sql:=format('delete from msnow.%I where %I=$1',l_pholder3,l_pholder4);
      execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
      -- Очистка записей сметы
      l_sql:=format('delete from msnow.%I where %I=$1',l_pholder5,l_pholder6);
      execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
      -- Заполнение списка объектов перечнем объектов найденного ТС
      l_sql:=format('insert into msnow.%I(id,%I,driveway_id)
                       select nextval(''ods.fdc_common_seq'')
                             ,$1
                             ,odh_id
                         from ods.%I
                        where title_id=$2'
                   ,l_pholder3,l_pholder4,l_pholder7
                   );
      execute l_sql using l_object_id,l_title_id;

      -- Расчет объемов работ сметы
      select driveway_qty
            ,driveway_with_estimate_qty
        into driveway_vol_qty
            ,driveway_with_estimate_vol_qty
        from msnow.fdc_estimate_volume_calculate(
                p_obligation_id   => l_obligation_id
               ,p_purchase_lot_id => l_purchase_lot_id
               ,p_agreement_id    => l_agreement_id
              );

      -- Расчет стоимости сметы
      select ec.driveway_qty
            ,ec.driveway_with_estimate_qty
            ,ec.estimate_qty
            ,ec.estimate_calculated_qty
            ,ec.work_type_qty
            ,ec.work_type_norate_qty
        into driveway_cost_qty
            ,driveway_with_estimate_cost_qty
            ,estimate_qty
            ,estimate_calculated_qty
            ,work_type_qty
            ,work_type_norate_qty
        from msnow.fdc_estimate_calculate(
                 p_obligation_id       => l_obligation_id
                ,p_purchase_lot_id     => l_purchase_lot_id
                ,p_agreement_id        => l_agreement_id
               ) ec;
    end if;
  end if;
end
$$;

