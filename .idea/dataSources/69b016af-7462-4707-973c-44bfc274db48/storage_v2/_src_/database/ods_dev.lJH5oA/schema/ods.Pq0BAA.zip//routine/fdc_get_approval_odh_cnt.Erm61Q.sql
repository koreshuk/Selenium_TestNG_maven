CREATE FUNCTION fdc_get_approval_odh_cnt(p_official_id bigint, OUT approval_cnt integer, OUT approved_object_cnt integer, OUT rejected_object_cnt integer, OUT onapproval_object_cnt integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает количество объектов ОДХ для блока Обратите внимание

    %param p_official_id - Ид текущего пользователя

    %return approval_cnt          -- Согласовать паспорта: <Количество паспортов ОДХ>
    %return approved_object_cnt   -- Согласовано за последние 3 дня: <Количество паспортов ОДХ>
    %return rejected_object_cnt   -- Отклонено: <Количество паспортов ОДХ>
    %return onapproval_object_cnt -- На согласовании: <Количество паспортов ОДХ>
  */
  l_responsible_for_approve secr.fdc_user_md.responsible_for_approve%type;
  l_user_person_id secr.fdc_user_md.person_id%type;
  l_result integer;
begin
  select responsible_for_approve
        ,person_id
    into strict l_responsible_for_approve,l_user_person_id
    from secr.fdc_user_md
   where id=p_official_id;

  select count(distinct tt.id)
    into approval_cnt
    from(select odh.id
           from ods.fdc_approval_workflow awf
           join secr.fdc_user_md u on awf.official_id=u.id
           join ods.fdc_approval_status aps on awf.approval_status_id=aps.id
           join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
           join ods.fdc_approval app on apit.approval_id=app.id
           join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
           join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
           join ods.fdc_odh odh on app.main_object_id=odh.id
           join ods.fdc_object obj on odh.id=obj.id
           join ods.fdc_object_state objs on obj.object_state_id=objs.id
          where aps.code='SENT'
            and atmplt.code='ODH'
            and objs.code='ON_APPROVAL'
            and awf.official_id=p_official_id
         union
         select odh.id
           from ods.fdc_approval_workflow awf
           join ods.fdc_approval_status aps on awf.approval_status_id=aps.id
           join ods.fdc_approval_temp_part atp on awf.approval_template_detail_id=atp.id
           join nsi.fdc_legal_person lp on atp.organization_id=lp.id
           join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
           join ods.fdc_approval app on apit.approval_id=app.id
           join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
           join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
           join ods.fdc_odh odh on app.main_object_id=odh.id
           join ods.fdc_object obj on odh.id=obj.id
           join ods.fdc_object_state objs on obj.object_state_id=objs.id
          where l_responsible_for_approve
            and aps.code='SENT'
            and atmplt.code='ODH'
            and awf.official_id is null
            and atp.data_dl=2
            and objs.code='ON_APPROVAL'
            and lp.root_id=l_user_person_id
        ) tt;

    select count(distinct odh.id)
      into approved_object_cnt
      from ods.fdc_approval_workflow awf
      join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
      join ods.fdc_approval app on apit.approval_id=app.id
      join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
      join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
      join ods.fdc_odh odh on app.main_object_id=odh.id
      join ods.fdc_object obj on odh.id=obj.id
      join ods.fdc_object_state ost on obj.object_state_id=ost.id
      join nsi.fdc_legal_person sprslp on awf.send_by_person_id=sprslp.id
     where ost.code='APPROVED'
       and atmplt.code='ODH'
       and sprslp.root_id=l_user_person_id
       and obj.approval_date between current_date -3 and current_date;

    select count(distinct odh.id)
      into rejected_object_cnt
      from ods.fdc_approval_workflow awf
      join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
      join ods.fdc_approval app on apit.approval_id=app.id
      join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
      join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
      join ods.fdc_approval_status apps on app.approval_status_id=apps.id
      join ods.fdc_odh odh on app.main_object_id=odh.id
      join ods.fdc_object obj on odh.id=obj.id
      join ods.fdc_object_state ost on obj.object_state_id=ost.id
      join nsi.fdc_legal_person sprslp on awf.send_by_person_id=sprslp.id
     where ost.code='PROJECT'
       and apps.code='REJECTED'
       and atmplt.code='ODH'
       and sprslp.root_id=l_user_person_id;

    select count(distinct odh.id)
      into onapproval_object_cnt
      from ods.fdc_approval_workflow awf
      join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
      join ods.fdc_approval app on apit.approval_id=app.id
      join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
      join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
      join ods.fdc_approval_status apps on app.approval_status_id=apps.id
      join ods.fdc_odh odh on app.main_object_id=odh.id
      join ods.fdc_object obj on odh.id=obj.id
      join ods.fdc_object_state ost on obj.object_state_id=ost.id
      join nsi.fdc_legal_person sprslp on awf.send_by_person_id=sprslp.id
     where ost.code='ON_APPROVAL'
       and apps.code='SENT'
       and atmplt.code='ODH'
       --and sprslp.root_id=l_user_person_id
       and ((l_responsible_for_approve and sprslp.root_id=l_user_person_id)
         or (not COALESCE(l_responsible_for_approve,FALSE) and awf.send_by_user_id = p_official_id))
       ;

  return;
end
$$;

