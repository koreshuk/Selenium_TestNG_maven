CREATE FUNCTION scr_purchase2agreement_repair(p_purchase_id bigint, p_agreement_id bigint, p_driveway_list text DEFAULT NULL::text)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Скрипт по переносу участков ремонта и смет из закупки в обязательств(контракт). Ремонт
  %param p_purchase_id   - Ид закупки
  %param p_agreement_id  - Ид обязательства
  %param p_driveway_list - Список участков ремонта из закупки
  */
  l_driveway_list bigint[];
  l_agreement_id msnow.fdc_agreement.id%type;
  l_agreement_type_code msnow.fdc_agreement_type.code%type;

  l_purchase_id msnow.fdc_purchase.id%type;
  l_purchase_decrease msnow.fdc_purchase.decrease%type;

  l_purchase_object_qty integer;
  l_copy_all boolean;
begin
  if p_driveway_list is not null then
    begin
      l_driveway_list:=string_to_array(p_driveway_list,',');
    exception
      when others then
        raise exception 'Некорректный формат списка идентификаторов участков ремонта.';
    end;
  end if;

  begin
    select agr.id
          ,agrt.code
      into strict l_agreement_id
          ,l_agreement_type_code
      from msnow.fdc_agreement agr
      join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
     where agr.id=p_agreement_id;
  exception
    when NO_DATA_FOUND then
      raise exception 'Не найдено обязательство с идентификатором %',p_agreement_id;
  end;

  if l_agreement_type_code not in('CONTRACT','MUNICIPAL_CONTRACT') then
    raise exception 'Недопустимый тип обязательства %',l_agreement_type_code;
  end if;

  begin
    select id
          ,decrease
      into strict l_purchase_id
          ,l_purchase_decrease
      from msnow.fdc_purchase
     where id=p_purchase_id;
  exception
    when NO_DATA_FOUND then
      raise exception 'Не найдена закупка с идентификатором %',p_purchase_id;
  end;

  select count(distinct driveway_segment_id)
    into l_purchase_object_qty
    from msnow.fdc_purchase_object
   where purchase_lot_id=l_purchase_id;

  l_copy_all:=case
                when p_driveway_list is null then true
                when l_purchase_object_qty = cardinality(l_driveway_list) then true
                else false
              end;

  delete from msnow.fdc_agr_estimate where agreement_id=l_agreement_id;
  delete from msnow.fdc_agreement_object where argeement_id=l_agreement_id;

  -- копируем участки
  update msnow.fdc_driveway_segment
     set agreement_id=l_agreement_id
   where id in(select distinct oo.driveway_segment_id
                 from msnow.fdc_purchase_object oo
                where oo.purchase_lot_id=l_purchase_id
                  and(l_copy_all or oo.driveway_segment_id in(select unnest(l_driveway_list)))
              );

  insert into msnow.fdc_agreement_object(id,argeement_id,driveway_segment_id)
    select nextval('ods.fdc_common_seq')
          ,l_agreement_id
          ,oo.driveway_segment_id
      from msnow.fdc_purchase_object oo
     where oo.purchase_lot_id=l_purchase_id
       and(l_copy_all or oo.driveway_segment_id in(select unnest(l_driveway_list)));

  -- копируем все сметы на уровне участка:
  insert into msnow.fdc_agr_estimate(id,agreement_id,driveway_segment_id,work_type_id,work_volume
                                    ,measure_unit_id,work_cost,is_estimate_sum,odh_group_id)
    select nextval('ods.fdc_common_seq')
          ,l_agreement_id
          ,oe.driveway_segment_id
          ,oe.work_type_id
          ,oe.work_volume
          ,oe.measure_unit_id
          ,case
             when l_purchase_decrease is null then
               oe.work_cost
             else
               oe.work_cost - ((l_purchase_decrease/100) * oe.work_cost)
           end
          ,oe.is_estimate_sum
          ,oe.odh_group_id
      from msnow.fdc_purchase_estimate oe
     where oe.purchase_lot_id=l_purchase_id
       and not oe.is_estimate_sum
       and ((l_copy_all and oe.driveway_segment_id is not null) or
            ((not l_copy_all) and oe.driveway_segment_id in(select unnest(l_driveway_list)))
           );

  -- вычисляем сводные сметы
  insert into msnow.fdc_agr_estimate(id,agreement_id,work_type_id
                                     ,measure_unit_id,work_volume,work_cost,is_estimate_sum)
    select nextval('ods.fdc_common_seq')
          ,oe.agreement_id
          ,oe.work_type_id
          ,wt.measure_unit_id
          ,round(sum(oe.work_volume)::numeric,3) work_volume
          ,round(sum(oe.work_cost)::numeric,2) work_cost
          ,true
      from msnow.fdc_agr_estimate oe
      join msnow.fdc_work_type wt on oe.work_type_id=wt.id
     where oe.agreement_id=l_agreement_id
       and oe.driveway_segment_id is not null
       and not oe.is_estimate_sum
     group by oe.agreement_id
             ,oe.work_type_id
             ,wt.measure_unit_id;
end
$$;

