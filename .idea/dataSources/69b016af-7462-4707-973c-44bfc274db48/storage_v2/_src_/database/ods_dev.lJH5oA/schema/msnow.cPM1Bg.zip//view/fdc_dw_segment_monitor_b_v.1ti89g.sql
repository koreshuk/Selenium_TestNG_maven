CREATE VIEW fdc_dw_segment_monitor_b_v AS
  WITH milling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_milling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), levelling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_levelling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), asph AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_asphalt AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), rside AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_roadside AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), f AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 20))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN levelling ON ((ssch.driveway_segment_id = levelling.driveway_segment_id)))
        ), b AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 50))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN asph ON ((ssch.driveway_segment_id = asph.driveway_segment_id)))
        ), a AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 15))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN rside ON ((ssch.driveway_segment_id = rside.driveway_segment_id)))
        ), e AS (
         SELECT ssch.driveway_segment_id,
            (((COALESCE(round((((ssch.end_date_plan + 1) - ssch.start_date_plan))::double precision), (0)::double precision) - (COALESCE(a.day_cnt, (0)::numeric))::double precision) - (COALESCE(f.day_cnt, (0)::numeric))::double precision) - (COALESCE(b.day_cnt, (0)::numeric))::double precision) AS day_cnt
           FROM ((((msnow.fdc_work_schedule ssch
             JOIN milling ON ((ssch.driveway_segment_id = milling.driveway_segment_id)))
             LEFT JOIN a ON ((ssch.driveway_segment_id = a.driveway_segment_id)))
             LEFT JOIN f ON ((ssch.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((ssch.driveway_segment_id = b.driveway_segment_id)))
        ), dates AS (
         SELECT sagre.driveway_segment_id,
            sagre.work_type_id,
                CASE
                    WHEN swt.is_asphalt THEN ajrn.delay_reason
                    ELSE wex.delay_reason
                END AS delay_reason,
            min(LEAST(date(wex.work_date), ajrn.work_date)) AS start_date_fact,
            max(GREATEST(
                CASE
                    WHEN wex.is_last_work THEN date(wex.work_date)
                    ELSE NULL::date
                END,
                CASE
                    WHEN ajrn.is_last_work THEN ajrn.work_date
                    ELSE NULL::date
                END)) AS end_date_fact,
            max(
                CASE
                    WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                    WHEN swt.is_milling THEN sch.start_date_plan
                    WHEN swt.is_levelling THEN (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                    WHEN swt.is_asphalt THEN GREATEST(((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer), sch.start_date_plan)
                    WHEN swt.is_roadside THEN LEAST((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer), sch.end_date_plan)
                    ELSE NULL::date
                END) AS start_date_plan,
            max(
                CASE
                    WHEN swt.is_roadside THEN sch.end_date_plan
                    WHEN swt.is_milling THEN GREATEST(((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer),
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        ELSE sch.start_date_plan
                    END)
                    WHEN swt.is_levelling THEN GREATEST(((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer),
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        ELSE (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                    END)
                    WHEN (swt.is_asphalt AND (rside.driveway_segment_id IS NOT NULL)) THEN ((((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer)
                    WHEN (swt.is_asphalt AND (rside.driveway_segment_id IS NULL)) THEN sch.end_date_plan
                    ELSE NULL::date
                END) AS end_date_plan
           FROM (((((((((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
             LEFT JOIN msnow.fdc_work_execute wex ON (((wex.driveway_segment_id = sagre.driveway_segment_id) AND (wex.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((ajrn.driveway_segment_id = sagre.driveway_segment_id) AND (ajrn.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_work_schedule sch ON ((sagre.driveway_segment_id = sch.driveway_segment_id)))
             LEFT JOIN e ON ((sagre.driveway_segment_id = e.driveway_segment_id)))
             LEFT JOIN f ON ((sagre.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((sagre.driveway_segment_id = b.driveway_segment_id)))
             LEFT JOIN rside ON ((sagre.driveway_segment_id = rside.driveway_segment_id)))
          WHERE (NOT swt.is_additional_work)
          GROUP BY sagre.driveway_segment_id, sagre.work_type_id,
                CASE
                    WHEN swt.is_asphalt THEN ajrn.delay_reason
                    ELSE wex.delay_reason
                END
        ), photo AS (
         SELECT DISTINCT ON (fagre.driveway_segment_id, fagre.work_type_id) fagre.driveway_segment_id,
            fagre.work_type_id,
            COALESCE(fwexp.file_id, fajrnp.file_id) AS photo_file_id
           FROM ((((((msnow.fdc_agreement fagr
             JOIN msnow.fdc_agr_estimate fagre ON ((fagr.id = fagre.agreement_id)))
             JOIN msnow.fdc_work_type fwt ON ((fagre.work_type_id = fwt.id)))
             LEFT JOIN msnow.fdc_work_execute fwex ON (((fwex.driveway_segment_id = fagre.driveway_segment_id) AND (fwex.work_type_id = fwt.id))))
             LEFT JOIN msnow.fdc_work_execute_photo fwexp ON ((fwex.id = fwexp.work_execute_id)))
             LEFT JOIN msnow.fdc_asphalt_journal fajrn ON (((fajrn.driveway_segment_id = fagre.driveway_segment_id) AND (fajrn.work_type_id = fwt.id))))
             LEFT JOIN msnow.fdc_asphalt_journal_photo fajrnp ON ((fajrn.id = fajrnp.asphalt_journal_id)))
          WHERE ((fagre.driveway_segment_id IS NOT NULL) AND (COALESCE(fwexp.file_id, fajrnp.file_id) IS NOT NULL) AND (NOT fwt.is_additional_work))
          ORDER BY fagre.driveway_segment_id, fagre.work_type_id, COALESCE(fwex.work_date, (fajrn.work_date)::timestamp without time zone) DESC NULLS LAST, COALESCE(fwexp.id, fajrnp.id) DESC NULLS LAST
        )
 SELECT t4.id,
    t4.work_type_id,
    t4.work_type_name,
    t4.start_date_plan,
    t4.start_date_fact,
    t4.end_date_plan,
    t4.end_date_fact,
        CASE
            WHEN ((t4.end_date_fact IS NULL) AND ((('now'::text)::date - t4.end_date_plan) > 0)) THEN (('now'::text)::date - t4.end_date_plan)
            WHEN ((t4.end_date_fact - t4.end_date_plan) > 0) THEN (t4.end_date_fact - t4.end_date_plan)
            ELSE 0
        END AS expiration_days,
    t4.delay_reason,
    t4.photo_file_id
   FROM ( SELECT ttt.id,
            NULL::bigint AS work_type_id,
            ttt.work_type_name,
            ttt.start_date_plan,
            min(ttt.start_date_fact) AS start_date_fact,
            ttt.end_date_plan,
            max(ttt.end_date_fact) AS end_date_fact,
            max(ttt.delay_reason) AS delay_reason,
            max(ttt.photo_file_id) AS photo_file_id
           FROM ( SELECT dws.id,
                    (
                        CASE
                            WHEN swt.is_milling THEN 'Работы по фрезерованию'::text
                            WHEN swt.is_levelling THEN 'Работы по устройству выравнивающего слоя'::text
                            WHEN swt.is_asphalt THEN 'Работы по укладке асфальтобетона'::text
                            WHEN swt.is_roadside THEN 'Работы по обустройству обочин'::text
                            ELSE NULL::text
                        END)::character varying(255) AS work_type_name,
                    dates.start_date_plan,
                    dates.start_date_fact,
                    dates.end_date_plan,
                    dates.end_date_fact,
                    dates.delay_reason,
                    photo.photo_file_id
                   FROM ((((((((msnow.fdc_driveway_segment dws
                     JOIN msnow.fdc_dw_segment_status dwss ON ((dws.status_id = dwss.id)))
                     JOIN msnow.fdc_segment s ON ((s.id = dws.id)))
                     JOIN fdc_driveway dw ON ((dws.driveway_id = dw.id)))
                     JOIN msnow.fdc_agreement agr ON ((dws.agreement_id = agr.id)))
                     JOIN msnow.fdc_agr_estimate agre ON (((agr.id = agre.agreement_id) AND (dws.id = agre.driveway_segment_id))))
                     JOIN msnow.fdc_work_type swt ON ((agre.work_type_id = swt.id)))
                     LEFT JOIN dates ON (((dws.id = dates.driveway_segment_id) AND (swt.id = dates.work_type_id))))
                     LEFT JOIN photo ON (((dws.id = photo.driveway_segment_id) AND (swt.id = photo.work_type_id))))
                  WHERE (((dwss.code)::text <> ALL ((ARRAY['FUTURE_PLANNED'::character varying, 'ON_VOTE'::character varying, 'ESTIMATED_RESULT'::character varying])::text[])) AND (NOT swt.is_additional_work) AND (swt.is_asphalt OR swt.is_milling OR swt.is_levelling OR swt.is_roadside))) ttt
          GROUP BY ttt.id, ttt.work_type_name, ttt.start_date_plan, ttt.end_date_plan) t4;

COMMENT ON VIEW fdc_dw_segment_monitor_b_v IS 'Все участки ремонта и виды работ по ним из связанного контракта для витрины Мониторинг работ по ремонту';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.id IS 'Ид участка ремонта';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.work_type_id IS 'Ид вида работы';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.work_type_name IS 'Наименование вида работы';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.start_date_plan IS 'Дата начала(план)';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.start_date_fact IS 'Дата начала(факт)';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.end_date_plan IS 'Дата окончания(план)';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.end_date_fact IS 'Дата окончания(факт)';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.expiration_days IS 'Дни просрочки';

COMMENT ON COLUMN fdc_dw_segment_monitor_b_v.delay_reason IS 'Причина отставания';

