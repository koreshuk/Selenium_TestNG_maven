CREATE FUNCTION fdc_person_children_root(p_parent_root_id bigint, OUT root_id bigint)
  RETURNS SETOF bigint
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает список root_id иерархии всех дочерних для p_parent_root_id организаций
      типа ЮЛ, Филиал, ИП

    %param p_parent_root_id - root_id родительской организации

    %return root_id         - root_id организаций (ЮЛ, Филиал, ИП) наследников p_parent_root_id
  */
begin
  return query with recursive rh(root_id
                                ,parent_root_id
                                ,person_type_id
                                ,level
                                ) as(select distinct l1.root_id
                                           ,l1.parent_root_id
                                           ,l1.person_type_id
                                           ,1
                                       from nsi.fdc_legal_person l1
                                      where l1.root_id= p_parent_root_id
                                     union all
                                     select distinct ln.root_id
                                           ,ln.parent_root_id
                                           ,ln.person_type_id
                                           ,level+1
                                       from nsi.fdc_legal_person ln
                                       join rh on rh.root_id=ln.parent_root_id
                      )
                      select rh.root_id
                        from rh;
                       --where rh.root_id<> p_parent_root_id;

  return;
end
$$;

