CREATE VIEW fdc_bti_okrug_v AS
  SELECT NULL::bigint AS id,
    NULL::bigint AS source_id,
    NULL::character varying AS code,
    NULL::character varying AS name,
    NULL::character varying AS short_name,
    NULL::boolean AS is_actual,
    NULL::integer AS sort_order,
    NULL::timestamp without time zone AS created,
    NULL::timestamp without time zone AS modified,
    NULL::timestamp without time zone AS deleted;

COMMENT ON VIEW fdc_bti_okrug_v IS 'Справочник БТИ. Районы';

COMMENT ON COLUMN fdc_bti_okrug_v.id IS 'Идентификатор округа';

COMMENT ON COLUMN fdc_bti_okrug_v.source_id IS 'Идентификатор в исходном файле';

COMMENT ON COLUMN fdc_bti_okrug_v.code IS 'Код в ас управления реестрами';

COMMENT ON COLUMN fdc_bti_okrug_v.name IS 'Наименование округа';

COMMENT ON COLUMN fdc_bti_okrug_v.short_name IS 'Наименование округа';

COMMENT ON COLUMN fdc_bti_okrug_v.is_actual IS 'Признак актуальности: 0 - нет; 1 - да';

COMMENT ON COLUMN fdc_bti_okrug_v.sort_order IS 'Порядок сортировки';

COMMENT ON COLUMN fdc_bti_okrug_v.created IS 'Дата создания';

COMMENT ON COLUMN fdc_bti_okrug_v.modified IS 'Дата модификации';

COMMENT ON COLUMN fdc_bti_okrug_v.deleted IS 'Дата удаления';

