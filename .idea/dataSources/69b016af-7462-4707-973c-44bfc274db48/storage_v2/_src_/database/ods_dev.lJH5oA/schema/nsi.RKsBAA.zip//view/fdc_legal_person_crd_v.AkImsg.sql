CREATE VIEW fdc_legal_person_crd_v AS
  SELECT t.id,
    t.root_id,
    t.person_type_id,
    t.code,
    t.name,
    t.short_name,
    t.ogrn,
    t.inn,
    t.kpp,
    t.okpo,
    t.is_ip,
    t.is_filial,
    t.provider_id,
    t.provider_name,
    t.reg_date,
    t.bank,
    t.bik,
    t.corr_account,
    t.account,
    t.legal_address,
    t.postal_address,
    t.phone,
    t.fax,
    t.email,
    t.off_post,
    t.off_name,
    t.cbr_bank_id,
    t.is_small_medium,
    t.sro_flag,
    t.sro_org_id,
    t.sro_regnum,
    t.person_code,
    t.person_code_name,
    t.data_state_id,
        CASE
            WHEN (t.data_state_id = 1) THEN 'Чистовик'::text
            WHEN (t.data_state_id = 3) THEN 'Субъект удалён'::text
            ELSE 'Черновик'::text
        END AS data_state,
    t.asur_sync_status,
    t.asur_sync_date,
    t.complete_values,
    t.has_no_collision,
    t.fns_validate,
    t.fns_sync_date,
    t.last_changed,
    t.username,
    t.okonh_id,
    t.okopf_id,
    t.okved_id,
    t.okfs_id,
    t.start_date,
    t.end_date,
    t.ver_start_date,
    t.ver_end_date,
    t.is_actual,
    t.is_local_version,
    t.user_fio,
    t.bind_person_id
   FROM ( SELECT lpr.id,
            lpr.root_id,
            lpr.person_type_id,
            lpr.code,
            lpr.name,
            lpr.short_name,
            lpr.ogrn,
            lpr.inn,
            lpr.kpp,
            lpr.okpo,
                CASE lpr.person_type_id
                    WHEN 2 THEN 1
                    ELSE 0
                END AS is_ip,
                CASE
                    WHEN (lpr.person_type_id = 3) THEN 1
                    ELSE 0
                END AS is_filial,
            rel.id AS provider_id,
            rel.name AS provider_name,
            lpr.reg_date,
            lpr.bank,
            lpr.bik,
            lpr.corr_account,
            lpr.account,
            lpr.legal_address,
            lpr.postal_address,
            lpr.phone,
            lpr.fax,
            lpr.email,
            lpr.off_post,
            lpr.off_name,
            lpr.parent_id,
            lpr.cbr_bank_id,
            lpr.is_small_medium,
            lpr.sro_flag,
            lpr.sro_org_id,
            lpr.sro_regnum,
            lpr.person_code,
            lpr.person_code_name,
                CASE
                    WHEN ((lpr.code IS NOT NULL) AND (COALESCE(lpr.has_no_collision, 0) = 1) AND (lpr.complete_values = 1) AND ((lpr.closing_date IS NULL) OR (lpr.closing_date > ('now'::text)::timestamp without time zone))) THEN 1
                    WHEN ((lpr.closing_date <= ('now'::text)::timestamp without time zone) AND (lpr.ver_end_date <= ('now'::text)::timestamp without time zone)) THEN 3
                    ELSE 2
                END AS data_state_id,
            lpr.asur_sync_status,
            lpr.asur_sync_date,
            lpr.complete_values,
            lpr.has_no_collision,
            lpr.fns_validate,
            lpr.fns_sync_date,
            lpr.okonh_id,
            lpr.okopf_id,
            lpr.okved_id,
            lpr.okfs_id,
            lpr.last_changed,
            lpr.username,
            ( SELECT min(l.ver_start_date) AS min
                   FROM nsi.fdc_legal_person l
                  WHERE (l.root_id = lpr.root_id)) AS start_date,
            lpr.closing_date AS end_date,
            lpr.ver_start_date,
            COALESCE(lpr.ver_end_date, (to_date('01.01.4000'::text, 'DD.MM.YYYY'::text))::timestamp without time zone) AS ver_end_date,
                CASE
                    WHEN (lpr.closing_date IS NOT NULL) THEN 1
                    WHEN (lpr.ver_end_date IS NOT NULL) THEN 0
                    ELSE 1
                END AS is_actual,
            lpr.is_local_version,
            lpr.username AS user_fio,
            lpr.bind_person_id
           FROM (( SELECT p.id,
                    p.root_id,
                    p.person_type_id,
                    p.code,
                    p.name,
                    p.short_name,
                    p.inn,
                    p.kpp,
                    p.ogrn,
                    p.okpo,
                    p.account,
                    p.postal_address,
                    p.legal_address,
                    p.email,
                    p.phone,
                    p.fax,
                    p.off_post,
                    p.off_name,
                    p.bik,
                    p.bank,
                    p.corr_account,
                    p.person_code,
                    p.person_code_name,
                    p.occupation_id,
                    p.okved,
                    p.reg_date,
                    p.gender,
                    p.patronymic,
                    p.snils,
                    p.birth_date,
                    p.birth_place,
                    p.birth_country_id,
                    p.identity_doctype_id,
                    p.docseries,
                    p.docnumber,
                    p.issue_date,
                    p.issue_department,
                    p.department_code,
                    p.work_length,
                    p.parent_id,
                    p.parent_root_id,
                    p.cbr_bank_id,
                    p.is_small_medium,
                    p.sro_flag,
                    p.sro_org_id,
                    p.sro_regnum,
                    p.asur_sync_date,
                    p.asur_sync_status,
                    p.fns_sync_date,
                    p.fns_validate,
                    p.suppress_asur_sync,
                    p.last_changed,
                    p.username,
                    p.person_state,
                    p.okonh_id,
                    p.okopf_id,
                    p.okved_id,
                    p.okfs_id,
                    p.ver_start_date,
                    p.ver_end_date,
                    p.closing_date,
                    p.is_actual,
                    p.is_local_version,
                    p.bind_person_id,
                        CASE
                            WHEN ((p.inn IS NOT NULL) AND (p.kpp IS NOT NULL) AND (p.ogrn IS NOT NULL)) THEN 1
                            ELSE 0
                        END AS complete_values,
                    cl.has_no_collision
                   FROM (( SELECT l.id,
                            l.root_id,
                            l.person_type_id,
                            l.code,
                            l.name,
                            l.short_name,
                            l.inn,
                            l.kpp,
                            l.ogrn,
                            l.okpo,
                            l.account,
                            l.postal_address,
                            l.legal_address,
                            l.email,
                            l.phone,
                            l.fax,
                            l.off_post,
                            l.off_name,
                            l.bik,
                            l.bank,
                            l.corr_account,
                            l.person_code,
                            l.person_code_name,
                            l.occupation_id,
                            l.okved,
                            l.reg_date,
                            l.gender,
                            l.patronymic,
                            l.snils,
                            l.birth_date,
                            l.birth_place,
                            l.birth_country_id,
                            l.identity_doctype_id,
                            l.docseries,
                            l.docnumber,
                            l.issue_date,
                            l.issue_department,
                            l.department_code,
                            l.work_length,
                            l.parent_id,
                            l.parent_root_id,
                            l.cbr_bank_id,
                            l.is_small_medium,
                            l.sro_flag,
                            l.sro_org_id,
                            l.sro_regnum,
                            l.asur_sync_date,
                            l.asur_sync_status,
                            l.fns_sync_date,
                            l.fns_validate,
                            l.suppress_asur_sync,
                            l.last_changed,
                            l.username,
                            l.person_state,
                            l.okonh_id,
                            l.okopf_id,
                            l.okved_id,
                            l.okfs_id,
                            l.ver_start_date,
                            COALESCE(l.ver_end_date, l.closing_date) AS ver_end_date,
                            l.closing_date,
                                CASE
                                    WHEN (l.closing_date IS NOT NULL) THEN 1
                                    WHEN (l.ver_end_date IS NOT NULL) THEN 0
                                    ELSE 1
                                END AS is_actual,
                            l.is_local_version,
                            l.bind_person_id
                           FROM nsi.fdc_person_v l) p
                     LEFT JOIN nsi.fdc_person_ver_collision_mv cl ON ((cl.id = p.id)))
                  WHERE (p.person_type_id = ANY (ARRAY[(0)::bigint, (1)::bigint, (2)::bigint, (3)::bigint]))) lpr
             LEFT JOIN nsi.fdc_legal_person rel ON ((rel.id = lpr.parent_id)))) t;

COMMENT ON VIEW fdc_legal_person_crd_v IS 'Карточка ЮЛ (включая ИП и филиалы и запросы в АСУР)';

COMMENT ON COLUMN fdc_legal_person_crd_v.id IS 'ИД организации';

COMMENT ON COLUMN fdc_legal_person_crd_v.root_id IS 'Сквозной Ид организации (для версионности, он же ИД субъекта в НСИ для интерфейса)';

COMMENT ON COLUMN fdc_legal_person_crd_v.person_type_id IS 'ИД родительской организации для филиалов';

COMMENT ON COLUMN fdc_legal_person_crd_v.code IS 'Код в АС Управления Реестрами';

COMMENT ON COLUMN fdc_legal_person_crd_v.name IS 'Полное наименование';

COMMENT ON COLUMN fdc_legal_person_crd_v.short_name IS 'Краткое наименование';

COMMENT ON COLUMN fdc_legal_person_crd_v.ogrn IS 'Основной государственный регистрационный номер';

COMMENT ON COLUMN fdc_legal_person_crd_v.inn IS 'Идентификационный номер налогоплательщика';

COMMENT ON COLUMN fdc_legal_person_crd_v.kpp IS 'Код причины постановки на учёт';

COMMENT ON COLUMN fdc_legal_person_crd_v.okpo IS 'Общероссийский классификатор предприятий и организаций';

COMMENT ON COLUMN fdc_legal_person_crd_v.is_ip IS 'Признак ИП. 1 - да, 0 - нет';

COMMENT ON COLUMN fdc_legal_person_crd_v.is_filial IS 'Признак филиала. 1 - да, 0 - нет';

COMMENT ON COLUMN fdc_legal_person_crd_v.provider_id IS 'Ид головной организации';

COMMENT ON COLUMN fdc_legal_person_crd_v.provider_name IS 'Наименование головной организации';

COMMENT ON COLUMN fdc_legal_person_crd_v.reg_date IS 'Дата регистрации';

COMMENT ON COLUMN fdc_legal_person_crd_v.bank IS 'Банк';

COMMENT ON COLUMN fdc_legal_person_crd_v.bik IS 'БИК';

COMMENT ON COLUMN fdc_legal_person_crd_v.account IS 'Расчётный счёт (текущий счёт)';

COMMENT ON COLUMN fdc_legal_person_crd_v.legal_address IS 'Юридический адрес';

COMMENT ON COLUMN fdc_legal_person_crd_v.postal_address IS 'Почтовый адрес';

COMMENT ON COLUMN fdc_legal_person_crd_v.phone IS 'Телефон организации или ответственного лица';

COMMENT ON COLUMN fdc_legal_person_crd_v.fax IS 'Факс организации';

COMMENT ON COLUMN fdc_legal_person_crd_v.email IS 'Электронная почта';

COMMENT ON COLUMN fdc_legal_person_crd_v.off_post IS 'Должность руководителя';

COMMENT ON COLUMN fdc_legal_person_crd_v.off_name IS 'ФИО руководителя';

COMMENT ON COLUMN fdc_legal_person_crd_v.cbr_bank_id IS 'Ид банк';

COMMENT ON COLUMN fdc_legal_person_crd_v.is_small_medium IS 'Признак малого или среднего бизнеса';

COMMENT ON COLUMN fdc_legal_person_crd_v.sro_flag IS 'Признак СРО';

COMMENT ON COLUMN fdc_legal_person_crd_v.sro_org_id IS 'Ид СРО';

COMMENT ON COLUMN fdc_legal_person_crd_v.sro_regnum IS 'Оегистрационный номер СРО';

COMMENT ON COLUMN fdc_legal_person_crd_v.person_code IS 'Код поразделения';

COMMENT ON COLUMN fdc_legal_person_crd_v.person_code_name IS 'Вид подразделения';

COMMENT ON COLUMN fdc_legal_person_crd_v.data_state_id IS 'Ил состояния данных';

COMMENT ON COLUMN fdc_legal_person_crd_v.data_state IS 'Состояние данных';

COMMENT ON COLUMN fdc_legal_person_crd_v.asur_sync_status IS 'статус синхронизации с асур (0-запрос не отправлялся, 1- ожидает ответа, 2- данные актуальны, 3 - не удалось синхронизировать) ';

COMMENT ON COLUMN fdc_legal_person_crd_v.asur_sync_date IS 'дата последней успешной синхронизации с асур ';

COMMENT ON COLUMN fdc_legal_person_crd_v.complete_values IS 'Признак заполнения ключевых регистрационных данных';

COMMENT ON COLUMN fdc_legal_person_crd_v.has_no_collision IS 'Признак отсутствия коллизий (1 - нет, 0 - есть)';

COMMENT ON COLUMN fdc_legal_person_crd_v.fns_validate IS 'признак того, обновлены сведения о юл данными из фнс ';

COMMENT ON COLUMN fdc_legal_person_crd_v.fns_sync_date IS 'дата синхронизации с фнс ';

COMMENT ON COLUMN fdc_legal_person_crd_v.last_changed IS 'дата последних изменении ';

COMMENT ON COLUMN fdc_legal_person_crd_v.username IS 'пользователь внесший изменение ';

COMMENT ON COLUMN fdc_legal_person_crd_v.okonh_id IS 'Ид ОКОНХ';

COMMENT ON COLUMN fdc_legal_person_crd_v.okopf_id IS 'Ид ОКОПФ';

COMMENT ON COLUMN fdc_legal_person_crd_v.okved_id IS 'Ид ОКВЕД';

COMMENT ON COLUMN fdc_legal_person_crd_v.okfs_id IS 'Ид ОКФС';

COMMENT ON COLUMN fdc_legal_person_crd_v.start_date IS 'Дата начала действия организации';

COMMENT ON COLUMN fdc_legal_person_crd_v.end_date IS 'Дата окончания действия(закрытия) организации';

COMMENT ON COLUMN fdc_legal_person_crd_v.ver_start_date IS 'Дата начала версии';

COMMENT ON COLUMN fdc_legal_person_crd_v.ver_end_date IS 'Дата окончания версии';

COMMENT ON COLUMN fdc_legal_person_crd_v.is_actual IS 'Признак последней/актуальной версии';

COMMENT ON COLUMN fdc_legal_person_crd_v.user_fio IS 'ФИО пользователя';

COMMENT ON COLUMN fdc_legal_person_crd_v.bind_person_id IS 'ИД связанного субъекта';

