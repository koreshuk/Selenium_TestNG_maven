CREATE FUNCTION rep_driveway_formhold_summary(p_driveway_category_id bigint, p_customer_id bigint DEFAULT NULL::bigint, p_fias_district_id bigint DEFAULT NULL::bigint, OUT id bigint, OUT name character varying, OUT customer_short_name character varying, OUT fias_name character varying, OUT holder_fio character varying, OUT holder_org_name character varying, OUT holder_occupation character varying, OUT date_plan date, OUT expiration_days integer)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Сводка по согласованию паспортов" по задерживающим согласование
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_customer_id           - Заказчик (Ид актуальной версии заказчика)
  %param p_fias_district_id      - Ид муниципального района/городского округа

  %return id                  -- Ид
  %return name                -- Паспорт
  %return customer_short_name -- Заказчик
  %return fias_name           -- Муниц. район/ городской округ
  %return holder_fio          -- ФИО задерживающего согласование
  %return holder_org_name     -- Организация     задерживающего согласование
  %return holder_occupation   -- Должность       задерживающего согласование
  %return date_plan           -- Планируемая дата согласования
  %return expiration_days     -- Дней просрочки
  */
  l_summary_date date;
begin
  l_summary_date:=current_date;

  return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                      and (p_fias_district_id is null or lp.id in(select distinct obj.customer_id
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                   join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                   join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                   join ods.fdc_as_addrobj fias on fias.id=p_fias_district_id
                                                                  where /*objs.code='APPROVED'
                                                                    and*/ obj.driveway_category_id=p_driveway_category_id
                                                                  --  and l_summary_date between obj.version_date_from and obj.version_date_to
                                                                    and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                         (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                        )
                                                                 )
                          )
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as driveway_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='ODH'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select m.driveway_id
                             ,m.approval_iteration_id
                         from maxiter m
                         join ods.fdc_approval_workflow awf on m.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )
          ,dvway as(select obj.id as driveway_id
                          ,obj.name as driveway_name
                          ,acust.customer_short_name
                          ,mi.approval_iteration_id
                          ,case
                             when obj.as_area_id is not null then
                               fiasar.formal_name||case
                                                     when fiasar.short_name is not null then ' '||fiasar.short_name
                                                     else ''
                                                   end
                             when obj.as_place_id is not null then
                               fiaspl.formal_name||case
                                                     when fiaspl.short_name is not null then ' '||fiaspl.short_name
                                                     else ''
                                                   end
                           end as fias_name
                      from expired mi
                      join ods.fdc_object obj on mi.driveway_id=obj.id
                      join ods.fdc_odh odh on obj.id=odh.id
                      join ods.fdc_object_state objs on obj.object_state_id=objs.id
                      join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                      join rcust acust on cust.root_id=acust.customer_root_id
                      left join ods.fdc_as_addrobj fiasar on obj.as_area_id=fiasar.id
                      left join ods.fdc_as_addrobj fiaspl on obj.as_place_id=fiaspl.id
                     where objs.code='ON_APPROVAL'
                   )
          ,agwflow as(select dvway.driveway_id
                            ,dvway.driveway_name
                            ,dvway.customer_short_name
                            ,dvway.fias_name
                            ,awf.date_plan
                            ,awf.date_fact
                            ,l_summary_date - awf.date_plan as expiration_days
                            ,coalesce(awf.official_id::text
                                     ,(select string_agg(u.id::text,';')
                                         from secr.fdc_user_md u
                                        where u.responsible_for_approve
                                          and coalesce(u.person_id,-1) = coalesce(awfo.root_id,-1)
                                          --and coalesce(u.division_id,-1) = coalesce(awfd.root_id,-1)
                                          --and coalesce(u.occupation_id,-1) = coalesce(awf.occupation_id,-1)
                                          --limit 1--на всякий случай
                                      )
                                     ) as holder_user_id
                        from dvway
                        join ods.fdc_approval_workflow awf on dvway.approval_iteration_id=awf.approval_iteration_id
                        join ods.fdc_approval_status ast on awf.approval_status_id=ast.id

                        left join nsi.fdc_legal_person awfo on awf.organization_id=awfo.id
                        left join nsi.fdc_legal_person awfd on awf.division_id=awfd.id
                       where ast.code = 'SENT'
                         and(awf.is_obligatory or
                              (awf.date_fact is not null and exists(select null
                                                                      from ods.fdc_approval_temp_part atp
                                                                      join ods.fdc_approval_temp_stage ats on atp.approval_temp_stage_id=ats.id
                                                                     where atp.id=awf.approval_template_detail_id
                                                                       and ats.rule_stage=2
                                                                   )
                              )
                            )
                         and awf.date_plan < l_summary_date
                     )
                    ,holder_user_list as (SELECT unnest(string_to_array(agwflow.holder_user_id,';'))::bigint as holder_user_id,
                                                  agwflow.driveway_id
                                             FROM agwflow)

           select twf.driveway_id as id
                 ,twf.driveway_name::varchar as name
                 ,twf.customer_short_name
                 ,twf.fias_name::varchar
                 ,(hu.family||case
                                when hu.first_name is not null then ' '||hu.first_name
                                else ''
                              end||case
                                     when hu.second_name is not null then ' '||hu.second_name
                                     else ''
                                   end
                  )::varchar as holder_fio
                 ,huorg.short_name as holder_org_name
                 ,ocp.name as holder_occupation
                 ,twf.date_plan
                 ,twf.expiration_days
             from agwflow twf
             left join holder_user_list hul on hul.driveway_id = twf.driveway_id
             left join secr.fdc_user_md hu on hul.holder_user_id=hu.id
             left join nsi.fdc_legal_person huorg on hu.person_id=huorg.root_id
                                                     and statement_timestamp() between huorg.ver_start_date and huorg.ver_end_date
             left join nsi.fdc_occupation ocp on hu.occupation_id=ocp.id;

end
$$;

