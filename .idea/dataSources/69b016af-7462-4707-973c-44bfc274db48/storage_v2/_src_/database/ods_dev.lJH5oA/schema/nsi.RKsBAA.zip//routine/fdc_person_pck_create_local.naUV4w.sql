CREATE FUNCTION fdc_person_pck_create_local(p_event_id bigint, p_old_ver_id bigint, p_legal_person nsi.fdc_legal_person)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Создает локальную версию
  %usage Используется в legal_edit
  %param p_old_ver_id Ид старой версии
  %param p_event_id Ид события
  %param p_legal_person Строка данных локальной версии
  */
  l_res          nsi.fdc_legal_person.id%type;
  l_legal_person nsi.fdc_legal_person;
  l_inn          nsi.fdc_legal_person.inn%type;
  l_crc          nsi.fdc_legal_person.crc%type;
begin
  l_legal_person:=p_legal_person;

  if l_legal_person.person_type_id in (nsi.c_sl_organization(), nsi.c_sl_declarant(), nsi.c_sl_branch()) then
    -- ЮЛ
    perform nsi.fdc_nsi_pck_flk_legal_person
        ( p_event_id        => p_event_id
        , p_code            => null
        , p_person_type_id  => p_legal_person.person_type_id
        , p_root_id         => p_legal_person.root_id
        , p_name            => p_legal_person.name
        , p_short_name      => p_legal_person.short_name
        , p_inn             => p_legal_person.inn
        , p_ogrn            => p_legal_person.ogrn
        , p_okpo            => p_legal_person.okpo
        , p_kpp             => p_legal_person.kpp
        , p_email           => p_legal_person.email
        , p_bik             => p_legal_person.bik
        , p_account         => p_legal_person.account
        , p_parent_id       => p_legal_person.parent_id
        );
  else
    raise exception 'Ошибка создания версии. Локальная версия для субъекта % не предусмотрена.',l_legal_person.person_type_id;
  end if;

  select root_id
        ,inn
        ,crc
    into l_legal_person.root_id
        ,l_inn
        ,l_legal_person.crc
    from nsi.fdc_legal_person
   where id = p_old_ver_id;

  if l_inn is not null and coalesce(l_inn, '-') <> coalesce(l_legal_person.inn, '-') then
    raise exception 'Изменять ИНН запрещено.';
  end if;

  l_crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_legal_person);

  select max(l.id)
    into l_res
    from nsi.fdc_legal_person l
   where l.root_id = l_legal_person.root_id
     and l.crc = l_crc
     and l.is_local_version = true;

  if l_res is null then--l_legal_person.crc != l_crc then

    l_legal_person.crc := l_crc;
    l_legal_person.id := nextval('nsi.fdc_person_seq');
    l_legal_person.ver_start_date:=localtimestamp;
    l_legal_person.ver_end_date:=localtimestamp;
    l_legal_person.is_local_version:=true;

    perform nsi.insert_legal_person_row(l_legal_person);
  end if;

  return l_res;
end
$$;

