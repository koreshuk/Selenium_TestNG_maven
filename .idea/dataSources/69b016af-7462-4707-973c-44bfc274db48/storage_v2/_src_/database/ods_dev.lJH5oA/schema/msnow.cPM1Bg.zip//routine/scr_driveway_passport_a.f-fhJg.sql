CREATE FUNCTION scr_driveway_passport_a(p_municipality_id bigint, OUT driveway_id bigint, OUT driveway_name character varying, OUT driveway_owner_name character varying, OUT agreement_id bigint, OUT agreement_year character varying, OUT work_category_name character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Список дорог (с привязкой к контракту)
    %param p_municipality_id - Ид муниц. района/ГО ФИАС

    %return driveway_id          -- Ид дороги
    %return driveway_name        -- Наименование дороги
    %return driveway_owner_name  -- Наименование заказчика дороги
    %return agreement_id         -- Ид контракта
    %return agreement_year       -- Год контракта
    %return work_category_name   -- Наименование категории работ
  */
begin
 return query select dw.id as driveway_id
                    ,dw.name as driveway_name
                    ,cust.name as driveway_owner_name
                    ,a.id as agreement_id
                    ,extract('year' from a.work_date_from)::varchar as agreement_year
                    ,wc.name as work_category_name
                from msnow.fdc_driveway dw
                left join msnow.fdc_agreement_object ao on dw.id=ao.driveway_id
                left join msnow.fdc_agreement a on ao.argeement_id=a.id
                left join msnow.fdc_work_category wc on a.work_category_id=wc.id
                left join nsi.fdc_legal_person cust on dw.owner_id=cust.root_id
                                                       and statement_timestamp() between cust.ver_start_date and cust.ver_end_date
               where dw.owner_id in(select id
                                      from msnow.fdc_ods_organization
                                     where municipality_id=p_municipality_id--130001
                                   );
  return;
end
$$;

