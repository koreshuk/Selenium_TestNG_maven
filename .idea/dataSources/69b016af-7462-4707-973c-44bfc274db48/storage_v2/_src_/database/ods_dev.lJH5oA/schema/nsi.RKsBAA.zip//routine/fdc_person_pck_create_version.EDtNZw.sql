CREATE FUNCTION fdc_person_pck_create_version(p_old_ver_id bigint, p_legal_person nsi.fdc_legal_person, p_event_id bigint, p_start_date timestamp without time zone DEFAULT NULL::timestamp without time zone, p_with_flk boolean DEFAULT true)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция создания версии
  %usage Используется внутри пакета
  %param p_old_version_id  - ид редактируемой версии
  %param p_legal_person    - данные fdc_legal_person
  %param p_start_date      - дата начала действия организации = min дате начала версии
  %param p_event_id        - Ид события
  %param p_with_flk        - Признак необходимости ФЛК (1 - флк нужен)
  %return Ид новой версии
  */
  l_new_legal_person  nsi.fdc_legal_person;
  l_sysdate           timestamp := localtimestamp;
  l_min_start_date    nsi.fdc_legal_person.ver_start_date%type; -- Дата начала действия редактируемой организации (мин дата начала версии)
  l_min_id            nsi.fdc_person.id%type; 
  l_old_person_crc    nsi.fdc_legal_person.crc%type;
  l_code              nsi.fdc_person.code%type;
  l_old_person_type_id nsi.fdc_legal_person.person_type_id%type;
  l_user              nsi.fdc_person.username%type;

 
begin
  l_user:=secr.get_current_user_name();

  l_new_legal_person:=p_legal_person;
  
  l_new_legal_person.is_local_version := coalesce(l_new_legal_person.is_local_version, false);
  l_new_legal_person.is_small_medium := coalesce(l_new_legal_person.is_small_medium, 0);
  l_new_legal_person.sro_flag  := coalesce(l_new_legal_person.sro_flag, false);
  l_new_legal_person.ver_start_date := l_sysdate + interval '1' second;
  l_new_legal_person.ver_end_date := null;

  -- чистка пробелов в серии и номере
  l_new_legal_person.docseries:=replace(l_new_legal_person.docseries, ' ','');
  l_new_legal_person.docnumber:=replace(l_new_legal_person.docnumber, ' ','');

  -- замещаем текстовые поля спраовчником
  if l_new_legal_person.bank_id is not null and
     (l_new_legal_person.bik is not null or l_new_legal_person.bank is not null) then
    l_new_legal_person.bik := null;
    l_new_legal_person.bank := null;
    l_new_legal_person.corr_account := null;
  end if;

  -- поиск parent_root_id (не заполнен или поменялся)
  if l_new_legal_person.parent_id is not null then
    select root_id
      into strict l_new_legal_person.parent_root_id
      from nsi.fdc_legal_person
     where id = l_new_legal_person.parent_id;
  else
    l_new_legal_person.parent_root_id := null;
  end if;

  l_new_legal_person.crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_new_legal_person);
  if p_old_ver_id is not null then -- создание очередной версии
    begin
      -- Выбираем данные старой версии
      select p.crc
           , p.root_id
           , p.code
           , p.person_type_id
        into l_old_person_crc
           , l_new_legal_person.root_id
           , l_code
           , l_old_person_type_id
        from nsi.fdc_person_v p
       where p.id = p_old_ver_id
         and p.ver_end_date is null;
    exception
      when no_data_found then
        raise exception 'Ошибка создания версии. Действующая версия с ID = % не найдена.',p_old_ver_id;
    end;

    -- поиск ид и даты начала первой версии
    -- (дата начала первой версии = дата начала действия организации)
    select lp.ver_start_date
          ,lp.id
      into strict l_min_start_date
          ,l_min_id    
      from nsi.fdc_person p
          ,nsi.fdc_legal_person lp
     where p.id = l_new_legal_person.root_id   
       and p.id=lp.root_id;
  
    if l_old_person_type_id <> nsi.c_sl_request() then -- если не запрос в асур
      -- Проверка даты начала орг, если изменилась
      ----
      
      if p_start_date is not null and p_start_date <> l_min_start_date then
        
        if p_start_date > l_min_start_date then
          raise exception 'Дата начала не может быть изменена на большую.'; -- т.к. могут быть связи
        end if;
        
        -- Редактирование даты появления организации (мин дата начала версии)
        update nsi.fdc_legal_person
           set ver_start_date = date_trunc('day',p_start_date)
         where id = l_min_id;
      end if;
      
      ---
      l_new_legal_person.crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_new_legal_person);
      -- Редактируем, если контрольная сумма изменилась
      if l_new_legal_person.crc != l_old_person_crc then
        -- ФЛК
        perform nsi.fdc_person_pck_check_flk(pc_code                     => l_code
                                            ,pc_legal_person             => l_new_legal_person
                                            ,pc_with_flk                 => p_with_flk
                                            ,pc_new_legal_person_type_id => l_new_legal_person.person_type_id
                                            ,pc_event_id                 => p_event_id
                                            );

        -- Закрываем предыдущую запись
        update  nsi.fdc_legal_person
           set ver_end_date = l_sysdate
         where id = p_old_ver_id;

        -- обновляем корень
        update nsi.fdc_person p
           set last_changed = l_sysdate
             , username = l_user
         where id = l_new_legal_person.root_id;
        -- Создаем новую версию
        l_new_legal_person.id := nextval('nsi.fdc_person_seq');

        perform nsi.insert_legal_person_row(l_new_legal_person);
      else
        return p_old_ver_id; -- досрочный выход без изменений
      end if; 
    else
      -- Запись первого ответа АСУР
      -- ФЛК
      perform nsi.fdc_person_pck_check_flk(pc_code                     => l_code
                                          ,pc_legal_person             => l_new_legal_person
                                          ,pc_with_flk                 => p_with_flk
                                          ,pc_new_legal_person_type_id => l_new_legal_person.person_type_id
                                          ,pc_event_id                 => p_event_id
                                          );      

      -- закрываем запись типа заявки датой открытия
      -- в интерфейсе должно произойти обновление ид орг в документе
      update nsi.fdc_legal_person
         set ver_end_date = l_min_start_date
       where id = p_old_ver_id;
      -- версия
      l_new_legal_person.id := nextval('nsi.fdc_person_seq');
      l_new_legal_person.ver_start_date := l_min_start_date- interval '1' second; -- полностью блокируем заявку от поиска на дату

      perform nsi.insert_legal_person_row(l_new_legal_person);

    end if;
  else
    -- Ручной режим добавления или добавл при онлайн синхр с АСУР
    -- ФЛК
    perform nsi.fdc_person_pck_check_flk(pc_code                     => l_code
                                        ,pc_legal_person             => l_new_legal_person
                                        ,pc_with_flk                 => p_with_flk
                                        ,pc_new_legal_person_type_id => l_new_legal_person.person_type_id
                                        ,pc_event_id                 => p_event_id
                                        );      

    -- Создаем новую версию
    insert into nsi.fdc_person(id
                              ,last_changed
                              ,username
                              )
      values(nextval('nsi.fdc_person_seq')
            ,l_sysdate
            ,l_user)
      returning id
               ,id 
           into l_new_legal_person.id
               ,l_new_legal_person.root_id;

    l_new_legal_person.crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_new_legal_person); -- т.к. записали root_id, надо пересчитать
    l_new_legal_person.ver_start_date := date_trunc('day',coalesce(p_start_date, l_sysdate));

    perform nsi.insert_legal_person_row(l_new_legal_person);
  end if;
  -- здесь останавливаемся, логировать не будем 
  return l_new_legal_person.id;
end
$$;

