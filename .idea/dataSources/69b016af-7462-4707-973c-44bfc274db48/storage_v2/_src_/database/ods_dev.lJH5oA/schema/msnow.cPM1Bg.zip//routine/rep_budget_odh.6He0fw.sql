CREATE FUNCTION rep_budget_odh(p_year integer, p_driveway_category_id bigint, p_work_category_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, p_odh_id bigint DEFAULT NULL::bigint, OUT id bigint, OUT work_type_name character varying, OUT work_category_name character varying, OUT work_volume double precision, OUT measure_unit_name character varying, OUT work_cost double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /*Отчет "Сведения об исполнении бюджета по содержанию и ремонту автомобильных дорог"

    %param p_year integer         - Год
    %param p_driveway_category_id - Балансовая принадлежность
    %param p_work_category_id     - Категория работ 
    %param p_customer_id          - Заказчик
    %param p_odh_id               - Дорога
    
    %return id                    - Ид контракта
    %return work_type_name        - Вид работ
    %return work_category_name    - Категория работ
    %return work_volume           - Объем работ
    %return measure_unit_name     - Единица измерения
    %return work_cost             - Стоимость работ, руб 
  */
  
  l_year_start_date date;
begin
  l_year_start_date:=to_date('01.01.'||p_year,'dd.mm.yyyy');
  return query
    with cust as(select lp.id as customer_id
                       ,lp.root_id as customer_root_id
                       ,lp.fias_district_id
                       ,lp.short_name as customer_short_name
                   from nsi.fdc_legal_person lp
                   join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                   join nsi.fdc_role r on pr.role_id=r.id
                  where lp.person_type_id in(1,3)
                    and l_year_start_date between lp.ver_start_date and lp.ver_end_date
                    and l_year_start_date between pr.begin_date and pr.end_date
                    and r.code='CUSTOMER'
                  )
        ,omsu_mo as(select distinct cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,m.root_id as municipality_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                      join nsi.fdc_legal_person_municipality lpm on cust.customer_id=lpm.legal_person_id
                      join nsi.fdc_municipality m on lpm.municipality_id=m.id  
                     where r.code='OMSU'
                       and current_date between lpm.start_date and lpm.end_date 
                       and p_driveway_category_id = 1
                   )     
        ,rcust as(select cust.customer_id 
                        ,cust.customer_root_id
                        ,cust.customer_short_name
                    from cust
                    join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                    join nsi.fdc_role r on pr.role_id=r.id
                   where r.code='RUAD'
                     and p_driveway_category_id = 2
                  union
                  select cust.customer_id
                        ,cust.customer_root_id
                        ,cust.customer_short_name
                    from cust
                    join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                    join nsi.fdc_role r on pr.role_id=r.id
                   where r.code='OMSU'
                     and p_driveway_category_id = 1
                  union
                  select cust.customer_id
                        ,cust.customer_root_id
                        ,cust.customer_short_name
                    from cust
                    join nsi.fdc_legal_person_municipality lpm on cust.customer_id=lpm.legal_person_id
                    join nsi.fdc_municipality m on lpm.municipality_id=m.id
                    join omsu_mo on m.root_id = omsu_mo.municipality_root_id 
                   where cust.customer_root_id not in(select pr.person_id
                                                        from nsi.fdc_person_role pr
                                                        join nsi.fdc_role r on pr.role_id=r.id
                                                       where r.code in('OMSU','RUAD','MA','TO','KO')
                                                     )
                     and current_date between lpm.start_date and lpm.end_date 
                     and p_driveway_category_id = 1
                   )
        ,odh_wt as(select distinct agre.work_type_id
                     from msnow.fdc_agr_estimate agre
                    where p_work_category_id=2--'MAINTAIN' -- содержание 
                      and agre.driveway_id=p_odh_id
                   union 
                   select distinct agre.work_type_id
                     from msnow.fdc_agr_estimate agre
                    where p_work_category_id=2--'MAINTAIN' -- содержание 
                      and agre.odh_group_id is not null
                      and p_odh_id is not null
                   union
                   select distinct agre.work_type_id
                     from msnow.fdc_agr_estimate agre
                     join msnow.fdc_driveway_segment dws on agre.driveway_segment_id=dws.id
                    where p_work_category_id=3--'REPAIR_PROGRAM' -- содержание 
                      and dws.driveway_id=p_odh_id
                  )  
        ,odh_agr as(select distinct ao.argeement_id
                      from msnow.fdc_agreement_object ao  
                     where p_work_category_id=2--'MAINTAIN' -- содержание 
                       and ao.driveway_id=p_odh_id
                    union
                    select distinct ao.argeement_id
                      from msnow.fdc_agreement_object ao  
                      join msnow.fdc_driveway_segment dws on ao.driveway_segment_id=dws.id
                     where p_work_category_id=3--'REPAIR_PROGRAM' -- ремонт
                       and dws.driveway_id=p_odh_id 
                   )               
                           
             select aemsr.agreement_id
                   ,aemsr.work_type_name
                   ,aemsr.work_category_name
                   ,aemsr.work_volume
                   ,aemsr.measure_unit_name
                   ,aemsr.work_cost
               from(select wt.name as work_type_name
                          ,wc.name as work_category_name
                          ,agre.work_volume
                          ,mu.name as measure_unit_name
                          ,agre.work_cost
                          ,agr.id as agreement_id
                          ,row_number() over (partition by agr.agr_root_id,agre.work_type_id order by agr.version_date_to desc, agr.version_date_from desc) rnk 
                      from msnow.fdc_agreement agr
                      join msnow.fdc_agreement_obligation_status agrs on agr.agreement_status_id=agrs.id
                      join msnow.fdc_agr_estimate agre on agr.id=agre.agreement_id --! >>
                      join msnow.fdc_work_type wt on agre.work_type_id=wt.id
                      join msnow.fdc_work_category wc on wt.work_category_id=wc.id
                      join msnow.fdc_measure_unit mu on agre.measure_unit_id=mu.id
                      join nsi.fdc_legal_person cust on agr.customer_id=cust.root_id
                      join rcust on cust.id=rcust.customer_id
                     where agrs.code='APPROVED'
                       and agre.is_estimate_sum
                       and wc.code in('MAINTAIN','REPAIR_PROGRAM')
                       and extract(year from agr.version_date_from)=p_year
                       and (p_work_category_id is null or wt.work_category_id = p_work_category_id)
                       and(p_customer_id is null or cust.id = p_customer_id)
                       and (p_odh_id is null or agre.work_type_id in(select work_type_id from odh_wt))
                       and (p_odh_id is null or agr.id in(select agreement_id from odh_agr))   
                   ) aemsr
              where aemsr.rnk=1;  
  
  return;
end
$$;

