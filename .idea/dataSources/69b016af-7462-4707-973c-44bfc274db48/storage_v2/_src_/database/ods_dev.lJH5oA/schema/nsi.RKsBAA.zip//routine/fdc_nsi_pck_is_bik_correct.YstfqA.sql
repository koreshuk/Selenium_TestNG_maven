CREATE FUNCTION fdc_nsi_pck_is_bik_correct(p_bik character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
/** Проверка БИК
  %usage Используется в пакете
  %param p_bik   - БИК
  %return true  - заданный БИК прошел проверку на корректность
          false - заданный БИК не прошел проверку на корректность
  */
begin
  return true;
end
$$;

