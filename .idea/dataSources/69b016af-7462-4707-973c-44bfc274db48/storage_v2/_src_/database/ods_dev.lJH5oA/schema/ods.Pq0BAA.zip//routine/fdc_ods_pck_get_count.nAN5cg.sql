CREATE FUNCTION fdc_ods_pck_get_count(p_date_act date, p_object_type_id bigint DEFAULT NULL::bigint, p_owner_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, p_okrug_id bigint DEFAULT NULL::bigint, p_district_id bigint DEFAULT NULL::bigint, p_state_id bigint DEFAULT NULL::bigint, p_object_type_sub_id bigint DEFAULT NULL::bigint, p_object_type_up_id bigint DEFAULT NULL::bigint, p_name_or_id text DEFAULT NULL::text, p_passport_num character varying DEFAULT NULL::character varying, p_passport_author_id bigint DEFAULT NULL::bigint, p_passport_developer_id bigint DEFAULT NULL::bigint, p_address_list bigint[] DEFAULT NULL::bigint[], p_with_actual_address boolean DEFAULT false, p_category_id bigint DEFAULT NULL::bigint, p_ownerless bigint DEFAULT NULL::bigint, p_clean_category_id bigint DEFAULT NULL::bigint, p_clean_subcategory_id bigint DEFAULT NULL::bigint, p_own_agree boolean DEFAULT false)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
   /**Функция для вывода количества строк результатов поиска
   <Pre><i>Сopyright (c)</i> 2015 <b>ФОРС Центр Разработки</b></pre>
   %author aevseev
   %usage Используется Вэб приложением для уточнения количества строк при поиске объектов ОГХ по параметрам (форма поиска)

   %chg

   %param p_object_type_id             Идентификатор типа объекта
   %param p_date_act                   Дата действия
   %param p_owner_id                   Идентификатор балансодержателя
   %param p_customer_id                Идентификатор заказчика
   %param p_okrug_id                   Идентификатор округа
   %param p_district_id                Идентификатор района
   %param p_agree_status_id            Ид статуса согласования
   %param p_state_id                   Ид статуса объекта
   %param p_object_type_sub_id         Ид подтипа объекта
   %param p_object_type_up_id          Ид типа верхнего уровня объекта
   %param p_name_or_id                 Наименование или идентификатор объекта
   %param p_passport_num               Номер паспорта объекта
   %param p_passport_author_id         Ид составителя паспорта
   %param p_passport_developer_id      Ид разработчика паспорта
   %param p_address_list               Коллекция идентификаторов адресов
   %param p_with_actual_address        Флаг актуальности адресов
   %param p_category_id                Идентификатор категории объектов
   %param p_ownerless                  Фильтр для бесхозных объектов (Все - null, 0 - Есть паспорт на объект, 1 - Бесхозный объект)
   %param p_clean_category_id          Ид категории уборки
   %param p_clean_subcategory_id       Ид подкатегории уборки
   %param p_own_agree                  Признак у меня на согласовании
   */
  l_address_ids_cnt integer;
  l_cnt integer;
begin
  select count(1)
    into l_address_ids_cnt
    from unnest(p_address_list) t;

  select count(o.id)
    into l_cnt
    from ods.fdc_object o
    join ods.fdc_object_type_v t on t.id=o.object_type_id
    join ods.fdc_object_state_v s on s.id=o.object_state_id
  left join ods.fdc_nsi_person_v w on w.id=o.owner_id
  left join ods.fdc_nsi_person_v c on c.id=o.customer_id
  left join nsi.fdc_bti_okrug_v okr on okr.id = o.okrug_id
  left join nsi.fdc_bti_district_v dst on dst.id=o.district_id
 where p_date_act between o.version_date_from and o.version_date_to
   and (p_owner_id is null or o.owner_id = p_owner_id)
   and (p_customer_id is null or
        ((p_customer_id = -1 and o.customer_id is null) or o.customer_id = p_customer_id)
       )
   and (p_okrug_id is null or o.okrug_id=p_okrug_id)
   and (p_district_id is null or o.district_id=p_district_id)
   and (p_state_id is null or o.object_state_id=p_state_id)
   and (p_name_or_id is null or
        (upper(o.name) like '%'||upper(p_name_or_id)||'%' or
         o.root_id::varchar(255) = p_name_or_id
        )
       )
   and (l_address_ids_cnt =0 or exists(select null
                                         from ods.fdc_object_address oa
                                             ,ods.fdc_nsi_bti_address_v bav
                                             ,unnest(p_address_list) addl
                                        where bav.id = oa.address_id
                                          and oa.object_id = o.id
                                          and oa.address_id=addl
                                          and (coalesce(p_with_actual_address,false)=false or bav.is_actual = p_with_actual_address)
                                      )
       )
   and (coalesce(p_with_actual_address,false) = false or exists (select null
                                                                  from ods.fdc_object_address oa
                                                                      ,ods.fdc_nsi_bti_address_v bav
                                                                 where bav.id = oa.address_id
                                                                   and oa.object_id = o.id
                                                                   and bav.is_actual = p_with_actual_address
                                                               )
       )
   and (coalesce(p_own_agree,false)=false or
        ods.fdc_approval_pck_is_approval_required(o.approval_id,null,o.id) = p_own_agree
       );
  return l_cnt;
end
$$;

