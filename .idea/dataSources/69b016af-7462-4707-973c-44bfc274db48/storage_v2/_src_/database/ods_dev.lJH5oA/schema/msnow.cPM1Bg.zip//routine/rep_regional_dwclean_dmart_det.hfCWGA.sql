CREATE FUNCTION rep_regional_dwclean_dmart_det(p_detail_column text, p_session_id character varying, p_report_date date, p_work_type_group_id bigint, p_work_type_id bigint DEFAULT NULL::bigint, p_performer_id bigint DEFAULT NULL::bigint, p_odh_id bigint DEFAULT NULL::bigint, p_maintain_group_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Интерактивная витрина «Ежедневный отчет по уборке региональных дорог»
     Детализация.

     %param p_detail_column      - Наименование колонки по которой выводится детализация
     %param p_session_id         - Ид сессии
     %param p_report_date        - Дата
     %param p_work_type_group_id - Ид группы видов работ
     %param p_work_type_id       - Ид вида работы
     %param p_performer_id       - Ид исполнителя
     %param p_odh_id             - Ид участка дороги
  */
  l_performer_root_id nsi.fdc_legal_person.root_id%type;
  l_odh_root_id ods.fdc_object.root_id%type;

  l_today_start timestamp;
  l_today_end timestamp;
  l_tomorrow_start timestamp;
  l_tomorrow_end timestamp;
begin

  l_today_start:=to_timestamp(to_char(p_report_date,'dd.mm.yyyy')||' 08:00:00','dd.mm.yyyy hh24:mi:ss');
  l_today_end:=to_timestamp(to_char(p_report_date,'dd.mm.yyyy')||' 23:59:59','dd.mm.yyyy hh24:mi:ss');

  l_tomorrow_start:=to_timestamp(to_char(p_report_date + interval '1' day,'dd.mm.yyyy')||' 00:00:00','dd.mm.yyyy hh24:mi:ss');
  l_tomorrow_end:=to_timestamp(to_char(p_report_date + interval '1' day,'dd.mm.yyyy')||' 07:59:59','dd.mm.yyyy hh24:mi:ss');

  delete from msnow.fdc_regional_dwclean_dmart_det where session_id=p_session_id;
  delete from msnow.fdc_regional_dwclean_dmart_det where set_date < current_date -2;

  begin
    select root_id
      into strict l_performer_root_id
      from nsi.fdc_legal_person
     where id=p_performer_id;
  exception
    when NO_DATA_FOUND then
      l_performer_root_id:=null;
  end;
  begin
    select root_id
      into strict l_odh_root_id
      from ods.fdc_object
     where id=p_odh_id;
  exception
    when NO_DATA_FOUND then
      l_odh_root_id:=null;
  end;
  if lower(p_detail_column) in('plan','not_execute_percent') then
   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
      ,plan_pw as(select pw.id
                        ,pw.driveway_id
                        ,pw.maintenance_route_id
                        ,pw.work_volume
                        ,agr.performer_id as performer_root_id
                        ,pw.work_type_id
                    from msnow.fdc_planed_work pw
                    join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                    join msnow.fdc_wtype_wtype_group wtwtg on pw.work_type_id=wtwtg.work_type_id
                    join msnow.fdc_agreement agr on pw.agreement_id=agr.id
                   where pw.work_date= p_report_date
                     and pws.code in ('APPROVED','DONE')
                     and wtwtg.work_type_group_id=p_work_type_group_id
                     and (p_work_type_id is null or pw.work_type_id=p_work_type_id)
                     and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                 )
      ,fact as(select tt.object_root_id
                     ,tt.customer_root_id
                     ,tt.performer_root_id
                     ,tt.work_type_id
                     ,sum(tt.work_volume) as work_volume_fact
                     ,max(tt.work_execute_id) as work_execute_id
                 from(select obj.root_id as object_root_id
                            ,ruad.customer_root_id
                            ,agr.performer_id as performer_root_id
                            ,we.work_type_id
                            ,we.id as work_execute_id
                            ,row_number() over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) rnb
                            --,max(we.work_volume) over(partition by obj.root_id,agr.agr_root_id,we.work_type_id,date(we.work_date)) as work_volume
                            ,max(we.vehicles_passage_fact) over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) as work_volume
                        from msnow.fdc_work_execute we
                        join msnow.fdc_work_status ws on we.work_status_id=ws.id
                        join msnow.fdc_wtype_wtype_group wtwtg on we.work_type_id=wtwtg.work_type_id
                        join msnow.fdc_agreement agr on we.agreement_id=agr.id
                        join ods.fdc_odh odh on we.driveway_id=odh.id
                        join ods.fdc_object obj on odh.id=obj.id
                        join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                        join ruad on cust.root_id = ruad.customer_root_id
                       where ws.code in('DONE','ACCEPTED')
                         and ((we.work_date between l_today_start and l_today_end) or
                              (we.work_date between l_tomorrow_start and l_tomorrow_end)
                             )
                         and wtwtg.work_type_group_id=p_work_type_group_id
                         and (p_work_type_id is null or we.work_type_id=p_work_type_id)
                         and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                         and (p_odh_id is null or obj.root_id=l_odh_root_id)
                         and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                     ) tt
                where tt.rnb=1
                group by tt.object_root_id
                        ,tt.customer_root_id
                        ,tt.performer_root_id
                        ,tt.work_type_id
              )

       insert into msnow.fdc_regional_dwclean_dmart_det(ID
                                                       ,DETAIL_COLUMN
                                                       ,SESSION_ID
                                                       ,SET_DATE
                                                       ,OBJECT_ROOT_ID
                                                       ,OBJECT_NAME
                                                       ,CUSTOMER_ROOT_ID
                                                       ,CUSTOMER_NAME
                                                       ,PERFORMER_ROOT_ID
                                                       ,PERFORMER_NAME
                                                       ,MAINTAIN_GROUP_ID
                                                       ,MAINTAIN_GROUP_NAME
                                                       ,WORK_TYPE_ID
                                                       ,WORK_TYPE_NAME
                                                       ,WORK_VOLUME_PLAN
                                                       ,WORK_VOLUME_FACT
                                                       ,MEASURE_UNIT_ID
                                                       ,MEASURE_UNIT_NAME
                                                       ,WORK_EXECUTE_ID
                                                       )

     select nextval('event.fdc_datamart_seq')
           ,lower(p_detail_column) as detail_column
           ,p_session_id
           ,current_date
           ,pagg.object_root_id
           ,pagg.object_name
           ,pagg.customer_root_id
           ,pagg.customer_name
           ,pagg.performer_root_id
           ,pagg.performer_name
           ,pagg.maintain_group_id
           ,pagg.maintain_group_name
           ,pagg.work_type_id
           ,pagg.work_type_name
           ,pagg.work_volume_plan
           ,fact.work_volume_fact / 1000.000
           ,pagg.measure_unit_id
           ,pagg.measure_unit_name
           ,fact.work_execute_id
       from(select tt.object_root_id
                  ,onm.name as object_name
                  ,ruad.customer_root_id
                  ,ruad.customer_name
                  ,tt.performer_root_id
                  ,perf.short_name as performer_name
                  ,tt.maintain_group_id
                  ,tt.maintain_group_name
                  ,tt.work_type_id
                  ,tt.work_type_name
                  ,tt.measure_unit_id
                  ,mu.name as measure_unit_name
                  ,sum(tt.work_volume) as work_volume_plan
              from(-- Сумма объемов по фактическим работам, если на вход передан Ид участка
                   select obj.root_id as object_root_id

                         ,cust.root_id as customer_root_id
                         ,ppw.performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,ppw.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,calc.stat_axes_length as work_volume
                     from plan_pw ppw
                     join ods.fdc_odh odh on ppw.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                    where ppw.maintenance_route_id is null
                      and ppw.driveway_id=p_odh_id
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   select obj.root_id as object_root_id
                        -- ,obj.name as object_name
                         ,cust.root_id as customer_root_id
                         ,ppw.performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,ppw.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,calc.stat_axes_length as work_volume
                     from plan_pw ppw
                     join ods.fdc_maintenance_route dist on ppw.maintenance_route_id=dist.id
                     join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                     join ods.fdc_odh odh on disto.odh_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                    where ppw.driveway_id is null
                      and dist.work_plan_approved
                      and odh.id=p_odh_id
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   -- Сумма объемов по фактическим работам, если на вход не передан Ид участка
                   select obj.root_id as object_root_id
                        -- ,obj.name as object_name
                         ,cust.root_id as customer_root_id
                         ,ppw.performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,ppw.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,calc.stat_axes_length as work_volume
                     from plan_pw ppw
                     join ods.fdc_odh odh on ppw.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                    where ppw.maintenance_route_id is null
                      and p_odh_id is null
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   select ttt.object_root_id
                         --,ttt.object_name
                         ,ttt.customer_root_id
                         ,ttt.performer_root_id
                         ,ttt.maintain_group_id
                         ,ttt.maintain_group_name
                         ,ttt.work_type_id
                         ,ttt.work_type_name
                         ,ttt.measure_unit_id
                         ,ttt.work_volume
                     from(select obj.root_id as object_root_id
                              --  ,obj.name as object_name
                                ,cust.root_id as customer_root_id
                                ,ppw.performer_root_id
                                ,odh.maintain_group_id
                                ,mtg.name as maintain_group_name
                                ,ppw.work_type_id
                                ,wt.name as work_type_name
                                ,wt.measure_unit_id
                                --,ppw.work_volume
                                ,calc.stat_axes_length as work_volume
                                ,row_number() over(partition by ppw.id,disto.maintenance_route_id,disto.odh_id,cust.root_id) rnk
                            from plan_pw ppw
                            join ods.fdc_maintenance_route dist on ppw.maintenance_route_id=dist.id
                            join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                            join ods.fdc_odh odh on disto.odh_id=odh.id
                            join ods.fdc_object obj on odh.id=obj.id
                            join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                            join ods.fdc_odh_calculation calc on obj.id=calc.id
                            join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                            left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                           where ppw.driveway_id is null
                             and dist.work_plan_approved
                             and p_odh_id is null
                             and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                         ) ttt
                    where ttt.rnk=1
                   union all
                   select obj.root_id as object_root_id
                       --  ,obj.name as object_name
                         ,cust.root_id as customer_root_id
                         ,dagr.performer_id as performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,swp.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,coalesce(calc.stat_axes_length,0.0) as work_volume
                     from msnow.fdc_scheduled_work_plan swp
                     join msnow.fdc_wtype_wtype_group wtwtg on swp.work_type_id=wtwtg.work_type_id
                     join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                     join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                     join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                     join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                     join ods.fdc_odh odh on disto.odh_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_object_state objs on obj.object_state_id=objs.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
               where dist.work_plan_approved
                 and swpd.performance_date=p_report_date
                 and p_report_date between obj.version_date_from and obj.version_date_to
                 and objs.code='APPROVED'
                 and wtwtg.work_type_group_id=p_work_type_group_id
                 and (p_work_type_id is null or swp.work_type_id=p_work_type_id)
                 and (p_performer_id is null or dagr.performer_id=l_performer_root_id)
                 and (p_odh_id is null or odh.id=p_odh_id)
                 and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
              ) tt
              join ruad on tt.customer_root_id = ruad.customer_root_id
              join msnow.fdc_measure_unit mu on tt.measure_unit_id = mu.id
              left join ods.fdc_object onm on tt.object_root_id = onm.root_id
                                              and p_report_date between onm.version_date_from and onm.version_date_to
              left join nsi.fdc_legal_person perf on tt.performer_root_id=perf.root_id
                                                     and p_report_date between perf.ver_start_date and perf.ver_end_date
             group by tt.object_root_id
                     ,onm.name
                     ,ruad.customer_root_id
                     ,ruad.customer_name
                     ,tt.performer_root_id
                     ,perf.short_name
                     ,tt.maintain_group_id
                     ,tt.maintain_group_name
                     ,tt.work_type_id
                     ,tt.work_type_name
                     ,tt.measure_unit_id
                     ,mu.name
           ) pagg
      left join fact on pagg.object_root_id=fact.object_root_id
                        and pagg.customer_root_id=fact.customer_root_id
                        and pagg.performer_root_id=fact.performer_root_id
                        and pagg.work_type_id=fact.work_type_id;

  elsif lower(p_detail_column)='fact' then
   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
      ,plan_pw as(select pw.id
                        ,pw.driveway_id
                        ,pw.maintenance_route_id
                        ,pw.work_volume
                        ,agr.performer_id as performer_root_id
                        ,pw.work_type_id
                    from msnow.fdc_planed_work pw
                    join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                    join msnow.fdc_wtype_wtype_group wtwtg on pw.work_type_id=wtwtg.work_type_id
                    join msnow.fdc_agreement agr on pw.agreement_id=agr.id
                   where pw.work_date= p_report_date
                     and pws.code in ('APPROVED','DONE')
                     and wtwtg.work_type_group_id=p_work_type_group_id
                     and (p_work_type_id is null or pw.work_type_id=p_work_type_id)
                     and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                 )
       ,plan as(select tt.object_root_id
                  ,onm.name as object_name
                  ,ruad.customer_root_id
                  ,ruad.customer_name
                  ,tt.performer_root_id
                  ,perf.short_name as performer_name
                  ,tt.maintain_group_id
                  ,tt.maintain_group_name
                  ,tt.work_type_id
                  ,tt.work_type_name
                  ,tt.measure_unit_id
                  ,mu.name as measure_unit_name
                  ,sum(tt.work_volume) as work_volume_plan
              from(-- Сумма объемов по фактическим работам, если на вход передан Ид участка
                   select obj.root_id as object_root_id

                         ,cust.root_id as customer_root_id
                         ,ppw.performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,ppw.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,calc.stat_axes_length as work_volume
                     from plan_pw ppw
                     join ods.fdc_odh odh on ppw.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                    where ppw.maintenance_route_id is null
                      and ppw.driveway_id=p_odh_id
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   select obj.root_id as object_root_id
                        -- ,obj.name as object_name
                         ,cust.root_id as customer_root_id
                         ,ppw.performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,ppw.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,calc.stat_axes_length as work_volume
                     from plan_pw ppw
                     join ods.fdc_maintenance_route dist on ppw.maintenance_route_id=dist.id
                     join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                     join ods.fdc_odh odh on disto.odh_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                    where ppw.driveway_id is null
                      and dist.work_plan_approved
                      and odh.id=p_odh_id
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   -- Сумма объемов по фактическим работам, если на вход не передан Ид участка
                   select obj.root_id as object_root_id
                        -- ,obj.name as object_name
                         ,cust.root_id as customer_root_id
                         ,ppw.performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,ppw.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,calc.stat_axes_length as work_volume
                     from plan_pw ppw
                     join ods.fdc_odh odh on ppw.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                    where ppw.maintenance_route_id is null
                      and p_odh_id is null
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   select ttt.object_root_id
                         --,ttt.object_name
                         ,ttt.customer_root_id
                         ,ttt.performer_root_id
                         ,ttt.maintain_group_id
                         ,ttt.maintain_group_name
                         ,ttt.work_type_id
                         ,ttt.work_type_name
                         ,ttt.measure_unit_id
                         ,ttt.work_volume
                     from(select obj.root_id as object_root_id
                              --  ,obj.name as object_name
                                ,cust.root_id as customer_root_id
                                ,ppw.performer_root_id
                                ,odh.maintain_group_id
                                ,mtg.name as maintain_group_name
                                ,ppw.work_type_id
                                ,wt.name as work_type_name
                                ,wt.measure_unit_id
                                --,ppw.work_volume
                                ,calc.stat_axes_length as work_volume
                                ,row_number() over(partition by ppw.id,disto.maintenance_route_id,disto.odh_id,cust.root_id) rnk
                            from plan_pw ppw
                            join ods.fdc_maintenance_route dist on ppw.maintenance_route_id=dist.id
                            join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                            join ods.fdc_odh odh on disto.odh_id=odh.id
                            join ods.fdc_object obj on odh.id=obj.id
                            join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                            join ods.fdc_odh_calculation calc on obj.id=calc.id
                            join msnow.fdc_work_type wt on ppw.work_type_id=wt.id
                            left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                           where ppw.driveway_id is null
                             and dist.work_plan_approved
                             and p_odh_id is null
                             and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                         ) ttt
                    where ttt.rnk=1
                   union all
                   select obj.root_id as object_root_id
                       --  ,obj.name as object_name
                         ,cust.root_id as customer_root_id
                         ,dagr.performer_id as performer_root_id
                         ,odh.maintain_group_id
                         ,mtg.name as maintain_group_name
                         ,swp.work_type_id
                         ,wt.name as work_type_name
                         ,wt.measure_unit_id
                         ,coalesce(calc.stat_axes_length,0.0) as work_volume
                     from msnow.fdc_scheduled_work_plan swp
                     join msnow.fdc_wtype_wtype_group wtwtg on swp.work_type_id=wtwtg.work_type_id
                     join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                     join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                     join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                     join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                     join ods.fdc_odh odh on disto.odh_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_object_state objs on obj.object_state_id=objs.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                     join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                     left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
               where dist.work_plan_approved
                 and swpd.performance_date=p_report_date
                 and p_report_date between obj.version_date_from and obj.version_date_to
                 and objs.code='APPROVED'
                 and wtwtg.work_type_group_id=p_work_type_group_id
                 and (p_work_type_id is null or swp.work_type_id=p_work_type_id)
                 and (p_performer_id is null or dagr.performer_id=l_performer_root_id)
                 and (p_odh_id is null or odh.id=p_odh_id)
                 and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
              ) tt
              join ruad on tt.customer_root_id = ruad.customer_root_id
              join msnow.fdc_measure_unit mu on tt.measure_unit_id = mu.id
              left join ods.fdc_object onm on tt.object_root_id = onm.root_id
                                              and p_report_date between onm.version_date_from and onm.version_date_to
              left join nsi.fdc_legal_person perf on tt.performer_root_id=perf.root_id
                                                     and p_report_date between perf.ver_start_date and perf.ver_end_date
             group by tt.object_root_id
                     ,onm.name
                     ,ruad.customer_root_id
                     ,ruad.customer_name
                     ,tt.performer_root_id
                     ,perf.short_name
                     ,tt.maintain_group_id
                     ,tt.maintain_group_name
                     ,tt.work_type_id
                     ,tt.work_type_name
                     ,tt.measure_unit_id
                     ,mu.name
	           )

       insert into msnow.fdc_regional_dwclean_dmart_det(ID
                                                       ,DETAIL_COLUMN
                                                       ,SESSION_ID
                                                       ,SET_DATE
                                                       ,OBJECT_ROOT_ID
                                                       ,OBJECT_NAME
                                                       ,CUSTOMER_ROOT_ID
                                                       ,CUSTOMER_NAME
                                                       ,PERFORMER_ROOT_ID
                                                       ,PERFORMER_NAME
                                                       ,MAINTAIN_GROUP_ID
                                                       ,MAINTAIN_GROUP_NAME
                                                       ,WORK_TYPE_ID
                                                       ,WORK_TYPE_NAME
                                                       ,WORK_VOLUME_PLAN
                                                       ,WORK_VOLUME_FACT
                                                       ,MEASURE_UNIT_ID
                                                       ,MEASURE_UNIT_NAME
                                                       ,WORK_EXECUTE_ID
                                                       )

     select nextval('event.fdc_datamart_seq')
           ,lower(p_detail_column) as detail_column
           ,p_session_id
           ,current_date
           ,fagg.object_root_id
           ,onm.name as object_name
           ,fagg.customer_root_id
           ,fagg.customer_name
           ,fagg.performer_root_id
           ,perf.short_name as performer_name
           ,fagg.maintain_group_id
           ,fagg.maintain_group_name
           ,fagg.work_type_id
           ,fagg.work_type_name
           ,plan.work_volume_plan
           ,fagg.work_volume_fact / 1000.000
           ,fagg.measure_unit_id
           ,fagg.measure_unit_name
           ,fagg.work_execute_id
	  from(select tt.object_root_id
                 ,tt.customer_root_id
                 ,tt.customer_name
                 ,tt.performer_root_id
                 ,tt.work_type_id
                 ,tt.work_type_name
                 ,tt.measure_unit_id
                 ,tt.measure_unit_name
                 ,tt.maintain_group_id
                 ,tt.maintain_group_name
                 ,sum(tt.work_volume) as work_volume_fact
                 ,max(tt.work_execute_id) as work_execute_id
             from(select obj.root_id as object_root_id
                        ,ruad.customer_root_id
                        ,ruad.customer_name
                        ,agr.performer_id as performer_root_id
                        ,we.work_type_id
				        ,wt.name as work_type_name
				        ,wt.measure_unit_id
				        ,mu.name as measure_unit_name
				        ,odh.maintain_group_id
				        ,mtg.name as maintain_group_name
                        ,we.id as work_execute_id
                        ,row_number() over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) rnb
                        --,max(we.work_volume) over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) as work_volume
                        ,max(we.vehicles_passage_fact) over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) as work_volume
                    from msnow.fdc_work_execute we
                    join msnow.fdc_work_status ws on we.work_status_id=ws.id
                    join msnow.fdc_wtype_wtype_group wtwtg on we.work_type_id=wtwtg.work_type_id
                    join msnow.fdc_agreement agr on we.agreement_id=agr.id
                    join ods.fdc_odh odh on we.driveway_id=odh.id
                    join ods.fdc_object obj on odh.id=obj.id
                    join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                    join ruad on cust.root_id = ruad.customer_root_id
			        join msnow.fdc_work_type wt on we.work_type_id=wt.id
			        join msnow.fdc_measure_unit mu on wt.measure_unit_id = mu.id
			        left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                   where ws.code in('DONE','ACCEPTED')
                     and ((we.work_date between l_today_start and l_today_end) or
                          (we.work_date between l_tomorrow_start and l_tomorrow_end)
                         )
                     and wtwtg.work_type_group_id=p_work_type_group_id
                     and (p_work_type_id is null or we.work_type_id=p_work_type_id)
                     and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                     and (p_odh_id is null or obj.root_id=l_odh_root_id)
                     and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                 ) tt
            where tt.rnb=1
            group by tt.object_root_id
                 ,tt.customer_root_id
                 ,tt.customer_name
                 ,tt.performer_root_id
                 ,tt.work_type_id
                 ,tt.work_type_name
                 ,tt.measure_unit_id
                 ,tt.measure_unit_name
                 ,tt.maintain_group_id
                 ,tt.maintain_group_name
          ) fagg
	  left join ods.fdc_object onm on fagg.object_root_id = onm.root_id
                                      and p_report_date between onm.version_date_from and onm.version_date_to
      left join nsi.fdc_legal_person perf on fagg.performer_root_id=perf.root_id
                                             and p_report_date between perf.ver_start_date and perf.ver_end_date
      left join plan on fagg.object_root_id=plan.object_root_id
                        and fagg.customer_root_id=plan.customer_root_id
                        and fagg.performer_root_id=plan.performer_root_id
                        and fagg.work_type_id=plan.work_type_id;
    end if;
  return;
end
$$;

