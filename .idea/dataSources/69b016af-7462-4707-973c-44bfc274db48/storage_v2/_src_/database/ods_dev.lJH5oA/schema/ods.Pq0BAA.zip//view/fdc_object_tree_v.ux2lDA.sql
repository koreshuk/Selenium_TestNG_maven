CREATE VIEW fdc_object_tree_v AS
  SELECT otr.level,
    otr.object_id AS id,
    obj.id AS object_id,
    otr.object_root_id,
    otr.object_name,
    otr.object_type_code,
    otr.object_state_code,
    otr.version_date_from,
    otr.version_date_to
   FROM (fdc_object obj
     JOIN LATERAL build_object_tree(p_object_id => obj.id) otr(level, object_id, object_root_id, object_name, object_type_code, object_state_code, version_date_from, version_date_to) ON (true));

COMMENT ON VIEW fdc_object_tree_v IS 'Дерево объектов дорожного хозяйства';

COMMENT ON COLUMN fdc_object_tree_v.level IS 'Уроевень вложенности. Уровень 1 = Дорога';

COMMENT ON COLUMN fdc_object_tree_v.id IS 'Ид версии объекта';

COMMENT ON COLUMN fdc_object_tree_v.object_id IS 'Ид версии выбранного объекта';

COMMENT ON COLUMN fdc_object_tree_v.object_root_id IS 'Сквозной Ид объекта';

COMMENT ON COLUMN fdc_object_tree_v.object_name IS 'Наименование объекта';

COMMENT ON COLUMN fdc_object_tree_v.object_type_code IS 'Код типа объекта';

COMMENT ON COLUMN fdc_object_tree_v.object_state_code IS 'Код статуса объекта';

COMMENT ON COLUMN fdc_object_tree_v.version_date_from IS 'Дата начала действия версии';

COMMENT ON COLUMN fdc_object_tree_v.version_date_to IS 'Дата окончания действия версии';

