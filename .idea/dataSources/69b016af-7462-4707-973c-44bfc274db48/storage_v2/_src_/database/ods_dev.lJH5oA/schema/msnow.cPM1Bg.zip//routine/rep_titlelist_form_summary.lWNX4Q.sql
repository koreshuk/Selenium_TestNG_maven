CREATE FUNCTION rep_titlelist_form_summary(p_summary_type integer, p_year integer, p_work_category_id bigint, p_driveway_category_id bigint, p_customer_id bigint DEFAULT NULL::bigint, p_fias_district_id bigint DEFAULT NULL::bigint, OUT id bigint, OUT name character varying, OUT total_qty bigint, OUT passport_qty bigint, OUT passport_tl_qty bigint, OUT passport_notl_qty bigint, OUT total_orphan_qty bigint, OUT orphan_tl_qty bigint, OUT orphan_notl_qty bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Сводка по формированию ТС"
  %param p_summary_type          - Тип формирования сводки:
                                   - 1 - в разрезе заказчиков
                                   - 2 - в разрезе муниципальных районов/городских округов
  %param p_year                  - Год
  %param p_work_category_id      - Категория ТС (Ид категории работ)
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_customer_id           - Заказчик (Ид актуальной на начало выбранного года версии заказчика)
  %param p_fias_district_id      - Ид муниципального района/городского округа

  %return id                     - ROOT_ID заказчика/ Ид муниц. района(городского округа)
  %return name                   - Заказчик/Муниц. район(городской округ)
  %return total_qty              - Всего дорог
  %return passport_qty           - Паспортизтрованные дороги. Всего
  %return passport_tl_qty        - Паспортизтрованные дороги. Включено в ТС
  %return passport_notl_qty      - Паспортизтрованные дороги. Не включено в ТС
  %return total_orphan_qty       - Бесхоз. Всего
  %return orphan_tl_qty          - Бесхоз.Включено в ТС
  %return orphan_notl_qty        - Бесхоз. Не включено в ТС
  */
  l_year integer;
  l_year_start_date date;

  C_CUSTOMER_TYPE constant INTEGER:=1;
  C_FIAS_TYPE constant integer:=2;
begin
  l_year:=coalesce(p_year,extract(year from current_date));
  l_year_start_date:=to_date('01.01.'||l_year::text,'dd.mm.yyyy');

  if p_summary_type = C_CUSTOMER_TYPE then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_year_start_date between lp.ver_start_date and lp.ver_end_date
                      and l_year_start_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                      and (p_fias_district_id is null or lp.id in(select distinct obj.customer_id
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                   join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                   join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                   join ods.fdc_as_addrobj fias on fias.id=p_fias_district_id
                                                                  where objs.code='APPROVED'
                                                                    and obj.driveway_category_id=p_driveway_category_id
                                                                    and l_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                                                                    and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                         (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                        )
                                                                 )
                          )
                  )
          ,lastdw as(select distinct on(obj.root_id)
                            obj.version_date_to
                           ,obj.version_date_from
                           ,cst.root_id as customer_root_id
                           ,obj.id as driveway_id
                           ,odh.is_orphan_object
                       from ods.fdc_object obj
                       join ods.fdc_odh odh on obj.id=odh.id
                       join ods.fdc_object_state objs on obj.object_state_id=objs.id
                       join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                      where objs.code='APPROVED'
                        and obj.driveway_category_id=p_driveway_category_id
                        and l_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                      order by obj.root_id
                              ,obj.version_date_to desc
                             ,obj.version_date_from desc
                    )
          ,lasttl as(select distinct on(todh.odh_id)
                            tl.date_to
                           ,tl.date_from
                           ,todh.odh_id as driveway_id
                           ,cst.root_id as customer_root_id
                       from ods.fdc_title tl
                       join ods.fdc_title_status tls on tl.title_status_id=tls.id
                       join nsi.fdc_legal_person cst on tl.customer_id=cst.id
                       join ods.fdc_title_odh todh on tl.id=todh.title_id
                      where tls.code='APPROVED'
                        and tl.work_category_id = p_work_category_id
                        and l_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                      order by todh.odh_id
                              ,tl.date_to desc
                              ,tl.date_from desc
                    )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where p_customer_id is not null
                   )
           select rcust.customer_root_id
                 ,rcust.customer_short_name
                 ,count(distinct lastdw.driveway_id) as total_qty
                 ,count(distinct case
                                   when not lastdw.is_orphan_object then lastdw.driveway_id
                                  end
                       ) as total_passport_qty

                 ,count(distinct case
                                   when not lastdw.is_orphan_object and lasttl.driveway_id is not null then lastdw.driveway_id
                                  end
                       ) as passport_tl_qty
                 ,count(distinct case
                                   when not lastdw.is_orphan_object and lasttl.driveway_id is null then lastdw.driveway_id
                                  end
                       ) as passport_notl_qty
                 ,count(distinct case
                                   when lastdw.is_orphan_object then lastdw.driveway_id
                                  end
                       ) as total_orphan_qty
                 ,count(distinct case
                                   when lastdw.is_orphan_object and lasttl.driveway_id is not null then lastdw.driveway_id
                                  end
                       ) as orphan_tl_qty
                 ,count(distinct case
                                   when lastdw.is_orphan_object and lasttl.driveway_id is null then lastdw.driveway_id
                                  end
                       ) as orphan_notl_qty
             from rcust
             left join lastdw on rcust.customer_root_id=lastdw.customer_root_id
             left join lasttl on lasttl.customer_root_id=lastdw.customer_root_id
                                 and lasttl.driveway_id= lastdw.driveway_id
             group by rcust.customer_root_id
                     ,rcust.customer_short_name;
  elsif p_summary_type = C_FIAS_TYPE then
    return query
      with fias_distr as(select fias.id as fias_district_id
                               ,fias.ao_level
                               ,fias.formal_name||case
                                                    when fias.short_name is not null then ' '||fias.short_name
                                                    else ''
                                                  end as fias_name
                           from ods.fdc_as_addrobj fias
                          where fias.id=p_fias_district_id
                            and fias.live_status
                            and (fias.ao_level=3 or (fias.ao_level in(4,6) and fias.area_code =0))
                         union
                         select fias.id as fias_district_id
                               ,fias.ao_level
                               ,fias.formal_name||case
                                                    when fias.short_name is not null then ' '||fias.short_name
                                                    else ''
                                                  end as fias_name
                           from ods.fdc_as_addrobj fias
                          where fias.live_status
                            and (fias.ao_level=3 or (fias.ao_level in(4,6) and fias.area_code =0))
                            and p_fias_district_id is null
                            and (p_customer_id is null or exists(select null
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                   join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                   join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                  where objs.code='APPROVED'
                                                                    and obj.driveway_category_id=p_driveway_category_id
                                                                    and l_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                                                                    and obj.customer_id=p_customer_id
                                                                    and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                         (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                        )
                                                                )
                                )
                        )

          ,lastdw as(select distinct on(obj.root_id)
                            obj.version_date_to
                           ,obj.version_date_from
                           ,cst.root_id as customer_root_id
                           ,obj.id as driveway_id
                           ,odh.is_orphan_object
                           ,obj.as_area_id
                           ,obj.as_place_id
                       from ods.fdc_object obj
                       join ods.fdc_odh odh on obj.id=odh.id
                       join ods.fdc_object_state objs on obj.object_state_id=objs.id
                       join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                      where objs.code='APPROVED'
                        and obj.driveway_category_id=p_driveway_category_id
                        and l_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                        and (p_customer_id is null or obj.customer_id=p_customer_id)
                      order by obj.root_id
                              ,obj.version_date_to desc
                              ,obj.version_date_from desc
                    )
          ,lasttl as(select distinct on(todh.odh_id)
                            tl.date_to
                           ,tl.date_from
                           ,todh.odh_id as driveway_id
                           ,cst.root_id as customer_root_id
                       from ods.fdc_title tl
                       join ods.fdc_title_status tls on tl.title_status_id=tls.id
                       join nsi.fdc_legal_person cst on tl.customer_id=cst.id
                       join ods.fdc_title_odh todh on tl.id=todh.title_id
                      where tls.code='APPROVED'
                        and tl.work_category_id = p_work_category_id
                        and l_year between extract(year from tl.date_from) and extract(year from tl.date_to)
                      order by todh.odh_id
                              ,tl.date_to desc
                              ,tl.date_from desc
                    )

           select fds.fias_district_id
                 ,fds.fias_name::varchar
                 ,count(distinct fds.driveway_id) as total_qty
                 ,count(distinct case
                                   when not fds.is_orphan_object then fds.driveway_id
                                  end
                       ) as total_passport_qty

                 ,count(distinct case
                                   when not fds.is_orphan_object and lasttl.driveway_id is not null then fds.driveway_id
                                  end
                       ) as passport_tl_qty
                 ,count(distinct case
                                   when not fds.is_orphan_object and lasttl.driveway_id is null then fds.driveway_id
                                  end
                       ) as passport_notl_qty
                 ,count(distinct case
                                   when fds.is_orphan_object then fds.driveway_id
                                  end
                       ) as total_orphan_qty
                 ,count(distinct case
                                   when fds.is_orphan_object and lasttl.driveway_id is not null then fds.driveway_id
                                  end
                       ) as orphan_tl_qty
                 ,count(distinct case
                                   when fds.is_orphan_object and lasttl.driveway_id is null then fds.driveway_id
                                  end
                       ) as orphan_notl_qty
              from(select fias_distr.fias_district_id
                         ,fias_distr.fias_name
                         ,lastdw.customer_root_id
                         ,lastdw.driveway_id
                         ,lastdw.is_orphan_object
                     from fias_distr
                     left join lastdw on fias_distr.ao_level=3 and fias_distr.fias_district_id=lastdw.as_area_id
                   union
                   select fias_distr.fias_district_id
                         ,fias_distr.fias_name
                         ,lastdw.customer_root_id
                         ,lastdw.driveway_id
                         ,lastdw.is_orphan_object
                     from fias_distr
                     left join lastdw on fias_distr.ao_level in(4,6) and fias_distr.fias_district_id=lastdw.as_place_id
                  ) as fds
              left join lasttl on lasttl.customer_root_id=fds.customer_root_id
                                  and lasttl.driveway_id =fds.driveway_id

             group by fds.fias_district_id
                     ,fds.fias_name;
  end if;

  return;
end
$$;

