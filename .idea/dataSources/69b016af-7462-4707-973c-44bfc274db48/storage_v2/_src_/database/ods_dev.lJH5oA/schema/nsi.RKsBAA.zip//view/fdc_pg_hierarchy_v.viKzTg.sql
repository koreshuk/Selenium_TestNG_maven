CREATE VIEW fdc_pg_hierarchy_v AS
  WITH RECURSIVE grp(group_id, parent_id, level) AS (
         SELECT g1.group_id,
            g1.parent_id,
            1
           FROM ( SELECT g.id AS group_id,
                    ggl.group_id AS parent_id
                   FROM (nsi.fdc_person_group g
                     LEFT JOIN nsi.fdc_person_ggroup_link ggl ON ((ggl.child_id = g.id)))) g1
          WHERE (g1.parent_id IS NULL)
        UNION
         SELECT gn.group_id,
            gn.parent_id,
            (grp_1.level + 1)
           FROM (( SELECT g.id AS group_id,
                    ggl.group_id AS parent_id
                   FROM (nsi.fdc_person_group g
                     LEFT JOIN nsi.fdc_person_ggroup_link ggl ON ((ggl.child_id = g.id)))) gn
             JOIN grp grp_1 ON ((grp_1.group_id = gn.parent_id)))
        )
 SELECT grp.level,
    grp.group_id,
    grp.parent_id
   FROM grp;

COMMENT ON VIEW fdc_pg_hierarchy_v IS 'Иерархия групп организаций';

COMMENT ON COLUMN fdc_pg_hierarchy_v.level IS 'Уровень иерархии';

COMMENT ON COLUMN fdc_pg_hierarchy_v.group_id IS 'Ид группы организации';

COMMENT ON COLUMN fdc_pg_hierarchy_v.parent_id IS 'Ид родительской группы';

