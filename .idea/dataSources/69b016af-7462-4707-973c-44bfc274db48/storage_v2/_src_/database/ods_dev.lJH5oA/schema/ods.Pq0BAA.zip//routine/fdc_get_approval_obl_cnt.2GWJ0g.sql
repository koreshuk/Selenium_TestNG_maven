CREATE FUNCTION fdc_get_approval_obl_cnt(p_official_id bigint, OUT approval_cnt integer, OUT approved_obl_cnt integer, OUT rejected_obl_cnt integer, OUT onapproval_obl_cnt integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает количество бюджетов для блока Обратите внимание

    %param p_official_id - Ид текущего пользователя

    %return approval_cnt      -- Согласовать бюджеты: <Количество бюджетов>
    %return approved_tl_cnt   -- Согласовано за последние 3 дня: <Количество бюджетов>
    %return rejected_tl_cnt   -- Отклонено: <Количество бюджетов>
    %return onapproval_tl_cnt -- На согласовании: <Количество бюджетов>
  */
  l_responsible_for_approve secr.fdc_user_md.responsible_for_approve%type;
  l_user_person_id secr.fdc_user_md.person_id%type;
  l_result integer;
begin
  select responsible_for_approve
        ,person_id
    into strict l_responsible_for_approve,l_user_person_id
    from secr.fdc_user_md
   where id=p_official_id;

  select count(distinct tt.id)
    into approval_cnt
    from(select obl.id
           from ods.fdc_approval_workflow awf
           join secr.fdc_user_md u on awf.official_id=u.id
           join ods.fdc_approval_status aps on awf.approval_status_id=aps.id
           join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
           join ods.fdc_approval app on apit.approval_id=app.id
           join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
           join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
           join msnow.fdc_obligation obl on app.main_object_id=obl.id
           join msnow.fdc_agreement_obligation_status obls on obl.obligation_status_id=obls.id
          where aps.code='SENT'
            and atmplt.code='OBLIGATION'
            and obls.code='ON_APPROVAL'
            and awf.official_id=p_official_id
         union
         select obl.id
           from ods.fdc_approval_workflow awf
           join ods.fdc_approval_status aps on awf.approval_status_id=aps.id
           join ods.fdc_approval_temp_part atp on awf.approval_template_detail_id=atp.id
           join nsi.fdc_legal_person lp on atp.organization_id=lp.id
           join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
           join ods.fdc_approval app on apit.approval_id=app.id
           join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
           join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
           join msnow.fdc_obligation obl on app.main_object_id=obl.id
           join msnow.fdc_agreement_obligation_status obls on obl.obligation_status_id=obls.id
          where l_responsible_for_approve
            and aps.code='SENT'
            and atmplt.code='OBLIGATION'
            and obls.code='ON_APPROVAL'
            and awf.official_id is null
            and atp.data_dl=2
            and lp.root_id=l_user_person_id
        ) tt;

  select count(distinct obl.id)
    into approved_obl_cnt
    from ods.fdc_approval_workflow awf
    join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
    join ods.fdc_approval app on apit.approval_id=app.id
    join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
    join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
    join msnow.fdc_obligation obl on app.main_object_id=obl.id
    join msnow.fdc_agreement_obligation_status obls on obl.obligation_status_id=obls.id
    join nsi.fdc_legal_person sprslp on awf.send_by_person_id=sprslp.id
   where obls.code='APPROVED'
     and atmplt.code='OBLIGATION'
     and sprslp.root_id=l_user_person_id
     and obl.approval_date between current_date -3 and current_date;

  select count(distinct obl.id)
    into rejected_obl_cnt
    from ods.fdc_approval_workflow awf
    join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
    join ods.fdc_approval app on apit.approval_id=app.id
    join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
    join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
    join ods.fdc_approval_status apps on app.approval_status_id=apps.id
    join nsi.fdc_legal_person sprslp on awf.send_by_person_id=sprslp.id
    join msnow.fdc_obligation obl on app.main_object_id=obl.id
    join msnow.fdc_agreement_obligation_status obls on obl.obligation_status_id=obls.id
   where obls.code='PROJECT'
     and apps.code='REJECTED'
     and atmplt.code='OBLIGATION'
     and sprslp.root_id=l_user_person_id;

  select count(distinct obl.id)
    into onapproval_obl_cnt
    from ods.fdc_approval_workflow awf
    join ods.fdc_approval_iteration apit on awf.approval_iteration_id=apit.id
    join ods.fdc_approval app on apit.approval_id=app.id
    join ods.fdc_approval_template atmpl on app.approval_template_id=atmpl.id
    join ods.fdc_approval_template_type atmplt on atmpl.approval_template_type_id=atmplt.id
    join ods.fdc_approval_status apps on app.approval_status_id=apps.id
    join nsi.fdc_legal_person sprslp on awf.send_by_person_id=sprslp.id
    join msnow.fdc_obligation obl on app.main_object_id=obl.id
    join msnow.fdc_agreement_obligation_status obls on obl.obligation_status_id=obls.id
   where obls.code='ON_APPROVAL'
     and apps.code='SENT'
     and atmplt.code='OBLIGATION'
     --and sprslp.root_id=l_user_person_id
     and ((l_responsible_for_approve and sprslp.root_id=l_user_person_id)
         or (not COALESCE(l_responsible_for_approve,FALSE) and awf.send_by_user_id = p_official_id))
     ;
  return;
end
$$;

