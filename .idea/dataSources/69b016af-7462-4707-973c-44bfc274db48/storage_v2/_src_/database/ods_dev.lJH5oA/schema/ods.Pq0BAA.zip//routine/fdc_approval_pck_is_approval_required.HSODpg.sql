CREATE FUNCTION fdc_approval_pck_is_approval_required(p_approval_id bigint, p_user_id bigint DEFAULT NULL::bigint, p_object_id bigint DEFAULT NULL::bigint)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает 1, если пользователю есть что согласовывать в данном запросе, 0 - если нет
  %param p_approval_id           ИД согласования
  %param p_user_id               ИД пользователя системы
  %param p_object_id             ИД объекта ОГХ для согласования
  returns признак необходимости согласования
  */
  l_res boolean:=false;

  l_organization_id  ods.fdc_secr_user_md_v.person_id%type;
  l_division_id      ods.fdc_secr_user_md_v.division_id%type;
  l_occupation_id    ods.fdc_secr_user_md_v.position_id%type;
  l_user_id          ods.fdc_secr_user_md_v.id%type;
begin
  if p_approval_id is not null then
    p_user_id := coalesce(p_user_id,secr.get_current_user_id());
    select coalesce(lp.root_id, -1)
         , coalesce(sv.root_id, -1)
         , coalesce(u.position_id, -1)
         , u.id
      into l_organization_id
         , l_division_id
         , l_occupation_id
         , l_user_id
      from ods.fdc_secr_user_md_v u
 left join nsi.fdc_legal_person_v lp on lp.id = u.PERSON_ID
 left join nsi.fdc_subdivision_v sv on sv.id = u.division_id
     where u.id = p_user_id;

    select case
             when count(1)>0 then true
             else false
           end
      into l_res
      from ods.fdc_approval a
      join ods.fdc_approval_workflow_v w on w.approval_id = a.id
 left join nsi.fdc_legal_person_v lp on lp.id = w.organization_id
 left join nsi.fdc_subdivision_v sv on sv.id = w.division_id
     where a.id = p_approval_id
       and (a.main_object_id = p_object_id or
            (a.main_object_id is null and p_object_id is null)
           )
       and w.approval_status_id = ods.c_as_sent()
       and l_user_id = coalesce(w.official_id, l_user_id)
       and l_division_id = coalesce(sv.root_id, l_division_id)
       and l_organization_id = coalesce(lp.root_id, l_organization_id)
       and l_occupation_id = coalesce(w.occupation_id, l_occupation_id)
       and (w.organization_group_id is null or exists(select 1
                                                        from nsi.fdc_person_group_link l
                                                             /* Пока не работает со структурой в НСИ */
                                                            --,table(fdc_nsi_srch_person_group_pck.get_person_group_struct(p_group_id => w.organization_group_id)) g
                                                            ,nsi.fdc_legal_person_v lp1
                                                       where lp1.id = l.person_id
                                                         and lp1.root_id = l_organization_id
                                                         --and g.group_id = l.group_id
                                                     )
           );
  end if;


  return l_res;
end
$$;

