CREATE VIEW fdc_title_v AS
  SELECT t.id,
    t.name,
    t.date_from,
    t.date_to,
    cust.root_id AS customer_id,
    cust.name AS customer_name,
    ot.code AS object_type_code,
    wc.code AS work_category_code,
    wc.name AS work_category_name,
    ttyp.code AS title_type_code,
    ttyp.name AS title_type_name
   FROM (((((fdc_title t
     JOIN fdc_title_status ts ON ((t.title_status_id = ts.id)))
     JOIN nsi.fdc_legal_person cust ON ((t.customer_id = cust.id)))
     LEFT JOIN fdc_object_type ot ON ((t.object_type_id = ot.id)))
     LEFT JOIN msnow.fdc_work_category wc ON ((t.work_category_id = wc.id)))
     LEFT JOIN fdc_title_type ttyp ON ((t.title_type_id = ttyp.id)))
  WHERE ((ts.code)::text = 'APPROVED'::text);

COMMENT ON VIEW fdc_title_v IS 'Перечень титульных списков';

COMMENT ON COLUMN fdc_title_v.id IS 'Ид ТС';

COMMENT ON COLUMN fdc_title_v.name IS 'Наименование ТС';

COMMENT ON COLUMN fdc_title_v.date_from IS 'Дата начла действия';

COMMENT ON COLUMN fdc_title_v.date_to IS 'Дата окончания действия';

COMMENT ON COLUMN fdc_title_v.customer_id IS 'Ид заказчика';

COMMENT ON COLUMN fdc_title_v.customer_name IS 'Наименование заказчика';

COMMENT ON COLUMN fdc_title_v.object_type_code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_title_v.work_category_code IS 'Код категории работ';

COMMENT ON COLUMN fdc_title_v.work_category_name IS 'Наименование категории работ';

COMMENT ON COLUMN fdc_title_v.title_type_code IS 'Ид типа ТС';

COMMENT ON COLUMN fdc_title_v.title_type_name IS 'Наименование типа ТС';

