CREATE VIEW fdc_odh_calculation_v AS
  SELECT oc.id,
    oc.internal_area,
    oc.total_area,
    oc.roadway_area,
    oc.stat_axes_length,
    oc.margin_area,
    oc.footway_area,
    oc.other_flat_area,
    oc.tram_road_length,
    oc.gutters_length,
    oc.bound_stone_area_plan,
    oc.bound_stone_area,
    oc.bound_stone_length,
    oc.planting_area,
    oc.engin_constr_qty,
    oc.bus_stop_qty,
    oc.sign_qty,
    oc.pointer_qty,
    oc.info_qty,
    oc.traff_light_qty,
    oc.guides_qty_pcs,
    oc.guides_qty,
    oc.guides_qty_sqr,
    oc.bicycle_area,
    oc.bicycle_length,
    oc.tpu_area,
    oc.cleaning_area,
    oc.roadway_noprkg_clean_area,
    oc.roadway_prkg_clean_area,
    oc.auto_footway_area,
    oc.manual_footway_area,
    oc.snow_area,
    oc.rotor_area,
    oc.station_area,
    oc.bar_new_jersey,
    oc.station_number,
    oc.protective_wall,
    oc.buffer,
    oc.asperity
   FROM fdc_odh_calculation oc;

COMMENT ON VIEW fdc_odh_calculation_v IS 'Объект дорожного хозяйства (ОДХ) расчетные показатели';

COMMENT ON COLUMN fdc_odh_calculation_v.id IS 'Ид версии объекта';

COMMENT ON COLUMN fdc_odh_calculation_v.internal_area IS 'Общая площадь в границах ОДХ, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.total_area IS 'Общая площадь в ТС, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.roadway_area IS 'Проезжая часть, всего, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.stat_axes_length IS 'Протяженность по пикетажам, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.margin_area IS 'Обочины, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.footway_area IS 'Тротуары. м2';

COMMENT ON COLUMN fdc_odh_calculation_v.other_flat_area IS 'Прочие территории, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.tram_road_length IS 'Трамвайные пути, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.gutters_length IS 'Протяженность лотков, п.м.';

COMMENT ON COLUMN fdc_odh_calculation_v.bound_stone_area_plan IS 'Бортовой камень в плане, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.bound_stone_area IS 'Бортовой камень, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.bound_stone_length IS 'Бортовой камень, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.planting_area IS 'Озеленённые территории, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.engin_constr_qty IS 'Инженерные сооружения, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.bus_stop_qty IS 'Остановки общественного транспорта, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.sign_qty IS 'Дорожные знаки, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.pointer_qty IS 'Указатели, информационные указатели, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.traff_light_qty IS 'Светофорные объекты, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.guides_qty_pcs IS 'Ограждающие и направляющие устройства, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.guides_qty IS 'Ограждающие и направляющие устройства, пм';

COMMENT ON COLUMN fdc_odh_calculation_v.guides_qty_sqr IS 'Ограждающие и направляющие устройства, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.bicycle_area IS 'Велодорожки, общая площадь, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.bicycle_length IS 'Велодорожки, протяженность по пикетажам, п.м.';

COMMENT ON COLUMN fdc_odh_calculation_v.tpu_area IS 'ТПУ, общая площадь, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.cleaning_area IS 'Площадь уборки, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.roadway_noprkg_clean_area IS 'Площадь уборки проезжей части (без парковок), м2';

COMMENT ON COLUMN fdc_odh_calculation_v.roadway_prkg_clean_area IS 'Площадь уборки парковочного пространства, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.auto_footway_area IS 'Площадь уборки тротуаров, механическая, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.manual_footway_area IS 'Площадь уборки тротуаров, ручной, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.snow_area IS 'Площадь вывоза снега, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.rotor_area IS 'Площадь роторной перекидки, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.station_area IS 'Площадь уборки остановок, м2';

COMMENT ON COLUMN fdc_odh_calculation_v.bar_new_jersey IS 'Стенка Нью-Джерси, п.м.';

COMMENT ON COLUMN fdc_odh_calculation_v.station_number IS 'Количество убираемых остановок, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.protective_wall IS 'Защитная стенка, п.м.';

COMMENT ON COLUMN fdc_odh_calculation_v.buffer IS 'Буфер безопасности, шт';

COMMENT ON COLUMN fdc_odh_calculation_v.asperity IS 'ИДН, шт';

