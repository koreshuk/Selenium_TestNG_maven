CREATE MATERIALIZED VIEW fdc_person_ver_collision_mv AS SELECT p.id,
        CASE
            WHEN ((p.person_type_id = 3) OR ((p.person_type_id = ANY (ARRAY[(1)::bigint, (2)::bigint])) AND (NOT (EXISTS ( SELECT NULL::unknown AS unknown
               FROM nsi.fdc_legal_person t
              WHERE ((((t.inn)::text = (p.inn)::text) OR ((t.ogrn)::text = (p.ogrn)::text) OR (lower((t.name)::text) = lower((p.name)::text))) AND (t.person_type_id = ANY (ARRAY[(1)::bigint, (2)::bigint])) AND (t.root_id <> p.root_id) AND (t.ver_end_date IS NULL))))))) THEN 1
            WHEN ((p.person_type_id = ANY (ARRAY[(4)::bigint, (5)::bigint])) AND (NOT (EXISTS ( SELECT NULL::unknown AS unknown
               FROM nsi.fdc_legal_person t
              WHERE ((t.person_type_id = ANY (ARRAY[(4)::bigint, (5)::bigint])) AND (((t.inn)::text = (p.inn)::text) OR (lower(((p.docseries)::text || (p.docnumber)::text)) = lower(((t.docseries)::text || (t.docnumber)::text))) OR ((t.snils)::text = (p.snils)::text) OR (lower(((((p.name)::text || (p.short_name)::text) || (p.patronymic)::text) || to_char((p.birth_date)::timestamp with time zone, 'ddmmyyyy'::text))) = lower(((((t.name)::text || (t.short_name)::text) || (t.patronymic)::text) || to_char((t.birth_date)::timestamp with time zone, 'ddmmyyyy'::text))))) AND (t.id <> p.id) AND (t.ver_end_date IS NULL)))))) THEN 1
            ELSE 0
        END AS has_no_collision
   FROM nsi.fdc_person_version_v p;

