CREATE FUNCTION fdc_object_pck_add_object_piquetage_list(p_object_id bigint, p_object_piquetage_tab t_object_piquetage[])
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Процедура добавления параметров пикетажа
  %param     p_object_id              ИД Объекта
  %param     p_object_piquetage_tab   Коллекция параметров пикетажа
  */
begin
  insert into ods.fdc_object_piquetage(id
                                  ,object_id
                                  ,piquetage_type_id
                                  ,value
                                  ,odh_location_side_id
                                  ,axes_type_id
                                  )
      select nextval('ods.fdc_object_piquetage_seq')
            ,p_object_id
            ,pq.piquetage_type_id
            ,pq.piq_value
            ,pq.side_id
            ,pq.axes_type_id
        from unnest(p_object_piquetage_tab) as pq;
  return;
end
$$;

