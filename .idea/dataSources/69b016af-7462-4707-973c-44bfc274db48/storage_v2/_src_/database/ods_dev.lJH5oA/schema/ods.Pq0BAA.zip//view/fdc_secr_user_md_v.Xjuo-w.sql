CREATE VIEW fdc_secr_user_md_v AS
  SELECT u.id,
        CASE
            WHEN ((u.sysname)::text ~~ 'DELETE%'::text) THEN NULL::character varying
            ELSE u.sysname
        END AS sysname,
    u.first_name,
    u.second_name,
    u.family,
    u.phone,
    u.description,
    u.person_id,
    COALESCE(p.short_name, p.name) AS person_name,
    u.off_name,
    u.email,
    u.camera_access_granted,
    u.training,
    u.training_type,
    u.training_date,
    u.division_id,
    COALESCE(d.short_name, d.name) AS division_name,
    ocp.id AS position_id,
    ocp.name AS position_name,
    u.status_id,
    sus.code AS status_code,
    sus.name AS status_name,
    u.date_from,
    (((((u.family)::text || ' '::text) || (u.first_name)::text) || ' '::text) || (u.second_name)::text) AS user_fio,
    u.responsible_for_approve
   FROM (((((secr.fdc_user_md u
     JOIN secr.fdc_user_status sus ON ((u.status_id = sus.id)))
     LEFT JOIN nsi.fdc_legal_person p ON (((p.root_id = u.person_id) AND ((statement_timestamp() >= p.ver_start_date) AND (statement_timestamp() <= p.ver_end_date)))))
     LEFT JOIN nsi.fdc_legal_person d ON (((d.root_id = u.division_id) AND ((statement_timestamp() >= d.ver_start_date) AND (statement_timestamp() <= d.ver_end_date)))))
     LEFT JOIN nsi.fdc_legal_person emp ON (((emp.root_id = u.employee_id) AND ((statement_timestamp() >= emp.ver_start_date) AND (statement_timestamp() <= emp.ver_end_date)))))
     LEFT JOIN nsi.fdc_occupation ocp ON ((emp.occupation_id = ocp.id)))
  WHERE ((sus.code)::text = 'ACTIVE'::text);

COMMENT ON VIEW fdc_secr_user_md_v IS 'Системные пользователи';

COMMENT ON COLUMN fdc_secr_user_md_v.id IS 'Ид пользователя';

COMMENT ON COLUMN fdc_secr_user_md_v.sysname IS 'Системное имя учетной записи';

COMMENT ON COLUMN fdc_secr_user_md_v.first_name IS 'Имя пользователя';

COMMENT ON COLUMN fdc_secr_user_md_v.second_name IS 'Отчество пользователя';

COMMENT ON COLUMN fdc_secr_user_md_v.family IS 'Фамилия пользователя';

COMMENT ON COLUMN fdc_secr_user_md_v.phone IS 'Номер телефона';

COMMENT ON COLUMN fdc_secr_user_md_v.description IS 'Описание';

COMMENT ON COLUMN fdc_secr_user_md_v.person_id IS 'Ид организации';

COMMENT ON COLUMN fdc_secr_user_md_v.person_name IS 'Наименование организации';

COMMENT ON COLUMN fdc_secr_user_md_v.off_name IS 'Должность';

COMMENT ON COLUMN fdc_secr_user_md_v.email IS 'Должность';

COMMENT ON COLUMN fdc_secr_user_md_v.camera_access_granted IS 'Доступ к видеокамерам. 0 - доступа нет, 1 доступ есть';

COMMENT ON COLUMN fdc_secr_user_md_v.training IS 'Прошел обучение 0 - Нет 1-Да';

COMMENT ON COLUMN fdc_secr_user_md_v.training_type IS 'Форма обучения 0 - Очная 1- Заочная';

COMMENT ON COLUMN fdc_secr_user_md_v.training_date IS 'Дата обучения';

COMMENT ON COLUMN fdc_secr_user_md_v.division_id IS 'Ид подразделения';

COMMENT ON COLUMN fdc_secr_user_md_v.division_name IS 'Наименование подразделения';

COMMENT ON COLUMN fdc_secr_user_md_v.position_id IS 'Ид должности';

COMMENT ON COLUMN fdc_secr_user_md_v.position_name IS 'Наименование должности';

COMMENT ON COLUMN fdc_secr_user_md_v.status_id IS 'Ид статуса';

COMMENT ON COLUMN fdc_secr_user_md_v.status_code IS 'Код статуса';

COMMENT ON COLUMN fdc_secr_user_md_v.status_name IS 'Наименование статуса';

COMMENT ON COLUMN fdc_secr_user_md_v.date_from IS 'Дата добавления';

COMMENT ON COLUMN fdc_secr_user_md_v.user_fio IS 'Полное ФИО';

