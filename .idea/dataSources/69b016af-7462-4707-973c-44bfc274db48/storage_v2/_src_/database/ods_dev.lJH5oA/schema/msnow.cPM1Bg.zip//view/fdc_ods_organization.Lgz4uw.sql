CREATE VIEW fdc_ods_organization AS
  SELECT p.id,
    lp.short_name AS name,
    (
        CASE rl.org_type_code
            WHEN 'OMSU'::text THEN 1
            WHEN 'RUAD'::text THEN 2
            WHEN 'TO'::text THEN 3
            ELSE NULL::integer
        END)::bigint AS org_type_id,
    lp.fias_district_id AS municipality_id,
    lp.parent_root_id AS parent_id,
    (p.id || ('|'::character varying(255))::text) AS org_path,
        CASE
            WHEN (mnc.customer_role_id IS NULL) THEN false
            ELSE true
        END AS is_msnow,
    lp.fias_district_ao_guid AS municipality_ao_guid
   FROM (((nsi.fdc_person p
     JOIN ( SELECT DISTINCT ON (llp.root_id) llp.root_id,
            llp.short_name,
            llp.parent_root_id,
            llp.fias_district_id,
            fias.ao_guid AS fias_district_ao_guid
           FROM (nsi.fdc_legal_person llp
             LEFT JOIN fdc_as_addrobj fias ON ((llp.fias_district_id = fias.id)))
          ORDER BY llp.root_id, llp.ver_start_date DESC) lp ON ((p.id = lp.root_id)))
     LEFT JOIN ( SELECT porgtype.person_id,
            orgtype.code AS org_type_code
           FROM (nsi.fdc_person_role porgtype
             JOIN nsi.fdc_role orgtype ON ((orgtype.id = porgtype.role_id)))
          WHERE (((statement_timestamp())::timestamp without time zone >= porgtype.begin_date) AND ((statement_timestamp())::timestamp without time zone <= porgtype.end_date) AND ((orgtype.code)::text = ANY (ARRAY[('OMSU'::character varying)::text, ('RUAD'::character varying)::text, ('TO'::character varying)::text])))) rl ON ((p.id = rl.person_id)))
     LEFT JOIN ( SELECT DISTINCT ON (porgtype.person_id) porgtype.person_id,
            porgtype.id AS customer_role_id,
            mncp.fias_district_id AS municipality_id
           FROM ((nsi.fdc_person_role porgtype
             JOIN nsi.fdc_role orgtype ON ((orgtype.id = porgtype.role_id)))
             LEFT JOIN nsi.fdc_person_role_address mncp ON ((mncp.person_role_id = porgtype.id)))
          WHERE (((statement_timestamp())::timestamp without time zone >= porgtype.begin_date) AND ((statement_timestamp())::timestamp without time zone <= porgtype.end_date) AND ((orgtype.code)::text = ANY (ARRAY[('CUSTOMER'::character varying)::text, ('TO'::character varying)::text])))
          ORDER BY porgtype.person_id) mnc ON ((p.id = mnc.person_id)));

COMMENT ON VIEW fdc_ods_organization IS 'Справочник организации';

COMMENT ON COLUMN fdc_ods_organization.id IS 'Ид';

COMMENT ON COLUMN fdc_ods_organization.name IS 'Наименование';

COMMENT ON COLUMN fdc_ods_organization.org_type_id IS 'Ид вида организации';

COMMENT ON COLUMN fdc_ods_organization.municipality_id IS 'Ид муниципального образования';

COMMENT ON COLUMN fdc_ods_organization.parent_id IS 'Ид родительской организации';

