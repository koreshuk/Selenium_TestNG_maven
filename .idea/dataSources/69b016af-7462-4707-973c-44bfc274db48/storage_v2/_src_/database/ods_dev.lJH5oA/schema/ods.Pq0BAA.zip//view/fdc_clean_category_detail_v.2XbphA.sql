CREATE VIEW fdc_clean_category_detail_v AS
  SELECT t1.category_id,
    t2.code AS category_code,
    t2.name AS category_name,
    t1.code,
    t1.date_from,
    t1.date_to,
    t1.history_id,
    t3.code AS history_code,
    t3.name AS history_name,
    t1.id,
    t1.name,
    t1.summer,
    t1.winter
   FROM ((fdc_clean_category_detail t1
     LEFT JOIN fdc_clean_category t2 ON ((t2.id = t1.category_id)))
     LEFT JOIN fdc_clean_category_detail t3 ON ((t3.id = t1.history_id)));

COMMENT ON VIEW fdc_clean_category_detail_v IS 'Справочник Детализация категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.category_id IS 'Ид категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.category_code IS 'Код категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.category_name IS 'Наименование категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.code IS 'Код детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_clean_category_detail_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_clean_category_detail_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_clean_category_detail_v.history_code IS 'Код детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.history_name IS 'Наименование детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.id IS 'Ид детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.name IS 'Наименование детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_clean_category_detail_v.summer IS 'Признак Лето';

COMMENT ON COLUMN fdc_clean_category_detail_v.winter IS 'Признак Зима';

