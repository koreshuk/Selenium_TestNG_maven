CREATE FUNCTION fdc_geo_pck_from_wkt(p_wkt_geometry text)
  RETURNS geometry
LANGUAGE plpgsql
AS $$
declare
  /* Преобразование строки в формате WKT в геометрический объект
  */
  l_res geometry;
begin
  if p_wkt_geometry is not null then
    l_res := st_geomfromtext(p_wkt_geometry,ods.fdc_geo_pck_srid_wgs84());
  end if;
  return l_res;
end
$$;

