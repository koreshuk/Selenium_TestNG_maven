CREATE FUNCTION fdc_get_approval_participants_obl(p_approval_template_id bigint, p_obligation_id bigint, p_condition_obligatory_id bigint, OUT num_stage bigint, OUT num_part bigint, OUT participant_id bigint, OUT organization_id bigint, OUT has_user boolean)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Список должностных лиц, участвующих в согласовании Бюджета.
    %param p_approval_template_id     -- Ид шаблона согласования
    %param p_obligation_id            -- Ид согласуемого бюджета
    %param p_condition_obligatory_id  -- Ид причины изменения

    %return num_stage                 -- Номер этапа
    %return num_part                  -- Номер участника
    %return participant_id            -- Ид участника
    %return organization_id           -- Ид организации
    %return has_user                  -- Признак Наличие пользователя в участнике
  */
  rec record;
  l_err_level integer:=1;
  l_err_message text;

  l_condition_obligatory_code ods.fdc_condition_obligatory.code%type;
begin
  if p_condition_obligatory_id is not null then
    select code
      into strict l_condition_obligatory_code
      from ods.fdc_condition_obligatory
     where id=p_condition_obligatory_id;
  end if;
  for rec in(with recursive stlnk(approval_temp_stage_id_from
                                 ,approval_temp_stage_id_to
                                 ,level
                                 ) as(select lnk.approval_temp_stage_id_from
                                            ,lnk.approval_temp_stage_id_to
                                            ,1
                                        from ods.fdc_appr_temp_stage_link lnk
                                        join ods.fdc_approval_temp_stage stf on lnk.approval_temp_stage_id_from=stf.id
                                        join ods.fdc_condition_obligatory obl on lnk.condition_obligatory_id=obl.id
                                       where stf.approval_template_id=p_approval_template_id
                                         and stf.num_stage=1
                                         and obl.code in(l_condition_obligatory_code,'ALWAYS')
                                      union all
                                      select lnkn.approval_temp_stage_id_from
                                            ,lnkn.approval_temp_stage_id_to
                                            ,level+1
                                        from ods.fdc_appr_temp_stage_link lnkn
                                        join ods.fdc_condition_obligatory obln on lnkn.condition_obligatory_id=obln.id
                                        join stlnk on lnkn.approval_temp_stage_id_from = stlnk.approval_temp_stage_id_to
                                       where obln.code in(l_condition_obligatory_code,'ALWAYS')
                                     )
                           ,apid as(select id as approval_temp_stage_id
                                          ,ss.num_stage
                                      from ods.fdc_approval_temp_stage ss
                                     where ss.approval_template_id=p_approval_template_id
                                       and ss.num_stage=1
                                    union
                                    select stlnk.approval_temp_stage_id_to as approval_temp_stage_id
                                          ,n.num_stage
                                      from stlnk
                                      join ods.fdc_approval_temp_stage n on stlnk.approval_temp_stage_id_to=n.id
                                     where approval_template_id=p_approval_template_id
                                   )

             select cob.code
                   ,atp.id as participant_id -- ИД УЧАСТНИКА
                   ,atp.organization_id      -- ИД ОРГАНИЗАЦИИ
                   ,lp.root_id as organization_root_id
                   ,ats.num_stage -- номер этапа
                   ,atp.num_part  -- номер участника
                   ,atp.data_dl
                   ,atp.official_id
                   ,atp.organization_group_id -- Ид группы участника этапа
                   ,cndch.code as condition_choice_code
               from apid ats
               join ods.fdc_approval_temp_part atp on ats.approval_temp_stage_id=atp.approval_temp_stage_id
               join ods.fdc_condition_obligatory cob on atp.condition_obligatory_id=cob.id
               left join nsi.fdc_legal_person lp on atp.organization_id=lp.id
               left join ods.fdc_condition_choice cndch on atp.condition_choice_id=cndch.id
              where cob.code in (l_condition_obligatory_code,'ALWAYS')
            ) loop
    l_err_level:=0;
    if rec.data_dl=1 then -- Точный выбор
      begin
        select rec.num_stage
              ,rec.num_part
              ,rec.participant_id
              ,u.person_id as organization_id
              ,case us.code
                 when 'ACTIVE' then true
                 else false
               end
          into strict num_stage
                     ,num_part
                     ,participant_id
                     ,organization_id
                     ,has_user
          from secr.fdc_user_md u
          join secr.fdc_user_status us on u.status_id=us.id
         where u.id=rec.official_id;

        return next;
      exception
        when no_data_found then
          l_err_level:=3;
          exit;
      end;
    elsif rec.data_dl=2 then -- Ответственный
      if rec.organization_id is not null or rec.condition_choice_code in ('CUSTOM') then
        return query
          with orgroot as(select organization_root_id
                            from (values(rec.organization_root_id)
                                 ) as nno(organization_root_id)
                           where organization_root_id is not null
                          union
                          select cust.root_id
                            from msnow.fdc_obligation obl
                            join nsi.fdc_legal_person cust on obl.authority_org_id=cust.id
                            join nsi.fdc_person_group_link pgl on cust.root_id=pgl.person_id
                           where obl.id= p_obligation_id
                             and pgl.group_id=rec.organization_group_id
                             and rec.condition_choice_code='CUSTOM'
                             and rec.organization_root_id is null
                         )
             select distinct rec.num_stage
                   ,rec.num_part
                   ,rec.participant_id
                   ,orgroot.organization_root_id as organization_id
                   ,case
                      when exists (select null
                                     from secr.fdc_user_md u
                                     join secr.fdc_user_status us on u.status_id=us.id
                                    where u.person_id=orgroot.organization_root_id
                                      and us.code='ACTIVE'
                                  ) then true
                      else false
                    end
               from orgroot;
      else
        return query
          with custorg as(select cust.id as customer_id
                                ,cust.root_id as customer_root_id
                                ,cust.fias_district_id
                            from msnow.fdc_obligation obl
                            join nsi.fdc_legal_person cust on obl.authority_org_id=cust.id
                            join nsi.fdc_person_role cpr on cust.root_id=cpr.person_id
                            join nsi.fdc_role cr on cpr.role_id=cr.id
                           where statement_timestamp() between cpr.begin_date and cpr.end_date
                             and cr.code='OMSU'
                             and obl.id= p_obligation_id
                         )

              select rec.num_stage
                    ,rec.num_part
                    ,rec.participant_id
                    ,lp.root_id as organization_id
                    ,case
                       when exists (select null
                                      from secr.fdc_user_md u
                                      join secr.fdc_user_status us on u.status_id=us.id
                                     where u.person_id=lp.root_id
                                       and us.code='ACTIVE'
                                  ) then true
                       else false
                     end
                from nsi.fdc_person_group_link pgl
                join nsi.fdc_legal_person lp on pgl.person_id=lp.root_id
                join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                join nsi.fdc_role r on pr.role_id=r.id
                join custorg on lp.fias_district_id=custorg.fias_district_id
               where pgl.group_id=rec.organization_group_id
                 and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                 and statement_timestamp() between pr.begin_date and pr.end_date
                 and r.code='OMSU';
      end if;
    end if;
  end loop;

  if l_err_level>0 then
    raise exception '%',case l_err_level
                          when 1 then 'Для данного объекта не настроен процесс согласования. Обратитесь к адмиинистратору.'
                          when 3 then 'Отсутствует пользователь, ответственный за согласование.'
                        end;
  end if;
  return;
end
$$;

