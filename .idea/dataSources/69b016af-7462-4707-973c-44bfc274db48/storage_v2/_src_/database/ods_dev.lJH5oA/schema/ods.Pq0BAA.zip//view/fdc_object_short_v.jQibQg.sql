CREATE VIEW fdc_object_short_v AS
  SELECT o.id,
    o.parent_version_id,
    o.root_id,
    o.version_date_from,
    o.version_date_to,
    o.customer_id,
    COALESCE(cust.short_name, cust.name) AS customer_short_name,
    o.object_type_id,
    ot.code AS object_type_code,
    ot.name AS object_type_name,
    ot.short_name AS object_type_short_name,
    o.object_state_id,
    os.code AS object_state_code,
    os.name AS object_state_name,
    o.owner_id,
    COALESCE(own.short_name, own.name) AS owner_short_name,
    o.root_owner_id,
    o.object_sub_type_id,
    ost.code AS object_sub_type_code,
    ost.name AS object_sub_type_name,
    o.description,
    o.okrug_id,
    o.district_id,
    o.inventory_id,
    o.reason_type_id,
    rt.code AS reason_type_code,
    rt.name AS reason_type_name,
    o.tree_name,
    ot.parent_id AS parent_type_id,
    opt.code AS parent_type_code,
    o.name,
    o.reason_type_del_id,
    rt_del.code AS reason_type_code_del,
    rt_del.name AS reason_type_name_del,
    o.reason_comment,
    o.reason_del_comment
   FROM ((((((((fdc_object o
     LEFT JOIN fdc_object_type ot ON ((ot.id = o.object_type_id)))
     LEFT JOIN fdc_object_type ost ON ((ost.id = o.object_sub_type_id)))
     LEFT JOIN fdc_object_type opt ON ((opt.id = ot.parent_id)))
     LEFT JOIN fdc_object_state os ON ((os.id = o.object_state_id)))
     LEFT JOIN nsi.fdc_legal_person_v own ON ((own.id = o.owner_id)))
     LEFT JOIN nsi.fdc_legal_person_v cust ON ((cust.id = o.customer_id)))
     LEFT JOIN fdc_reason_type rt ON ((rt.id = o.reason_type_id)))
     LEFT JOIN fdc_reason_type rt_del ON ((rt_del.id = o.reason_type_del_id)));

