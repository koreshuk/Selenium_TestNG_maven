CREATE FUNCTION c_sl_branch()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 3::bigint;
$$;

