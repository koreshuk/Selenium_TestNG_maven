CREATE FUNCTION c_sl_request()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 0::bigint;
$$;

