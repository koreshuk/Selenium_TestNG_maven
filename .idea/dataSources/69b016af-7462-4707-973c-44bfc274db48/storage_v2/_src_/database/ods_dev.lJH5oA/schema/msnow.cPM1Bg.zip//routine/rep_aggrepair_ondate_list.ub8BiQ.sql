CREATE FUNCTION rep_aggrepair_ondate_list(p_date date, p_driveway_category_id bigint, OUT driveway_segment_name character varying, OUT plan_volume_on_date double precision, OUT fact_volume_on_date double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Отчет по ремонту дорог по состоянию на дату (список отставание)
    %param p_date date            - Дата
    %param p_driveway_category_id - Балансовая принадлежность

    %return driveway_segment_name   - Наименование участка ремонта
    %return plan_volume_on_date     - Должно быть выполнено работ на дату
    %return fact_volume_on_date     - Выполнено работ на дату
  */
  l_driveway_category_code msnow.fdc_driveway_category.code%type;
  l_current_year text;
begin
  select code
    into strict l_driveway_category_code
    from msnow.fdc_driveway_category
   where id=p_driveway_category_id;

  l_current_year:=to_char(current_date,'YYYY');

  return query
  with org_ruad as(select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_role r on pr.role_id=r.id
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and r.code in('RUAD')
                      and l_driveway_category_code='REGION_INTERMUNICIPAL'
                   union all
                   select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and l_driveway_category_code='LOCAL'
                      and not exists(select null
                                       from nsi.fdc_role r
                                       join nsi.fdc_person_role prr on r.id=prr.role_id
                                      where prr.person_id=pr.person_id
                                        and statement_timestamp() between prr.begin_date and prr.end_date
                                        and r.code in('RUAD')
                                    )
                  )
      ,agrewt as(select agre.driveway_segment_id
                       ,agre.agreement_id
                       ,sum(agre.work_volume) as work_volume
                   from msnow.fdc_agr_estimate agre
                   join msnow.fdc_work_type agrewt on agre.work_type_id=agrewt.id
                   join msnow.fdc_measure_unit mu on agrewt.measure_unit_id=mu.id
                  where not agre.is_estimate_sum
                    and agrewt.is_asphalt
                    and mu.code='MTK'
                  group by agre.driveway_segment_id
                          ,agre.agreement_id
                )
      ,factwrk as(select aj.driveway_segment_id
                        ,sum(aj.work_volume) as work_volume
                    from msnow.fdc_asphalt_journal aj
                   where aj.work_date<p_date
                   group by aj.driveway_segment_id
                 )

   select tot.driveway_segment_name
         ,round(coalesce(tot.plan_volume_on_date,0)::numeric,2)::double precision
         ,round(coalesce(tot.fact_volume_on_date,0)::numeric,2)::double precision
     from(select agrewt.work_volume as plan_volume_per_year
                ,case
                    when sch.end_date_plan - sch.start_date_plan = 0 then 0.0
                    else
                     (case
                        when sch.end_date_plan - sch.start_date_plan = 0 then 0.0
                        else
                          case
                            when sch.start_date_plan< p_date then
                              agrewt.work_volume
                            else 0.0
                          end / ceiling((sch.end_date_plan - sch.start_date_plan) /2.0)
                      end
                     ) * case
                           when p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer) <0 then 0
                           else p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer)
                         end
                 end as plan_volume_on_date
                ,case
                   when sch.start_date_plan< p_date then
                     agrewt.work_volume
                   else 0.0
                 end as inter_A
                ,ceiling((sch.end_date_plan - sch.start_date_plan) /2.0) as inter_B
                ,case
                   when sch.end_date_plan - sch.start_date_plan = 0  then 0.0
                   else
                     case
                       when sch.start_date_plan< p_date then
                         agrewt.work_volume
                       else 0.0
                     end / ceiling((sch.end_date_plan - sch.start_date_plan) /2.0)
                 end as inter_C
                ,case
                   when p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer) <0 then 0
                   else p_date- (sch.start_date_plan + floor((sch.end_date_plan - sch.start_date_plan) / 2.0)::integer)
                 end as inter_D
                ,factwrk.work_volume as fact_volume_on_date
                ,dws.name as driveway_segment_name
            from msnow.fdc_driveway_segment dws --S
            join msnow.fdc_agreement agr on dws.agreement_id=agr.id --S
            join org_ruad on dws.org_ruad_id=org_ruad.org_ruad_id    --S
            join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id --S
            join agrewt on agr.id=agrewt.agreement_id --E
                           and dws.id=agrewt.driveway_segment_id
            left join factwrk on dws.id=factwrk.driveway_segment_id
           where to_char(sch.start_date_plan,'YYYY')=l_current_year
             and sch.start_date_plan is not null
             and sch.end_date_plan is not null
         ) tot
   where coalesce(tot.fact_volume_on_date,0)< coalesce(tot.plan_volume_on_date,0);
  return;
end
$$;

