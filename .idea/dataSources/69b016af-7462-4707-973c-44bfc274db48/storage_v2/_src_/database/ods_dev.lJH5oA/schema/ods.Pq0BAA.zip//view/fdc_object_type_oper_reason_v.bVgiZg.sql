CREATE VIEW fdc_object_type_oper_reason_v AS
  SELECT otor.id,
    ot.id AS object_type_id,
    ot.name AS object_type_name,
    ot.code AS object_type_code,
    o.id AS operation_id,
    o.code AS operation_code,
    o.name AS operation_name,
    rt.id AS reason_type_id,
    rt.name AS reason_type_name,
    rt.code AS reason_type_code
   FROM fdc_object_type_oper_reason otor,
    fdc_object_type ot,
    fdc_operation o,
    fdc_reason_type rt
  WHERE ((ot.id = otor.object_type_id) AND (o.id = otor.operation_id) AND (rt.id = otor.reason_type_id));

