CREATE VIEW fdc_bti_district_v AS
  SELECT NULL::bigint AS id,
    NULL::character varying AS code,
    NULL::bigint AS okrug_id,
    NULL::character varying AS name,
    NULL::boolean AS is_actual;

