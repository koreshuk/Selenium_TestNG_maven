CREATE FUNCTION fdc_nsi_pck_is_inn_correct(p_inn character varying, p_person_type_id bigint, p_event_id bigint DEFAULT NULL::bigint, p_err_raise character varying DEFAULT NULL::character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  /** Проверка ИНН
  %usage Используется в пакете
  %param p_inn             - ИНН
  %param p_event_id        - ID события
  %param p_person_type_id  - Ид типа субъекта права
  %param p_err_raise       - Нужно ли делать raise_application_error (Y/N)
  %return true  - заданный ИНН прошел проверку на корректность
          false - заданный ИНН не прошел проверку на корректность
  */
  l_inn_length integer;
begin
  return true;
end
$$;

