CREATE VIEW fdc_work_status_priority_v AS
  SELECT fdc_work_status.id,
    fdc_work_status.code,
    fdc_work_status.name,
        CASE fdc_work_status.code
            WHEN 'CORRECTING'::text THEN 1
            WHEN 'NOT_ACCEPTED'::text THEN 2
            WHEN 'DONE'::text THEN 3
            WHEN 'ACCEPTED'::text THEN 4
            ELSE NULL::integer
        END AS priority
   FROM msnow.fdc_work_status;

