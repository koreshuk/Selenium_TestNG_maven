CREATE FUNCTION fdc_person_pck_check_flk(pc_code character varying, pc_legal_person nsi.fdc_legal_person, pc_with_flk boolean, pc_new_legal_person_type_id bigint, pc_event_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* ФЛК по типам субъекта права
  */
begin
  if pc_with_flk then
  if pc_new_legal_person_type_id in(nsi.c_sl_organization(),nsi.c_sl_declarant(), nsi.c_sl_branch()) then
    -- ЮЛ
    perform nsi.fdc_nsi_pck_flk_legal_person(p_event_id        => pc_event_id
                                            ,p_code            => pc_code
                                            ,p_person_type_id  => pc_legal_person.person_type_id
                                            ,p_root_id         => pc_legal_person.root_id
                                            ,p_name            => pc_legal_person.name
                                            ,p_short_name      => pc_legal_person.short_name
                                            ,p_inn             => pc_legal_person.inn
                                            ,p_ogrn            => pc_legal_person.ogrn
                                            ,p_okpo            => pc_legal_person.okpo
                                            ,p_kpp             => pc_legal_person.kpp
                                            ,p_email           => pc_legal_person.email
                                            ,p_bik             => pc_legal_person.bik
                                            ,p_account         => pc_legal_person.account
                                            ,p_parent_id       => pc_legal_person.parent_id
                                            );
  elsif pc_new_legal_person_type_id in (nsi.c_sl_private(), nsi.c_sl_employee()) then
        -- ФЛ
    perform nsi.fdc_nsi_pck_flk_private(p_event_id             => pc_event_id
                                       ,p_person_type_id       => pc_legal_person.person_type_id
                                       ,p_root_id              => pc_legal_person.root_id
                                       ,p_last_name            => pc_legal_person.name
                                       ,p_first_name           => pc_legal_person.short_name
                                       ,p_patronymic           => pc_legal_person.patronymic
                                       ,p_occupation           => null
                                       ,p_inn                  => pc_legal_person.inn
                                       ,p_snils                => pc_legal_person.snils
                                       ,p_email                => pc_legal_person.email
                                       ,p_parent_id            => pc_legal_person.parent_id
                                       ,p_identity_doctype_id  => pc_legal_person.identity_doctype_id
                                       ,p_docseries            => pc_legal_person.docseries
                                       ,p_docnumber            => pc_legal_person.docnumber
                                       ,p_issue_date           => pc_legal_person.issue_date
                                       ,p_issue_department     => pc_legal_person.issue_dept
                                       ,p_department_code      => pc_legal_person.issue_dept_code
                                       ,p_occupation_id        => pc_legal_person.occupation_id
                                       );
  elsif pc_new_legal_person_type_id = nsi.c_sl_subdivision() then
    perform nsi.fdc_nsi_pck_flk_subdivision(p_event_id       => pc_event_id
                                          , p_root_id        => pc_legal_person.root_id
                                          , p_code           => pc_legal_person.person_code
                                          , p_email          => pc_legal_person.email
                                          , p_parent_root_id => pc_legal_person.parent_root_id
                                           );
  elsif pc_new_legal_person_type_id is null then
    raise exception 'Параметр тип субъекта обязателен для заполнения.';
  else
    raise exception 'Ошибка создания версии. ФЛК для субъекта % не предусмотрена.',pc_new_legal_person_type_id;
  end if;
  end if;
end
$$;

