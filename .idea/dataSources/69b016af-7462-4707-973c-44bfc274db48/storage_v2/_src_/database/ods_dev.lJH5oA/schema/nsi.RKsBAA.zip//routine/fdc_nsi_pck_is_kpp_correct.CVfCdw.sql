CREATE FUNCTION fdc_nsi_pck_is_kpp_correct(p_kpp character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  /** Проверка КПП
  %usage Используется в пакете
  %param p_kpp   - КПП
  %return true  - заданный КПП прошел проверку на корректность
          false - заданный КПП не прошел проверку на корректность
  */
begin
  return true;
end
$$;

