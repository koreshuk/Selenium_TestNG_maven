CREATE FUNCTION fdc_odh_pck_update_obj_attribute_list(p_object_id bigint, p_attribute_tab fdc_odh, p_prev_object_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare

begin
  insert into ods.fdc_odh(id
                         ,passport_developer_id
                         ,passport_author_id
                         ,category_odh_id
                         ,clean_subcategory_id
                         ,category_detail_id_winter
                         ,category_detail_id_summer
                         ,clean_category_id
                         ,object_group_id
                         ,name
                         ,register_code
                         ,register_num
                         ,passport_num
                         ,passport_date
                         ,glonass_no_check
                         ,bord_begin
                         ,bord_end
                         ,geometry
                         ,is_orphan_object
                         ,distance
                         ,is_include_title_list
                         ,passport_author
                         )
     select p_object_id id
           ,p_attribute_tab.passport_developer_id
           ,p_attribute_tab.passport_author_id
           ,p_attribute_tab.category_odh_id
           ,p_attribute_tab.clean_subcategory_id
           ,p_attribute_tab.category_detail_id_winter
           ,p_attribute_tab.category_detail_id_summer
           ,p_attribute_tab.clean_category_id
           ,p_attribute_tab.object_group_id
           ,p_attribute_tab.name
           ,p_attribute_tab.register_code
           ,p_attribute_tab.register_num
           ,p_attribute_tab.passport_num
           ,p_attribute_tab.passport_date
           ,coalesce(p_attribute_tab.glonass_no_check,false) glonass_no_check
           ,p_attribute_tab.bord_begin
           ,p_attribute_tab.bord_end
           ,p_attribute_tab.geometry
           ,coalesce(p_attribute_tab.is_orphan_object,false) is_orphan_object
           ,p_attribute_tab.distance
           ,coalesce(p_attribute_tab.is_include_title_list,false) is_include_title_list
           ,p_attribute_tab.passport_author
      on conflict(id) do update set bord_begin = excluded.bord_begin
                                   ,bord_end = excluded.bord_end
                                   ,category_detail_id_summer = excluded.category_detail_id_summer
                                   ,category_detail_id_winter = excluded.category_detail_id_winter
                                   ,category_odh_id = excluded.category_odh_id
                                   ,clean_category_id = excluded.clean_category_id
                                   ,clean_subcategory_id = excluded.clean_subcategory_id
                                   ,distance = excluded.distance
                                   ,geometry = excluded.geometry
                                   ,glonass_no_check = excluded.glonass_no_check
                                   ,is_include_title_list = excluded.is_include_title_list
                                   ,is_orphan_object = excluded.is_orphan_object
                                   ,name = excluded.name
                                   ,object_group_id = excluded.object_group_id
                                   ,passport_author = excluded.passport_author
                                   ,passport_author_id = excluded.passport_author_id
                                   ,passport_date = excluded.passport_date
                                   ,passport_developer_id = excluded.passport_developer_id
                                   ,passport_num = excluded.passport_num
                                   ,register_code = excluded.register_code
                                   ,register_num = excluded.register_num;

end
$$;

