CREATE FUNCTION fdc_geo_pck_srid_wgs84()
  RETURNS integer
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 4326::integer;
$$;

