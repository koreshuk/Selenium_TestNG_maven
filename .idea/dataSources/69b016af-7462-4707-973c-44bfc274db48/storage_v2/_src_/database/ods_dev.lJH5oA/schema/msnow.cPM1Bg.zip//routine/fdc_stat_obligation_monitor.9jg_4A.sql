CREATE FUNCTION fdc_stat_obligation_monitor(p_obligation_year character varying, p_work_category_id bigint, p_driveway_category_id bigint)
  RETURNS SETOF msnow.t_obligation_monitor
LANGUAGE plpgsql
AS $$
declare
  /** Отчет мониторинга заполнения реестра бюджетов

      %param p_obligation_year       - Год бюджетного планирования
      %param p_work_category_id      - Ид категории работ
      %param p_driveway_category_id  - Ид категории дорог
  */

  l_org_type_code msnow.fdc_org_type.code%type;
  l_work_category_name msnow.fdc_work_category.name%type;

  l_estimate_work_cost_sum double precision;

begin
  begin
    select case code
             when 'LOCAL' then 'OMSU'
             when 'REGION_INTERMUNICIPAL' then 'RUAD'
           end
      into strict l_org_type_code
      from msnow.fdc_driveway_category
     where id=p_driveway_category_id;
  exception
    when NO_DATA_FOUND then null;
  end;
  begin
   select name
     into strict l_work_category_name
     from msnow.fdc_work_category
    where id=p_work_category_id;
  exception
    when NO_DATA_FOUND then null;
  end;

  return query
            with ods_organization as(select lp.root_id as id
                                          ,lp.short_name as name
                                          ,orgtype.role_id as org_type_id
                                          ,orgtype.role_code as org_type_code
                                          ,lp.fias_district_id as municipality_id
                                          ,lp.parent_root_id as parent_id
                                          ,fias.ao_guid as municipality_ao_guid
                                      from nsi.fdc_legal_person lp
                                      left join ods.fdc_as_addrobj fias on lp.fias_district_id=fias.id
                                      left join (select pr.person_id
                                                       ,pr.begin_date
                                                       ,pr.end_date
                                                       ,r.id as role_id
                                                       ,r.code as role_code
                                                   from nsi.fdc_person_role pr
                                                   join nsi.fdc_role r on pr.role_id=r.id
                                                  where r.code in('OMSU','RUAD','TO')
                                                ) orgtype on lp.root_id=orgtype.person_id
                                                             and statement_timestamp() between orgtype.begin_date and orgtype.end_date
                                     where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                                   )
                ,orgs as(select org.id
                               ,org.id as morg_id
                               ,org.name as municipality_name
                           from ods_organization org
                          where org.org_type_code=l_org_type_code
                         union
                         select org.id
                               ,morg.id as morg_id
                               ,org.name as municipality_name
                           from ods_organization org
                           join ods_organization morg on morg.municipality_ao_guid=org.municipality_ao_guid
                          where (l_org_type_code='OMSU' and org.org_type_code=l_org_type_code)
                            and (morg.org_type_code is null or morg.org_type_code<>'OMSU')
                        )
                ,est_work_cost as(select oble.obligation_id
                                        ,sum(case
                                               when oble.is_estimate_sum then oble.work_cost
                                             end
                                            ) as estimate_work_cost
                                        ,sum(case
                                               when grp.code='ONE_CH' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_1ch
                                        ,sum(case
                                               when grp.code='ONE_C' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_1c
                                        ,sum(case
                                               when grp.code='ONE_H' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_1h
                                        ,sum(case
                                               when grp.code='ONE' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_1
                                        ,sum(case
                                               when grp.code='TWO_H' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_2h
                                        ,sum(case
                                               when grp.code='TWO' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_2
                                        ,sum(case
                                               when grp.code='THREE_H' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_3h
                                        ,sum(case
                                               when grp.code='THREE_A' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_3a
                                        ,sum(case
                                               when grp.code='THREE' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_3
                                        ,sum(case
                                               when grp.code='OTHER' then oble.work_cost
                                             end
                                            ) as estimate_work_cost_other
                                    from msnow.fdc_obligation_estimate oble
                                    left join msnow.fdc_odh_group grp on oble.odh_group_id=grp.id
                                   group by oble.obligation_id
                                 )
                ,obl_est as(select distinct orgs.id as municipality_id
                                  ,orgs.municipality_name
                                  ,obl.id as obligation_id
                                  ,case
                                     when wc.id is null then
                                       l_work_category_name
                                     else wc.name
                                   end as work_category_name
                                  ,case
                                     when obl.id is null then
                                       p_obligation_year
                                     else obl.obligation_year
                                   end as obligation_year
                                  ,case
                                     when row_number() over (partition by obl.id order by obl.id) =1 then obl.work_cost
                                     else 0
                                   end as work_cost
                                  ,ewc.estimate_work_cost
                                  ,ewc.estimate_work_cost_1ch
                                  ,ewc.estimate_work_cost_1c
                                  ,ewc.estimate_work_cost_1h
                                  ,ewc.estimate_work_cost_1
                                  ,ewc.estimate_work_cost_2h
                                  ,ewc.estimate_work_cost_2
                                  ,ewc.estimate_work_cost_3h
                                  ,ewc.estimate_work_cost_3a
                                  ,ewc.estimate_work_cost_3
                                  ,ewc.estimate_work_cost_other
                              from orgs
                              left join msnow.fdc_obligation obl on orgs.morg_id=obl.authority_org_id
                              left join msnow.fdc_work_category wc on obl.work_category_id=wc.id
                              left join est_work_cost ewc on obl.id=ewc.obligation_id
                             where obl.obligation_year=p_obligation_year     -- вх.
                               and obl.work_category_id=p_work_category_id    -- вх.
                           )
                 ,objqty as(select ore.municipality_id
                                 , count(distinct obleobj.driveway_id) object_cnt
                              from obl_est ore
                              join msnow.fdc_obligation_object obleobj on ore.obligation_id=obleobj.obligation_id
                              left join msnow.fdc_driveway dw on obleobj.driveway_id=dw.id
                                                                 and dw.driveway_category_id=p_driveway_category_id -- left join здесь, ЭТО СТРАННО!
                             where obleobj.obligation_id=ore.obligation_id
                             group by ore.municipality_id
                           )
                 ,drvqty as(select orgs.id as municipality_id
                                  ,count(dw.id) as driveway_qty
                              from msnow.fdc_driveway dw
                              join orgs on dw.owner_id=orgs.morg_id
                             group by orgs.id
                           )

                 ,agg as(select o.name as municipality_name
                               ,coalesce(ore.work_category_name,l_work_category_name) as work_category_name
                               ,coalesce(ore.obligation_year,p_obligation_year) as obligation_year
                               ,coalesce(objqty.object_cnt,0) as object_cnt
                               ,coalesce(sum(ore.work_cost),0) as work_cost
                               ,coalesce(sum(ore.estimate_work_cost),0) as estimate_work_cost_pre --!
                               ,coalesce(sum(ore.estimate_work_cost_1ch),0) as estimate_work_cost_1ch
                               ,coalesce(sum(ore.estimate_work_cost_1c),0) as estimate_work_cost_1c
                               ,coalesce(sum(ore.estimate_work_cost_1h),0) as estimate_work_cost_1h
                               ,coalesce(sum(ore.estimate_work_cost_1),0) as estimate_work_cost_1
                               ,coalesce(sum(ore.estimate_work_cost_2h),0) as estimate_work_cost_2h
                               ,coalesce(sum(ore.estimate_work_cost_2),0) as estimate_work_cost_2
                               ,coalesce(sum(ore.estimate_work_cost_3h),0) as estimate_work_cost_3h
                               ,coalesce(sum(ore.estimate_work_cost_3a),0) as estimate_work_cost_3a
                               ,coalesce(sum(ore.estimate_work_cost_3),0) as estimate_work_cost_3
                               ,coalesce(sum(ore.estimate_work_cost_other),0) as estimate_work_cost_other
                               ,coalesce(drvqty.driveway_qty,0) as driveway_cnt

                               ,coalesce(sum(ore.estimate_work_cost_1ch),0)
                                +coalesce(sum(ore.estimate_work_cost_1c),0)
                                +coalesce(sum(ore.estimate_work_cost_1h),0)
                                +coalesce(sum(ore.estimate_work_cost_1),0)
                                +coalesce(sum(ore.estimate_work_cost_2h),0)
                                +coalesce(sum(ore.estimate_work_cost_2),0)
                                +coalesce(sum(ore.estimate_work_cost_3h),0)
                                +coalesce(sum(ore.estimate_work_cost_3a),0)
                                +coalesce(sum(ore.estimate_work_cost_3),0)
                                +coalesce(sum(ore.estimate_work_cost_other),0) as estimate_work_cost_sum
                           from ods_organization o
                           left join objqty on o.id=objqty.municipality_id
                           left join obl_est ore on o.id=ore.municipality_id
                           left join drvqty on o.id=drvqty.municipality_id
                          where o.org_type_code=l_org_type_code
                          group by o.name
                                  ,coalesce(ore.work_category_name,l_work_category_name)
                                  ,coalesce(ore.obligation_year,p_obligation_year)
                                  ,objqty.object_cnt
                                  ,drvqty.driveway_qty
                        )

                   select agg.municipality_name::varchar(255)
                         ,agg.work_category_name
                         ,agg.obligation_year::varchar(4)
                         ,agg.work_cost
                         ,agg.object_cnt::integer
                         ,case
                            when coalesce(agg.estimate_work_cost_pre,0)>0 then agg.estimate_work_cost_pre
                            else agg.estimate_work_cost_sum
                          end as estimate_work_cost
                         ,agg.estimate_work_cost_1ch
                         ,agg.estimate_work_cost_1c
                         ,agg.estimate_work_cost_1h
                         ,agg.estimate_work_cost_1
                         ,agg.estimate_work_cost_2h
                         ,agg.estimate_work_cost_2
                         ,agg.estimate_work_cost_3h
                         ,agg.estimate_work_cost_3a
                         ,agg.estimate_work_cost_3
                         ,agg.estimate_work_cost_other
                         ,agg.driveway_cnt::integer
                         ,case
                            when agg.work_cost>0 then 1
                            else 0
                          end::double precision as score_i
                         ,case
                            when agg.estimate_work_cost_sum > 0 or agg.estimate_work_cost_pre>0 then 1
                            else 0
                          end::double precision  as score_ii
                         ,case
                            when agg.estimate_work_cost_sum = 0 and agg.estimate_work_cost_pre=0 then 0
                            else round((least(agg.estimate_work_cost_sum,agg.estimate_work_cost_pre)::numeric/greatest(agg.estimate_work_cost_sum,agg.estimate_work_cost_pre))::numeric,1)
                          end::double precision  as score_iii
                         ,case
                            when agg.object_cnt=0 or agg.driveway_cnt=0 then 0
                            else round((agg.object_cnt::numeric/agg.driveway_cnt)::numeric,1)
                          end::double precision  as score_iv
                         ,case
                            when agg.work_cost>0 then 1
                            else 0
                          end
                          + case
                              when agg.estimate_work_cost_sum > 0 or agg.estimate_work_cost_pre>0 then 1
                              else 0
                            end
                          + case
                              when agg.estimate_work_cost_sum = 0 and agg.estimate_work_cost_pre=0 then 0
                              else round((least(agg.estimate_work_cost_sum,agg.estimate_work_cost_pre)::numeric/greatest(agg.estimate_work_cost_sum,agg.estimate_work_cost_pre))::numeric,1)
                            end
                          + case
                              when agg.object_cnt=0 or agg.driveway_cnt=0 then 0
                              else round((agg.object_cnt::numeric/agg.driveway_cnt)::numeric,1)
                            end::double precision  as score_sum
                         ,round(((case
                                    when agg.work_cost>0 then 1
                                    else 0
                                  end
                                  + case
                                      when agg.estimate_work_cost_sum > 0 or agg.estimate_work_cost_pre>0 then 1
                                      else 0
                                    end
                                  + case
                                      when agg.estimate_work_cost_sum = 0 and agg.estimate_work_cost_pre=0 then 0
                                      else round((least(agg.estimate_work_cost_sum,agg.estimate_work_cost_pre)::numeric/greatest(agg.estimate_work_cost_sum,agg.estimate_work_cost_pre))::numeric,1)
                                    end
                                  + case
                                      when agg.object_cnt=0 or agg.driveway_cnt=0 then 0
                                      else round((agg.object_cnt::numeric/agg.driveway_cnt)::numeric,1)
                                    end
                                 )::numeric/4)::numeric * 100,1
                               )::double precision  as score_rate_percent
                         ,case
                            when coalesce(agg.work_cost,0)=0 then 0
                            else (agg.estimate_work_cost_pre*100)::numeric/agg.work_cost
                          end::double precision  as distribution_rate
                     from agg;

  return;
end
$$;

