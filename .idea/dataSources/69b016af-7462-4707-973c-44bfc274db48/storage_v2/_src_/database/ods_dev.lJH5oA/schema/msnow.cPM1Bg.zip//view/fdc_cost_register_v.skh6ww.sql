CREATE VIEW fdc_cost_register_v AS
  SELECT 'fdc_obligation'::text AS cost_type,
    'Бюджет'::text AS cost_type_desc,
    o.id,
    o.work_category_id,
    org.municipality_id,
    o.authority_org_id AS organization_id,
        CASE
            WHEN (o.obligation_year IS NOT NULL) THEN to_date(('01.01.'::text || (o.obligation_year)::text), 'dd.mm.yyyy'::text)
            ELSE NULL::date
        END AS work_date_from,
        CASE
            WHEN (o.obligation_year IS NOT NULL) THEN to_date(('31.12.'::text || (o.obligation_year)::text), 'dd.mm.yyyy'::text)
            ELSE NULL::date
        END AS work_date_to,
    o.work_cost AS cost,
    perf.root_id AS performer_id,
    o.obligation_status_id AS status_id,
    ost.code AS status_code,
    ost.name AS status_name
   FROM (((msnow.fdc_obligation o
     LEFT JOIN msnow.fdc_ods_organization org ON ((org.id = o.authority_org_id)))
     LEFT JOIN msnow.fdc_agreement_obligation_status ost ON ((o.obligation_status_id = ost.id)))
     LEFT JOIN nsi.fdc_legal_person perf ON ((o.performer_id = perf.id)))
UNION ALL
 SELECT 'fdc_purchase'::text AS cost_type,
    'Закупка'::text AS cost_type_desc,
    p.id,
    p.work_category_id,
    org.municipality_id,
    p.customer_id AS organization_id,
    p.work_date_from,
    p.work_date_to,
    p.cost,
    NULL::bigint AS performer_id,
    NULL::bigint AS status_id,
    NULL::character varying AS status_code,
    NULL::character varying AS status_name
   FROM (msnow.fdc_purchase p
     LEFT JOIN msnow.fdc_ods_organization org ON ((org.id = p.customer_id)))
UNION ALL
 SELECT 'fdc_agreement'::text AS cost_type,
    'Контракт/задание'::text AS cost_type_desc,
    a.id,
    a.work_category_id,
    org.municipality_id,
    a.customer_id AS organization_id,
    a.work_date_from,
    a.work_date_to,
    a.cost,
    a.performer_id,
    a.agreement_status_id AS status_id,
    ast.code AS status_code,
    ast.name AS status_name
   FROM ((msnow.fdc_agreement a
     LEFT JOIN msnow.fdc_ods_organization org ON ((org.id = a.customer_id)))
     LEFT JOIN msnow.fdc_agreement_obligation_status ast ON ((a.agreement_status_id = ast.id)));

COMMENT ON VIEW fdc_cost_register_v IS 'Консолидированный реестр смет';

COMMENT ON COLUMN fdc_cost_register_v.cost_type IS 'Тип сметы';

COMMENT ON COLUMN fdc_cost_register_v.cost_type_desc IS 'Описание типа сметы';

COMMENT ON COLUMN fdc_cost_register_v.id IS 'Ид объекта';

COMMENT ON COLUMN fdc_cost_register_v.work_category_id IS 'Ид категории работ';

COMMENT ON COLUMN fdc_cost_register_v.municipality_id IS 'Ид муниципального образования';

COMMENT ON COLUMN fdc_cost_register_v.organization_id IS 'Ид организации (орган, заказчик)';

COMMENT ON COLUMN fdc_cost_register_v.work_date_from IS 'Действует с';

COMMENT ON COLUMN fdc_cost_register_v.work_date_to IS 'Действует по';

COMMENT ON COLUMN fdc_cost_register_v.cost IS 'Общая стоимость';

COMMENT ON COLUMN fdc_cost_register_v.performer_id IS 'Ид исполнителя';

COMMENT ON COLUMN fdc_cost_register_v.status_id IS 'Ид статуса';

COMMENT ON COLUMN fdc_cost_register_v.status_code IS 'Код статуса';

COMMENT ON COLUMN fdc_cost_register_v.status_name IS 'Наименование статуса';

