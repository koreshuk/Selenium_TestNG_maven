CREATE FUNCTION rep_regional_dwclean_dmart_agg(p_session_id character varying, p_report_date date, p_work_type_group_id bigint, p_work_type_id bigint DEFAULT NULL::bigint, p_performer_id bigint DEFAULT NULL::bigint, p_odh_id bigint DEFAULT NULL::bigint, p_maintain_group_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Интерактивная витрина «Ежедневный отчет по уборке региональных дорог»
     Сводная таблица.

     %param p_session_id         - Ид сессии
     %param p_report_date        - Дата
     %param p_work_type_group_id - Ид группы видов работ
     %param p_work_type_id       - Ид вида работы
     %param p_performer_id       - Ид исполнителя
     %param p_odh_id             - Ид участка дороги
  */
  l_performer_root_id nsi.fdc_legal_person.root_id%type;
  l_odh_root_id ods.fdc_object.root_id%type;

  l_pricip_list bigint[]; -- Осадки

  l_today_start timestamp;
  l_today_end timestamp;
  l_tomorrow_start timestamp;
  l_tomorrow_end timestamp;
begin

  l_today_start:=to_timestamp(to_char(p_report_date,'dd.mm.yyyy')||' 08:00:00','dd.mm.yyyy hh24:mi:ss');
  l_today_end:=to_timestamp(to_char(p_report_date,'dd.mm.yyyy')||' 23:59:59','dd.mm.yyyy hh24:mi:ss');

  l_tomorrow_start:=to_timestamp(to_char(p_report_date + interval '1' day,'dd.mm.yyyy')||' 00:00:00','dd.mm.yyyy hh24:mi:ss');
  l_tomorrow_end:=to_timestamp(to_char(p_report_date + interval '1' day,'dd.mm.yyyy')||' 07:59:59','dd.mm.yyyy hh24:mi:ss');

  delete from msnow.fdc_regional_dwclean_dmart_agg where session_id=p_session_id;
  delete from msnow.fdc_regional_dwclean_dmart_agg where set_date < current_date -2;

  begin
    select root_id
      into strict l_performer_root_id
      from nsi.fdc_legal_person
     where id=p_performer_id;
  exception
    when NO_DATA_FOUND then
      l_performer_root_id:=null;
  end;
  begin
    select root_id
      into strict l_odh_root_id
      from ods.fdc_object
     where id=p_odh_id;
  exception
    when NO_DATA_FOUND then
      l_odh_root_id:=null;
  end;

  l_pricip_list:=array(with ruad as(select distinct on(cust.root_id)
                                           cust.root_id as customer_root_id
                                          ,cust.id as customer_id
                                          ,cust.short_name as customer_name
                                      from nsi.fdc_legal_person cust
                                      join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                                      join nsi.fdc_role r on pr.role_id=r.id
                                     where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                                       and p_report_date between pr.begin_date and pr.end_date
                                       and r.code='RUAD'
                                     order by cust.root_id
                                             ,cust.ver_end_date desc
                                             ,cust.ver_start_date desc
                                             ,cust.id
                                   )
                           select distinct ruad.customer_root_id
                             from ruad
                             join nsi.fdc_legal_person_municipality lpm on ruad.customer_id=lpm.legal_person_id
                             join nsi.fdc_fias_address_reference_v fias on lpm.municipality_id=fias.municipality_id
                             join msnow.fdc_weather w on fias.id=w.municipality_id
                            where p_report_date between lpm.start_date and lpm.end_date
                              and p_report_date between date(w.snow_date_from) and coalesce(date(w.snow_date_to),to_date('01.01.3000','dd.mm.yyyy'))
                      );

   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
      ,agr_lastapp as(select distinct on(a.agr_root_id)
                             a.agr_root_id
                            ,a.version_date_from
                            ,a.version_date_to
                            ,a.performer_id as performer_root_id
                            ,a.work_date_from
                            ,a.work_date_to
                        from msnow.fdc_agreement a
                        join msnow.fdc_agreement_obligation_status ast on a.agreement_status_id=ast.id
                       where ast.code='APPROVED'
                       order by a.agr_root_id
                               ,a.version_date_to desc
                               ,a.version_date_from desc
                               ,a.id desc
                     )
      ,obj_in_dist as(select distinct obj.root_id
                            ,alap.performer_root_id
                        from ods.fdc_maintenance_route dist
                        join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                        join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                        join ods.fdc_odh odh on disto.odh_id=odh.id
                        join ods.fdc_object obj on odh.id=obj.id
                        join agr_lastapp alap on dagr.agr_root_id=alap.agr_root_id
                       where dist.work_plan_approved
                         and p_report_date between alap.work_date_from and alap.work_date_to
                   )
       -- Закрепленная сеть
       insert into msnow.fdc_regional_dwclean_dmart_agg(id
                                                       ,session_id
                                                       ,set_date
                                                       ,customer_id
                                                       ,customer_root_id
                                                       ,customer_name
                                                       ,performer_root_id
                                                       ,is_snowfall
                                                       ,route_distance
                                                       )
           select nextval('event.fdc_datamart_seq')
                 ,p_session_id
                 ,current_date
                 ,ruad.customer_id
                 ,ruad.customer_root_id
                 ,ruad.customer_name
                 ,oids.performer_root_id
                 ,case
                    when prc is not null then 'Да'
                    else 'Нет'
                  end
                 ,coalesce(calc.stat_axes_length,0.0) as route_distance
             from ods.fdc_odh odh
             join ods.fdc_object obj on odh.id=obj.id
             join ods.fdc_odh_calculation calc on obj.id=calc.id
             join ods.fdc_object_state objs on obj.object_state_id=objs.id
             join nsi.fdc_legal_person cust on obj.customer_id=cust.id
             join ruad on cust.root_id=ruad.customer_root_id
             join obj_in_dist oids on obj.root_id=oids.root_id
             left join unnest(l_pricip_list) prc on ruad.customer_root_id = prc
            where p_report_date between obj.version_date_from and obj.version_date_to
              and objs.code='APPROVED'
              and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id);

  -- Факт, км
   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
       insert into msnow.fdc_regional_dwclean_dmart_agg(id
                                                       ,session_id
                                                       ,set_date
                                                       ,customer_id
                                                       ,customer_root_id
                                                       ,customer_name
                                                       ,performer_root_id
                                                       ,is_snowfall
                                                       ,fact
                                                       )

        select nextval('event.fdc_datamart_seq')
              ,p_session_id
              ,current_date
              ,tt.customer_id
              ,tt.customer_root_id
              ,tt.customer_name
              ,tt.performer_root_id
              ,tt.is_snowfall
              ,coalesce(tt.work_volume,0.0) / 1000.000 as fact
          from(select ruad.customer_id
                     ,ruad.customer_root_id
                     ,ruad.customer_name
                     ,agr.performer_id as performer_root_id
                     ,case
                        when prc is not null then 'Да'
                        else 'Нет'
                      end as is_snowfall
                     ,row_number() over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) rnb
                     --,max(we.work_volume) over(partition by obj.root_id,agr.agr_root_id,we.work_type_id,date(we.work_date) as work_volume
                     ,max(we.vehicles_passage_fact) over(partition by obj.root_id,agr.agr_root_id,we.work_type_id) as work_volume
                 from msnow.fdc_work_execute we
                 join msnow.fdc_work_status ws on we.work_status_id=ws.id
                 join msnow.fdc_wtype_wtype_group wtwtg on we.work_type_id=wtwtg.work_type_id
                 join msnow.fdc_agreement agr on we.agreement_id=agr.id
                 join ods.fdc_odh odh on we.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 join ruad on cust.root_id = ruad.customer_root_id
                 left join unnest(l_pricip_list) prc on ruad.customer_root_id = prc
                where ws.code in('DONE','ACCEPTED')
                  and ((we.work_date between l_today_start and l_today_end) or
                       (we.work_date between l_tomorrow_start and l_tomorrow_end)
                      )
                  and wtwtg.work_type_group_id=p_work_type_group_id
                  and (p_work_type_id is null or we.work_type_id=p_work_type_id)
                  and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                  and (p_odh_id is null or obj.root_id=l_odh_root_id)
                  and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
              ) tt
        where tt.rnb=1;
  -- Техника
   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
       insert into msnow.fdc_regional_dwclean_dmart_agg(id
                                                       ,session_id
                                                       ,set_date
                                                       ,customer_id
                                                       ,customer_root_id
                                                       ,customer_name
                                                       ,performer_root_id
                                                       ,is_snowfall
                                                       ,machinery_used
                                                       )

               select nextval('event.fdc_datamart_seq')
                     ,p_session_id
                     ,current_date
                     ,ruad.customer_id
                     ,ruad.customer_root_id
                     ,ruad.customer_name
                     ,agr.performer_id as performer_root_id
                     ,case
                        when prc is not null then 'Да'
                        else 'Нет'
                      end
                     ,replace(lower(we.machinery_used),' ','') as machinery_count
                 from msnow.fdc_work_execute we
                 join msnow.fdc_work_status ws on we.work_status_id=ws.id
                 join msnow.fdc_wtype_wtype_group wtwtg on we.work_type_id=wtwtg.work_type_id
                 join msnow.fdc_agreement agr on we.agreement_id=agr.id
                 join ods.fdc_odh odh on we.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 join ruad on cust.root_id = ruad.customer_root_id
                 left join unnest(l_pricip_list) prc on ruad.customer_root_id = prc
                where ws.code in('DONE','ACCEPTED')
                  and ((we.work_date between l_today_start and l_today_end) or
                       (we.work_date between l_tomorrow_start and l_tomorrow_end)
                      )
                  and wtwtg.work_type_group_id=p_work_type_group_id
                  and (p_work_type_id is null or we.work_type_id=p_work_type_id)
                  and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                  and (p_odh_id is null or obj.root_id=l_odh_root_id)
                  and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id);


  -- План, км
   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
      ,plan_pw as(select pw.driveway_id
                        ,pw.maintenance_route_id
                        ,pw.work_volume
                        ,agr.performer_id as performer_root_id
                    from msnow.fdc_planed_work pw
                    join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                    join msnow.fdc_wtype_wtype_group wtwtg on pw.work_type_id=wtwtg.work_type_id
                    join msnow.fdc_agreement agr on pw.agreement_id=agr.id
                   where pw.work_date= p_report_date
                     and pws.code in ('APPROVED','DONE')
                     and wtwtg.work_type_group_id=p_work_type_group_id
                     and (p_work_type_id is null or pw.work_type_id=p_work_type_id)
                     and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                 )
       -- Сумма объемов по фактическим работам, если на вход передан Ид участка
       insert into msnow.fdc_regional_dwclean_dmart_agg(id
                                                       ,session_id
                                                       ,set_date
                                                       ,customer_id
                                                       ,customer_root_id
                                                       ,customer_name
                                                       ,performer_root_id
                                                       ,is_snowfall
                                                       ,plan
                                                       )
            select nextval('event.fdc_datamart_seq')
                  ,p_session_id
                  ,current_date
                  ,ruad.customer_id
                  ,ruad.customer_root_id
                  ,ruad.customer_name
                  ,tt.performer_root_id
                  ,case
                     when prc is not null then 'Да'
                     else 'Нет'
                   end
                  ,coalesce(tt.work_volume,0.0) as work_volume
              from(select cust.root_id as customer_root_id
                         ,calc.stat_axes_length as work_volume
                         ,ppw.performer_root_id
                     from plan_pw ppw
                     join ods.fdc_odh odh on ppw.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                    where ppw.maintenance_route_id is null
                      and ppw.driveway_id=p_odh_id
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   select cust.root_id as customer_root_id
                         ,calc.stat_axes_length as work_volume
                         ,ppw.performer_root_id
                     from plan_pw ppw
                     join ods.fdc_maintenance_route dist on ppw.maintenance_route_id=dist.id
                     join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                     join ods.fdc_odh odh on disto.odh_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                    where ppw.driveway_id is null
                      and dist.work_plan_approved
                      and odh.id=p_odh_id
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  ) tt
              join ruad on tt.customer_root_id = ruad.customer_root_id
              left join unnest(l_pricip_list) prc on ruad.customer_root_id = prc;

   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
      ,plan_pw as(select pw.id
                        ,pw.driveway_id
                        ,pw.maintenance_route_id
                        ,pw.work_volume
                        ,agr.performer_id as performer_root_id
                    from msnow.fdc_planed_work pw
                    join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                    join msnow.fdc_wtype_wtype_group wtwtg on pw.work_type_id=wtwtg.work_type_id
                    join msnow.fdc_agreement agr on pw.agreement_id=agr.id
                   where pw.work_date= p_report_date
                     and pws.code in ('APPROVED','DONE')
                     and wtwtg.work_type_group_id=p_work_type_group_id
                     and (p_work_type_id is null or pw.work_type_id=p_work_type_id)
                     and (p_performer_id is null or agr.performer_id=l_performer_root_id)
                 )
       -- Сумма объемов по фактическим работам, если на вход не передан Ид участка
       insert into msnow.fdc_regional_dwclean_dmart_agg(id
                                                       ,session_id
                                                       ,set_date
                                                       ,customer_id
                                                       ,customer_root_id
                                                       ,customer_name
                                                       ,performer_root_id
                                                       ,is_snowfall
                                                       ,plan
                                                       )

            select nextval('event.fdc_datamart_seq')
                  ,p_session_id
                  ,current_date
                  ,ruad.customer_id
                  ,ruad.customer_root_id
                  ,ruad.customer_name
                  ,tt.performer_root_id
                  ,case
                     when prc is not null then 'Да'
                     else 'Нет'
                   end
                 ,coalesce(tt.work_volume,0.0) as work_volume
              from(select cust.root_id as customer_root_id
                         ,calc.stat_axes_length as work_volume
                         ,ppw.performer_root_id
                     from plan_pw ppw
                     join ods.fdc_odh odh on ppw.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     join ods.fdc_odh_calculation calc on obj.id=calc.id
                    where ppw.maintenance_route_id is null
                      and p_odh_id is null
                      and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                   union all
                   select ttt.customer_root_id
                         ,ttt.work_volume
                         ,ttt.performer_root_id
                     from(select cust.root_id as customer_root_id
                                ,disto.maintenance_route_id
                                --,ppw.work_volume
                                ,calc.stat_axes_length as work_volume
                                ,ppw.performer_root_id
                                ,row_number() over(partition by ppw.id,disto.maintenance_route_id,disto.odh_id,cust.root_id) rnk
                            from plan_pw ppw
                            join ods.fdc_maintenance_route dist on ppw.maintenance_route_id=dist.id
                            join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
                            join ods.fdc_odh odh on disto.odh_id=odh.id
                            join ods.fdc_object obj on odh.id=obj.id
                            join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                            join ods.fdc_odh_calculation calc on obj.id=calc.id
                           where ppw.driveway_id is null
                             and dist.work_plan_approved
                             and p_odh_id is null
                             and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                         ) ttt
                    where ttt.rnk=1
                  ) tt
              join ruad on tt.customer_root_id = ruad.customer_root_id
              left join unnest(l_pricip_list) prc on ruad.customer_root_id = prc;

  -- Сумма объемов по регламентным работам
   with ruad as(select distinct on(cust.root_id)
                       cust.root_id as customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                  from nsi.fdc_legal_person cust
                  join nsi.fdc_person_role pr on cust.root_id=pr.person_id
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_report_date between date(cust.ver_start_date) and date(cust.ver_end_date)
                   and p_report_date between pr.begin_date and pr.end_date
                   and r.code='RUAD'
                 order by cust.root_id
                         ,cust.ver_end_date desc
                         ,cust.ver_start_date desc
                         ,cust.id
               )
       insert into msnow.fdc_regional_dwclean_dmart_agg(id
                                                       ,session_id
                                                       ,set_date
                                                       ,customer_id
                                                       ,customer_root_id
                                                       ,customer_name
                                                       ,performer_root_id
                                                       ,is_snowfall
                                                       ,plan
                                                       )
            select nextval('event.fdc_datamart_seq')
                  ,p_session_id
                  ,current_date
                  ,ruad.customer_id
                  ,ruad.customer_root_id
                  ,ruad.customer_name
                  ,dagr.performer_id as performer_root_id
                  ,case
                     when prc is not null then 'Да'
                     else 'Нет'
                   end
                  ,coalesce(calc.stat_axes_length,0.0) as work_volume
              from msnow.fdc_scheduled_work_plan swp
              join msnow.fdc_wtype_wtype_group wtwtg on swp.work_type_id=wtwtg.work_type_id
              join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
              join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
              join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
              join ods.fdc_maintenance_route_odh disto on dist.id=disto.maintenance_route_id
              join ods.fdc_odh odh on disto.odh_id=odh.id
              join ods.fdc_object obj on odh.id=obj.id
              join nsi.fdc_legal_person cust on obj.customer_id=cust.id
              join ods.fdc_object_state objs on obj.object_state_id=objs.id
              join ods.fdc_odh_calculation calc on obj.id=calc.id
              join ruad on cust.root_id=ruad.customer_root_id
              left join unnest(l_pricip_list) prc on ruad.customer_root_id = prc
             where dist.work_plan_approved
               and swpd.performance_date=p_report_date
               and p_report_date between obj.version_date_from and obj.version_date_to
               and objs.code='APPROVED'
               and wtwtg.work_type_group_id=p_work_type_group_id
               and (p_work_type_id is null or swp.work_type_id=p_work_type_id)
               and (p_performer_id is null or dagr.performer_id=l_performer_root_id)
               and (p_odh_id is null or odh.id=p_odh_id)
               and (p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id);

  return;
end
$$;

