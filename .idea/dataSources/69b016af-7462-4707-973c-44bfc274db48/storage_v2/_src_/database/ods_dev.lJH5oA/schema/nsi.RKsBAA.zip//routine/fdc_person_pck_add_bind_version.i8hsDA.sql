CREATE FUNCTION fdc_person_pck_add_bind_version(p_person_id bigint, p_start_date timestamp without time zone, p_inn character varying, p_bind_person_id bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция для создания копии организации
  %usage Используется при создании версионированных связей между субъектами
  %param p_person_id       - Ид для которой необходима копия
  %param p_start_date      - Дата начала действия версии
  %param p_inn             - ИНН для новой версии
  %param p_bind_person_id  - Ид связываемого субъекта
  %return Номер версии субъекта
  */
  l_person_id_row    nsi.fdc_legal_person;
  l_new_person_id    nsi.fdc_person.id%type;
  l_event_id         event.fdc_event_log.event_id%type;
begin
  select d.*
    into strict l_person_id_row
    from nsi.fdc_legal_person d
   where d.id = p_person_id;

  l_person_id_row.bind_person_id:= p_bind_person_id;

  if l_person_id_row.person_type_id = nsi.c_sl_private() then
    l_person_id_row.inn := p_inn;
  elsif l_person_id_row.person_type_id = nsi.c_sl_employee() then
    l_person_id_row.inn := p_inn;
  end if;

  --Создаем версию
  l_new_person_id := nsi.fdc_person_pck_create_version(p_old_ver_id   => p_person_id
                                                     ,p_legal_person => l_person_id_row
                                                     ,p_start_date   => null
                                                     ,p_event_id     => l_event_id
                                                     ,p_with_flk     => false
                                                     );

  --Копируем расширенный адрес ЮР. если есть
  perform nsi.fdc_person_address_pck_add_address(p_person_id            => l_new_person_id
                                                ,p_legal_person_address => nsi.fdc_person_address_pck_get_address
                                                                                           (p_person_id    => p_person_id
                                                                                           ,p_address_type => 1
                                                                                           )
                                                );
  --Копируем расширенный адрес Факт. если есть
  perform nsi.fdc_person_address_pck_add_address(p_person_id            => l_new_person_id
                                                ,p_legal_person_address => nsi.fdc_person_address_pck_get_address
                                                                                           (p_person_id    => p_person_id
                                                                                           ,p_address_type => 0
                                                                                           )
                                    );
  return l_new_person_id;
end
$$;

