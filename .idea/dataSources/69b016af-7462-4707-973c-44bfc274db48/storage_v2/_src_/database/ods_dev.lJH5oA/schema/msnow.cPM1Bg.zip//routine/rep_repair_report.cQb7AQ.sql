CREATE FUNCTION rep_repair_report(p_report_date date, p_driveway_category_id bigint, p_agreement_type_id bigint DEFAULT NULL::bigint, OUT customer_name character varying, OUT performer_name character varying, OUT driveway_segment_name character varying, OUT segment_start double precision, OUT segment_end double precision, OUT distance double precision, OUT asphalt_area double precision, OUT asphalt_distance double precision, OUT repair_type_name character varying, OUT milling_plan_volume double precision, OUT milling_fact_volume double precision, OUT milling_percent_volume double precision, OUT milling_day_volume double precision, OUT levelling_plan_volume double precision, OUT levelling_fact_volume double precision, OUT levelling_percent_volume double precision, OUT levelling_day_volume double precision, OUT asphalt_plan_volume double precision, OUT asphalt_fact_volume double precision, OUT asphalt_percent_volume double precision, OUT asphalt_day_volume double precision, OUT start_date_plan date, OUT start_date_fact date, OUT work_status text, OUT expiration integer, OUT district_name character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Отчет по ремонтам Мосавтодора
    %param p_report_date          - Дата отчета
    %param p_driveway_category_id - Ид балансовой принадлежности
    %param p_agreement_type_id    - Ид вида обязательства

    %return customer_name              - Заказчик
    %return performer_name             - Исполнитель
    %return driveway_segment_name      - Титул автомобильной дороги
    %return segment_start              - Начало участка ремонта
    %return segment_end                - Конец участка ремонта
    %return distance                   - Общая протяженность ремонта
    %return asphalt_area               - Площадь укладки а/б покрытия
    %return asphalt_distance           - Прив. км
    %return repair_type_name           - Вид ремонта
    %return milling_plan_volume        - Фрезерование. План
    %return milling_fact_volume        - Фрезерование. Факт
    %return milling_percent_volume     - Фрезерование. %
    %return milling_day_volume         - Фрезерование. За прошедшие сутки
    %return levelling_plan_volume      - Устройство выравнивающего слоя. План
    %return levelling_fact_volume      - Устройство выравнивающего слоя. Факт
    %return levelling_percent_volume   - Устройство выравнивающего слоя. %
    %return levelling_day_volume       - Устройство выравнивающего слоя. За прошедшие сутки
    %return asphalt_plan_volume        - Устройство а/б покрытия. План
    %return asphalt_fact_volume        - Устройство а/б покрытия. Факт
    %return asphalt_percent_volume     - Устройство а/б покрытия. %
    %return asphalt_day_volume         - Устройство а/б покрытия. За прошедшие сутки
    %return start_date_plan            - Дата выхода на объект по графику
    %return start_date_fact            - Дата выхода на объект
    %return work_status                - Статус работ
    %return expiration                 - Просрочка
    %return district_name              - значение Район из Муниц. район/городской округ карточки ремонтируемого участка.
  */
  l_driveway_category_code msnow.fdc_driveway_category.code%type;
begin
  select code
    into strict l_driveway_category_code
    from msnow.fdc_driveway_category
   where id=p_driveway_category_id;

  return query
    with custorg as(select distinct pr.person_id as customer_id
                          ,lp.name as customer_name
                      from nsi.fdc_person_role pr
                      join nsi.fdc_role r on pr.role_id=r.id
                      join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                     where statement_timestamp() between pr.begin_date and pr.end_date
                       and r.code in('MA','RUAD')
                       and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                       and l_driveway_category_code='REGION_INTERMUNICIPAL'
                    union
                    select distinct pr.person_id as customer_id
                          ,lp.name as customer_name
                      from nsi.fdc_person_role pr
                      join nsi.fdc_role r on pr.role_id=r.id
                      join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                     where statement_timestamp() between pr.begin_date and pr.end_date
                       and r.code ='OMSU'
                       and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                       and l_driveway_category_code='LOCAL'
                    union
                    select distinct lp.root_id as customer_id
                          ,lp.name as customer_name
                     from nsi.fdc_legal_person lp
                     left join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     left join nsi.fdc_role r on pr.role_id=r.id
                    where statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                      and (r.code is null or r.code not in('OMSU','TO','KO','RUAD','MA'))
                      and l_driveway_category_code='LOCAL'
                   )
        ,last_day_work_exec as(select lwel.agreement_id
                                     ,lwel.driveway_segment_id
                                     ,lwel.work_type_id
                                     ,sum(lwel.work_volume) as work_volume
                                 from msnow.fdc_work_execute lwel
                                where date(lwel.work_date)=p_report_date
                                group by lwel.agreement_id
                                        ,lwel.driveway_segment_id
                                        ,lwel.work_type_id
                              )
        ,work_exec as(select lwe.agreement_id
                            ,lwe.driveway_segment_id
                            ,lwe.work_type_id
                            ,sum(lwe.work_volume) as work_volume
                        from msnow.fdc_work_execute lwe
                       group by lwe.agreement_id
                               ,lwe.driveway_segment_id
                               ,lwe.work_type_id
                     )
        ,nae as (select tae.agreement_id
                       ,tae.driveway_segment_id
                       ,tae.milling_plan_volume
                       ,tae.milling_fact_volume
                       ,case
                          when tae.milling_plan_volume <> 0 then
                            tae.milling_fact_volume * 100.0 / tae.milling_plan_volume
                          else 0
                        end as milling_percent_volume
                       ,tae.milling_day_volume
                       ,tae.levelling_plan_volume
                       ,tae.levelling_fact_volume
                       ,case
                          when tae.levelling_plan_volume <> 0 then
                            tae.levelling_fact_volume * 100.0 / tae.levelling_plan_volume
                          else 0
                        end as levelling_percent_volume
                       ,tae.levelling_day_volume
                       ,tae.asphalt_plan_volume
                       ,tae.asphalt_fact_volume
                       ,case
                          when tae.asphalt_plan_volume <> 0 then
                            tae.asphalt_fact_volume * 100.0 / tae.asphalt_plan_volume
                          else 0
                        end as asphalt_percent_volume
                       ,tae.asphalt_day_volume
                   from(select ae.agreement_id
                              ,ae.driveway_segment_id
                              ,coalesce(sum(case
                                              when aewt.is_milling and aemu.code='MTK' then ae.work_volume
                                            end
                                           ),0
                                       ) as milling_plan_volume
                              ,coalesce(sum(case
                                              when aewt.is_milling and aemu.code='MTK' then we.work_volume
                                            end
                                           ),0
                                       ) as milling_fact_volume
                              ,coalesce(sum(case
                                              when aewt.is_milling and aemu.code='MTK' then ldwe.work_volume
                                            end
                                           ),0
                                       ) as milling_day_volume
                              ,coalesce(sum(case
                                              when aewt.is_levelling and aemu.code='TNE' then ae.work_volume
                                            end
                                            ),0
                                       ) as levelling_plan_volume
                              ,coalesce(sum(case
                                              when aewt.is_levelling and aemu.code='TNE' then we.work_volume
                                            end
                                           ),0
                                       ) as levelling_fact_volume
                              ,coalesce(sum(case
                                              when aewt.is_levelling and aemu.code='TNE' then ldwe.work_volume
                                            end
                                           ),0
                                       ) as levelling_day_volume
                              ,coalesce(sum(case
                                              when aewt.is_asphalt and aemu.code='MTK' then ae.work_volume
                                            end
                                           ),0
                                       ) as asphalt_plan_volume
                              ,coalesce(sum(case
                                              when aewt.is_asphalt and aemu.code='MTK' then we.work_volume
                                            end
                                           ),0
                                       ) as asphalt_fact_volume
                              ,coalesce(sum(case
                                              when aewt.is_asphalt and aemu.code='MTK' then ldwe.work_volume
                                            end
                                           ),0
                                       ) as asphalt_day_volume
                          from msnow.fdc_agr_estimate ae
                          join msnow.fdc_work_type aewt on ae.work_type_id=aewt.id
                          join msnow.fdc_measure_unit aemu on aewt.measure_unit_id=aemu.id
                          left join last_day_work_exec ldwe on ae.work_type_id=ldwe.work_type_id
                                                               and ae.agreement_id=ldwe.agreement_id
                                                               and ae.driveway_segment_id=ldwe.driveway_segment_id
                          left join work_exec we on ae.work_type_id=we.work_type_id
                                                    and ae.agreement_id=we.agreement_id
                                                    and ae.driveway_segment_id=we.driveway_segment_id
                         where ae.driveway_segment_id is not null
                         group by ae.agreement_id
                                 ,ae.driveway_segment_id
                       ) tae
                )
   select custorg.customer_name
         ,perf.name as performer_name
         ,dws.name as driveway_segment_name
         ,dws.segment_start
         ,dws.segment_end
         ,dws.distance
         ,dws.asphalt_area
         ,dws.asphalt_distance
         ,rt.name as repair_type_name
         ,nae.milling_plan_volume
         ,nae.milling_fact_volume
         ,nae.milling_percent_volume
         ,nae.milling_day_volume
         ,nae.levelling_plan_volume
         ,nae.levelling_fact_volume
         ,nae.levelling_percent_volume
         ,nae.levelling_day_volume
         ,nae.asphalt_plan_volume
         ,nae.asphalt_fact_volume
         ,nae.asphalt_percent_volume
         ,nae.asphalt_day_volume
         ,sch.start_date_plan
         ,sch.start_date_fact
         ,case
            when (nae.milling_percent_volume+nae.levelling_percent_volume+nae.asphalt_percent_volume)/3.0 > 95.0 then 'Завершено'
            when nae.milling_fact_volume>0.0 or nae.levelling_fact_volume>0.0 or nae.asphalt_fact_volume>0.0 then 'В работе'
          end::text as work_status
         ,case
            when sch.start_date_fact is not null and sch.start_date_plan < sch.start_date_fact then sch.start_date_fact - sch.start_date_plan
            when sch.start_date_plan < current_date then current_date - sch.start_date_plan
            else 0
          end as expiration
         ,CAST(addr.formal_name||' '||addr.short_name AS varchar) as district_name
     from nae
     join msnow.fdc_driveway_segment dws on nae.driveway_segment_id=dws.id
     join msnow.fdc_segment seg on seg.id = dws.id
     join msnow.fdc_agreement agr on nae.agreement_id=agr.id
     join msnow.fdc_dw_segment_status st on st.id = dws.status_id
     join msnow.fdc_work_category wc on agr.work_category_id=wc.id
     join custorg on agr.customer_id=custorg.customer_id
     left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                            and statement_timestamp() between perf.ver_start_date and perf.ver_end_date
     left join msnow.fdc_repair_type rt on dws.repair_type_id=rt.id
     left join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
     join ods.fdc_odh odh ON odh.id = dws.driveway_id
     join ods.fdc_object o ON o.id = odh.id
     left join ods.fdc_as_addrobj addr ON addr.id = coalesce(o.as_area_id,o.as_place_id)
    where wc.code='REPAIR_PROGRAM'
      and p_report_date between agr.work_date_from and agr.work_date_to
      and st.code in ('COMPLETED','PLANNED','IN_PROCESS')
      and case when p_agreement_type_id is not null then agr.agr_type_id = p_agreement_type_id
               when l_driveway_category_code = 'REGION_INTERMUNICIPAL' then agr.agr_type_id in (1,2,3)
               when l_driveway_category_code='LOCAL' then agr.agr_type_id in (4,5)
          end
      ;

  return;
end
$$;

