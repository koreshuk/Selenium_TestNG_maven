CREATE FUNCTION fdc_person_pck_legal_card_add(p_name character varying, p_short_name character varying, p_code character varying DEFAULT NULL::character varying, p_inn character varying DEFAULT NULL::character varying, p_kpp character varying DEFAULT NULL::character varying, p_ogrn character varying DEFAULT NULL::character varying, p_okpo character varying DEFAULT NULL::character varying, p_account character varying DEFAULT NULL::character varying, p_postal_address character varying DEFAULT NULL::character varying, p_legal_address character varying DEFAULT NULL::character varying, p_email character varying DEFAULT NULL::character varying, p_phone character varying DEFAULT NULL::character varying, p_fax character varying DEFAULT NULL::character varying, p_off_post character varying DEFAULT NULL::character varying, p_off_name character varying DEFAULT NULL::character varying, p_bank character varying DEFAULT NULL::character varying, p_bik character varying DEFAULT NULL::character varying, p_corr_account character varying DEFAULT NULL::character varying, p_reg_date date DEFAULT NULL::date, p_is_ip boolean DEFAULT false, p_is_filial boolean DEFAULT false, p_parent_id bigint DEFAULT NULL::bigint, p_start_date timestamp without time zone DEFAULT NULL::timestamp without time zone, p_end_date timestamp without time zone DEFAULT NULL::timestamp without time zone, p_person_role_tab bigint[] DEFAULT NULL::bigint[], p_fns_sync_date timestamp without time zone DEFAULT NULL::timestamp without time zone, p_fns_validate boolean DEFAULT NULL::boolean, p_person_code character varying DEFAULT NULL::character varying, p_person_code_name character varying DEFAULT NULL::character varying, p_cbr_bank_id bigint DEFAULT NULL::bigint, p_is_small_medium bigint DEFAULT NULL::bigint, p_sro_flag boolean DEFAULT NULL::boolean, p_sro_org_id bigint DEFAULT NULL::bigint, p_sro_regnum character varying DEFAULT NULL::character varying, p_okonh_id bigint DEFAULT NULL::bigint, p_okopf_id bigint DEFAULT NULL::bigint, p_okved_id bigint DEFAULT NULL::bigint, p_okfs_id bigint DEFAULT NULL::bigint, p_t_legal_address nsi.t_legal_person_address DEFAULT NULL::nsi.t_legal_person_address, p_t_postal_address nsi.t_legal_person_address DEFAULT NULL::nsi.t_legal_person_address, p_bind_ver_id bigint DEFAULT NULL::bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Добавление организации
  %usage Используется в карточке ЮЛ
  %param p_code        --Код в АС Управления Реестрами (если null - ручной режим, not null - онлайн синхр с АСУР)
  %param p_name        --Полное наименование
  %param p_short_name  --Краткое наименование
  %param p_inn         --Идентификационный номер налогоплательщика
  %param p_kpp         --Код причины постановки на учёт
  %param p_ogrn        --Основной государственный регистрационный номер
  %param p_okpo        --Общероссийский классификатор предприятий и организаций
  %param p_account     --Расчётный счёт (текущий счёт)
  %param p_postal_address --Фактический адрес
  %param p_legal_address  --Юридический адрес
  %param p_email          --Электронная почта
  %param p_phone          --Телефон организации или ответственного лица
  %param p_fax            --Факс организации
  %param p_off_post       --Должность руководителя
  %param p_off_name       --ФИО руководителя
  %param p_bank           -- Банк
  %param p_bik            -- БИК
  %param p_person_code    -- Код подразделения
  %param p_okved          -- ОКВЭД
  %param p_corr_account   -- Корреспондентский счет
  %param p_reg_date       -- Дата регистрации
  %param p_is_IP          -- Признак ИП (1 - ИП, 0 - организация)
  %param p_is_filial       -- Признак Филиал (1 - филиал, 0 - организация)
  %param p_parent_id       -- Ид головной организации
  %param p_start_date      -- Дата начала действия организации (заплняется только при редактировании в карточке ЮЛ)
  %param p_end_date        -- Дата окончания действия организации (но не версии), введенная пользователем
  %param p_person_role_tab -- Список ролей (fdc_person_role_v.role_id)
  %param p_fns_sync_date   -- дата синхронизации с фнс
  %param p_fns_validate    -- признак того, обновлены сведения о юл данными из фнс
  %param p_person_code_name -- Вид подразделения
  %param p_cbr_bank_id      -- Ид банка
  %param p_is_small_medium  -- Признак малого или среднего бизнеса
  %param p_sro_flag         -- Признак СРО
  %param p_sro_org_id       -- Ид СРО
  %param p_sro_regnum       -- Регистрационный номер СРО
  %param p_okonh_id            Ид ОКОНХ
  %param p_okopf_id            Ид ОКОПФ
  %param p_okved_id            Ид ОКВЕД
  %param p_okfs_id             Ид ОКФС
  %param p_t_legal_address  -- объект юридический адрес
  %param p_t_postal_address -- объект фактический адрес
  %param p_bind_ver_id      -- ИД связанного субъекта
  %return ИД организации
  */
  l_event_id       event.fdc_event_log.event_id%type;
  l_res            nsi.fdc_legal_person.id%type;
  l_person_type_id nsi.fdc_legal_person.person_type_id%type;
  l_root_id        nsi.fdc_person.id%type;
  l_def_start_date nsi.fdc_legal_person.ver_start_date%type := date_trunc('day',coalesce(p_start_date, localtimestamp));
begin
  /*  На текущий момент логирование не реализовано
   fdc_event_pck.event_start(p_event_id        => l_event_id
                            ,p_event_type_code => const.c_et_add
                            ,p_event_category  => const.c_ec_person
                            );
  */

  -- опеределяем тип
  l_person_type_id := nsi.fdc_person_pck_get_legal_person_type_id(p_event_id  => l_event_id
                                                                 ,p_is_IP     => p_is_IP
                                                                 ,p_is_filial => p_is_filial
                                                                 );


  l_res := nsi.fdc_person_pck_legal_add
                      (p_person_type_id   => l_person_type_id,
                       p_name             => p_name,
                       p_short_name       => p_short_name,
                       p_inn              => p_inn,
                       p_kpp              => p_kpp,
                       p_ogrn             => p_ogrn,
                       p_okpo             => p_okpo,
                       p_account          => p_account,
                       p_postal_address   => p_postal_address,
                       p_legal_address    => p_legal_address,
                       p_email            => p_email,
                       p_phone            => p_phone,
                       p_fax              => p_fax,
                       p_off_post         => p_off_post,
                       p_off_name         => p_off_name,
                       p_bank             => p_bank,
                       p_bik              => p_bik,
                       p_person_code      => p_person_code,
                       p_person_code_name => p_person_code_name,
                       p_corr_account     => p_corr_account,
                       p_reg_date         => p_reg_date,
                       p_start_date       => l_def_start_date,
                       p_end_date         => p_end_date,
                       p_parent_id        => p_parent_id,
                       p_cbr_bank_id      => p_cbr_bank_id,
                       p_is_small_medium  => p_is_small_medium,
                       p_sro_flag         => p_sro_flag,
                       p_sro_org_id       => p_sro_org_id,
                       p_sro_regnum       => p_sro_regnum,
                       p_okfs_id          => p_okfs_id,
                       p_okonh_id         => p_okonh_id,
                       p_okopf_id         => p_okopf_id,
                       p_okved_id         => p_okved_id,
                       p_event_id         => l_event_id,
                       p_t_legal_address  => p_t_legal_address,
                       p_t_postal_address => p_t_postal_address,
                       p_bind_ver_id      => p_bind_ver_id
                       );

  -- добавление ролей из списка
  perform  nsi.fdc_person_pck_role_tab_add(p_id              => l_res
                                         , p_person_role_tab => p_person_role_tab
                                         , p_start_date      => l_def_start_date
                                          );

  begin
    select root_id
      into strict l_root_id
      from nsi.fdc_legal_person
     where id = l_res;
  exception
    when others then null; -- это временно, пока заработает legal_add(). Потом надо убрать
  end;
  /* Взаимодействие с АСУР не реализовано
  -- создаем запрос в АСУР для последующего обновления данных
    l_request_id:= fdc_asur_pck.set_request(p_subject_type => l_person_type_id,
                                           p_root_id => l_root_id,
                                           p_name => null,
                                           p_short_name => null,
                                           p_inn => p_inn,
                                           p_kpp => null,
                                           p_ogrn => null,
                                           p_okpo => null,
                                           p_account => null,
                                           p_postal_address => null,
                                           p_legal_address => null,
                                           p_email => null,
                                           p_phone => null,
                                           p_fax => null,
                                           p_off_post => null,
                                           p_off_name => null,
                                           p_bank => null,
                                           p_bik => null,
                                           p_okved => null,
                                           p_corr_account => null,
                                           p_reg_date => null
                                           );
  */
  /*  На текущий момент логирование не реализовано
   fdc_event_pck.event_finish(p_event_id => l_event_id, p_source_id => l_root_id);
  */
  return l_res;

/*  На текущий момент логирование не реализовано
exception
  when others then
    fdc_event_pck.error_handler(p_event_id   => l_event_id
                               ,p_err_code   => -20101
                               ,p_err_params => p_name || '~' || fdc_event_pck.get_error_trace
                               ,p_err_raise  => fdc_event_pck.c_err_finish
                               );
*/
end;
$$;

