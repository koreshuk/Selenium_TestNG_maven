CREATE FUNCTION fdc_ldv_dwregistry_stat(p_municipality_id bigint, OUT municipality_name text, OUT object_id bigint, OUT object_name text, OUT rgn text, OUT is_orphan_object text, OUT owner_name text, OUT odh_group_name text, OUT cover_type_name text, OUT dw_gost_category_name text)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Статистика по местным дорогам муниц. района" - Реестр дорог
  %param p_municipality_id - Ид муниципального района/городского округа
  */
begin
  return query select mnc.formal_name||case
                                   when mnc.short_name is not null then ' '||mnc.short_name
                                   else ''
                                 end::text as municipality_name
                     ,obj.root_id as object_id
                     ,obj.name::text as object_name
                     ,odh.register_code::text as rgn
                     ,case odh.is_orphan_object
                        when true then 'да'
                        else ''
                      end::text is_orphan_object
                     ,owr.short_name::text as owner_name
                     ,grp.name::text as odh_group_name
                     ,ct.name::text as cover_type_name
                     ,dwg.name::text as dw_gost_category_name
                 from ods.fdc_object obj
                 join ods.fdc_object_type objt on obj.object_type_id=objt.id
                 join ods.fdc_object_state objs on obj.object_state_id=objs.id
                 join ods.fdc_odh odh on obj.id=odh.id
                 join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 join ods.fdc_as_addrobj mnc on cust.fias_district_id=mnc.id
                 left join nsi.fdc_legal_person owr on obj.owner_id=owr.id
                 left join msnow.fdc_maintain_group grp on odh.maintain_group_id=grp.id
                 left join msnow.fdc_cover_type ct on odh.cover_type_id=ct.id
                 left join msnow.fdc_driveway_gost_category dwg on odh.driveway_gost_category_id=dwg.id
                where objt.code='ODH'
                  and objs.code='APPROVED'
                  and mnc.id=p_municipality_id--24724--?
                  and current_date between obj.version_date_from and obj.version_date_to;

  return;
end
$$;

