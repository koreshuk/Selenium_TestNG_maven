CREATE FUNCTION fdc_workplan_get_snowinfall_qty(p_snowfall_period integer, p_work_date timestamp without time zone)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
/* Расчет суммарного количества осадков по указанному периоду снегопада
  %param p_snowfall_period - Код периода снегопада
  %param p_work_date       - Дата из фильтра Дата работ с

  %return Количество осадков в сантиметрах
*/
  l_total_snow_qty double precision:=0;
  l_work_date timestamp;
begin
  l_work_date:=date_trunc('day',p_work_date);
  if p_snowfall_period in(32,34) then -- II период
    l_total_snow_qty:=msnow.fdc_workplan_get_rainfall(p_work_date => l_work_date)+
                      msnow.fdc_workplan_get_rainfall(p_work_date => l_work_date - interval '1' day);
  elsif p_snowfall_period=33 then -- III период
    l_total_snow_qty:=msnow.fdc_workplan_get_rainfall(p_work_date => l_work_date)+
                      msnow.fdc_workplan_get_rainfall(p_work_date => l_work_date - interval '1' day)+
                      msnow.fdc_workplan_get_rainfall(p_work_date => l_work_date - interval '2' day);
  else
    l_total_snow_qty:=msnow.fdc_workplan_get_rainfall(p_work_date => l_work_date);
  end if;
  return l_total_snow_qty;
end;
$$;

