CREATE FUNCTION fdc_nsi_pck_is_account_correct(p_account character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  /** Проверка расч. счета
  %usage Используется в пакете
  %param p_account   - расч. счет
  %return true  - заданный расч. счет прошел проверку на корректность
          false - заданный расч. счет не прошел проверку на корректность
  */
begin
  return true;
end
$$;

