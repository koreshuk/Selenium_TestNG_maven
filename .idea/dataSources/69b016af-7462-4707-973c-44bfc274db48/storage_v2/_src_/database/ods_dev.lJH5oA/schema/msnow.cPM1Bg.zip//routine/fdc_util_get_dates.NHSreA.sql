CREATE FUNCTION fdc_util_get_dates(p_date_from date, p_date_to date)
  RETURNS SETOF date
IMMUTABLE
LANGUAGE plpgsql
AS $$
declare
  /* Возвращает все даты между p_date_from и p_date_to без учета года.
     Т.е. после декабря следует январь
  */
  l_base_year int:=2016; -- потому что высокосная, учтем 29.02
  l_date_from date;
  l_date_to date;
begin
  if p_date_from is not null and p_date_to is not null then
    l_date_from:=to_date(EXTRACT('day' from p_date_from)||'.'||EXTRACT('month' from p_date_from)||'.'||l_base_year::varchar(4),'dd.mm.yyyy');
    l_date_to:=to_date(EXTRACT('day' from p_date_to)||'.'||EXTRACT('month' from p_date_to)||'.'||
                         (l_base_year+
                           case
                             when EXTRACT('month' from p_date_from)::INT > EXTRACT('month' from p_date_to)::INT then 1
                             else 0
                           end
                         )::varchar(4),'dd.mm.yyyy');

    
    /*
    loop
      --return next l_date_from;
      return next to_date(EXTRACT('day' from l_date_from)||'.'||EXTRACT('month' from l_date_from)||'.'||l_base_year::varchar(4),'dd.mm.yyyy');
      l_date_from:=l_date_from + interval '1' day;
      exit when l_date_from>l_date_to;
    end loop;*/

    return query SELECT to_date(substring(to_char(dt,'dd.mm.yyyy') from 1 for 6)||l_base_year,'dd.mm.yyyy') 
                   FROM generate_series(l_date_from::timestamp
                                       ,l_date_to::timestamp
                                       ,'1 days'
                                       ) dt; 
  end if;
  return;
end
$$;

