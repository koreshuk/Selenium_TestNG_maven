CREATE FUNCTION c_at_ozn_cat_1_2()
  RETURNS character varying
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 'OZN_CAT_1_2'::varchar;
$$;

