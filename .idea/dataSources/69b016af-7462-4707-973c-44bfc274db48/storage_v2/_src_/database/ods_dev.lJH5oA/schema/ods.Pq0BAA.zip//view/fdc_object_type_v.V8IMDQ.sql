CREATE VIEW fdc_object_type_v AS
  SELECT t1.id,
    t1.history_id,
    t2.code AS history_code,
    t2.name AS history_name,
    t2.short_name AS history_short_name,
    t1.parent_id,
    t3.code AS parent_code,
    t3.name AS parent_name,
    t3.short_name AS parent_short_name,
    t1.code,
    t1.name,
    t1.date_from,
    t1.date_to,
    t1.short_name,
    t1.is_upper_level,
    t1.is_point_avail,
    t1.is_line_avail,
    t1.is_polygon_avail,
    t1.is_check_area,
    t1.is_calc_area,
    t1.is_calc_yard
   FROM ((fdc_object_type t1
     LEFT JOIN fdc_object_type t2 ON ((t1.history_id = t2.id)))
     LEFT JOIN fdc_object_type t3 ON ((t1.parent_id = t3.id)));

COMMENT ON VIEW fdc_object_type_v IS 'Справочник Тип ОГХ';

COMMENT ON COLUMN fdc_object_type_v.id IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_object_type_v.history_code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.history_name IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.history_short_name IS 'Краткое наименование типа объекта ОГХ';

COMMENT ON COLUMN fdc_object_type_v.parent_id IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.parent_code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.parent_name IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.parent_short_name IS 'Краткое наименование типа объекта ОГХ';

COMMENT ON COLUMN fdc_object_type_v.code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.name IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_type_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_object_type_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_object_type_v.short_name IS 'Краткое наименование типа объекта ОГХ';

COMMENT ON COLUMN fdc_object_type_v.is_upper_level IS 'Признак, что объект верхнего уровня';

COMMENT ON COLUMN fdc_object_type_v.is_point_avail IS 'Признак, что геометрия точка доступна для типа';

COMMENT ON COLUMN fdc_object_type_v.is_line_avail IS 'Признак, что геометрия линия доступна для типа';

COMMENT ON COLUMN fdc_object_type_v.is_polygon_avail IS 'Признак, что геометрия полигон доступна для типа';

COMMENT ON COLUMN fdc_object_type_v.is_check_area IS 'Признак необходимости проверки площади';

COMMENT ON COLUMN fdc_object_type_v.is_calc_area IS 'Признак необходимости расчета параметров родителя ДТ';

