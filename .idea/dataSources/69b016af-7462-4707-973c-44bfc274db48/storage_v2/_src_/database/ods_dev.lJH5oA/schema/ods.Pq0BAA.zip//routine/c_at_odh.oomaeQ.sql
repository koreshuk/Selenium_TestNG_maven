CREATE FUNCTION c_at_odh()
  RETURNS character varying
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 'ODH'::varchar;
$$;

