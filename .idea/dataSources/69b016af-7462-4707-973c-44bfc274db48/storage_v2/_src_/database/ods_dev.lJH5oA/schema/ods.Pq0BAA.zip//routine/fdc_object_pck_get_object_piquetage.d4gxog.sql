CREATE FUNCTION fdc_object_pck_get_object_piquetage(p_object_id bigint)
  RETURNS SETOF t_object_piquetage
LANGUAGE plpgsql
AS $$
declare
  /*Получить Парамнетры пикетажа объекта ОДТИ
  %param      p_object_id    ИД версии объекта
  %return     Парметры пикетажа объекта ОДТИ
  */
begin
  return query select op.id::bigint
                    , op.object_id::bigint
                    , op.piquetage_type_id::bigint
                    , op.piquetage_type_code::varchar(50)
                    , op.piquetage_type_name::varchar(255)
                    , op.value::double precision piq_value
                    , op.odh_location_side_id::bigint side_id
                    , op.odh_location_side_code::varchar(50) side_code
                    , op.odh_location_side_name::varchar(255) side_name
                    , op.axes_type_id::bigint
                    , op.axes_type_code::varchar(50)
                    , op.axes_type_name::varchar(255)
                    , otp.id::bigint sort_id
                 from ods.fdc_object_v o
                    , ods.fdc_object_piquetage_v op
                    , ods.fdc_object_type_piquetage_v otp
                where o.id = p_object_id
                  and op.object_id = o.id
                  and otp.object_type_id = o.object_type_id
                  and otp.piquetage_type_id = op.piquetage_type_id;
  return;
end;
$$;

