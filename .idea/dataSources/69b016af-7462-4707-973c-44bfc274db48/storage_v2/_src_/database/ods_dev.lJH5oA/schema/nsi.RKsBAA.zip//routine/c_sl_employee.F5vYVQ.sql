CREATE FUNCTION c_sl_employee()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 5::bigint;
$$;

