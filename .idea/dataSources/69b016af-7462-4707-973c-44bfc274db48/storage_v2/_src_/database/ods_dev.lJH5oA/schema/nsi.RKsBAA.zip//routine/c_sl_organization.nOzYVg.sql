CREATE FUNCTION c_sl_organization()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 1::bigint;
$$;

