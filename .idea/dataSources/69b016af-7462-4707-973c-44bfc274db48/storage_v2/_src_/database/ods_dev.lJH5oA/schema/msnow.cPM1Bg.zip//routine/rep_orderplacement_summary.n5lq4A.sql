CREATE FUNCTION rep_orderplacement_summary(p_date_from date, p_date_to date, p_work_category_id bigint, p_driveway_category_id bigint, p_customer_id bigint DEFAULT NULL::bigint, p_terms_violation_flag boolean DEFAULT false, p_trading_result_id bigint DEFAULT NULL::bigint, OUT customer_short_name character varying, OUT expiration_days_qty integer, OUT purchase_regnum character varying, OUT purchase_name character varying, OUT purchase_cost double precision, OUT notice_date_plan date, OUT notice_date_fact date, OUT result_date_plan date, OUT result_date_fact date, OUT contract_date_plan date, OUT trading_result_name character varying, OUT agreement_reg_num character varying, OUT agreement_reg_date date, OUT performer_short_name character varying, OUT agreement_cost double precision, OUT saving_sum double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт Сведения о размещении заказа на проведение работ по содержанию и текущему ремонту автом. дорог

  %param p_date_from             - Дата с
  %param p_date_to               - Дата по
  %param p_work_category_id      - Категория работ
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_customer_id           - Заказчик (Ид актуальной на текущую дату версии заказчика)
  %param p_terms_violation_flag  - Флаг "С нарушением сроков"
  %param p_trading_result_id     - Итоги торгов

  %return customer_short_name    -- Заказчик
  %return expiration_days_qty    -- Количество дней просрочки
  %return purchase_regnum        -- Сведения о закупке.Реестровый номер
  %return purchase_name          -- Сведения о закупке.Наименование
  %return purchase_cost          -- Сведения о закупке.НМЦ, руб.
  %return notice_date_plan       -- Сведения о закупке.Дата публикации извещения.План
  %return notice_date_fact       -- Сведения о закупке.Дата публикации извещения.Факт
  %return result_date_plan       -- Сведения о закупке.Дата подведения итогов.План
  %return result_date_fact       -- Сведения о закупке.Дата подведения итогов.Факт
  %return contract_date_plan     -- Сведения о закупке.Дата заключения контракта(план)
  %return trading_result_name    -- Сведения о закупке.Итоги торгов

  %return agreement_reg_num      -- Сведения о новом контракте/задании.Рег номер документа
  %return agreement_reg_date     -- Сведения о новом контракте/задании.Рег дата документа
  %return performer_short_name   -- Сведения о новом контракте/задании.Исполнитель
  %return agreement_cost         -- Сведения о новом контракте/задании.Сумма контракта
  %return saving_sum             -- Сведения о новом контракте/задании.Сумма экономии
  */
begin
  return query
    with cust as(select --lp.id as customer_id
                        distinct lp.root_id as customer_root_id
                      -- ,lp.fias_district_id
                     --  ,lp.short_name as customer_short_name
                   from nsi.fdc_legal_person lp
                   join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                   join nsi.fdc_role r on pr.role_id=r.id
                  where lp.person_type_id in(1,3)
                   -- and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                    and statement_timestamp() between pr.begin_date and pr.end_date
                    and r.code='CUSTOMER'
                    and (p_customer_id is null or lp.id=p_customer_id)
                  )
        ,omsu_mo as(select --distinct cust.customer_id
                           distinct cust.customer_root_id
                         -- ,cust.customer_short_name
                          ,m.root_id as municipality_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                      join nsi.fdc_legal_person clp on cust.customer_root_id=clp.root_id
                      join nsi.fdc_legal_person_municipality lpm on clp.id= lpm.legal_person_id
                      join nsi.fdc_municipality m on lpm.municipality_id=m.id
                     where r.code='OMSU'
                       and current_date between lpm.start_date and lpm.end_date
                       and statement_timestamp() between pr.begin_date and pr.end_date
                       and p_driveway_category_id = 1
                   )
        ,rcust as(select /*cust.customer_id
                        ,*/cust.customer_root_id
                      --  ,cust.customer_short_name
                    from cust
                    join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                    join nsi.fdc_role r on pr.role_id=r.id
                   where r.code='RUAD'
                     and statement_timestamp() between pr.begin_date and pr.end_date
                     and p_driveway_category_id = 2
                  union
                  select /*cust.customer_id
                        ,*/cust.customer_root_id
                       -- ,cust.customer_short_name
                    from cust
                    join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                    join nsi.fdc_role r on pr.role_id=r.id
                   where r.code='OMSU'
                     and statement_timestamp() between pr.begin_date and pr.end_date
                     and p_driveway_category_id = 1
                  union
                  select /*cust.customer_id
                        ,*/cust.customer_root_id
                       -- ,cust.customer_short_name
                    from cust
                    join nsi.fdc_legal_person clp on cust.customer_root_id=clp.id
                    join nsi.fdc_legal_person_municipality lpm on clp.id=lpm.legal_person_id
                    join nsi.fdc_municipality m on lpm.municipality_id=m.id
                    join omsu_mo on m.root_id = omsu_mo.municipality_root_id
                   where cust.customer_root_id not in(select pr.person_id
                                                        from nsi.fdc_person_role pr
                                                        join nsi.fdc_role r on pr.role_id=r.id
                                                       where r.code in('OMSU','RUAD','MA','TO','KO')
                                                         and statement_timestamp() between pr.begin_date and pr.end_date
                                                     )
                     and current_date between lpm.start_date and lpm.end_date
                     and p_driveway_category_id = 1
                   )
        ,agrm as(select tt.purchase_lot_id
                       ,tt.reg_num
                       ,tt.reg_date
                       ,tt.performer_short_name
                       ,tt.cost
                   from(select agr.purchase_lot_id
                              ,agr.reg_num
                              ,agr.reg_date
                              ,perf.short_name as performer_short_name
                              ,agr.cost
                              ,row_number() over(partition by agr.purchase_lot_id,agr.agr_root_id order by agr.reg_date) rnk
                          from msnow.fdc_agreement agr
                          join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                            and agr.version_date_from between perf.ver_start_date and perf.ver_end_date
                         where agr.purchase_lot_id is not null
                       ) tt
                  where tt.rnk=1
                )
        ,custname as (select distinct on(root_id)
                             root_id as customer_root_id
                            ,short_name as customer_short_name
                        from nsi.fdc_legal_person
                       order by root_id
                               ,ver_start_date desc
                     )
  select custname.customer_short_name
        ,case
           when coalesce(p.notice_date_fact,current_date) - p.notice_date_plan < 0 then 0
           else coalesce(p.notice_date_fact,current_date) - p.notice_date_plan
         end as expiration_days_qty
        ,p.purchase_regnum
        ,p.purchase_name
        ,coalesce(p.cost,0.0) as purchase_cost
        ,p.notice_date_plan
        ,p.notice_date_fact
        ,p.result_date_plan
        ,p.result_date_fact
        ,p.contract_date_plan
        ,trr.name as trading_result_name
        ,agrm.reg_num as agreement_reg_num
        ,agrm.reg_date as agreement_reg_date
        ,agrm.performer_short_name
        ,agrm.cost as agreement_cost
        ,coalesce(p.cost,0.0) - coalesce(agrm.cost,0.0) as saving_sum
    from msnow.fdc_purchase p
    join custname on p.customer_id=custname.customer_root_id
    join rcust on p.customer_id=rcust.customer_root_id
    left join msnow.fdc_trading_result trr on p.trading_result_id=trr.id
    left join agrm on p.id=agrm.purchase_lot_id
   where p.work_category_id=p_work_category_id
     and p.notice_date_plan between p_date_from and p_date_to
     and(p_trading_result_id is null or p.trading_result_id=p_trading_result_id)
     and exists(select null
                  from msnow.fdc_purchase_estimate pe
                  join msnow.fdc_work_type pewt on pe.work_type_id=pewt.id
                 where pe.purchase_lot_id = p.id
                   and pe.is_estimate_sum
                   and pewt.work_category_id=p_work_category_id
               )
     and (not coalesce(p_terms_violation_flag,false) or
          (p_terms_violation_flag and (coalesce(p.notice_date_fact,current_date) - p.notice_date_plan) > 0)
         );
  return;
end
$$;

