CREATE FUNCTION srv_set_fias_local_names()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Актуализирует строки в ods.fdc_as_addrobj_loc после загрузки адресов ФИАС в ods.fdc_as_addrobj
  */
  rec_rc record;
  rec_ref record;

  l_changes_cnt integer;
begin
  /* Убедимся, что секции для указанных в параметре FIAS_REGION_CODE регионы существуют и заполнены. */
  --raise notice 'Checkpoint 1: %',to_char(clock_timestamp(),'hh24:mi:ss');
  perform ods.srv_handle_addrobj_loc_partitions();
  --raise notice 'Checkpoint 2: %',to_char(clock_timestamp(),'hh24:mi:ss');

  if exists(select null
              from ods.srv_address_reference_changes
             where region_code in(select unnest(string_to_array(param_value,','))::integer rc
                                    from parameter.fdc_parameter_md
                                   where param_code='FIAS_REGION_CODE'
                                     and current_date between date_from and date_to
                                 )
           ) then
    with rcp as(select unnest(string_to_array(param_value,','))::integer rc
                  from parameter.fdc_parameter_md
                 where param_code='FIAS_REGION_CODE'
                   and current_date between date_from and date_to
               )
    insert into ods.FDC_AS_ADDROBJ_LOC(ID
                                      ,AO_ID
                                      ,AO_GUID
                                      ,FORMAL_NAME
                                      ,REGION_CODE
                                      ,AUTO_CODE
                                      ,AREA_CODE
                                      ,CITY_CODE
                                      ,CTAR_CODE
                                      ,PLACE_CODE
                                      ,STREET_CODE
                                      ,EXTR_CODE
                                      ,SEXT_CODE
                                      ,OFF_NAME
                                      ,POSTAL_CODE
                                      ,IFNS_FL
                                      ,TERR_IFNS_FL
                                      ,IFNS_UL
                                      ,TERR_IFNS_UL
                                      ,OKATO
                                      ,OKTMO
                                      ,UPDATE_DATE
                                      ,SHORT_NAME
                                      ,AO_LEVEL
                                      ,PARENT_GUID
                                      ,PREV_ID
                                      ,NEXT_ID
                                      ,CODE
                                      ,PLAIN_CODE
                                      ,ACT_STATUS
                                      ,CENT_STATUS
                                      ,OPER_STATUS
                                      ,CURR_STATUS
                                      ,START_DATE
                                      ,END_DATE
                                      ,NORM_DOC
                                      ,LIVE_STATUS
                                     )
              select fias.ID
                    ,fias.AO_ID
                    ,fias.AO_GUID
                    ,fias.FORMAL_NAME
                    ,fias.REGION_CODE
                    ,fias.AUTO_CODE
                    ,fias.AREA_CODE
                    ,fias.CITY_CODE
                    ,fias.CTAR_CODE
                    ,fias.PLACE_CODE
                    ,fias.STREET_CODE
                    ,fias.EXTR_CODE
                    ,fias.SEXT_CODE
                    ,fias.OFF_NAME
                    ,fias.POSTAL_CODE
                    ,fias.IFNS_FL
                    ,fias.TERR_IFNS_FL
                    ,fias.IFNS_UL
                    ,fias.TERR_IFNS_UL
                    ,fias.OKATO
                    ,fias.OKTMO
                    ,fias.UPDATE_DATE
                    ,fias.SHORT_NAME
                    ,fias.AO_LEVEL
                    ,fias.PARENT_GUID
                    ,fias.PREV_ID
                    ,fias.NEXT_ID
                    ,fias.CODE
                    ,fias.PLAIN_CODE
                    ,fias.ACT_STATUS
                    ,fias.CENT_STATUS
                    ,fias.OPER_STATUS
                    ,fias.CURR_STATUS
                    ,fias.START_DATE
                    ,fias.END_DATE
                    ,fias.NORM_DOC
                    ,fias.LIVE_STATUS
                from ods.fdc_as_addrobj fias
                join ods.srv_address_reference_changes mrc on fias.id=mrc.as_addrobj_id
               where mrc.region_code in(select rc
                                          from rcp
                                       )
        on conflict(id) do update set
                     AO_ID    =excluded.AO_ID
                    ,AO_GUID       =excluded.AO_GUID
                    ,FORMAL_NAME    =excluded.FORMAL_NAME
                    ,REGION_CODE    =excluded.REGION_CODE
                    ,AUTO_CODE      =excluded.AUTO_CODE
                    ,AREA_CODE     =excluded.AREA_CODE
                    ,CITY_CODE      =excluded.CITY_CODE
                    ,CTAR_CODE      =excluded.CTAR_CODE
                    ,PLACE_CODE    =excluded.PLACE_CODE
                    ,STREET_CODE    =excluded.STREET_CODE
                    ,EXTR_CODE      =excluded.EXTR_CODE
                    ,SEXT_CODE  =excluded.SEXT_CODE
                    ,OFF_NAME       =excluded.OFF_NAME
                    ,POSTAL_CODE     =excluded.POSTAL_CODE
                    ,IFNS_FL         =excluded.IFNS_FL
                    ,TERR_IFNS_FL     =excluded.TERR_IFNS_FL
                    ,IFNS_UL          =excluded.IFNS_UL
                    ,TERR_IFNS_UL     =excluded.TERR_IFNS_UL
                    ,OKATO           =excluded.OKATO
                    ,OKTMO          =excluded.OKTMO
                    ,UPDATE_DATE    =excluded.UPDATE_DATE
                    ,SHORT_NAME      =excluded.SHORT_NAME
                    ,AO_LEVEL        =excluded.AO_LEVEL
                    ,PARENT_GUID  =excluded.PARENT_GUID
                    ,PREV_ID       =excluded.PREV_ID
                    ,NEXT_ID           =excluded.NEXT_ID
                    ,CODE              =excluded.CODE
                    ,PLAIN_CODE        =excluded.PLAIN_CODE
                    ,ACT_STATUS      =excluded.ACT_STATUS
                    ,CENT_STATUS      =excluded.CENT_STATUS
                    ,OPER_STATUS     =excluded.OPER_STATUS
                    ,CURR_STATUS       =excluded.CURR_STATUS
                    ,START_DATE       =excluded.START_DATE
                    ,END_DATE        =excluded.END_DATE
                    ,NORM_DOC       =excluded.NORM_DOC
                    ,LIVE_STATUS   =excluded.LIVE_STATUS;

     --raise notice 'Checkpoint 3: %',to_char(clock_timestamp(),'hh24:mi:ss');
     for rec_rc in(select unnest(string_to_array(param_value,','))::integer rc
                    from parameter.fdc_parameter_md
                   where param_code='FIAS_REGION_CODE'
                     and current_date between date_from and date_to
                 ) loop
       -- set area_name
       update ods.fdc_as_addrobj_loc l
          set area_name=clc.area_name
         from(select tt.id
                    ,tt.area_name
                from(select ao.id
                           ,l3.formal_name||' '||l3.short_name as area_name
                           ,row_number() over(partition by ao.id order by l3.id DESC) rn
                       from ods.fdc_as_addrobj_loc ao
                       join ods.fdc_as_addrobj_loc l3 on l3.ao_level=3
                                                         and ao.area_code=l3.area_code
                                                         --and l3.end_date between ao.start_date and ao.end_date
                                                         and ao.end_date>=l3.start_date
                                                         and ao.start_date<=l3.end_date
                      where ao.region_code=rec_rc.rc
                        and l3.region_code=rec_rc.rc
                    ) tt
               where tt.rn=1
             ) clc
        where l.id=clc.id
          and l.region_code=rec_rc.rc;
       --raise notice 'Checkpoint 4: %',to_char(clock_timestamp(),'hh24:mi:ss');

       -- set city_name
       update ods.fdc_as_addrobj_loc l
          set city_name = clc.city_name
         from(select tt.id
                    ,tt.city_name
                from(select ao.id
                           ,l4.formal_name||' '||l4.short_name as city_name
                           ,row_number() over(partition by ao.id order by l4.id DESC) rn
                       from ods.fdc_as_addrobj_loc ao
                       join ods.fdc_as_addrobj_loc l4 on l4.ao_level=4
                                                     and ao.area_code=l4.area_code
                                                     and ao.city_code=l4.city_code
                                                     --and l4.end_date between ao.start_date and ao.end_date
                                                     and ao.end_date>=l4.start_date
                                                     and ao.start_date<=l4.end_date
                      where ao.region_code=rec_rc.rc
                        and l4.region_code=rec_rc.rc
                    ) tt where rn=1
             ) clc
        where l.id=clc.id
          and l.region_code=rec_rc.rc;
          --raise notice 'Checkpoint 5: %',to_char(clock_timestamp(),'hh24:mi:ss');

       -- set place_name
       update ods.fdc_as_addrobj_loc l
          set place_name = clc.place_name
         from(select tt.id
                    ,tt.place_name
                from(select ao.id
                           ,l6.formal_name||' '||l6.short_name as place_name
                           ,row_number() over(partition by ao.id order by l6.id DESC) rn
                       from ods.fdc_as_addrobj_loc ao
                       join ods.fdc_as_addrobj_loc l6 on l6.ao_level=6
                                                     and ao.area_code=l6.area_code
                                                     and ao.city_code=l6.city_code
                                                     and ao.place_code=l6.place_code
                                                     --and l6.end_date between ao.start_date and ao.end_date
                                                     and ao.end_date>=l6.start_date
                                                     and ao.start_date<=l6.end_date
                      where ao.region_code=rec_rc.rc
                        and l6.region_code=rec_rc.rc
                    ) tt where rn=1
             ) clc
        where l.id=clc.id
          and l.region_code=rec_rc.rc;
       --raise notice 'Checkpoint 6: %',to_char(clock_timestamp(),'hh24:mi:ss');
   end loop;
   truncate table ods.srv_address_reference_changes;

   -- здесь municipality загрузим
   refresh materialized view nsi.fdc_as_addrobj_hierarchy_mv;

   with mo_name as(select distinct ao.ao_guid
                         ,fm.start_date
                         ,fm.end_date
                         ,m.short_name as municipality_name
                         ,m.id as municipality_id
                     from nsi.fdc_fias_municipality fm
                     join nsi.fdc_municipality m on fm.municipality_id=m.id
                     join ods.fdc_as_addrobj_loc ao on fm.fias_id=ao.id
                    where fm.start_date is not null
                      and fm.end_date is not null
                  )
       ,mo as(select adr.ao_guid
                    ,mo_name.municipality_id
                    ,mo_name.municipality_name
                    ,mo_name.start_date
                    ,mo_name.end_date
                from nsi.fdc_as_addrobj_hierarchy_mv as adr
                join mo_name on adr.top_ao_guid=mo_name.ao_guid
             )
     update ods.fdc_as_addrobj_loc aol
        set municipality_id=chg.municipality_id
           ,municipality_name = chg.municipality_name
       from(select tt.id
                  ,tt.municipality_id
                  ,tt.municipality_name
              from(select mo.municipality_id
                         ,mo.municipality_name
                         ,row_number() over(partition by ao.id order by mo.end_date,mo.municipality_id desc) rn
                         ,ao.id
                     from ods.fdc_as_addrobj_loc ao
                     join mo on ao.ao_guid=mo.ao_guid
                                and mo.start_date<=ao.end_date
                                and mo.end_date >=ao.start_date
                  ) tt
             where tt.rn=1
           ) chg
      where aol.id=chg.id;

  end if;
  return;
end
$$;

