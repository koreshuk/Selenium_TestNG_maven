CREATE FUNCTION fdc_stat_get_work_type_id_wt(p_season_date_from date, p_season_date_to date, p_work_type_id bigint)
  RETURNS SETOF bigint
LANGUAGE plpgsql
AS $$
declare
  /* Функция поиска видов работ, попадающих по датам выполнения в указанный период
    %param p_season_date_from - Дата с
    %param p_season_date_to   - Дата по
    %param p_work_type_id     - Ид вида работы
    %return Идентификаторы работ, попадающих по датам выполнения в указанный период
  */
  rec record;
  l_work_type_ok boolean;
begin
  for rec in(select id
                   ,season_date_from
                   ,season_date_to
               from msnow.fdc_work_type
              where id=p_work_type_id
                and ((season_date_from is null and season_date_to is null)
                      or (season_date_from<=season_date_to)
                    )  
            ) LOOP
    l_work_type_ok:=false;

    if rec.season_date_from is null and rec.season_date_to is null THEN
      l_work_type_ok:=true;
    else
      select true
        into l_work_type_ok
        from msnow.fdc_util_get_dates(p_date_from => p_season_date_from
                                   ,p_date_to   => p_season_date_to
                                   ) flt
            ,msnow.fdc_util_get_dates(p_date_from => rec.season_date_from
                                   ,p_date_to   => rec.season_date_to
                                   ) tbl
       where flt=tbl
       limit 1;
    end if;
    if l_work_type_ok then
      return next rec.id;
    end if;
  end loop;
end
$$;

