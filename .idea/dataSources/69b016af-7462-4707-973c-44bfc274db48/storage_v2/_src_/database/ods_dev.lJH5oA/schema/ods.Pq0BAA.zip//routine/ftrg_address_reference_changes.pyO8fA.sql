CREATE FUNCTION ftrg_address_reference_changes()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
  /* Выполняется в триггере на ods.fdc_as_addrobj
     Сохраняет id добавленных/измененных в процессе обновления ФИАС строк
  */
begin
  if tg_when='AFTER' and tg_level='ROW' and tg_op in('INSERT','UPDATE')  then
    insert into ods.srv_address_reference_changes(as_addrobj_id
                                                 ,region_code
                                                 ) values
      (new.id
      ,new.region_code
      )
      on conflict(as_addrobj_id) do update
        set region_code = excluded.region_code;
  end if;
  return null;
end
$$;

