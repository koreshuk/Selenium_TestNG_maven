CREATE FUNCTION srv_get_segregistry_tab_status(p_driveway_segment_id bigint, OUT registry_tab_code character varying, OUT registry_tab_name character varying, OUT registry_tab_status_code character varying, OUT registry_tab_status_name character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Статусы заполнения вкладок реестра ремонтируемых участков

     %param p_driveway_segment_id - Ид ремонтируемого участка

     %return registry_tab_code        - Код вкладки
     %return registry_tab_name        - Наименование вкладки
     %return registry_tab_status_code - Код статуса заполнения
     %return registry_tab_status_name - Наименование статуса заполнения

  */
  rec record;
  l_status_empty ods.fdc_dw_segregistry_tab_status%rowtype;
  l_status_filled ods.fdc_dw_segregistry_tab_status%rowtype;
  l_status_undef ods.fdc_dw_segregistry_tab_status%rowtype;

  l_total_cnt integer;
  l_not_present_cnt integer;

  l_agreement_id msnow.fdc_agreement.id%type;
begin
  select * into l_status_empty from ods.fdc_dw_segregistry_tab_status where code='EMPTY';
  select * into l_status_filled from ods.fdc_dw_segregistry_tab_status where code='FILLED';
  select * into l_status_undef from ods.fdc_dw_segregistry_tab_status where code='UNDEFINED';

  begin
    select distinct on(a.agr_root_id)
           a.id
      into strict l_agreement_id
      from msnow.fdc_agr_estimate ae
      join msnow.fdc_agreement a on ae.agreement_id=a.id
      join msnow.fdc_agreement_obligation_status agrs on a.agreement_status_id=agrs.id
     where ae.driveway_segment_id=p_driveway_segment_id
       and agrs.code='APPROVED'
     order by a.agr_root_id
             ,a.version_date_from desc;
  exception
    when NO_DATA_FOUND then
      null;
    when TOO_MANY_ROWS then
      raise exception 'Участок ремонта может быть связан только с одним контрактом';
  end;

  for rec in(select id
                   ,code
                   ,name
               from ods.fdc_dw_segregistry_tab
              where intent=1
            ) loop
    registry_tab_code:=rec.code;
    registry_tab_name:=rec.name;
    if rec.code='WORK_SCHEDULE' then
      if exists(select null
                  from msnow.fdc_work_schedule
                 where driveway_segment_id=p_driveway_segment_id
                   and start_date_plan is not null
                   and end_date_plan is not null
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='CONVEYANCE_ACT' then
      if exists(select null
                  from msnow.fdc_segment_conveyance_act a
                  join msnow.fdc_segment_conv_act_file af on a.id=af.segment_conveyance_act_id
                 where a.driveway_segment_id = p_driveway_segment_id
                   and a.convey_date is not null
                  -- and a.piquetage_start is not null
                  -- and a.piquetage_end is not null
                  -- and a.latitude_start is not null
                  -- and a.longitude_start is not null
                  -- and a.latitude_end is not null
                  -- and a.longitude_end is not null
                   and a.ruad_representative_fio is not null
                   and a.ruad_occupation is not null
                   and a.to_representative_fio is not null
                   and a.to_occupation is not null

               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code in('START_WORK_NOTIFICATION','END_WORK_NONIFICATION') then
      if exists(select null
                  from msnow.fdc_work_notification n
                  join msnow.fdc_work_notification_type nt on n.work_notification_type_id=nt.id
                 where n.driveway_segment_id=p_driveway_segment_id
                   and n.file_id is not null
                   and nt.code=case
                                 when rec.code='START_WORK_NOTIFICATION' then '1'
                                 when rec.code='END_WORK_NONIFICATION' then '2'
                               end
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='INGRESS_REGISTRATION' then
      if exists(select null
                  from msnow.fdc_ingress_registration
                 where driveway_segment_id=p_driveway_segment_id
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='WORK_EXECUTE' then null;
      if exists(with wexrt as(select distinct wexi.driveway_segment_id
                                    ,wexi.work_type_id
                                    ,wexa.agr_root_id
                                from msnow.fdc_work_execute wexi
                                join msnow.fdc_agreement wexa on wexi.agreement_id=wexa.id
                               where wexi.is_last_work
                             )
                   select null
                     from(select sum(case
                                       when wex.driveway_segment_id is null then 1
                                       else 0
                                     end
                                    ) as unapplicable
                            from msnow.fdc_agr_estimate ae
                            join msnow.fdc_agreement a on ae.agreement_id=a.id
                            join msnow.fdc_work_type wt on ae.work_type_id=wt.id
                            join msnow.fdc_repair_work_stage wst on wt.repair_work_stage_id=wst.id
                            left join wexrt wex on ae.driveway_segment_id=wex.driveway_segment_id
                                                   and ae.work_type_id=wex.work_type_id
                                                   and a.agr_root_id=wex.agr_root_id
                           where ae.driveway_segment_id=p_driveway_segment_id
                             and a.id=l_agreement_id
                             and wst.code<>'IS_ASPHALT'
                         ) tt
                    where tt.unapplicable=0
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='ASPHALT_JOURNAL' then
      if exists(select null
                  from(select sum(case
                                    when wex.driveway_segment_id is null then 1
                                    else 0
                                  end
                                 ) as unapplicable
                         from msnow.fdc_agr_estimate ae
                         join msnow.fdc_work_type wt on ae.work_type_id=wt.id
                         join msnow.fdc_repair_work_stage wst on wt.repair_work_stage_id=wst.id
                         left join msnow.fdc_asphalt_journal wex on ae.driveway_segment_id=wex.driveway_segment_id
                                                                    and ae.work_type_id=wex.work_type_id
                                                                    and wex.is_last_work
                        where ae.driveway_segment_id=p_driveway_segment_id
                          and wst.code='IS_ASPHALT'
                          and ae.agreement_id=l_agreement_id
                      ) tt
                 where unapplicable=0
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code in('WORK_ASSIGNMENT','COMPETITIVE_SHEET') then
      if exists(with wexrt as(select distinct wexi.driveway_segment_id
                                    ,wexi.work_type_id
                                    ,wexa.agr_root_id
                                from msnow.fdc_work_execute wexi
                                join msnow.fdc_work_status wst on wexi.work_status_id=wst.id
                                join msnow.fdc_agreement wexa on wexi.agreement_id=wexa.id
                               where wexi.is_last_work
                                 and wst.code='ACCEPTED'
                             )
                    ,asph as(select aj.driveway_segment_id
                                   ,aj.work_type_id
                               from msnow.fdc_asphalt_journal aj
                               join msnow.fdc_work_status wst on aj.work_status_id=wst.id
                              where aj.is_last_work
                                and wst.code='ACCEPTED'
                            )
                        select null
                          from(select sum(case
                                            when wexrt.driveway_segment_id is null and asph.driveway_segment_id is null then 1
                                            else 0
                                          end
                                         ) as unapplicable
                                 from msnow.fdc_agr_estimate ae
                                 join msnow.fdc_agreement a on ae.agreement_id=a.id
                                 join msnow.fdc_work_type wt on ae.work_type_id=wt.id
                                 join msnow.fdc_repair_work_stage wst on wt.repair_work_stage_id=wst.id
                                 left join asph on ae.driveway_segment_id=asph.driveway_segment_id
                                                   and ae.work_type_id=asph.work_type_id
                                 left join wexrt on ae.driveway_segment_id=wexrt.driveway_segment_id
                                                    and ae.work_type_id=wexrt.work_type_id
                                                    and a.agr_root_id=wexrt.agr_root_id
                                where ae.driveway_segment_id=p_driveway_segment_id
                                  and ae.agreement_id=l_agreement_id
                              ) tt
                         where unapplicable=0
               ) and
         (rec.code<>'COMPETITIVE_SHEET' or
           exists(select null
                    from msnow.fdc_driveway_segment
                   where id=p_driveway_segment_id
                     and compsheet_creator_fio is not null
                     and compsheet_creator_occupation is not null
                     and compsheet_creator_id is not null
                     and compsheet_auditor_fio is not null
                     and compsheet_auditor_occupation is not null
                     and compsheet_auditor_id is not null
                 )
         ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='LABRADOR_ACT' then
      if exists(select null
                  from msnow.fdc_labrador_act a
                  join msnow.fdc_lab_analysis_result r on a.lab_analysis_result_id=r.id
                 where a.driveway_segment_id=p_driveway_segment_id
                   and r.code='POSITIVE'
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='HIDDEN_ACT' then
      if exists(select null
                  from(select sum(case
                                    when hid.driveway_segment_id is null then 1
                                    else 0
                                  end
                                 ) as unapplicable
                         from msnow.fdc_agr_estimate ae
                         join msnow.fdc_agreement a on ae.agreement_id=a.id
                         join msnow.fdc_work_type wt on ae.work_type_id=wt.id
                         join msnow.fdc_repair_work_stage wst on wt.repair_work_stage_id=wst.id
                         left join msnow.fdc_hidden_work_act hid on ae.driveway_segment_id=hid.driveway_segment_id
                                                                    and wt.id=hid.work_type_id
                        where ae.driveway_segment_id=p_driveway_segment_id
                          and wst.code not in('IS_ADDITIONAL_WORK','IS_BINDING')
                          and ae.agreement_id=l_agreement_id
                      ) tt
                where tt.unapplicable=0
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='EXECUTE_ACT' then
      if exists(select null
                  from msnow.fdc_execute_act a
                  join msnow.fdc_execute_act_status ast on a.status_id=ast.id
                 where a.driveway_segment_id=p_driveway_segment_id
                   and a.act_file_id is not null
                   and ast.code='APPROVED'
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='PAYMENT' then
      if exists(select null
                  from msnow.fdc_payment
                 where driveway_segment_id=p_driveway_segment_id
                   and payment_file_id is not null
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code='ANALYZE_ASPHALT_CUT' then
      with aacmd as(select max(create_date) as max_create_date
                      from msnow.fdc_analyze_asphalt_cut
                     where driveway_segment_id=p_driveway_segment_id
                   )
          select count(1)
                ,sum(case
                         when not geometry_present or not video_present then 1
                         else 0
                       end
                      )
            into l_total_cnt
                ,l_not_present_cnt
            from(select case
                          when aac.geometry_fact is null then false
                          else true
                        end as geometry_present
                       ,case
                          when exists(select null
                                        from msnow.fdc_analyze_asphalt_cut_video aacv
                                       where aacv.analyze_asphalt_cut_id=aac.id
                                     ) then true
                          else false
                        end as video_present
                   from msnow.fdc_analyze_asphalt_cut aac
                   join aacmd on true
                  where aac.driveway_segment_id=p_driveway_segment_id
                    and aac.create_date=aacmd.max_create_date
                ) tt;
      if l_total_cnt > 0 and l_not_present_cnt = 0 then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code = 'REPAIR_EFFECT' then
      if exists(select null
                  from msnow.fdc_segment_repair_effect
                 where driveway_segment_id=p_driveway_segment_id
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    elsif rec.code = 'MARK_LAYON' then
      if exists(select null
                  from msnow.fdc_driveway_segment dws
                  join msnow.fdc_segment_repair_photo srp on dws.id=srp.driveway_segment_id
                 where dws.mark_lay_on
                   and dws.id=p_driveway_segment_id
               ) then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
    else
      registry_tab_status_code :=l_status_undef.code;
      registry_tab_status_name:= l_status_undef.name;
    end if;
    return next;
  end loop;
  return;
end
$$;

