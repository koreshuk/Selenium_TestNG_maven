CREATE FUNCTION fdc_person_pck_get_legal_collision(p_person_id bigint)
  RETURNS SETOF nsi.t_person_collision
LANGUAGE plpgsql
AS $$
begin
  /** Получение списка коллизий для организации (ЮЛ, ИП, Структ. подразд.)
  %usage Используется для получания списка коллизий
  %param p_person_id Ид организации
  %return Список коллизий
  */
  return query select p.id::bigint
                     ,p.root_id::bigint
                     ,p.name::varchar(1024)
                     ,p.inn::varchar(12)
                     ,p.kpp::varchar(9)
                     ,p.ogrn::varchar(15)
                     ,p.legal_address::varchar(512)
                     ,null::date
                     ,null::varchar(255)
                     ,null::varchar(512)
                     ,null::varchar(14)
                     ,CASE
                        when lower(COALESCE(p.name,'~'))=lower(t.name) then true
                        else false
                      end::boolean --color_name
                     ,case
                        when coalesce(p.inn,'~')=t.inn then TRUE
                        else false
                      end::boolean --color_inn
                     ,case
                        when coalesce(p.ogrn,'~')=t.ogrn then true
                        else false
                      end::boolean --color_ogrn
                     ,null::boolean
                     ,null::boolean
                 from nsi.fdc_legal_person t
                     ,nsi.fdc_legal_person p
               where (p.inn = t.inn or p.ogrn = t.ogrn or lower(p.name) = lower(t.name))
                 and p.person_type_id in (nsi.c_sl_organization(), nsi.c_sl_declarant())
                 and p.id <> t.id
                 and t.id = p_person_id
                 and p.ver_end_date is null;
  return;
end;
$$;

