CREATE FUNCTION ftrg_addrobj_loc_dispatcher()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
  /* Выполняется в триггере на ods.fdc_as_addrobj_loc
     Распределяет строки адресов ФИАС в правильные секции.
  */
  l_schema varchar(50);
  l_table_name varchar(50);

  C_TABLE_NAME constant varchar(50):='fdc_as_addrobj_loc';
begin
  l_schema:=tg_table_schema;

  if C_TABLE_NAME = TG_TABLE_NAME then
    if exists(select null
                from pg_class prt
                join pg_namespace prt_ns on prt.relnamespace=prt_ns.oid
               where prt.relkind='r'
                 and prt_ns.nspname = l_schema
                 and prt.relname = TG_TABLE_NAME||'_'||new.region_code::varchar(3)
             ) then
      l_table_name:=TG_TABLE_NAME||'_'||new.region_code::varchar(3);
    else
      return new;--l_table_name:=TG_TABLE_NAME;
    end if;

    if tg_op = 'INSERT' then
      execute
        format('insert into %I.%I(ID
                                 ,AO_ID
                                 ,AO_GUID
                                 ,FORMAL_NAME
                                 ,REGION_CODE
                                 ,AUTO_CODE
                                 ,AREA_CODE
                                 ,CITY_CODE
                                 ,CTAR_CODE
                                 ,PLACE_CODE
                                 ,STREET_CODE
                                 ,EXTR_CODE
                                 ,SEXT_CODE
                                 ,OFF_NAME
                                 ,POSTAL_CODE
                                 ,IFNS_FL
                                 ,TERR_IFNS_FL
                                 ,IFNS_UL
                                 ,TERR_IFNS_UL
                                 ,OKATO
                                 ,OKTMO
                                 ,UPDATE_DATE
                                 ,SHORT_NAME
                                 ,AO_LEVEL
                                 ,PARENT_GUID
                                 ,PREV_ID
                                 ,NEXT_ID
                                 ,CODE
                                 ,PLAIN_CODE
                                 ,ACT_STATUS
                                 ,CENT_STATUS
                                 ,OPER_STATUS
                                 ,CURR_STATUS
                                 ,START_DATE
                                 ,END_DATE
                                 ,NORM_DOC
                                 ,LIVE_STATUS
                                 ,municipality_id
                                 ,municipality_name
                                 ,area_name
                                 ,city_name
                                 ,place_name
                                 ) values($1
                                       ,$2
                                       ,$3
                                       ,$4
                                       ,$5
                                       ,$6
                                       ,$7
                                       ,$8
                                       ,$9
                                       ,$10
                                       ,$11
                                       ,$12
                                       ,$13
                                       ,$14
                                       ,$15
                                       ,$16
                                       ,$17
                                       ,$18
                                       ,$19
                                       ,$20
                                       ,$21
                                       ,$22
                                       ,$23
                                       ,$24
                                       ,$25
                                       ,$26
                                       ,$27
                                       ,$28
                                       ,$29
                                       ,$30
                                       ,$31
                                       ,$32
                                       ,$33
                                       ,$34
                                       ,$35
                                       ,$36
                                       ,$37
                                       ,$38
                                       ,$39
                                       ,$40
                                       ,$41
                                       ,$42
                                       )
                    on conflict(id) do update set AO_ID = $43
                                 ,AO_GUID = $44
                                 ,FORMAL_NAME  = $45
                                 ,REGION_CODE  = $46
                                 ,AUTO_CODE  = $47
                                 ,AREA_CODE  = $48
                                 ,CITY_CODE  = $49
                                 ,CTAR_CODE  = $50
                                 ,PLACE_CODE  = $51
                                 ,STREET_CODE  = $52
                                 ,EXTR_CODE  = $53
                                 ,SEXT_CODE  = $54
                                 ,OFF_NAME  = $55
                                 ,POSTAL_CODE  = $56
                                 ,IFNS_FL  = $57
                                 ,TERR_IFNS_FL  = $58
                                 ,IFNS_UL  = $59
                                 ,TERR_IFNS_UL  = $60
                                 ,OKATO  = $61
                                 ,OKTMO  = $62
                                 ,UPDATE_DATE  = $63
                                 ,SHORT_NAME  = $64
                                 ,AO_LEVEL  = $65
                                 ,PARENT_GUID  = $66
                                 ,PREV_ID   = $67
                                 ,NEXT_ID  = $68
                                 ,CODE   = $69
                                 ,PLAIN_CODE  = $70
                                 ,ACT_STATUS  = $71
                                 ,CENT_STATUS   = $72
                                 ,OPER_STATUS  = $73
                                 ,CURR_STATUS   = $74
                                 ,START_DATE   = $75
                                 ,END_DATE  = $76
                                 ,NORM_DOC  = $77
                                 ,LIVE_STATUS  = $78
                                 ,municipality_id  = $79
                                 ,municipality_name  = $80
                                 ,area_name  = $81
                                 ,city_name  = $82
                                 ,place_name = $83'
               ,l_schema
               ,l_table_name
              )
        using new.ID
             ,new.AO_ID
             ,new.AO_GUID
             ,new.FORMAL_NAME
             ,new.REGION_CODE
             ,new.AUTO_CODE
             ,new.AREA_CODE
             ,new.CITY_CODE
             ,new.CTAR_CODE
             ,new.PLACE_CODE
             ,new.STREET_CODE
             ,new.EXTR_CODE
             ,new.SEXT_CODE
             ,new.OFF_NAME
             ,new.POSTAL_CODE
             ,new.IFNS_FL
             ,new.TERR_IFNS_FL
             ,new.IFNS_UL
             ,new.TERR_IFNS_UL
             ,new.OKATO
             ,new.OKTMO
             ,new.UPDATE_DATE
             ,new.SHORT_NAME
             ,new.AO_LEVEL
             ,new.PARENT_GUID
             ,new.PREV_ID
             ,new.NEXT_ID
             ,new.CODE
             ,new.PLAIN_CODE
             ,new.ACT_STATUS
             ,new.CENT_STATUS
             ,new.OPER_STATUS
             ,new.CURR_STATUS
             ,new.START_DATE
             ,new.END_DATE
             ,new.NORM_DOC
             ,new.LIVE_STATUS
             ,new.municipality_id
             ,new.municipality_name
             ,new.area_name
             ,new.city_name
             ,new.place_name
             ,new.AO_ID
             ,new.AO_GUID
             ,new.FORMAL_NAME
             ,new.REGION_CODE
             ,new.AUTO_CODE
             ,new.AREA_CODE
             ,new.CITY_CODE
             ,new.CTAR_CODE
             ,new.PLACE_CODE
             ,new.STREET_CODE
             ,new.EXTR_CODE
             ,new.SEXT_CODE
             ,new.OFF_NAME
             ,new.POSTAL_CODE
             ,new.IFNS_FL
             ,new.TERR_IFNS_FL
             ,new.IFNS_UL
             ,new.TERR_IFNS_UL
             ,new.OKATO
             ,new.OKTMO
             ,new.UPDATE_DATE
             ,new.SHORT_NAME
             ,new.AO_LEVEL
             ,new.PARENT_GUID
             ,new.PREV_ID
             ,new.NEXT_ID
             ,new.CODE
             ,new.PLAIN_CODE
             ,new.ACT_STATUS
             ,new.CENT_STATUS
             ,new.OPER_STATUS
             ,new.CURR_STATUS
             ,new.START_DATE
             ,new.END_DATE
             ,new.NORM_DOC
             ,new.LIVE_STATUS
             ,new.municipality_id
             ,new.municipality_name
             ,new.area_name
             ,new.city_name
             ,new.place_name
             ;
    elsif tg_op = 'UPDATE' then
      execute
        format('update %I.%I set  AO_ID = $1
                                 ,AO_GUID = $2
                                 ,FORMAL_NAME  = $3
                                 ,REGION_CODE  = $4
                                 ,AUTO_CODE  = $5
                                 ,AREA_CODE  = $6
                                 ,CITY_CODE  = $7
                                 ,CTAR_CODE  = $8
                                 ,PLACE_CODE  = $9
                                 ,STREET_CODE  = $10
                                 ,EXTR_CODE  = $11
                                 ,SEXT_CODE  = $12
                                 ,OFF_NAME  = $13
                                 ,POSTAL_CODE  = $14
                                 ,IFNS_FL  = $15
                                 ,TERR_IFNS_FL  = $16
                                 ,IFNS_UL  = $17
                                 ,TERR_IFNS_UL  = $18
                                 ,OKATO  = $19
                                 ,OKTMO  = $20
                                 ,UPDATE_DATE  = $21
                                 ,SHORT_NAME  = $22
                                 ,AO_LEVEL  = $23
                                 ,PARENT_GUID  = $24
                                 ,PREV_ID   = $25
                                 ,NEXT_ID  = $26
                                 ,CODE   = $27
                                 ,PLAIN_CODE  = $28
                                 ,ACT_STATUS  = $29
                                 ,CENT_STATUS   = $30
                                 ,OPER_STATUS  = $31
                                 ,CURR_STATUS   = $32
                                 ,START_DATE   = $33
                                 ,END_DATE  = $34
                                 ,NORM_DOC  = $35
                                 ,LIVE_STATUS  = $36
                                 ,municipality_id  = $37
                                 ,municipality_name  = $38
                                 ,area_name  = $39
                                 ,city_name  = $40
                                 ,place_name = $41'
              ,l_schema
              ,l_table_name
              )
        using new.AO_ID
             ,new.AO_GUID
             ,new.FORMAL_NAME
             ,new.REGION_CODE
             ,new.AUTO_CODE
             ,new.AREA_CODE
             ,new.CITY_CODE
             ,new.CTAR_CODE
             ,new.PLACE_CODE
             ,new.STREET_CODE
             ,new.EXTR_CODE
             ,new.SEXT_CODE
             ,new.OFF_NAME
             ,new.POSTAL_CODE
             ,new.IFNS_FL
             ,new.TERR_IFNS_FL
             ,new.IFNS_UL
             ,new.TERR_IFNS_UL
             ,new.OKATO
             ,new.OKTMO
             ,new.UPDATE_DATE
             ,new.SHORT_NAME
             ,new.AO_LEVEL
             ,new.PARENT_GUID
             ,new.PREV_ID
             ,new.NEXT_ID
             ,new.CODE
             ,new.PLAIN_CODE
             ,new.ACT_STATUS
             ,new.CENT_STATUS
             ,new.OPER_STATUS
             ,new.CURR_STATUS
             ,new.START_DATE
             ,new.END_DATE
             ,new.NORM_DOC
             ,new.LIVE_STATUS
             ,new.municipality_id
             ,new.municipality_name
             ,new.area_name
             ,new.city_name
             ,new.place_name;
    end if;
  end if;
  if l_table_name = C_TABLE_NAME then
    return new;
  else
    return null;
  end if;
end
$$;

