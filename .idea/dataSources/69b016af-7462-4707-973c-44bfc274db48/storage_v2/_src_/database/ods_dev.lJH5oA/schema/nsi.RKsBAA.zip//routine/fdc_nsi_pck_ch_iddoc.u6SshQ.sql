CREATE FUNCTION fdc_nsi_pck_ch_iddoc(p_root_id bigint, p_identity_doctype_id bigint, p_docseries character varying, p_docnumber character varying, p_issue_date date, p_issue_department character varying, p_department_code character varying, p_event_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
/* Проверка на корректность данных о документе ФЛ*/
begin
  null;
end
$$;

