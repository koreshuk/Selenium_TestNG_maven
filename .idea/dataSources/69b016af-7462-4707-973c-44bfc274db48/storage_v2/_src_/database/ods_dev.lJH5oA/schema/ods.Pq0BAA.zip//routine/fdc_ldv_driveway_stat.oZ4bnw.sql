CREATE FUNCTION fdc_ldv_driveway_stat(p_municipality_id bigint, OUT municipality_name text, OUT driveway_total_cnt integer, OUT driveway_orphan_cnt integer, OUT group_1ch_cnt integer, OUT group_1c_cnt integer, OUT group_1h_cnt integer, OUT group_1_cnt integer, OUT group_other_cnt integer, OUT group_2h_cnt integer, OUT group_2_cnt integer, OUT group_3h_cnt integer, OUT group_3a_cnt integer, OUT group_3_cnt integer, OUT group_inner_cnt integer, OUT group_total_cnt integer, OUT cover_type_i_cnt integer, OUT cover_type_ii_cnt integer, OUT cover_type_iii_cnt integer, OUT cover_type_total_cnt integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Статистика по местным дорогам муниц. района" - Статистика Дороги
  %param p_municipality_id - Ид муниципального района/городского округа
  */
begin
  select d.municipality_name
        ,count(distinct d.id) as driveway_total_cnt
        ,count(distinct d.orphan_object_id) as driveway_orphan_cnt
        ,count(distinct d.grp_1ch) as group_1ch_cnt
        ,count(distinct d.grp_1c) as group_1c_cnt
        ,count(distinct d.grp_1h) as group_1h_cnt
        ,count(distinct d.grp_1) as group_1_cnt
        ,count(distinct d.grp_other) as group_other_cnt
        ,count(distinct d.grp_2h) as group_2h_cnt
        ,count(distinct d.grp_2) as group_2_cnt
        ,count(distinct d.grp_3h) as group_3h_cnt
        ,count(distinct d.grp_3a) as group_3a_cnt
        ,count(distinct d.grp_3) as group_3_cnt
        ,count(distinct d.grp_inner) as group_inner_cnt
        ,count(distinct d.grp_total) as group_total_cnt
        ,count(distinct d.cover_type_i) as cover_type_i_cnt
        ,count(distinct d.cover_type_ii) as cover_type_ii_cnt
        ,count(distinct d.cover_type_iii) as cover_type_iii_cnt
        ,count(distinct d.cover_type_total) as cover_type_total_cnt
    into municipality_name
        ,driveway_total_cnt
        ,driveway_orphan_cnt
        ,group_1ch_cnt
        ,group_1c_cnt
        ,group_1h_cnt
        ,group_1_cnt
        ,group_other_cnt
        ,group_2h_cnt
        ,group_2_cnt
        ,group_3h_cnt
        ,group_3a_cnt
        ,group_3_cnt
        ,group_inner_cnt
        ,group_total_cnt
        ,cover_type_i_cnt
        ,cover_type_ii_cnt
        ,cover_type_iii_cnt
        ,cover_type_total_cnt
    from(select mnc.formal_name||case
                                   when mnc.short_name is not null then ' '||mnc.short_name
                                   else ''
                                 end as municipality_name
               ,odh.id
               ,case odh.is_orphan_object
                  when true then odh.id
                end as orphan_object_id
               ,case grp.code
                  when 'ONE_CH' then odh.id
                end as grp_1ch
               ,case grp.code
                  when 'ONE_C' then odh.id
                end as grp_1c
               ,case grp.code
                  when 'ONE_H' then odh.id
                end as grp_1h
               ,case grp.code
                  when 'ONE' then odh.id
                end as grp_1
               ,case grp.code
                  when 'OTHER' then odh.id
                end as grp_other
               ,case grp.code
                  when 'TWO_H' then odh.id
                end as grp_2h
               ,case grp.code
                  when 'TWO' then odh.id
                end as grp_2
               ,case grp.code
                 when 'THREE_H' then odh.id
                end as grp_3h
               ,case grp.code
                  when 'THREE_A' then odh.id
                end as grp_3a
               ,case grp.code
                  when 'THREE' then odh.id
                end as grp_3
               ,case grp.code
                  when '1' then odh.id
                end as grp_inner
               ,case
                  when grp.id is not null then
                    odh.id
                end as grp_total
               ,case ct.code
                  when 'IMPROVED' then odh.id
                end as cover_type_i
               ,case ct.code
                  when 'TRANSIT' then odh.id
                end as cover_type_ii
               ,case ct.code
                  when 'DIRT_ROAD' then odh.id
                end as cover_type_iii
               ,case
                  when ct.id is not null then odh.id
               end as cover_type_total
           from ods.fdc_object obj
           join ods.fdc_object_type objt on obj.object_type_id=objt.id
           join ods.fdc_object_state objs on obj.object_state_id=objs.id
           join ods.fdc_odh odh on obj.id = odh.id
           join nsi.fdc_legal_person cust on obj.customer_id=cust.id
           join ods.fdc_as_addrobj mnc on cust.fias_district_id=mnc.id
           left join msnow.fdc_maintain_group grp on odh.maintain_group_id=grp.id
           left join msnow.fdc_cover_type ct on odh.cover_type_id=ct.id
          where objt.code='ODH'
            and objs.code='APPROVED'
            and mnc.id=p_municipality_id--24724--?
            and current_date between obj.version_date_from and obj.version_date_to
        ) as d
  group by d.municipality_name;

end
$$;

