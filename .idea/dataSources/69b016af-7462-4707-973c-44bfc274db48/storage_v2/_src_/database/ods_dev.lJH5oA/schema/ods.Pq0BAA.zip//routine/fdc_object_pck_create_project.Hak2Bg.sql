CREATE FUNCTION fdc_object_pck_create_project(p_object_id bigint, p_project_date date)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция создания проекта
  %param    p_object_id         Ид утвержденной версии, на основе которой создается проект
  %param   p_project_date       Дата, с которой создается проект
  %return                       Ид созданного проекта
  */
  r_object ods.fdc_object%rowtype;
  r_object_before ods.fdc_object%rowtype;
  r_object_after ods.fdc_object%rowtype;
  l_object_type_code ods.fdc_object_type.code%type;
  l_date_from_tc timestamp;
  l_is_on_approval boolean;
  l_dup_object boolean;
  l_prev_project_id ods.fdc_object.id%type;
  l_object_id       ods.fdc_object.id%type;
  l_object_piquetage_tab ods.t_object_piquetage[];
  cur record;

begin
  /*fdc_event_pck.event_start( p_event_id        => l_event_id
                           , p_event_type_code => const_core.c_et_add_proj
                           , p_event_category  => const_core.c_ec_obj
                           );*/
  r_object := ods.fdc_object_pck_get_object(p_object_id          => p_object_id
                                           ,p_object_update_date => p_project_date
                                           );
  r_object_before:= r_object;

  select ov.object_type_code
    into strict l_object_type_code
    from ods.fdc_object_v  ov
   where ov.id = p_object_id;

  -- Проверка дат ТС
  l_date_from_tc:=ods.fdc_ods_pck_get_tc_date(p_object_id    => p_object_id
                                             ,p_project_date => p_project_date
                                             );

  if l_date_from_tc is not null and
     l_date_from_tc >= p_project_date then
    raise exception
      'Дата начала действия проекта % должна быть больше даты начала % утвержденного ТС куда входит родитель объекта'
      ,to_char(p_project_date,'dd.mm.yyyy')
      ,to_char(l_date_from_tc,'dd.mm.yyyy');
  end if;

  if p_project_date < r_object.version_date_from+interval '1' day or p_project_date > r_object.version_date_to then
    raise EXCEPTION
      'Дата начала действия проекта выходит за допустимые пределы: % - %'
      ,to_char(r_object.version_date_from+interval '1' day,'dd.mm.yyyy')
      ,to_char(r_object.version_date_to,'dd.mm.yyyy');
  end if;

  select case COALESCE(min(1),0)
           when 1 then true
           else false
         end
    into strict l_is_on_approval
    from ods.fdc_object o
   where p_project_date between o.version_date_from and o.version_date_to
     and o.object_state_id = ods.c_os_submited()
     and root_id = r_object_before.root_id;
  if l_is_on_approval then
    raise exception 'На данную дату есть версия в статусе "На согласовании". Проект создать нелья';
  end if;

  -- Поиск предыдущей версии в статусе проект
  select min(o.id)
    into strict l_prev_project_id
    from ods.fdc_object o
   where p_project_date between o.version_date_from and o.version_date_to
     and o.object_state_id = ods.c_os_project()
     and o.parent_version_id = r_object_before.parent_version_id;

  -- Поиск даты начала следующей версии в статусе проект
  select date_trunc('day',min(o.version_date_from))  - interval '1' second
    into strict r_object.version_date_to
    from ods.fdc_object o
   where o.parent_version_id = r_object_before.parent_version_id
     and o.version_date_from >= p_project_date
     and o.object_state_id = ods.c_os_project();

  -- ODSX-712 Если нет последующей версии в статусе проект дата окончания берется из родител
  if r_object.version_date_to is null then
    select o.version_date_to
      into strict r_object.version_date_to
      from ods.fdc_object o
     where o.id = p_object_id;
  end if;

  -- Проверим, нет ли уже проекта на заданную дату
  select case COALESCE(min(o.id),0)
           when 0 then false
           else true
         end
    into strict l_dup_object
    from ods.fdc_object o
   where o.version_date_from = p_project_date
     and o.root_id = r_object_before.root_id;

  if l_dup_object then
    raise exception 'Для выбранного периода действия уже существует версия данного объекта. Измените период действия версии для успешного сохранения объекта';
  end if;

  r_object.id                 := null;
  r_object.approval_id        := null;
  r_object.parent_version_id  := p_object_id;
  r_object.version_date_from  := date_trunc('day',p_project_date);
  r_object.update_date        := date_trunc('day',statement_timestamp());
  r_object.version_date_from  := date_trunc('day',p_project_date);

  select coalesce(min(o.version_date_from)-interval '1' day, r_object.version_date_to)
    into strict r_object.version_date_to
    from ods.fdc_object o
   where o.parent_version_id = p_object_id
     and o.version_date_from > p_project_date
     and o.object_state_id = ods.c_os_project();

  r_object.object_state_id    := ods.c_os_project();

  --> Вставим новую версию
  r_object:=ods.fdc_object_pck_insert_object(p_object=>r_object);

  update ods.fdc_object
     set version_date_to = date_trunc('day',p_project_date - interval '1' day)
   where id = l_prev_project_id;

  --> Получим версию объекта со всеми изменениями для целей аудита
  r_object_after := ods.fdc_object_pck_get_object(p_object_id          => r_object.id
                                                 ,p_object_update_date => null
                                                 );

  for cur in select l.object_id_2 object_id
                   ,l.object_link_rule_id
               from ods.fdc_object_link l
                   ,ods.fdc_object_link_rule lr
              where l.object_id_1 = p_object_id
                and lr.id = l.object_link_rule_id
                and lr.link_type_id = ods.c_lt_inclusion_full()
              loop
     with recursive ol1(id
                       ,parent_version_id
                       ,version_date_from
                       ,version_date_to
                       ,object_state_id
                       ,level
                      ) as(select o1.id
                                 ,o1.parent_version_id
                                 ,o1.version_date_from
                                 ,o1.version_date_to
                                 ,o1.object_state_id
                                 ,1
                             from ods.fdc_object o1
                            where o1.id=cur.object_id
                           union
                           select o2.id
                                 ,o2.parent_version_id
                                 ,o2.version_date_from
                                 ,o2.version_date_to
                                 ,o2.object_state_id
                                 ,level+1
                             from ods.fdc_object o2
                             join ol1 on ol1.id=o2.parent_version_id
                          )
    select min(ol1.id)
      into strict l_object_id
      from ol1
     where p_project_date between ol1.version_date_from and ol1.version_date_to
       and ol1.object_state_id = ods.c_os_project();

    if l_object_id is null then
      with recursive ol1(id
                        ,parent_version_id
                        ,version_date_from
                        ,version_date_to
                        ,object_state_id
                        ,level
                       ) as(select o1.id
                                  ,o1.parent_version_id
                                  ,o1.version_date_from
                                  ,o1.version_date_to
                                  ,o1.object_state_id
                                  ,1
                              from ods.fdc_object o1
                             where o1.id=cur.object_id
                            union
                            select o2.id
                                  ,o2.parent_version_id
                                  ,o2.version_date_from
                                  ,o2.version_date_to
                                  ,o2.object_state_id
                                  ,level+1
                              from ods.fdc_object o2
                              join ol1 on ol1.id=o2.parent_version_id
                           )
    select min(ol1.id)
      into strict l_object_id
      from ol1
     where p_project_date between ol1.version_date_from and ol1.version_date_to
       and ol1.object_state_id = ods.c_os_approved();
    end if;
  end loop;

  insert into ods.fdc_object_address(id
                                    ,object_id
                                    ,address_id
                                    ,address_detail
                                    )
    select nextval('ods.fdc_object_address_seq')
          ,r_object.id
          ,ft.address_id
          ,ft.address_detail
      from ods.fdc_object_pck_get_object_address(p_object_id) ft;

  select array_agg(ROW(op.id
                      ,op.object_id
                      ,op.piquetage_type_id
                      ,op.piquetage_type_code
                      ,op.piquetage_type_name
                      ,op.piq_value
                      ,op.side_id
                      ,op.side_code
                      ,op.side_name
                      ,op.axes_type_id
                      ,op.axes_type_code
                      ,op.axes_type_name
                      ,op.sort_id
                      )::t_object_piquetage
                  )
    into l_object_piquetage_tab
    from ods.fdc_object_pck_get_object_piquetage(p_object_id => p_object_id) op;

  perform ods.fdc_object_pck_add_object_piquetage_list(p_object_id            => r_object.id
                                                      ,p_object_piquetage_tab => l_object_piquetage_tab
                                                      );

  /*fdc_event_pck.event_finish(p_event_id  => l_event_id
                            ,p_comment   => 'package=fdc_object_pck' || chr(10) ||
                                            'method=сreate_project'  || chr(10)
                            ,p_source_id => r_object.id
                            );*/

  return r_object.id;
end
$$;

