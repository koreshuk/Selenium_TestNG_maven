CREATE FUNCTION rep_maintain_dws_overview_det(p_detail_column text, p_session_id character varying, p_period integer, p_work_status_id bigint DEFAULT NULL::bigint, p_driveway_category_id bigint DEFAULT NULL::bigint, p_municipality_id bigint DEFAULT NULL::bigint, p_owner_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, p_performer_id bigint DEFAULT NULL::bigint, p_season_id bigint DEFAULT NULL::bigint, p_work_type_id bigint DEFAULT NULL::bigint, p_maintain_group_id bigint DEFAULT NULL::bigint, p_period_date date DEFAULT NULL::date, p_period_from date DEFAULT NULL::date, p_period_to date DEFAULT NULL::date)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Витрина «Мониторинг выполнения работ по содержанию»
     Детализация

     %param p_detail_column          - Наименование колонки по которой выводится детализация
                                       (ПЗ_Мониторинг выполнения работ по содержанию, Таблица 1, Физическое наименование атрибута)
     %param p_session_id             - Ид сессии
     %param p_period                 - Период
                                         - 1 На дату (p_period_date)
                                         - 2 Конкретный период (p_period_from - p_period_to)
     %param p_work_status_id         - Статус работ
     %param p_driveway_category_id   - Балансовая принадлежность
     %param p_municipality_id        - Муниципальное образование
     %param p_owner_id               - Балансодержатель
     %param p_customer_id            - Заказчик
     %param p_performer_id           - Исполнитель
     %param p_season_id              - Сезон
     %param p_work_type_id           - Вид работы
     %param p_maintain_group_id      - Группа по содержанию
     %param p_period_date            - Дата
     %param p_period_from            - Период с
     %param p_period_to              - Период по

  */
  C_NOTEXISTS_ID constant bigint:=-1;

  l_performer_root_id nsi.fdc_legal_person.root_id%type;
  l_owner_root_id nsi.fdc_legal_person.root_id%type;
  l_customer_root_id nsi.fdc_legal_person.root_id%type;
  l_work_status_code msnow.fdc_work_status.code%type;
  l_municipality_root_id nsi.fdc_municipality.root_id%type;

  l_current_date date:=current_date;
  l_detail_column text:=lower(p_detail_column);

  l_quadriple msnow.t_mdws_overview_quadriple[];
begin

  delete from msnow.fdc_rep_maintodh_overview_detf where session_id=p_session_id;
  delete from msnow.fdc_rep_maintodh_overview_detf where set_date < current_date -2;
  delete from msnow.fdc_rep_maintodh_overview_detw where session_id=p_session_id;
  delete from msnow.fdc_rep_maintodh_overview_detw where set_date < current_date -2;

  if p_performer_id is not null then
    begin
      select root_id
        into strict l_performer_root_id
        from nsi.fdc_legal_person
       where id=p_performer_id;
    exception
      when NO_DATA_FOUND then
        l_performer_root_id:=C_NOTEXISTS_ID;
    end;
  else
    l_performer_root_id:=null;
  end if;

  if p_owner_id is not null then
    begin
      select root_id
        into strict l_owner_root_id
        from nsi.fdc_legal_person
       where id=p_owner_id;
    exception
      when NO_DATA_FOUND then
        l_owner_root_id:=C_NOTEXISTS_ID;
    end;
  else
    l_owner_root_id:=null;
  end if;

  if p_customer_id is not null then
    begin
      select root_id
        into strict l_customer_root_id
        from nsi.fdc_legal_person
       where id=p_customer_id;
    exception
      when NO_DATA_FOUND then
        l_customer_root_id:=C_NOTEXISTS_ID;
    end;
  else
    l_customer_root_id:=null;
  end if;

  if p_work_status_id is not null then
    begin
      select code
        into strict l_work_status_code
        from msnow.fdc_work_status
       where id=p_work_status_id;
    exception
      when NO_DATA_FOUND then
        null;
    end;
  end if;
  if p_municipality_id is not null then
    begin
      select root_id
        into l_municipality_root_id
        from nsi.fdc_municipality
       where id=p_municipality_id;
    exception
      when NO_DATA_FOUND then
        null;
    end;
  end if;

  if l_detail_column in('money_plan','money_fact','money_differ_sum','money_differ_percent') then
    with odh_mun as(select odhf.id
                    from ods.fdc_object objf
                    join ods.fdc_odh odhf on objf.id=odhf.id
                    join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                    join nsi.fdc_municipality m on fias.municipality_id=m.id
                   where m.root_id=l_municipality_root_id
                  union
                  select odhf.id
                    from ods.fdc_object objf
                    join ods.fdc_odh odhf on objf.id=odhf.id
                    join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                    join nsi.fdc_municipality m on fias.municipality_id=m.id
                   where m.root_id=l_municipality_root_id
                 )

      ,estok as(select distinct ae.agreement_id
                  from msnow.fdc_agr_estimate ae
                  join msnow.fdc_work_type aewt on ae.work_type_id=aewt.id
                 where ae.is_estimate_sum
                   and(p_season_id is null or aewt.season_id = p_season_id)
                   and(p_work_type_id is null or ae.work_type_id=p_work_type_id)
               )
      ,agrodhok as(select distinct ao.argeement_id
                     from msnow.fdc_agreement_object ao
                     join ods.fdc_odh odh on ao.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                     left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                    where(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                      and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                      and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                      and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                      and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
                  )
      ,v5 as(select aa.customer_root_id
                   ,aa.performer_root_id
                   ,aa.agreement_root_id
                   ,max(aa.payment_date_plan) as payment_date_plan
                   ,aa.driveway_category_code
                   ,sum(aa.money_plan) as money_plan
               from(select agr.customer_id as customer_root_id
                          ,agr.performer_id as performer_root_id
                          ,agr.agr_root_id as agreement_root_id
                          ,case
                             when exists(select null
                                           from nsi.fdc_person_role pr
                                           join nsi.fdc_role r on pr.role_id=r.id
                                          where pr.person_id=agr.customer_id
                                            and r.code='RUAD'
                                        ) then 'REGION_INTERMUNICIPAL'
                             else 'LOCAL'
                           end as driveway_category_code
                          ,cdoc.cost_doc_date + 10 as payment_date_plan
                          ,cdoc.report_period_cost_vat as money_plan
                      from msnow.fdc_cost_doc cdoc
                      join msnow.fdc_agreement agr on cdoc.agreement_id = agr.id
                      join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                      join estok on agr.id=estok.agreement_id
                      join agrodhok on agr.id=agrodhok.argeement_id
                     where wc.code='MAINTAIN'
                       and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                       and((p_period=1 and (p_period_date is null or ((p_period_date between agr.version_date_from and agr.version_date_to) and
                                                                       cdoc.cost_doc_date + 10<=p_period_date
                                                                     )
                                            )
                           ) or
                           (p_period=2 and (agr.version_date_from<=p_period_to and
                                            agr.version_date_to>=p_period_from
                                           )
                                       and cdoc.cost_doc_date + 10 between p_period_from and p_period_to
                            )
                          )
                   ) aa
              group by aa.customer_root_id
                      ,aa.performer_root_id
                      ,aa.agreement_root_id
                      --,aa.payment_date_plan
                      ,aa.driveway_category_code
            )
      ,v6 as(select aa.customer_root_id
                   ,aa.performer_root_id
                   ,aa.agreement_root_id
                   ,aa.driveway_category_code
                   ,max(aa.payment_date_fact) as payment_date_fact
                   ,sum(aa.money_fact) as money_fact
               from(select agr.customer_id as customer_root_id
                          ,agr.performer_id as performer_root_id
                          ,agr.agr_root_id as agreement_root_id
                          ,case
                             when exists(select null
                                           from nsi.fdc_person_role pr
                                           join nsi.fdc_role r on pr.role_id=r.id
                                          where pr.person_id=agr.customer_id
                                            and r.code='RUAD'
                                        ) then 'REGION_INTERMUNICIPAL'
                             else 'LOCAL'
                           end as driveway_category_code
                          ,p.payment_date as payment_date_fact
                          ,p.amount as money_fact
                      from msnow.fdc_payment p
                      join msnow.fdc_agreement agr on p.agreement_id = agr.id
                      join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                      join estok on agr.id=estok.agreement_id
                      join agrodhok on agr.id=agrodhok.argeement_id
                     where wc.code='MAINTAIN'
                       and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                       and((p_period=1 and (p_period_date is null or ((p_period_date between agr.version_date_from and agr.version_date_to) and
                                                                       p.payment_date<=p_period_date
                                                                      )
                                            )
                          ) or
                          (p_period=2 and (agr.version_date_from<=p_period_to and
                                           agr.version_date_to>=p_period_from
                                           )
                                      and p.payment_date between p_period_from and p_period_to
                          )
                         )
                   ) aa
              group by aa.customer_root_id
                      ,aa.performer_root_id
                      ,aa.agreement_root_id
                      --,aa.payment_date_fact
                      ,aa.driveway_category_code
            )

        insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETF(SESSION_ID
                                                        ,SET_DATE
                                                        ,DETAIL_COLUMN
                                                        ,CUSTOMER_ROOT_ID
                                                        ,CUSTOMER_ID
                                                        ,CUSTOMER_NAME
                                                        ,PERFORMER_ROOT_ID
                                                        ,PERFORMER_ID
                                                        ,PERFORMER_NAME
                                                        ,AGREEMENT_ROOT_ID
                                                        ,AGREEMENT_ID
                                                        ,AGREEMENT
                                                        ,MONEY_PLAN
                                                        ,PAYMENT_DATE_PLAN
                                                        ,PAYMENT_DATE_FACT
                                                        ,MONEY_FACT
                                                        ,MONEY_DIFF
                                                        ,ID
                                                       )

         select p_session_id
               ,l_current_date
               ,l_detail_column
               ,dtl.customer_root_id
               ,dtl.customer_id
               ,dtl.customer_name
               ,dtl.performer_root_id
               ,dtl.performer_id
               ,dtl.performer_name
               ,dtl.agreement_root_id
               ,dtl.agreement_id
               ,dtl.agreement
               ,coalesce(dtl.money_plan,0.0) as money_plan
               ,dtl.payment_date_plan
               ,dtl.payment_date_fact
               ,coalesce(dtl.money_fact,0.0) as money_fact
               ,coalesce(dtl.money_fact,0.0) - coalesce(dtl.money_plan,0.0) as money_diff
               ,dtl.customer_id -- сурогатный Ид
           from(select v5.customer_root_id
                      ,cust.id as customer_id
                      ,cust.short_name as customer_name
                      ,v5.performer_root_id
                      ,perf.id as performer_id
                      ,perf.short_name as performer_name
                      ,v5.agreement_root_id
                      ,agr.id as agreement_id
                      ,'('||agrt.name||') '||
                       agr.reg_num||' '||
                       cust.short_name||' '||
                       agrwc.name as agreement
                      ,v5.money_plan
                      ,v5.payment_date_plan
                      ,(select max(payment_date_fact)
                          from v6
                         where v6.customer_root_id = v5.customer_root_id
                           and v6.performer_root_id = v5.performer_root_id
                           and v6.agreement_root_id = v5.agreement_root_id
                          -- and v6.payment_date_fact <= v5.payment_date_plan
                       ) as payment_date_fact
                      ,(select sum(money_fact)
                          from v6
                         where v6.customer_root_id = v5.customer_root_id
                           and v6.performer_root_id = v5.performer_root_id
                           and v6.agreement_root_id = v5.agreement_root_id
                         --  and v6.payment_date_fact <= v5.payment_date_plan
                       ) as money_fact
                  from v5
                  join msnow.fdc_driveway_category dwc on v5.driveway_category_code=dwc.code
                  join msnow.fdc_agreement agr on v5.agreement_root_id=agr.agr_root_id
                                                  and v5.payment_date_plan between agr.version_date_from and agr.version_date_to
                  join msnow.fdc_agreement_obligation_status agrs on agr.agreement_status_id = agrs.id

                  left join nsi.fdc_legal_person cust on v5.customer_root_id=cust.root_id
                                                         and v5.payment_date_plan between cust.ver_start_date and cust.ver_end_date
                  left join nsi.fdc_legal_person perf on v5.performer_root_id=perf.root_id
                                                         and v5.payment_date_plan between perf.ver_start_date and perf.ver_end_date

                  left join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
                  left join msnow.fdc_work_category agrwc on agr.work_category_id=agrwc.id
                 where agrs.code='APPROVED'
                   and (p_driveway_category_id is null or dwc.id=p_driveway_category_id)
               ) dtl;
  elsif l_detail_column = 'regul_plan_count' then -- 1
    with wex_agg as(select wa.driveway_id
                          ,wa.scheduled_work_plan_date_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.scheduled_work_plan_date_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.scheduled_work_plan_date_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.scheduled_work_plan_date_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.scheduled_work_plan_date_id

                       )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
     insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                     ,SET_DATE
                                                     ,DETAIL_COLUMN
                                                     ,ID
                                                     ,ODH_NAME
                                                     ,CUSTOMER_ID
                                                     ,CUSTOMER_NAME
                                                     ,PERFORMER_ID
                                                     ,PERFORMER_NAME
                                                     ,WORK_TYPE_ID
                                                     ,WORK_TYPE_NAME
                                                     ,MAINTAIN_GROUP_ID
                                                     ,MAINTAIN_GROUP_NAME
                                                     ,WORK_VOLUME_PLAN
                                                     ,WORK_VOLUME_FACT
                                                     ,MEASURE_UNIT_ID
                                                     ,MEASURE_UNIT_NAME
                                                     ,PLAN_WORK_DATE
                                                     ,FACT_WORK_DATE
                                                     ,SEASON_ID
                                                     ,SEASON_NAME
                                                     ,WORK_EXECUTE_ID
                                                     )

               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,odh.id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,null as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,swpd.performance_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                        and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                 left join wex_agg on wex_agg.driveway_id = odh.id
                                      and wex_agg.scheduled_work_plan_date_id = swpd.id
                                      --and wex_agg.customer_root_id = dagr.customer_id
                                      --and wex_agg.performer_root_id = dagr.performer_id
                                      --and wex_agg.work_type_id = swp.work_type_id
                                      --and wex_agg.work_date = swpd.performance_date
                where dist.work_plan_approved
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun));
  elsif l_detail_column = 'regul_fact_count' then   --2
    with wex_agg as(select wa.driveway_id
                          ,wa.scheduled_work_plan_date_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.scheduled_work_plan_date_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.scheduled_work_plan_date_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.scheduled_work_plan_date_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.scheduled_work_plan_date_id

                       )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
     insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                     ,SET_DATE
                                                     ,DETAIL_COLUMN
                                                     ,ID
                                                     ,ODH_NAME
                                                     ,CUSTOMER_ID
                                                     ,CUSTOMER_NAME
                                                     ,PERFORMER_ID
                                                     ,PERFORMER_NAME
                                                     ,WORK_TYPE_ID
                                                     ,WORK_TYPE_NAME
                                                     ,MAINTAIN_GROUP_ID
                                                     ,MAINTAIN_GROUP_NAME
                                                     ,WORK_VOLUME_PLAN
                                                     ,WORK_VOLUME_FACT
                                                     ,MEASURE_UNIT_ID
                                                     ,MEASURE_UNIT_NAME
                                                     ,PLAN_WORK_DATE
                                                     ,FACT_WORK_DATE
                                                     ,SEASON_ID
                                                     ,SEASON_NAME
                                                     ,WORK_EXECUTE_ID
                                                     )

               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,odh.id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,null as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,swpd.performance_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join wex_agg on wex_agg.driveway_id = odh.id
                                 and wex_agg.scheduled_work_plan_date_id = swpd.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                        and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id

                where dist.work_plan_approved
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun));
  elsif l_detail_column in('regul_differ_count','regul_differ_percent') then --  diff
    with wex_agg as(select wa.driveway_id
                          ,wa.scheduled_work_plan_date_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.scheduled_work_plan_date_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.scheduled_work_plan_date_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.scheduled_work_plan_date_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.scheduled_work_plan_date_id

                       )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
     insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                     ,SET_DATE
                                                     ,DETAIL_COLUMN
                                                     ,ID
                                                     ,ODH_NAME
                                                     ,CUSTOMER_ID
                                                     ,CUSTOMER_NAME
                                                     ,PERFORMER_ID
                                                     ,PERFORMER_NAME
                                                     ,WORK_TYPE_ID
                                                     ,WORK_TYPE_NAME
                                                     ,MAINTAIN_GROUP_ID
                                                     ,MAINTAIN_GROUP_NAME
                                                     ,WORK_VOLUME_PLAN
                                                     ,WORK_VOLUME_FACT
                                                     ,MEASURE_UNIT_ID
                                                     ,MEASURE_UNIT_NAME
                                                     ,PLAN_WORK_DATE
                                                     ,FACT_WORK_DATE
                                                     ,SEASON_ID
                                                     ,SEASON_NAME
                                                     ,WORK_EXECUTE_ID
                                                     )

               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,odh.id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,null as work_volume_plan
                     --,wex_agg.work_volume as work_volume_fact
                     ,null::double precision as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,swpd.performance_date as plan_work_date
                     --,wex_agg.work_date as fact_work_date
                     ,NULL::date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     --,wex_agg.work_execute_id
                     ,null::bigint as work_execute_id
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
               --  join wex_agg on wex_agg.driveway_id = odh.id
               --                  and wex_agg.scheduled_work_plan_date_id = swpd.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                        and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id

                where dist.work_plan_approved
                  and obj.driveway_category_id is not null
                  and not exists(select null
                                   from wex_agg
                                  where wex_agg.driveway_id = odh.id
                                    and wex_agg.scheduled_work_plan_date_id = swpd.id
                                )
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun));
  elsif l_detail_column='actual_plan_count' then -- 3
/*    with wex_agg as(select wex.driveway_id
                          ,agr.customer_id as customer_root_id
                          ,agr.performer_id as performer_root_id
                          ,wex.work_type_id
                          ,date(wex.work_date) as work_date
                          ,sum(wex.work_volume) as work_volume
                          ,max(wex.id) as work_execute_id
                      from msnow.fdc_work_execute wex
                      join msnow.fdc_agreement agr on wex.agreement_id=agr.id
                     group by wex.driveway_id
                             ,agr.customer_id
                             ,agr.performer_id
                             ,wex.work_type_id
                             ,date(wex.work_date)
                   )*/
    with wex_agg as(select wa.driveway_id
                          ,wa.planed_work_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.planed_work_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.planed_work_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.planed_work_id is not null
                           ) wa
                     group by wa.driveway_id
                             ,wa.planed_work_id

                   )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
            insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                            ,SET_DATE
                                                            ,DETAIL_COLUMN
                                                            ,ID
                                                            ,ODH_NAME
                                                            ,CUSTOMER_ID
                                                            ,CUSTOMER_NAME
                                                            ,PERFORMER_ID
                                                            ,PERFORMER_NAME
                                                            ,WORK_TYPE_ID
                                                            ,WORK_TYPE_NAME
                                                            ,MAINTAIN_GROUP_ID
                                                            ,MAINTAIN_GROUP_NAME
                                                            ,WORK_VOLUME_PLAN
                                                            ,WORK_VOLUME_FACT
                                                            ,MEASURE_UNIT_ID
                                                            ,MEASURE_UNIT_NAME
                                                            ,PLAN_WORK_DATE
                                                            ,FACT_WORK_DATE
                                                            ,SEASON_ID
                                                            ,SEASON_NAME
                                                            ,WORK_EXECUTE_ID
                                                            )
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,pw.driveway_id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,pw.work_volume as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,pw.work_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_planed_work pw
                 join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                 join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                 join ods.fdc_odh odh on pw.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                        and pw.work_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                 left join wex_agg on wex_agg.driveway_id = odh.id
                                      and wex_agg.planed_work_id=pw.id
                                     -- and wex_agg.customer_root_id = agr.customer_id
                                     -- and wex_agg.performer_root_id = agr.performer_id
                                     -- and wex_agg.work_type_id = pw.work_type_id
                                     -- and wex_agg.work_date = pw.work_date
                where wc.code='MAINTAIN'
                  and pws.code in ('APPROVED','DONE')
                  and pw.maintenance_route_id is null
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                  and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                       (p_period_to is null or pw.work_date<=p_period_to)
                      )
                     )
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
               union all
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,tt.id
                     ,tt.odh_name
                     ,tt.customer_id
                     ,tt.customer_name
                     ,tt.performer_id
                     ,tt.performer_name
                     ,tt.work_type_id
                     ,tt.work_type_name
                     ,tt.maintain_group_id
                     ,tt.maintain_group_name
                     ,tt.work_volume_plan
                     ,tt.work_volume_fact
                     ,tt.measure_unit_id
                     ,tt.measure_unit_name
                     --,swpd.performance_date as plan_work_date
                     ,tt.plan_work_date
                     ,tt.fact_work_date
                     ,tt.season_id
                     ,tt.season_name
                     ,tt.work_execute_id
                 from(select disto.odh_id as id
                             ,dobj.name as odh_name
                             ,dcust.id as customer_id
                             ,dcust.short_name as customer_name
                             ,perf.id as performer_id
                             ,perf.short_name as performer_name
                             ,wt.id as work_type_id
                             ,wt.name as work_type_name
                             ,dodh.maintain_group_id
                             ,mtg.name as maintain_group_name
                             ,dcalc.roadway_area/7000.0 as work_volume_plan
                             ,wex_agg.work_volume as work_volume_fact
                             ,swt.measure_unit_id
                             ,mu.name as measure_unit_name
                             --,swpd.performance_date as plan_work_date
                             ,pw.work_date as plan_work_date
                             ,wex_agg.work_date as fact_work_date
                             ,wt.season_id
                             ,ssn.name as season_name
                             ,wex_agg.work_execute_id
                             ,row_number() over(partition by disto.odh_id,pw.id) rn
                         from msnow.fdc_planed_work pw
                         join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                         join msnow.fdc_work_type wt on pw.work_type_id=wt.id--!!
                         join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                         join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                         join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                         join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                         join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                         join ods.fdc_odh dodh on disto.odh_id=dodh.id
                         join ods.fdc_object dobj on dodh.id=dobj.id
                         join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                         join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                         join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                         left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                         left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                         left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                                and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                         left join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                         left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                         left join msnow.fdc_maintain_group mtg on dodh.maintain_group_id=mtg.id
                         left join msnow.fdc_season ssn on wt.season_id=ssn.id
                         left join wex_agg on wex_agg.driveway_id = dodh.id
                                              and wex_agg.planed_work_id = pw.id
                                              --and wex_agg.customer_root_id = dagr.customer_id
                                              --and wex_agg.performer_root_id = dagr.performer_id
                                              --and wex_agg.work_type_id = swp.work_type_id
                                              --and wex_agg.work_date = swpd.performance_date
                                              --and wex_agg.work_date = pw.work_date
                        where pw.driveway_id is null
                          and dobj.driveway_category_id is not null
                          and wc.code='MAINTAIN'
                          and pws.code in ('APPROVED','DONE')
                          and dist.work_plan_approved
                          and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                          and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                          and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                          and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                          and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                          and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                          and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                          and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                          and(p_season_id is null or wt.season_id = p_season_id)
                          and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                              (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                              (p_period_to is null or pw.work_date<=p_period_to)
                              )
                             )
                     ) tt
                where tt.rn=1;
  elsif l_detail_column='actual_fact_count' then -- 4
/*    with wex_agg as(select wex.driveway_id
                          ,agr.customer_id as customer_root_id
                          ,agr.performer_id as performer_root_id
                          ,wex.work_type_id
                          ,date(wex.work_date) as work_date
                          ,sum(wex.work_volume) as work_volume
                          ,max(wex.id) as work_execute_id
                      from msnow.fdc_work_execute wex
                      join msnow.fdc_agreement agr on wex.agreement_id=agr.id
                     group by wex.driveway_id
                             ,agr.customer_id
                             ,agr.performer_id
                             ,wex.work_type_id
                             ,date(wex.work_date)
                   )*/
    with wex_agg as(select wa.driveway_id
                          ,wa.planed_work_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.planed_work_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.planed_work_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.planed_work_id is not null
                           ) wa
                     group by wa.driveway_id
                             ,wa.planed_work_id

                   )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
            insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                            ,SET_DATE
                                                            ,DETAIL_COLUMN
                                                            ,ID
                                                            ,ODH_NAME
                                                            ,CUSTOMER_ID
                                                            ,CUSTOMER_NAME
                                                            ,PERFORMER_ID
                                                            ,PERFORMER_NAME
                                                            ,WORK_TYPE_ID
                                                            ,WORK_TYPE_NAME
                                                            ,MAINTAIN_GROUP_ID
                                                            ,MAINTAIN_GROUP_NAME
                                                            ,WORK_VOLUME_PLAN
                                                            ,WORK_VOLUME_FACT
                                                            ,MEASURE_UNIT_ID
                                                            ,MEASURE_UNIT_NAME
                                                            ,PLAN_WORK_DATE
                                                            ,FACT_WORK_DATE
                                                            ,SEASON_ID
                                                            ,SEASON_NAME
                                                            ,WORK_EXECUTE_ID
                                                            )
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,pw.driveway_id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,pw.work_volume as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,pw.work_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_planed_work pw
                 join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                 join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                 join ods.fdc_odh odh on pw.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join wex_agg on wex_agg.driveway_id = odh.id
                                 and wex_agg.planed_work_id=pw.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                        and pw.work_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                where wc.code='MAINTAIN'
                  and pws.code in ('APPROVED','DONE')
                  and pw.maintenance_route_id is null
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                  and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                       (p_period_to is null or pw.work_date<=p_period_to)
                      )
                     )
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
               union all
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,tt.id
                     ,tt.odh_name
                     ,tt.customer_id
                     ,tt.customer_name
                     ,tt.performer_id
                     ,tt.performer_name
                     ,tt.work_type_id
                     ,tt.work_type_name
                     ,tt.maintain_group_id
                     ,tt.maintain_group_name
                     ,tt.work_volume_plan
                     ,tt.work_volume_fact
                     ,tt.measure_unit_id
                     ,tt.measure_unit_name
                     --,swpd.performance_date as plan_work_date
                     ,tt.plan_work_date
                     ,tt.fact_work_date
                     ,tt.season_id
                     ,tt.season_name
                     ,tt.work_execute_id
                 from(select disto.odh_id as id
                             ,dobj.name as odh_name
                             ,dcust.id as customer_id
                             ,dcust.short_name as customer_name
                             ,perf.id as performer_id
                             ,perf.short_name as performer_name
                             ,wt.id as work_type_id
                             ,wt.name as work_type_name
                             ,dodh.maintain_group_id
                             ,mtg.name as maintain_group_name
                             ,dcalc.roadway_area/7000.0 as work_volume_plan
                             ,wex_agg.work_volume as work_volume_fact
                             ,swt.measure_unit_id
                             ,mu.name as measure_unit_name
                             --,swpd.performance_date as plan_work_date
                             ,pw.work_date as plan_work_date
                             ,wex_agg.work_date as fact_work_date
                             ,wt.season_id
                             ,ssn.name as season_name
                             ,wex_agg.work_execute_id
                             ,row_number() over(partition by disto.odh_id,pw.id) rn
                         from msnow.fdc_planed_work pw
                         join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                         join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                         join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                         join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                         join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                         join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                         join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                         join ods.fdc_odh dodh on disto.odh_id=dodh.id
                         join ods.fdc_object dobj on dodh.id=dobj.id
                         join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                         join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                         join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                         join wex_agg on wex_agg.driveway_id = dodh.id
                                         and wex_agg.planed_work_id = pw.id
                         left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                         left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                         left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                                and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                         left join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                         left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                         left join msnow.fdc_maintain_group mtg on dodh.maintain_group_id=mtg.id
                         left join msnow.fdc_season ssn on wt.season_id=ssn.id
                        where pw.driveway_id is null
                          and wc.code='MAINTAIN'
                          and pws.code in ('APPROVED','DONE')
                          and dist.work_plan_approved
                          and dobj.driveway_category_id is not null
                          and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                          and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                          and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                          and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                          and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                          and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                          and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                          and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                          and(p_season_id is null or wt.season_id = p_season_id)
                          and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                              (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                              (p_period_to is null or pw.work_date<=p_period_to)
                              )
                             )
                     ) tt
                where tt.rn=1;
  elsif l_detail_column in('actual_differ_count','actual_differ_count_percent') then --3/4 diff
    with wex_agg as(select wa.driveway_id
                          ,wa.planed_work_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.planed_work_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.planed_work_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.planed_work_id is not null
                           ) wa
                     group by wa.driveway_id
                             ,wa.planed_work_id

                   )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
            insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                            ,SET_DATE
                                                            ,DETAIL_COLUMN
                                                            ,ID
                                                            ,ODH_NAME
                                                            ,CUSTOMER_ID
                                                            ,CUSTOMER_NAME
                                                            ,PERFORMER_ID
                                                            ,PERFORMER_NAME
                                                            ,WORK_TYPE_ID
                                                            ,WORK_TYPE_NAME
                                                            ,MAINTAIN_GROUP_ID
                                                            ,MAINTAIN_GROUP_NAME
                                                            ,WORK_VOLUME_PLAN
                                                            ,WORK_VOLUME_FACT
                                                            ,MEASURE_UNIT_ID
                                                            ,MEASURE_UNIT_NAME
                                                            ,PLAN_WORK_DATE
                                                            ,FACT_WORK_DATE
                                                            ,SEASON_ID
                                                            ,SEASON_NAME
                                                            ,WORK_EXECUTE_ID
                                                            )
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,pw.driveway_id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,pw.work_volume as work_volume_plan
                     --,wex_agg.work_volume as work_volume_fact
                     ,null::double precision  as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,pw.work_date as plan_work_date
                     --,wex_agg.work_date as fact_work_date
                     ,null::date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     --,wex_agg.work_execute_id
                     ,null::bigint as work_execute_id
                 from msnow.fdc_planed_work pw
                 join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                 join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                 join ods.fdc_odh odh on pw.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                        and pw.work_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id

                where wc.code='MAINTAIN'
                  and pws.code in ('APPROVED','DONE')
                  and pw.maintenance_route_id is null
                  and obj.driveway_category_id is not null
                  and not exists(select null
                                   from wex_agg
                                  where wex_agg.driveway_id = odh.id
                                    and wex_agg.planed_work_id=pw.id
                                )
                  and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                  and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                       (p_period_to is null or pw.work_date<=p_period_to)
                      )
                     )
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
               union all
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,tt.id
                     ,tt.odh_name
                     ,tt.customer_id
                     ,tt.customer_name
                     ,tt.performer_id
                     ,tt.performer_name
                     ,tt.work_type_id
                     ,tt.work_type_name
                     ,tt.maintain_group_id
                     ,tt.maintain_group_name
                     ,tt.work_volume_plan
                     ,tt.work_volume_fact
                     ,tt.measure_unit_id
                     ,tt.measure_unit_name
                     --,swpd.performance_date as plan_work_date
                     ,tt.plan_work_date
                     ,tt.fact_work_date
                     ,tt.season_id
                     ,tt.season_name
                     ,tt.work_execute_id
                 from(select disto.odh_id as id
                             ,dobj.name as odh_name
                             ,dcust.id as customer_id
                             ,dcust.short_name as customer_name
                             ,perf.id as performer_id
                             ,perf.short_name as performer_name
                             ,wt.id as work_type_id
                             ,wt.name as work_type_name
                             ,dodh.maintain_group_id
                             ,mtg.name as maintain_group_name
                             ,dcalc.roadway_area/7000.0 as work_volume_plan
                             --,wex_agg.work_volume as work_volume_fact
                             ,null::double precision  as work_volume_fact
                             ,swt.measure_unit_id
                             ,mu.name as measure_unit_name
                             --,swpd.performance_date as plan_work_date
                             ,pw.work_date as plan_work_date
                             --,wex_agg.work_date as fact_work_date
                             ,null::date as fact_work_date
                             ,wt.season_id
                             ,ssn.name as season_name
                             --,wex_agg.work_execute_id
                             ,null::bigint as work_execute_id
                             ,row_number() over(partition by disto.odh_id,pw.id) rn
                         from msnow.fdc_planed_work pw
                         join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                         join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                         join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                         join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                         join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                         join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                         join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                         join ods.fdc_odh dodh on disto.odh_id=dodh.id
                         join ods.fdc_object dobj on dodh.id=dobj.id
                         join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                         join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                         join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                         left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                         left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                         left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                                and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                         left join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                         left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                         left join msnow.fdc_maintain_group mtg on dodh.maintain_group_id=mtg.id
                         left join msnow.fdc_season ssn on wt.season_id=ssn.id
                        where pw.driveway_id is null
                          and wc.code='MAINTAIN'
                          and pws.code in ('APPROVED','DONE')
                          and dist.work_plan_approved
                          and dobj.driveway_category_id is not null
                          and not exists(select null
                                           from wex_agg
                                          where wex_agg.driveway_id = dodh.id
                                            and wex_agg.planed_work_id = pw.id
                                        )
                          and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                          and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                          and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                          and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                          and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                          and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                          and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                          and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                          and(p_season_id is null or wt.season_id = p_season_id)
                          and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                              (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                              (p_period_to is null or pw.work_date<=p_period_to)
                              )
                             )
                     ) tt
                where tt.rn=1;

  elsif l_detail_column = 'regul_plan_length' then   --7
    with wex_agg as(select wa.driveway_id
                          ,wa.scheduled_work_plan_date_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.scheduled_work_plan_date_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.scheduled_work_plan_date_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.scheduled_work_plan_date_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.scheduled_work_plan_date_id

                       )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
     insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                     ,SET_DATE
                                                     ,DETAIL_COLUMN
                                                     ,ID
                                                     ,ODH_NAME
                                                     ,CUSTOMER_ID
                                                     ,CUSTOMER_NAME
                                                     ,PERFORMER_ID
                                                     ,PERFORMER_NAME
                                                     ,WORK_TYPE_ID
                                                     ,WORK_TYPE_NAME
                                                     ,MAINTAIN_GROUP_ID
                                                     ,MAINTAIN_GROUP_NAME
                                                     ,WORK_VOLUME_PLAN
                                                     ,WORK_VOLUME_FACT
                                                     ,MEASURE_UNIT_ID
                                                     ,MEASURE_UNIT_NAME
                                                     ,PLAN_WORK_DATE
                                                     ,FACT_WORK_DATE
                                                     ,SEASON_ID
                                                     ,SEASON_NAME
                                                     ,WORK_EXECUTE_ID
                                                     )

               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,odh.id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,coalesce(calc.roadway_area / 7000.0,0.0) as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,swpd.performance_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                        and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                 left join wex_agg on wex_agg.driveway_id = odh.id
                                      and wex_agg.scheduled_work_plan_date_id = swpd.id
                                      --and wex_agg.customer_root_id = dagr.customer_id
                                      --and wex_agg.performer_root_id = dagr.performer_id
                                      --and wex_agg.work_type_id = swp.work_type_id
                                      --and wex_agg.work_date = swpd.performance_date
                where dist.work_plan_approved
                  and mu.code='RKMT'
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun));

  elsif l_detail_column = 'regul_fact_length' then   --8
    with wex_agg as(select wa.driveway_id
                          ,wa.scheduled_work_plan_date_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.scheduled_work_plan_date_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.scheduled_work_plan_date_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.scheduled_work_plan_date_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.scheduled_work_plan_date_id

                       )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
     insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                     ,SET_DATE
                                                     ,DETAIL_COLUMN
                                                     ,ID
                                                     ,ODH_NAME
                                                     ,CUSTOMER_ID
                                                     ,CUSTOMER_NAME
                                                     ,PERFORMER_ID
                                                     ,PERFORMER_NAME
                                                     ,WORK_TYPE_ID
                                                     ,WORK_TYPE_NAME
                                                     ,MAINTAIN_GROUP_ID
                                                     ,MAINTAIN_GROUP_NAME
                                                     ,WORK_VOLUME_PLAN
                                                     ,WORK_VOLUME_FACT
                                                     ,MEASURE_UNIT_ID
                                                     ,MEASURE_UNIT_NAME
                                                     ,PLAN_WORK_DATE
                                                     ,FACT_WORK_DATE
                                                     ,SEASON_ID
                                                     ,SEASON_NAME
                                                     ,WORK_EXECUTE_ID
                                                     )

               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,odh.id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,coalesce(calc.roadway_area / 7000.0,0.0) as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,swpd.performance_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 join wex_agg on wex_agg.driveway_id = odh.id
                                 and wex_agg.scheduled_work_plan_date_id = swpd.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                        and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id

                where dist.work_plan_approved
                  and mu.code='RKMT'
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun));
  elsif l_detail_column in('regul_differ_length','regul_differ_length_percent') then   --7/8 diff
    with wex_agg as(select wa.driveway_id
                          ,wa.scheduled_work_plan_date_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.scheduled_work_plan_date_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.scheduled_work_plan_date_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.scheduled_work_plan_date_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.scheduled_work_plan_date_id

                       )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
     insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                     ,SET_DATE
                                                     ,DETAIL_COLUMN
                                                     ,ID
                                                     ,ODH_NAME
                                                     ,CUSTOMER_ID
                                                     ,CUSTOMER_NAME
                                                     ,PERFORMER_ID
                                                     ,PERFORMER_NAME
                                                     ,WORK_TYPE_ID
                                                     ,WORK_TYPE_NAME
                                                     ,MAINTAIN_GROUP_ID
                                                     ,MAINTAIN_GROUP_NAME
                                                     ,WORK_VOLUME_PLAN
                                                     ,WORK_VOLUME_FACT
                                                     ,MEASURE_UNIT_ID
                                                     ,MEASURE_UNIT_NAME
                                                     ,PLAN_WORK_DATE
                                                     ,FACT_WORK_DATE
                                                     ,SEASON_ID
                                                     ,SEASON_NAME
                                                     ,WORK_EXECUTE_ID
                                                     )

               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,odh.id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,coalesce(calc.roadway_area / 7000.0,0.0) as work_volume_plan
                     --,wex_agg.work_volume as work_volume_fact
                     ,null::double precision  as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,swpd.performance_date as plan_work_date
                     --,wex_agg.work_date as fact_work_date
                     ,null::date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     --,wex_agg.work_execute_id
                     ,null::bigint as work_execute_id
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                        and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id

                where dist.work_plan_approved
                  and mu.code='RKMT'
                  and obj.driveway_category_id is not null
                  and not exists(select null
                                   from wex_agg
                                  where wex_agg.driveway_id = odh.id
                                    and wex_agg.scheduled_work_plan_date_id = swpd.id
                                )
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun));
  elsif l_detail_column = 'actual_plan_length' then   --9
    with wex_agg as(select wa.driveway_id
                          ,wa.planed_work_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.planed_work_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.planed_work_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.planed_work_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.planed_work_id
                   )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
            insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                            ,SET_DATE
                                                            ,DETAIL_COLUMN
                                                            ,ID
                                                            ,ODH_NAME
                                                            ,CUSTOMER_ID
                                                            ,CUSTOMER_NAME
                                                            ,PERFORMER_ID
                                                            ,PERFORMER_NAME
                                                            ,WORK_TYPE_ID
                                                            ,WORK_TYPE_NAME
                                                            ,MAINTAIN_GROUP_ID
                                                            ,MAINTAIN_GROUP_NAME
                                                            ,WORK_VOLUME_PLAN
                                                            ,WORK_VOLUME_FACT
                                                            ,MEASURE_UNIT_ID
                                                            ,MEASURE_UNIT_NAME
                                                            ,PLAN_WORK_DATE
                                                            ,FACT_WORK_DATE
                                                            ,SEASON_ID
                                                            ,SEASON_NAME
                                                            ,WORK_EXECUTE_ID
                                                            )
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,pw.driveway_id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,pw.work_volume as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,pw.work_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_planed_work pw
                 join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                 join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                 join ods.fdc_odh odh on pw.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                        and pw.work_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                 left join wex_agg on wex_agg.driveway_id = odh.id
                                      and wex_agg.planed_work_id=pw.id
                                      ---and wex_agg.customer_root_id = agr.customer_id
                                      ---and wex_agg.performer_root_id = agr.performer_id
                                      ---and wex_agg.work_type_id = pw.work_type_id
                                      ---and wex_agg.work_date = pw.work_date
                where wc.code='MAINTAIN'
                  and mu.code='RKMT'
                  and pws.code in ('APPROVED','DONE')
                  and pw.maintenance_route_id is null
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                  and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                       (p_period_to is null or pw.work_date<=p_period_to)
                      )
                     )
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
              union all
              select p_session_id
                    ,l_current_date
                    ,l_detail_column
                    ,tt.id
                    ,tt.odh_name
                    ,tt.customer_id
                    ,tt.customer_name
                    ,tt.performer_id
                    ,tt.performer_name
                    ,tt.work_type_id
                    ,tt.work_type_name
                    ,tt.maintain_group_id
                    ,tt.maintain_group_name
                    ,tt.work_volume_plan
                    ,tt.work_volume_fact
                    ,tt.measure_unit_id
                    ,tt.measure_unit_name
                    ,tt.plan_work_date--swpd.performance_date as plan_work_date
                    ,tt.fact_work_date
                    ,tt.season_id
                    ,tt.season_name
                    ,tt.work_execute_id
                from(select disto.odh_id as id
                           ,dobj.name as odh_name
                           ,dcust.id as customer_id
                           ,dcust.short_name as customer_name
                           ,perf.id as performer_id
                           ,perf.short_name as performer_name
                           ,wt.id as work_type_id
                           ,wt.name as work_type_name
                           ,dodh.maintain_group_id
                           ,mtg.name as maintain_group_name
                           ,dcalc.roadway_area/7000.0 as work_volume_plan
                           ,wex_agg.work_volume as work_volume_fact
                           ,swt.measure_unit_id
                           ,mu.name as measure_unit_name
                           ,pw.work_date as plan_work_date--swpd.performance_date as plan_work_date
                           ,wex_agg.work_date as fact_work_date
                           ,wt.season_id
                           ,ssn.name as season_name
                           ,wex_agg.work_execute_id
                           ,row_number() over(partition by disto.odh_id,pw.id) rn
                       from msnow.fdc_planed_work pw
                       join msnow.fdc_planed_work_status pws on pw.planed_work_status_id = pws.id
                       join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                       join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                       join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                       join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                       join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                       join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                       join ods.fdc_odh dodh on disto.odh_id=dodh.id
                       join ods.fdc_object dobj on dodh.id=dobj.id
                       join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                       join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                       join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                       join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                       left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                       left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                       left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                              and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                       left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                       left join msnow.fdc_maintain_group mtg on dodh.maintain_group_id=mtg.id
                       left join msnow.fdc_season ssn on wt.season_id=ssn.id
                       left join wex_agg on wex_agg.driveway_id = dodh.id
                                            and wex_agg.planed_work_id=pw.id
                                           -- and wex_agg.customer_root_id = dagr.customer_id
                                           -- and wex_agg.performer_root_id = dagr.performer_id
                                           -- and wex_agg.work_type_id = swp.work_type_id
                                           -- and wex_agg.work_date = pw.work_date --swpd.performance_date
                      where pw.driveway_id is null
                        and wc.code='MAINTAIN'
                        and mu.code='RKMT'
                        and pws.code in ('APPROVED','DONE')
                        and dist.work_plan_approved
                        and dobj.driveway_category_id is not null
                        and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                        and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                        and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                        and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                        and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                        and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                        and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                        and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                        and(p_season_id is null or wt.season_id = p_season_id)
                        and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                            (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                            (p_period_to is null or pw.work_date<=p_period_to)
                            )
                           )
                    ) tt
               where tt.rn=1;
  elsif l_detail_column = 'actual_fact_length' then   --10
    with wex_agg as(select wa.driveway_id
                          ,wa.planed_work_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.planed_work_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.planed_work_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.planed_work_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.planed_work_id
                   )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
            insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                            ,SET_DATE
                                                            ,DETAIL_COLUMN
                                                            ,ID
                                                            ,ODH_NAME
                                                            ,CUSTOMER_ID
                                                            ,CUSTOMER_NAME
                                                            ,PERFORMER_ID
                                                            ,PERFORMER_NAME
                                                            ,WORK_TYPE_ID
                                                            ,WORK_TYPE_NAME
                                                            ,MAINTAIN_GROUP_ID
                                                            ,MAINTAIN_GROUP_NAME
                                                            ,WORK_VOLUME_PLAN
                                                            ,WORK_VOLUME_FACT
                                                            ,MEASURE_UNIT_ID
                                                            ,MEASURE_UNIT_NAME
                                                            ,PLAN_WORK_DATE
                                                            ,FACT_WORK_DATE
                                                            ,SEASON_ID
                                                            ,SEASON_NAME
                                                            ,WORK_EXECUTE_ID
                                                            )
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,pw.driveway_id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,pw.work_volume as work_volume_plan
                     ,wex_agg.work_volume as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,pw.work_date as plan_work_date
                     ,wex_agg.work_date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     ,wex_agg.work_execute_id
                 from msnow.fdc_planed_work pw
                 join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                 join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                 join ods.fdc_odh odh on pw.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 join wex_agg on wex_agg.driveway_id = odh.id
                                 and wex_agg.planed_work_id=pw.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                        and pw.work_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                where wc.code='MAINTAIN'
                  and mu.code='RKMT'
                  and pws.code in ('APPROVED','DONE')
                  and pw.maintenance_route_id is null
                  and obj.driveway_category_id is not null
                  and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                  and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                       (p_period_to is null or pw.work_date<=p_period_to)
                      )
                     )
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
              union all
              select p_session_id
                    ,l_current_date
                    ,l_detail_column
                    ,tt.id
                    ,tt.odh_name
                    ,tt.customer_id
                    ,tt.customer_name
                    ,tt.performer_id
                    ,tt.performer_name
                    ,tt.work_type_id
                    ,tt.work_type_name
                    ,tt.maintain_group_id
                    ,tt.maintain_group_name
                    ,tt.work_volume_plan
                    ,tt.work_volume_fact
                    ,tt.measure_unit_id
                    ,tt.measure_unit_name
                    ,tt.plan_work_date--swpd.performance_date as plan_work_date
                    ,tt.fact_work_date
                    ,tt.season_id
                    ,tt.season_name
                    ,tt.work_execute_id
                from(select disto.odh_id as id
                           ,dobj.name as odh_name
                           ,dcust.id as customer_id
                           ,dcust.short_name as customer_name
                           ,perf.id as performer_id
                           ,perf.short_name as performer_name
                           ,wt.id as work_type_id
                           ,wt.name as work_type_name
                           ,dodh.maintain_group_id
                           ,mtg.name as maintain_group_name
                           ,dcalc.roadway_area/7000.0 as work_volume_plan
                           ,wex_agg.work_volume as work_volume_fact
                           ,swt.measure_unit_id
                           ,mu.name as measure_unit_name
                           ,pw.work_date as plan_work_date--swpd.performance_date as plan_work_date
                           ,wex_agg.work_date as fact_work_date
                           ,wt.season_id
                           ,ssn.name as season_name
                           ,wex_agg.work_execute_id
                           ,row_number() over(partition by disto.odh_id,pw.id) rn
                       from msnow.fdc_planed_work pw
                       join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                       join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                       join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                       join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                       join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                       join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                       join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                       join ods.fdc_odh dodh on disto.odh_id=dodh.id
                       join ods.fdc_object dobj on dodh.id=dobj.id
                       join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                       join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                       join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                       join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                       join wex_agg on wex_agg.driveway_id = dodh.id
                                       and wex_agg.planed_work_id=pw.id
                       left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                       left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                       left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                              and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                       left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                       left join msnow.fdc_maintain_group mtg on dodh.maintain_group_id=mtg.id
                       left join msnow.fdc_season ssn on wt.season_id=ssn.id
                      where pw.driveway_id is null
                        and wc.code='MAINTAIN'
                        and mu.code='RKMT'
                        and pws.code in ('APPROVED','DONE')
                        and dist.work_plan_approved
                        and dobj.driveway_category_id is not null
                        and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                        and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                        and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                        and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                        and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                        and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                        and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                        and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                        and(p_season_id is null or wt.season_id = p_season_id)
                        and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                            (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                            (p_period_to is null or pw.work_date<=p_period_to)
                            )
                           )
                    ) tt
               where tt.rn=1;
  elsif l_detail_column in('actual_differ_length','actual_differ_length_percent') then   -- 9/10
    with wex_agg as(select wa.driveway_id
                          ,wa.planed_work_id
                          ,max(wa.work_date) as work_date
                          ,sum(wa.work_volume) as work_volume
                          ,max(work_execute_id) as work_execute_id
                      from(select wex.driveway_id -- Ид участка
                                 ,wex.planed_work_id  -- Ид даты плановой работы
                                 ,date(wex.work_date) as work_date
                                 ,wex.work_volume
                                 ,max(wex.id) over(partition by wex.driveway_id,wex.planed_work_id order by wex.work_date desc) as work_execute_id
                             from msnow.fdc_work_execute wex
                            where wex.planed_work_id is not null
                          ) wa
                     group by wa.driveway_id
                             ,wa.planed_work_id
                   )
        ,odh_mun as(select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                   union
                   select odhf.id
                     from ods.fdc_object objf
                     join ods.fdc_odh odhf on objf.id=odhf.id
                     join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                     join nsi.fdc_municipality m on fias.municipality_id=m.id
                    where m.root_id=l_municipality_root_id
                  )
            insert into msnow.FDC_REP_MAINTODH_OVERVIEW_DETW(SESSION_ID
                                                            ,SET_DATE
                                                            ,DETAIL_COLUMN
                                                            ,ID
                                                            ,ODH_NAME
                                                            ,CUSTOMER_ID
                                                            ,CUSTOMER_NAME
                                                            ,PERFORMER_ID
                                                            ,PERFORMER_NAME
                                                            ,WORK_TYPE_ID
                                                            ,WORK_TYPE_NAME
                                                            ,MAINTAIN_GROUP_ID
                                                            ,MAINTAIN_GROUP_NAME
                                                            ,WORK_VOLUME_PLAN
                                                            ,WORK_VOLUME_FACT
                                                            ,MEASURE_UNIT_ID
                                                            ,MEASURE_UNIT_NAME
                                                            ,PLAN_WORK_DATE
                                                            ,FACT_WORK_DATE
                                                            ,SEASON_ID
                                                            ,SEASON_NAME
                                                            ,WORK_EXECUTE_ID
                                                            )
               select p_session_id
                     ,l_current_date
                     ,l_detail_column
                     ,pw.driveway_id as id
                     ,obj.name as odh_name
                     ,cust.id as customer_id
                     ,cust.short_name as customer_name
                     ,perf.id as performer_id
                     ,perf.short_name as performer_name
                     ,wt.id as work_type_id
                     ,wt.name as work_type_name
                     ,odh.maintain_group_id
                     ,mtg.name as maintain_group_name
                     ,pw.work_volume as work_volume_plan
                     --,wex_agg.work_volume as work_volume_fact
                     ,null::double precision as work_volume_fact
                     ,wt.measure_unit_id
                     ,mu.name as measure_unit_name
                     ,pw.work_date as plan_work_date
                     --,wex_agg.work_date as fact_work_date
                     ,null::date as fact_work_date
                     ,wt.season_id
                     ,ssn.name as season_name
                     --,wex_agg.work_execute_id
                     ,null::bigint as work_execute_id
                 from msnow.fdc_planed_work pw
                 join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                 join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                 join ods.fdc_odh odh on pw.driveway_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                        and pw.work_date between perf.ver_start_date and perf.ver_end_date
                 left join msnow.fdc_maintain_group mtg on odh.maintain_group_id=mtg.id
                 left join msnow.fdc_season ssn on wt.season_id=ssn.id
                where wc.code='MAINTAIN'
                  and mu.code='RKMT'
                  and pws.code in ('APPROVED','DONE')
                  and pw.maintenance_route_id is null
                  and obj.driveway_category_id is not null
                  and not exists(select null
                                   from wex_agg
                                  where wex_agg.driveway_id = odh.id
                                    and wex_agg.planed_work_id=pw.id
                                )
                  and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                  and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                       (p_period_to is null or pw.work_date<=p_period_to)
                      )
                     )
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
              union all
              select p_session_id
                    ,l_current_date
                    ,l_detail_column
                    ,tt.id
                    ,tt.odh_name
                    ,tt.customer_id
                    ,tt.customer_name
                    ,tt.performer_id
                    ,tt.performer_name
                    ,tt.work_type_id
                    ,tt.work_type_name
                    ,tt.maintain_group_id
                    ,tt.maintain_group_name
                    ,tt.work_volume_plan
                    ,tt.work_volume_fact
                    ,tt.measure_unit_id
                    ,tt.measure_unit_name
                    ,tt.plan_work_date--swpd.performance_date as plan_work_date
                    ,tt.fact_work_date
                    ,tt.season_id
                    ,tt.season_name
                    ,tt.work_execute_id
                from(select disto.odh_id as id
                           ,dobj.name as odh_name
                           ,dcust.id as customer_id
                           ,dcust.short_name as customer_name
                           ,perf.id as performer_id
                           ,perf.short_name as performer_name
                           ,wt.id as work_type_id
                           ,wt.name as work_type_name
                           ,dodh.maintain_group_id
                           ,mtg.name as maintain_group_name
                           ,dcalc.roadway_area/7000.0 as work_volume_plan
                           --,wex_agg.work_volume as work_volume_fact
                           ,null::double precision as work_volume_fact
                           ,swt.measure_unit_id
                           ,mu.name as measure_unit_name
                           ,pw.work_date as plan_work_date--swpd.performance_date as plan_work_date
                           --,wex_agg.work_date as fact_work_date
                           ,null::date as fact_work_date
                           ,wt.season_id
                           ,ssn.name as season_name
                           --,wex_agg.work_execute_id
                           ,null::bigint as work_execute_id
                           ,row_number() over(partition by disto.odh_id,pw.id) rn
                       from msnow.fdc_planed_work pw
                       join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                       join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                       join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                       join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                       join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                       join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                       join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                       join ods.fdc_odh dodh on disto.odh_id=dodh.id
                       join ods.fdc_object dobj on dodh.id=dobj.id
                       join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                       join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                       join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                       join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                       left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                       left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                       left join nsi.fdc_legal_person perf on dagr.performer_id=perf.root_id
                                                              and swpd.performance_date between perf.ver_start_date and perf.ver_end_date
                       left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                       left join msnow.fdc_maintain_group mtg on dodh.maintain_group_id=mtg.id
                       left join msnow.fdc_season ssn on wt.season_id=ssn.id
                      where pw.driveway_id is null
                        and wc.code='MAINTAIN'
                        and mu.code='RKMT'
                        and pws.code in ('APPROVED','DONE')
                        and dist.work_plan_approved
                        and dobj.driveway_category_id is not null
                        and not exists(select null
                                         from wex_agg
                                        where wex_agg.driveway_id = dodh.id
                                          and wex_agg.planed_work_id=pw.id
                                      )
                        and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                        and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                        and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                        and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                        and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                        and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                        and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                        and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                        and(p_season_id is null or wt.season_id = p_season_id)
                        and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                            (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                            (p_period_to is null or pw.work_date<=p_period_to)
                            )
                           )
                    ) tt
               where tt.rn=1;
  end if;
end
$$;

