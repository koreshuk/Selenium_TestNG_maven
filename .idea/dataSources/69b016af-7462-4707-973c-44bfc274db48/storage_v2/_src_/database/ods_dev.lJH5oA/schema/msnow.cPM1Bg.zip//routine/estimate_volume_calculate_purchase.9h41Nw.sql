CREATE FUNCTION estimate_volume_calculate_purchase(p_purchase_lot_id bigint, OUT driveway_qty integer, OUT driveway_with_estimate_qty integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
/** Расчет объемов работ сметы бюджетного обязательства/закупки/обязательства.
  %param p_obligation_id   -- Ид бюджетного обязательства
  %param p_purchase_lot_id -- Ид закупки
  %param p_agreement_id    -- Ид обязательства

  %return  driveway_qty               -- число дорог, включенных в объект
  %return  driveway_with_estimate_qty -- число дорог объекта, для которых рассчитаны объемы работ
*/
  l_sql text;
  l_seasondays_coef double precision;
  l_days_N integer;
  l_days_M integer;
  l_period_intersection boolean;
  l_work_volume double precision;

  rec record;
begin
  delete from msnow.fdc_purchase_estimate where purchase_lot_id=p_purchase_lot_id;
  
  for rec in(select oo.purchase_lot_id
                   ,oo.driveway_id
                   ,wr.work_type_id
                   ,wt.measure_unit_id
                   ,case
                      when dwp.code='DISTANCE' then dw.distance
                      when dwp.code='REDUCED_DISTANCE' then dw.reduced_distance
                      when dwp.code='STOP_COUNT' then dw.stop_count::double precision
                      when dwp.code='ROADWAY_AREA' then dw.roadway_area
                    end driveway_distance
                   ,wr.cycle_season
                   ,wt.season_date_from wt_date_from
                   ,wt.season_date_to   wt_date_to
                   ,o.work_date_from    object_date_from
                   ,o.work_date_to      object_date_to
               from msnow.fdc_purchase_object oo
               join msnow.fdc_purchase o on o.id=oo.purchase_lot_id 
               join msnow.fdc_driveway dw on dw.id=oo.driveway_id
               join msnow.fdc_work_rule wr on wr.odh_group_id=dw.odh_group_id
                                              and (wr.cover_type_id=dw.cover_type_id or wr.cover_type_id is null)
               join msnow.fdc_driveway_prop dwp on dwp.id=wr.driveway_prop_id
               join msnow.fdc_work_type wt on wt.id=wr.work_type_id
              where oo.purchase_lot_id = p_purchase_lot_id
                and o.work_date_from is not null
                and o.work_date_to is not null
            ) loop

    begin
     select true
        into strict l_period_intersection
        from msnow.fdc_stat_get_work_type_id_wt(p_season_date_from => rec.object_date_from-- дата с выполнения работ объекта
                                               ,p_season_date_to   => rec.object_date_to-- дата по выполнения работ объекта
                                               ,p_work_type_id     => rec.work_type_id
                                               );
    exception
      when NO_DATA_FOUND then null;
    end;
    continue when not coalesce(l_period_intersection,false);  

    if rec.wt_date_from is null or rec.wt_date_to is null or rec.object_date_from is null or rec.object_date_to is null then
      l_seasondays_coef:=1.0;
    else
      select count(work_type_days)
        into l_days_N
        from msnow.fdc_util_get_dates(p_date_from => rec.wt_date_from
                                     ,p_date_to   => rec.wt_date_to
                                     ) work_type_days;
     
      select count(object_work_days)
        into l_days_M
        from msnow.fdc_util_get_dates(p_date_from => rec.wt_date_from
                                     ,p_date_to   => rec.wt_date_to
                                     ) work_type_days
            ,msnow.fdc_util_get_dates(p_date_from => rec.object_date_from
                                     ,p_date_to   => rec.object_date_to
                                     ) object_work_days
       where work_type_days = object_work_days;

      l_seasondays_coef:= l_days_M::double precision/l_days_N;
    end if;
    l_work_volume:= rec.driveway_distance * round(rec.cycle_season * l_seasondays_coef);
    continue when not l_work_volume > 0;   
  end loop;
end
$$;

