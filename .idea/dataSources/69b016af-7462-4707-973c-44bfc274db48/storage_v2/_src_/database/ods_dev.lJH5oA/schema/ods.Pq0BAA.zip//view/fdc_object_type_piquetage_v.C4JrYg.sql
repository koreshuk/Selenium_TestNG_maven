CREATE VIEW fdc_object_type_piquetage_v AS
  SELECT otp.id,
    otp.object_type_id,
    ot.code AS object_type_code,
    ot.name AS object_type_name,
    otp.piquetage_type_id,
    pt.code AS piquetage_type_code,
    pt.name AS piquetage_type_name,
    pt.sort_order
   FROM fdc_object_type_piquetage otp,
    fdc_object_type ot,
    fdc_piquetage_type_v pt
  WHERE ((ot.id = otp.object_type_id) AND (pt.id = otp.piquetage_type_id));

COMMENT ON VIEW fdc_object_type_piquetage_v IS 'Справочник связи типов объектов ОГХ с типами пикетажа';

COMMENT ON COLUMN fdc_object_type_piquetage_v.id IS 'Ид записи';

COMMENT ON COLUMN fdc_object_type_piquetage_v.object_type_id IS 'Ид типа ОГХ';

COMMENT ON COLUMN fdc_object_type_piquetage_v.object_type_code IS 'Код типа ОГХ';

COMMENT ON COLUMN fdc_object_type_piquetage_v.object_type_name IS 'Наименование типа ОГХ';

COMMENT ON COLUMN fdc_object_type_piquetage_v.piquetage_type_id IS 'Ид типа пикетажа';

COMMENT ON COLUMN fdc_object_type_piquetage_v.piquetage_type_code IS 'Код типа пикетажа';

COMMENT ON COLUMN fdc_object_type_piquetage_v.piquetage_type_name IS 'Наименование типа пикетажа';

COMMENT ON COLUMN fdc_object_type_piquetage_v.sort_order IS 'Порядок сортировки';

