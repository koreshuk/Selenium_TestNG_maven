CREATE FUNCTION fdc_person_pck_get_default_kpp(p_inn character varying)
  RETURNS character varying
LANGUAGE plpgsql
AS $$
declare
  /** КПП по умолчанию
  %param  p_inn - ИНН
  %return КПП по умолчанию
  */
  l_kpp nsi.fdc_legal_person.kpp%type;
begin
  if p_inn is not null then
    l_kpp:=substr(p_inn,1,4)||'01001';
  end if;
  return l_kpp;
end
$$;

