CREATE FUNCTION fdc_person_address_pck_add_address(p_person_id bigint, p_legal_person_address nsi.t_legal_person_address)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Добавить адрес в формате КЛАДР
  %param p_person_id             - ИД организации
  %param p_legal_person_address  - Объект (содержит информацию об адресе в структуре КЛАДР)
  */
begin
  return;
end
$$;

