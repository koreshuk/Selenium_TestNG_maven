CREATE FUNCTION fdc_ods_pck_get_content(p_date_act date, p_object_type_id bigint DEFAULT NULL::bigint, p_owner_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, p_okrug_id bigint DEFAULT NULL::bigint, p_district_id bigint DEFAULT NULL::bigint, p_state_id bigint DEFAULT NULL::bigint, p_object_type_sub_id bigint DEFAULT NULL::bigint, p_object_type_up_id bigint DEFAULT NULL::bigint, p_name_or_id text DEFAULT NULL::text, p_passport_num character varying DEFAULT NULL::character varying, p_passport_author_id bigint DEFAULT NULL::bigint, p_passport_developer_id bigint DEFAULT NULL::bigint, p_address_list bigint[] DEFAULT NULL::bigint[], p_with_actual_address boolean DEFAULT false, p_category_id bigint DEFAULT NULL::bigint, p_ownerless bigint DEFAULT NULL::bigint, p_clean_category_id bigint DEFAULT NULL::bigint, p_clean_subcategory_id bigint DEFAULT NULL::bigint, p_own_agree boolean DEFAULT false, p_sort_order character varying DEFAULT 'id desc'::character varying, p_start_index integer DEFAULT 1, p_end_index integer DEFAULT 1000000)
  RETURNS SETOF t_search_object
LANGUAGE plpgsql
AS $$
declare
   /**Функция для вывода результатов поиска
   %usage Используется Вэб приложением для поиска объектов ОГХ в реестре по параметрам (форма поиска)
          Предусмотрен пейждинг.
          Если в форме поиска в качестве одного из параметров пользователь указал "Все", то следует передавать
          в функцию в качетсве соответствующего параметра NULL.
          Параметры пейджинга не обязательны. Фильтр для пейджинга накладывается только в случае заполненности
          ненулевыми и не пустыми значениями хотя бы одного из них.
   %chg

   %param p_object_type_id             Идентификатор типа объекта
   %param p_date_act                   Дата действия
   %param p_owner_id                   Идентификатор балансодержателя
   %param p_customer_id                Идентификатор заказчика
   %param p_okrug_id                   Идентификатор округа
   %param p_district_id                Идентификатор района
   %param p_agree_status_id            Ид статуса согласования
   %param p_state_id                   Ид статуса объекта
   %param p_object_type_sub_id         Ид подтипа объекта
   %param p_object_type_up_id          Ид типа верхнего уровня объекта
   %param p_name_or_id                 Наименование или идентификатор объекта
   %param p_passport_num               Номер паспорта объекта
   %param p_passport_author_id         Ид составителя паспорта
   %param p_passport_developer_id      Ид разработчика паспорта
   %param p_address_list               Коллекция идентификаторов адресов
   %param p_with_actual_address        Флаг актуальности адресов
   %param p_category_id                Идентификатор категории объектов
   %param p_ownerless                  Фильтр для бесхозных объектов (Все - null, 0 - Есть паспорт на объект, 1 - Бесхозный объект)
   %param p_clean_category_id          Ид категории уборки
   %param p_clean_subcategory_id       Ид подкатегории уборки
   %param p_own_agree                  Признак у меня на согласовании
   %param p_sort_order                 Порядок сортировки
   %param p_start_index                Начальный индекс для пейджинга (отсчет идет с 1)
   %param p_end_index                  Конечный индекс для пейджинга (отсчет идет с нуля)
   */
   l_row_from integer;
   l_row_to integer;
begin
  l_row_from:=coalesce(p_start_index,1);
  l_row_to:=coalesce(p_end_index,1000000);

  return query execute
   'select tt.rn
          ,tt.object_state_id
          ,tt.object_state_code
          ,tt.object_state_name
          ,tt.object_type_code
          ,tt.object_type_short_name
          ,tt.object_sub_type_short_name
          ,tt.id
          ,tt.name
          ,tt.version_date_from
          ,tt.version_date_to
          ,tt.okrug_short_name
          ,tt.district_name
          ,tt.owner_name
          ,tt.customer_name
          ,tt.parent_id
          ,tt.root_id
          ,tt.tree_upper_object_id
      from(select row_number() over(partition by 1 order by '||coalesce(p_sort_order,'id desc')||') rn
                 ,t.object_state_id
                 ,t.object_state_code
                 ,t.object_state_name
                 ,t.object_type_code
                 ,t.object_type_short_name
                 ,t.object_sub_type_short_name
                 ,t.id
                 ,t.name
                 ,t.version_date_from
                 ,t.version_date_to
                 ,t.okrug_short_name
                 ,t.district_name
                 ,t.owner_name
                 ,t.customer_name
                 ,t.parent_id
                 ,t.root_id
                 ,t.tree_upper_object_id
             from ods.fdc_ods_pck_get_content_inner(p_date_act              => $1
                                                   ,p_object_type_id        => $2
                                                   ,p_owner_id              => $3
                                                   ,p_customer_id           => $4
                                                   ,p_okrug_id              => $5
                                                   ,p_district_id           => $6
                                                   ,p_state_id              => $7
                                                   ,p_object_type_sub_id    => $8
                                                   ,p_object_type_up_id     => $9
                                                   ,p_name_or_id            => $10
                                                   ,p_passport_num          => $11
                                                   ,p_passport_author_id    => $12
                                                   ,p_passport_developer_id => $13
                                                   ,p_address_list          => $14
                                                   ,p_with_actual_address   => $15
                                                   ,p_category_id           => $16
                                                   ,p_ownerless             => $17
                                                   ,p_clean_category_id     => $18
                                                   ,p_clean_subcategory_id  => $19
                                                   ,p_own_agree             => $20
                                                   ) t
          ) tt
     where tt.rn between $21 and $22'
               using p_date_act             --$1
                    ,p_object_type_id       --$2
                    ,p_owner_id             --$3
                    ,p_customer_id          --$4
                    ,p_okrug_id             --$5
                    ,p_district_id          --$6
                    ,p_state_id             --$7
                    ,p_object_type_sub_id   --$8
                    ,p_object_type_up_id    --$9
                    ,p_name_or_id           --$10
                    ,p_passport_num         --$11
                    ,p_passport_author_id   --$12
                    ,p_passport_developer_id--$13
                    ,p_address_list         --$14
                    ,p_with_actual_address  --$15
                    ,p_category_id          --$16
                    ,p_ownerless            --$17
                    ,p_clean_category_id    --$18
                    ,p_clean_subcategory_id --$19
                    ,p_own_agree            --$20
                    ,l_row_from             --$21
                    ,l_row_to;              --$22
  return;
end
$$;

