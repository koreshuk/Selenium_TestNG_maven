CREATE FUNCTION fdc_person_pck_get_legal_crc(p_legal_person nsi.fdc_legal_person)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  /** Вычисление контрольной суммы для субъектов
  (!) При появлении новых атрибутов их необходимо добавлять в вычисление
  %usage Внутри пакета и в fdc_asur_pck
  %param p_legal_person Данные fdc_legal_person
  %return Контрольная сумма
  */

  /** Целочисленный формат*/
  c_integer_format  constant text := '9999999999999999999';
  /** Формат даты */
  c_date_format     constant text := 'DDMMYYYYHH24MISS';
  /** Разделитель */
  c_delim           constant text := chr(9);

  c_empty           constant varchar(1):='';
begin
 return md5(rtrim(coalesce(to_char(p_legal_person.person_type_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.name,c_empty)
                  ||c_delim||coalesce(p_legal_person.short_name,c_empty)
                  ||c_delim||coalesce(p_legal_person.patronymic,c_empty)
                  ||c_delim||coalesce(p_legal_person.inn,c_empty)
                  ||c_delim||coalesce(p_legal_person.kpp,c_empty)
                  ||c_delim||coalesce(p_legal_person.ogrn,c_empty)
                  ||c_delim||coalesce(p_legal_person.okpo,c_empty)
                  ||c_delim||coalesce(p_legal_person.snils,c_empty)
                  ||c_delim||coalesce(p_legal_person.account,c_empty)
                  ||c_delim||coalesce(p_legal_person.postal_address,c_empty)
                  ||c_delim||coalesce(p_legal_person.legal_address,c_empty)
                  ||c_delim||coalesce(p_legal_person.email,c_empty)
                  ||c_delim||coalesce(p_legal_person.phone,c_empty)
                  ||c_delim||coalesce(p_legal_person.fax,c_empty)
                  ||c_delim||coalesce(p_legal_person.off_post,c_empty)
                  ||c_delim||coalesce(p_legal_person.off_name,c_empty)
                  ||c_delim||coalesce(p_legal_person.bik,c_empty)
                  ||c_delim||coalesce(p_legal_person.bank,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.occupation_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.person_code,c_empty)
                  ||c_delim||coalesce(p_legal_person.person_code_name,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.birth_date,c_date_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.okved,c_empty)
                  ||c_delim||coalesce(p_legal_person.corr_account,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.reg_date,c_date_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.birth_place,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.closing_date,c_date_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.gender,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.birth_country_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.identity_doctype_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.docseries,c_empty)
                  ||c_delim||coalesce(p_legal_person.docnumber,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.issue_date,c_date_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.issue_dept,c_empty)
                  ||c_delim||coalesce(p_legal_person.issue_dept_code,c_empty)
                  ||c_delim||coalesce(p_legal_person.work_length,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.parent_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.root_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.bank_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.is_small_medium,c_integer_format),c_empty)
                  ||c_delim||case
                               when p_legal_person.sro_flag then '1'
                               when not p_legal_person.sro_flag then '0'
                               else ''
                             end
                  ||c_delim||coalesce(to_char(p_legal_person.sro_org_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.okonh_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.okopf_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.okved_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.okfs_id,c_integer_format),c_empty)
                  ||c_delim||coalesce(p_legal_person.sro_regnum,c_empty)
                  ||c_delim||coalesce(to_char(p_legal_person.bind_person_id,c_integer_format),c_empty)
                ,c_delim
                 )
           );
end
$$;

