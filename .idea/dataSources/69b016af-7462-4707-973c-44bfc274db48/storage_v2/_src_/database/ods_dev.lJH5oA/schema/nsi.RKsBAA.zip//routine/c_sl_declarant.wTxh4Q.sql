CREATE FUNCTION c_sl_declarant()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 2::bigint;
$$;

