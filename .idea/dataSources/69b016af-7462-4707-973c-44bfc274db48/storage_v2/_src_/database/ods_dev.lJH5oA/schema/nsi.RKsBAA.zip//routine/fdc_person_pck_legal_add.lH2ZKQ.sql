CREATE FUNCTION fdc_person_pck_legal_add(p_person_type_id bigint, p_name character varying, p_short_name character varying, p_inn character varying DEFAULT NULL::character varying, p_kpp character varying DEFAULT NULL::character varying, p_ogrn character varying DEFAULT NULL::character varying, p_okpo character varying DEFAULT NULL::character varying, p_account character varying DEFAULT NULL::character varying, p_postal_address character varying DEFAULT NULL::character varying, p_legal_address character varying DEFAULT NULL::character varying, p_email character varying DEFAULT NULL::character varying, p_phone character varying DEFAULT NULL::character varying, p_fax character varying DEFAULT NULL::character varying, p_off_post character varying DEFAULT NULL::character varying, p_off_name character varying DEFAULT NULL::character varying, p_bank character varying DEFAULT NULL::character varying, p_bik character varying DEFAULT NULL::character varying, p_person_code character varying DEFAULT NULL::character varying, p_corr_account character varying DEFAULT NULL::character varying, p_reg_date date DEFAULT NULL::date, p_parent_id bigint DEFAULT NULL::bigint, p_start_date timestamp without time zone DEFAULT NULL::timestamp without time zone, p_end_date timestamp without time zone DEFAULT NULL::timestamp without time zone, p_event_id bigint DEFAULT NULL::bigint, p_person_code_name character varying DEFAULT NULL::character varying, p_cbr_bank_id bigint DEFAULT NULL::bigint, p_is_small_medium bigint DEFAULT NULL::bigint, p_sro_flag boolean DEFAULT NULL::boolean, p_sro_org_id bigint DEFAULT NULL::bigint, p_sro_regnum character varying DEFAULT NULL::character varying, p_okonh_id bigint DEFAULT NULL::bigint, p_okopf_id bigint DEFAULT NULL::bigint, p_okved_id bigint DEFAULT NULL::bigint, p_okfs_id bigint DEFAULT NULL::bigint, p_t_legal_address nsi.t_legal_person_address DEFAULT NULL::nsi.t_legal_person_address, p_t_postal_address nsi.t_legal_person_address DEFAULT NULL::nsi.t_legal_person_address, p_bind_ver_id bigint DEFAULT NULL::bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Добавление организации
  %usage Используется в legal_card_add и в интерфейсе при добавлении орг в рамках документа
  %param p_person_type_id -- Тип суъекта права
  %param p_code        --Код в АС Управления Реестрами
  %param p_name        --Полное наименование
  %param p_short_name  --Краткое наименование
  %param p_inn         --Идентификационный номер налогоплательщика
  %param p_kpp         --Код причины постановки на учёт
  %param p_ogrn        --Основной государственный регистрационный номер
  %param p_okpo        --Общероссийский классификатор предприятий и организаций
  %param p_account     --Расчётный счёт (текущий счёт)
  %param p_postal_address --Фактический адрес
  %param p_legal_address  --Юридический адрес
  %param p_email          --Электронная почта
  %param p_phone          --Телефон организации или ответственного лица
  %param p_fax            --Факс организации
  %param p_off_post       --Должность руководителя
  %param p_off_name       --ФИО руководителя
  %param p_bank           -- Банк
  %param p_bik            -- БИК
  %param p_person_code    -- Код подразделения
  %param p_okved          -- ОКВЭД
  %param p_corr_account   -- Корреспондентский счет
  %param p_reg_date       -- Дата регистрации
  %param p_parent_id      -- Ид головной организации
  %param p_last_changed   -- Дата последнего изменения
  %param p_username       -- Кто изменил запись
  %param p_start_date     -- Дата начала действия организации (заплняется только при редактировании в карточке ЮЛ)
  %param p_end_date       -- Дата окончания действия организации (но не версии), введенная пользователем
  %param p_event_id       -- Ид события, если оно было зарегитсрировано вне legal_add (для внешних систем всегда null)
  %param p_person_code_name -- Вид подразделения
  %param p_cbr_bank_id      -- Ид банка
  %param p_is_small_medium  -- Признак малого или среднего бизнеса
  %param p_sro_flag         -- Признак СРО
  %param p_sro_org_id       -- Ид СРО
  %param p_sro_regnum       -- Регистрационный номер СРО
  %param p_okonh_id            Ид ОКОНХ
  %param p_okopf_id            Ид ОКОПФ
  %param p_okved_id            Ид ОКВЕД
  %param p_okfs_id             Ид ОКФС
  %param p_t_legal_address  -- объект юридический адрес
  %param p_t_postal_address -- объект фактический адрес
  %param p_bind_ver_id      -- ИД связанного субъекта
  %return ИД организации
  */
  l_event_id     event.fdc_event_log.event_id%type := p_event_id;
  l_legal_person nsi.fdc_legal_person;
begin
  if p_person_type_id is null then
    raise exception 'Не указан тип субъекта';
  elsif p_person_type_id not in (nsi.c_sl_organization(), nsi.c_sl_declarant(), nsi.c_sl_branch()) then
    raise exception 'ЮЛ. Неверно задан тип субъекта. PERSON_TYPE = %',p_person_type_id;
  end if;

  l_legal_person.person_type_id := p_person_type_id;
  l_legal_person.short_name := p_short_name;
  l_legal_person.okpo:=p_okpo;
  l_legal_person.account:=p_account;
  l_legal_person.postal_address:=p_postal_address;
  l_legal_person.email:=p_email;
  l_legal_person.fax:=p_fax;
  l_legal_person.off_post:=p_off_post;
  l_legal_person.off_name:=p_off_name;
  l_legal_person.bik:=p_bik;
  l_legal_person.bank:=p_bank;
  l_legal_person.person_code:=p_person_code;
  l_legal_person.person_code_name:=p_person_code_name;

  l_legal_person.corr_account:=p_corr_account;
  l_legal_person.closing_date := p_end_date;
  l_legal_person.parent_id := p_parent_id;
  l_legal_person.bank_id := p_cbr_bank_id;
  l_legal_person.is_small_medium := p_is_small_medium;
  l_legal_person.sro_flag := p_sro_flag;
  l_legal_person.sro_org_id := p_sro_org_id;
  l_legal_person.sro_regnum := p_sro_regnum;
  l_legal_person.okonh_id := p_okonh_id;
  l_legal_person.okopf_id := p_okopf_id;
  l_legal_person.okved_id := p_okved_id;
  l_legal_person.okfs_id := p_okfs_id;
  l_legal_person.phone := p_phone;

  -- ключевые реквизиты
  l_legal_person.name := p_name;
  l_legal_person.inn := p_inn;
  l_legal_person.kpp := p_kpp;
  l_legal_person.ogrn := p_ogrn;
  l_legal_person.legal_address := p_legal_address;
  l_legal_person.reg_date:=p_reg_date;
  l_legal_person.is_local_version := false;

  if l_legal_person.person_type_id<>nsi.c_sl_declarant() then
    l_legal_person.kpp:=coalesce(l_legal_person.kpp,nsi.fdc_person_pck_get_default_kpp(l_legal_person.inn));
  end if;

  -- Создание новой версии (ФЛК внутри)
  l_legal_person.id :=nsi.fdc_person_pck_add_version(p_old_ver_id       => l_legal_person.id
                                                    ,p_legal_person     => l_legal_person
                                                    ,p_start_date       => p_start_date
                                                    ,p_event_id         => l_event_id
                                                    ,p_with_flk         => true
                                                    ,p_is_local         => false
                                                    ,p_t_legal_address  => p_t_legal_address
                                                    ,p_t_postal_address => p_t_postal_address
                                                    ,p_bind_ver_id      => p_bind_ver_id
                                                    );

  return l_legal_person.id;
end
$$;

