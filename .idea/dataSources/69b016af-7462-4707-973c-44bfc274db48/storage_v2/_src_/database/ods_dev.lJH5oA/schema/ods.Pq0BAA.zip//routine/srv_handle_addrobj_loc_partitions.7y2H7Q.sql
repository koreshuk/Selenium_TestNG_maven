CREATE FUNCTION srv_handle_addrobj_loc_partitions()
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Отвязывает ненужные или создает/привязывает новые секции таблицы ods.fdc_as_addrobj_loc
     в зависимости от region_code набора используемых адресов ФИАС (указывается в параметре FIAS_REGION_CODE).
     Вызывается из функции ods.srv_set_fias_local_names()
  */
  rec record;
  rec_fk record;

  l_applog_partiton_name varchar(50);

  C_TAB_TABLESPACE constant varchar(50):='pg_default';
  C_IND_TABLESPACE constant varchar(50):='pg_default';
  C_SCHEMA constant varchar(50):='ods';

  C_PARTITION_COLUMN constant varchar(50):='region_code';
  C_CHECK_NAME_SUFFIX constant varchar(50):='_partcheck';

  C_MASTER_TABLE constant varchar(50):='fdc_as_addrobj_loc';
  C_APPLOG_NAME_PREFIX constant varchar(50):='fdc_as_addrobj_loc_';
begin
  -- отвязываем секции, которые больше не нужны
  for rec in(select chld_ns.nspname as child_schema
                   ,chld.relname as child_table
               from pg_inherits pgi
               join pg_class prnt on pgi.inhparent=prnt.oid
               join pg_namespace prnt_ns on prnt.relnamespace=prnt_ns.oid
               join pg_class chld on pgi.inhrelid=chld.oid
               join pg_namespace chld_ns on chld.relnamespace=chld_ns.oid
              where prnt_ns.nspname = C_SCHEMA
                and prnt.relname = C_MASTER_TABLE
                and prnt.relkind='r'
                and chld_ns.nspname = C_SCHEMA
                and chld.relkind='r'
                and chld.relname not in(select lower(C_APPLOG_NAME_PREFIX||unnest(string_to_array(param_value,',')))
                                          from parameter.fdc_parameter_md
                                         where param_code='FIAS_REGION_CODE'
                                           and current_date between date_from and date_to
                                        )
            ) loop
    execute
      format('ALTER TABLE %I.%I NO INHERIT %I.%I',rec.child_schema,rec.child_table,C_SCHEMA,C_MASTER_TABLE);
  end loop;
  for rec in(with p as (select unnest(string_to_array(param_value,','))::integer rc
                          from parameter.fdc_parameter_md
                         where param_code='FIAS_REGION_CODE'
                           and current_date between date_from and date_to
                       )
               select distinct region_code::varchar(3) as region_code
                 from ods.fdc_as_addrobj fias
                 join p on fias.region_code=p.rc
            ) loop
    l_applog_partiton_name :=lower(C_APPLOG_NAME_PREFIX||rec.region_code);
    -- Создаем таблицу секции, если не существует и внешние ключи, если такие есть в мастер таблице
    if not exists(select null
                    from pg_class prt
                    join pg_namespace prt_ns on prt.relnamespace=prt_ns.oid
                   where prt.relkind='r'
                     and prt_ns.nspname = C_SCHEMA
                     and prt.relname = l_applog_partiton_name
                 ) then
      execute
        format('CREATE TABLE %I.%I (LIKE %I.%I INCLUDING DEFAULTS INCLUDING ALL) tablespace %I',C_SCHEMA,l_applog_partiton_name,C_SCHEMA,C_MASTER_TABLE,C_TAB_TABLESPACE);

      for rec_fk in(select sch.nspname as fk_schema
                         ,cls.relname as fk_table
                         ,col.attname as fk_column
                         ,fk.conname as fk_name
                         ,fkref_sch.nspname as fk_ref_schema
                         ,fkref.relname as fk_ref_table
                         ,fkref_col.attname as fk_ref_column
                     from pg_class cls
                     join pg_namespace sch on sch.oid = cls.relnamespace
                     join pg_attribute col on col.attrelid = cls.oid
                     join pg_constraint fk on fk.conrelid=cls.oid and fk.contype='f' and exists(select null
                                                                                                  from unnest(fk.conkey) as cc
                                                                                                 where cc=col.attnum
                                                                                               )
                     join pg_class fkref on fkref.oid=fk.confrelid
                     join pg_namespace fkref_sch on fkref_sch.oid = fkref.relnamespace
                     join pg_attribute fkref_col on fkref_col.attrelid = fkref.oid and exists(select null
                                                                                                from unnest(fk.confkey) as ccf
                                                                                               where ccf=fkref_col.attnum
                                                                                              )
                    where sch.nspname = C_SCHEMA
                      and cls.relname = C_MASTER_TABLE
                      and cls.relkind='r'
                  ) loop
        execute
          format('alter table %I.%I
                    add constraint %I foreign key (%I)
                    references %I.%I (%I)
                    on delete restrict on update restrict'
                 ,C_SCHEMA,l_applog_partiton_name
                 ,l_applog_partiton_name||'_'||rec.fk_column||'_FK',rec.fk_column
                 ,rec.fk_ref_schema,rec.fk_ref_table,rec.fk_ref_column
                );
      end loop;
      -- Создаем CHECK ограничение по колонку секционирования
      execute
        format('alter table %I.%I
                add constraint %I check(%I = '||rec.region_code||
                                      ')'
              ,C_SCHEMA,l_applog_partiton_name
              ,l_applog_partiton_name||C_CHECK_NAME_SUFFIX,C_PARTITION_COLUMN
              );


    end if;
	/*
    perform ods.srv_fill_addrobj_loc_partition(p_region_code      => rec.region_code
                                              ,p_partition_schema => C_SCHEMA
                                              ,p_partition_name   => l_applog_partiton_name
                                              );
	*/										  
    -- Создаем индекс на колонке секционирования
    if not exists(select null
                    from pg_class cls
                    join pg_namespace sch on sch.oid = cls.relnamespace
                    join pg_attribute col on col.attrelid = cls.oid
                    join pg_index fkind2 on fkind2.indrelid=cls.oid and exists(select null
                                                                                 from unnest(fkind2.indkey) ik
                                                                                where ik=col.attnum
                                                                               )
                    join pg_class fkind on fkind.oid=fkind2.indexrelid and fkind.relkind='i'
                   where sch.nspname = C_SCHEMA
                     and cls.relname = l_applog_partiton_name
                     and cls.relkind='r'
                     and col.attname=C_PARTITION_COLUMN
                 ) then
      execute
         format('create index %I on %I.%I using btree(%I) tablespace %I'
                ,l_applog_partiton_name||'_'||C_PARTITION_COLUMN||'_i'
                ,C_SCHEMA
                ,l_applog_partiton_name
                ,C_PARTITION_COLUMN
                ,C_IND_TABLESPACE
               );
    end if;

    -- Делаем созданную таблицу наследником мастер таблицы
    if not exists(select null
                        from pg_inherits pgi
                        join pg_class prnt on pgi.inhparent=prnt.oid
                        join pg_namespace prnt_ns on prnt.relnamespace=prnt_ns.oid
                        join pg_class chld on pgi.inhrelid=chld.oid
                        join pg_namespace chld_ns on chld.relnamespace=chld_ns.oid
                       where prnt_ns.nspname = C_SCHEMA
                         and prnt.relname = C_MASTER_TABLE
                         and prnt.relkind='r'
                         and chld_ns.nspname = C_SCHEMA
                         and chld.relname = l_applog_partiton_name
                         and chld.relkind='r'
                     ) then
      execute
        format('ALTER TABLE %I.%I INHERIT %I.%I',C_SCHEMA,l_applog_partiton_name,C_SCHEMA,C_MASTER_TABLE);
      perform ods.srv_fill_addrobj_loc_partition(p_region_code      => rec.region_code
                                                ,p_partition_schema => C_SCHEMA
                                                ,p_partition_name   => l_applog_partiton_name
                                                );		
    end if;
  end loop;
end
$$;

