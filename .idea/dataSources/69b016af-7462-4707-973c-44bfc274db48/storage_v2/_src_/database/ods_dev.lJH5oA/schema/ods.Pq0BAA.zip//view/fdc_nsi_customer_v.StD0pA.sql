CREATE VIEW fdc_nsi_customer_v AS
  SELECT pr.id AS person_role_id,
    lp.id AS person_id,
    lp.root_id,
    lp.name,
    lp.short_name,
    date_trunc('day'::text, lp.start_date) AS person_start_date,
    COALESCE(date_trunc('day'::text, lp.end_date), (to_date('01.01.3000'::text, 'DD.MM.YYYY'::text))::timestamp without time zone) AS person_end_date,
    pr.sort_order,
    date_trunc('day'::text, pr.begin_date) AS role_start_date,
    COALESCE(date_trunc('day'::text, pr.end_date), (to_date('01.01.3000'::text, 'DD.MM.YYYY'::text))::timestamp without time zone) AS role_end_date
   FROM nsi.fdc_legal_person_v lp,
    nsi.fdc_person_role pr,
    nsi.fdc_role r
  WHERE ((pr.person_id = lp.root_id) AND (pr.role_id = r.id) AND ((r.code)::text = ANY (ARRAY[('17'::character varying)::text, ('1017'::character varying)::text])));

COMMENT ON VIEW fdc_nsi_customer_v IS 'Заказчик ОГХ';

COMMENT ON COLUMN fdc_nsi_customer_v.person_role_id IS 'ИД роли физического или юридического лица';

COMMENT ON COLUMN fdc_nsi_customer_v.person_id IS 'ИД субъекта';

COMMENT ON COLUMN fdc_nsi_customer_v.root_id IS 'ИД ROOT субъекта';

COMMENT ON COLUMN fdc_nsi_customer_v.name IS 'Наименование заказчика';

COMMENT ON COLUMN fdc_nsi_customer_v.short_name IS 'Краткое наименование заказчика';

COMMENT ON COLUMN fdc_nsi_customer_v.person_start_date IS 'Дата начала версии заказчика';

COMMENT ON COLUMN fdc_nsi_customer_v.person_end_date IS 'Дата окончания версии заказчика';

COMMENT ON COLUMN fdc_nsi_customer_v.sort_order IS 'Порядок сортировки';

COMMENT ON COLUMN fdc_nsi_customer_v.role_start_date IS 'Дата начала действия роли';

COMMENT ON COLUMN fdc_nsi_customer_v.role_end_date IS 'Дата окончания действия роли';

