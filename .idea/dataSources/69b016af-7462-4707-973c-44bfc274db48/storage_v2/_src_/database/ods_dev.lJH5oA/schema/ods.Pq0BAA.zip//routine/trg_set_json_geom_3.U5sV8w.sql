CREATE FUNCTION trg_set_json_geom_3()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare

begin
  if tg_when='BEFORE' and tg_level='ROW' and tg_op in('INSERT','UPDATE') then
    if st_srid(ST_GeomFromGeoJSON(new.geometry_wgs_json))<> 0 then
      new.geometry_wgs_json:=st_asgeojson(st_setSrid(ST_GeomFromGeoJSON(new.geometry_wgs_json),0));
    end if;
    new.geometry_wgs := ST_GeomFromGeoJSON(new.geometry_wgs_json);

    if st_srid(ST_GeomFromGeoJSON(new.geometry_msk_json))<> 0 then
      new.geometry_msk_json:=st_asgeojson(st_setSrid(ST_GeomFromGeoJSON(new.geometry_msk_json),0));
    end if;
    new.geometry_msk := ST_GeomFromGeoJSON(new.geometry_msk_json);
  end if;
  return NEW;
end
$$;

