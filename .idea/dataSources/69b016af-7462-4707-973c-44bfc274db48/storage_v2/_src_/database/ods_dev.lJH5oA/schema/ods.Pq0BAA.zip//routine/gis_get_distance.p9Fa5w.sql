CREATE FUNCTION gis_get_distance(lat1 double precision, lon1 double precision, lat2 double precision, lon2 double precision)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
  latMid double precision;
  m_per_deg_lat double precision;
  m_per_deg_lon double precision;
  deltaLat double precision;
  deltaLon double precision;
  dist_m double precision;
begin
  latMid = (Lat1+Lat2 )/2.0;
  
  m_per_deg_lat = 111132.954 - 559.822 * cos( 2.0 * latMid ) + 1.175 * cos( 4.0 * latMid);
  m_per_deg_lon = (3.14159265359/180.0 ) * 6367449.0 * cos ( latMid );

  deltaLat = abs(Lat1 - Lat2);
  deltaLon = abs(Lon1 - Lon2);

  dist_m = sqrt ( pow( deltaLat * m_per_deg_lat,2) + pow( deltaLon * m_per_deg_lon , 2));
  
  return dist_m;  
end
$$;

