CREATE FUNCTION fdc_workplan_get_snowfall_period_cd(p_work_date timestamp without time zone)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
  /* Диагностика периода снегопада

  %param p_work_date - дата из фильтра Дата работ с

  %return - период снегопада(числовый код)
  */
  l_work_date_start timestamp;
  l_work_date_end timestamp;
  l_work_date_start_48 timestamp;
  l_current_dt timestamp;

  l_last_date_end timestamp;

  l_snowfall_periods msnow.t_srv_snowfall_period[];

  rec record;

  l_total_snow_duration_hr double precision;
  l_cnt integer;

  l_rescode integer;
begin
  l_work_date_start:=date_trunc('day',p_work_date);
  l_work_date_end:=l_work_date_start+ interval '1' day - interval '1' second;
  l_work_date_start_48:=l_work_date_start- interval '48' hour;
  l_current_dt:=current_timestamp::timestamp;



  l_snowfall_periods:=array(select row(w.id
                                      ,w.snow_date_from
                                      ,w.snow_date_to
                                      ,case
                                         when w.snow_date_from<l_work_date_end and
                                              coalesce(w.snow_date_to,ods.c_infinity_plus())> l_work_date_start THEN
                                           true
                                         else
                                           false
                                       end --is_in_work_date -- true = снегопад полностью или частично попадает в указанные сутки
                                      ,case
                                         when w.snow_date_from<l_work_date_end and
                                              coalesce(w.snow_date_to,ods.c_infinity_plus())> l_work_date_start and
                                              coalesce(w.snow_date_to,ods.c_infinity_plus())> l_work_date_end THEN
                                           true
                                         else
                                           false
                                       end --lasts_in_work_date -- true = незавершенный на конец указанных суток снегопад
                                      ,(extract(epoch from coalesce(w.snow_date_to,l_work_date_end))-
                                        extract(epoch from w.snow_date_from)
                                       )/60/60 --snow_duration_hr
                                      ,(extract(epoch from w.snow_date_from) -
                                        extract(epoch FROM lead(w.snow_date_from,1,w.snow_date_from) over(order by w.snow_date_from DESC
                                                                                                                  ,w.snow_date_to desc nulls first
                                                                                                         )
                                               )
                                       )/60/60 --snowless_interval_hr
                                      )
                                 from msnow.fdc_weather w
                                where w.snow_date_from<l_work_date_end
                                  and coalesce(w.snow_date_to,ods.c_infinity_plus())> l_work_date_start_48

                           );

  select count(t.id)
    into l_cnt
    from unnest(l_snowfall_periods) as t;

  if l_cnt=0 then
    l_rescode:=1; -- Нет снегопада (более 48 часов после последнего).
  else
    select count(1)
      into l_cnt
      from unnest(l_snowfall_periods) as t
     where t.is_in_work_date=TRUE; -- снегопад полностью или частично попадает в указанные сутки
      -- and t.lasts_in_work_date=true;-- незакончен
    if l_cnt>0 then
      l_total_snow_duration_hr:=0;
      ----------------------------------------
      select max(COALESCE(t.snow_date_to,l_work_date_end))
        into l_last_date_end
        from unnest(l_snowfall_periods) as t
       where t.is_in_work_date=TRUE;

      if (l_last_date_end <= l_work_date_end) and
         (l_last_date_end + interval '10' hour between l_work_date_start and l_work_date_end) then
        l_rescode:=31;
      else
        select sum(extract(epoch from per.snow_workdate_to) -
                   extract(epoch from per.snow_workdate_from)
                  )/60/60
          into l_total_snow_duration_hr
          from(select case
                        when GREATEST(t.snow_date_from,l_work_date_start) between l_work_date_start and l_work_date_end then
                          GREATEST(t.snow_date_from,l_work_date_start)
                      end snow_workdate_from
                     ,case
                        when least(COALESCE(t.snow_date_to,l_work_date_end),l_work_date_end) between l_work_date_start and l_work_date_end then
                          least(COALESCE(t.snow_date_to,l_work_date_end),l_work_date_end)
                      end snow_workdate_to
                 from unnest(l_snowfall_periods) as t
                where t.is_in_work_date=TRUE
              ) per;
        l_rescode:=case
                     when l_total_snow_duration_hr >= 10 then
                       22 -- Снегопад длительностью (или несколько снегопадов суммарной длительностью от начала первого до конца последнего) более 10 часов
                     else
                       21 -- Снегопад длительностью (или несколько снегопадов суммарной длительностью от начала первого до конца последнего) менее 10 часов
                   end;
      end if;
    ELSE
      select max(t.snow_date_to) as snow_date_to
        into l_last_date_end
        from unnest(l_snowfall_periods) as t
       where t.snow_date_to <= l_work_date_end;--LEAST(l_current_dt,l_work_date_end);

      l_rescode:=case
                   when (l_last_date_end + interval '10' hour between l_work_date_start and l_work_date_end) and
                        (l_last_date_end + interval '24' hour between l_work_date_start and l_work_date_end) then 34
                   when l_last_date_end + interval '10' hour between l_work_date_start and l_work_date_end then 31
                   when l_last_date_end + interval '24' hour between l_work_date_start and l_work_date_end then 32
                   when l_last_date_end + interval '48' hour between l_work_date_start and l_work_date_end then 33
                 end;
    end if;
  end if;
  return l_rescode;
end
$$;

