CREATE FUNCTION fdc_ldv_obligation_stat(p_municipality_id bigint, OUT municipality_name text, OUT obligation_id bigint, OUT obligation_year text, OUT work_category text, OUT driveway_cnt integer, OUT work_cost double precision, OUT estimate_work_cost double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Статистика по местным дорогам муниц. района" - Реестр бюджетов
  %param p_municipality_id - Ид муниципального района/городского округа
  */
begin
  return query select mnc.formal_name||case
                                         when mnc.short_name is not null then ' '||mnc.short_name
                                         else ''
                                       end::text as municipality_name
                                      ,obl.id as obligation_id
                                      ,obl.obligation_year::text
                                      ,wc.name::text as work_category
                                      ,coalesce((select count(distinct oblo.driveway_id)
                                                   from msnow.fdc_obligation_object oblo
                                                  where oblo.obligation_id=obl.id
                                                ),0)::integer as driveway_cnt
                                      ,obl.work_cost
                                      ,coalesce((select sum(oble.work_cost)
                                                   from msnow.fdc_obligation_estimate oble
                                                  where oble.obligation_id=obl.id
                                                    and oble.is_estimate_sum
                                                ),0) as estimate_work_cost
                                  from msnow.fdc_obligation obl
                                  join msnow.fdc_work_category wc on obl.work_category_id=wc.id
                                  join nsi.fdc_person p on obl.authority_org_id=p.id
                                  join nsi.fdc_legal_person lp on p.id=lp.root_id
                                  join ods.fdc_as_addrobj mnc on lp.fias_district_id=mnc.id
                                 where wc.code in('MAINTAIN','REPAIR')
                                   and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                                   and mnc.id=p_municipality_id;

  return;
end
$$;

