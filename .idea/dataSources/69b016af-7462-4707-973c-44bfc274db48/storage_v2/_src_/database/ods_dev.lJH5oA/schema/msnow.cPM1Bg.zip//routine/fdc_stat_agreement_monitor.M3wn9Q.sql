CREATE FUNCTION fdc_stat_agreement_monitor()
  RETURNS SETOF msnow.t_agreement_monitor
LANGUAGE plpgsql
AS $$
declare
  /** Отчет "Мониторинг заполнения реестра обязательств"
  */
  rec record;
  l_row msnow.t_agreement_monitor;
begin
  for rec in(with hr as(select distinct pr.person_id
                          from nsi.fdc_person_role pr
                          join nsi.fdc_role r on pr.role_id=r.id
                         where statement_timestamp() between pr.begin_date and pr.end_date
                           and r.code in('OMSU','RUAD','TO')
                       )
                 ,mncp as(select distinct pr.person_id
                                ,lp.fias_district_id
                                ,lp.short_name
                            from nsi.fdc_person_role pr
                            join nsi.fdc_role r on pr.role_id=r.id
                            join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                           where statement_timestamp() between pr.begin_date and pr.end_date
                             and r.code in('OMSU')
                             and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                         )
             select agrmnt.customer_name
                   ,agrmnt.agreement_type_name
                   ,agrmnt.reg_num
                   ,agrmnt.work_category_name
                   ,to_char(agrmnt.work_date_from,'dd.mm.yyyy') as work_date_from
                   ,to_char(agrmnt.work_date_to,'dd.mm.yyyy') as work_date_to
                   ,agrmnt.agreement_cost
                   ,agrmnt.agreement_object_cnt
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                          where agre.agreement_id=agrmnt.agreement_id
                            and agre.is_estimate_sum
                        )
                    end as estimate_work_cost
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='ONE_CH'
                        )
                    end as estimate_work_cost_1ch
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='ONE_C'
                        )
                    end as estimate_work_cost_1c
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='ONE_H'
                        )
                    end as estimate_work_cost_1h
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='ONE'
                        )
                    end as estimate_work_cost_1
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='TWO_H'
                        )
                    end as estimate_work_cost_2h
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='TWO'
                        )
                    end as estimate_work_cost_2
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='THREE_H'
                        )
                    end as estimate_work_cost_3h
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='THREE_A'
                        )
                    end as estimate_work_cost_3a
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='THREE'
                        )
                    end as estimate_work_cost_3
                   ,case
                      when agrmnt.agreement_id is not null then
                        (select coalesce(sum(agre.work_cost),0)
                           from msnow.fdc_agr_estimate agre
                           join msnow.fdc_odh_group grpe on agre.odh_group_id=grpe.id
                          where agre.agreement_id=agrmnt.agreement_id
                            and grpe.code='OTHER'
                        )
                    end as estimate_work_cost_other
                   ,agrmnt.agreement_cost_sub
               from (select agr.id as agreement_id
                           ,agr.customer_id
                           ,case
                              when hr.person_id is not null then
                                (select clp.short_name
                                   from nsi.fdc_legal_person clp
                                  where clp.root_id=agr.customer_id
                                    and statement_timestamp() between clp.ver_start_date and clp.ver_end_date
                                )
                              else
                                (select mncp.short_name
                                   from mncp
                                  where fias_district_id=hrlp.fias_district_id
                                  limit 1
                                )
                            end as customer_name
                           ,agrt.name as agreement_type_name
                           ,agr.reg_num
                           ,wc.name as work_category_name
                           ,agr.work_date_from
                           ,agr.work_date_to
                           ,coalesce(agr.cost,0) as agreement_cost
                           ,coalesce(agr.cost_sub,0) as agreement_cost_sub
                           ,(select count(agro.id)
                               from msnow.fdc_agreement_object agro
                              where agro.argeement_id=agr.id
                            ) agreement_object_cnt
                       from msnow.fdc_agreement agr
                       left join hr on agr.customer_id=hr.person_id
                       left join nsi.fdc_legal_person hrlp on agr.customer_id=hrlp.root_id
                                                              and statement_timestamp() between hrlp.ver_start_date and hrlp.ver_end_date
                       left join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
                       left join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                    ) agrmnt
            ) loop
    l_row.customer_name:=rec.customer_name;
    l_row.agreement_type_name:=rec.agreement_type_name;
    l_row.reg_num:=rec.reg_num;
    l_row.work_category_name:=rec.work_category_name;
    l_row.work_date_from:=rec.work_date_from;
    l_row.work_date_to:=rec.work_date_to;
    l_row.agreement_cost:=rec.agreement_cost;
    l_row.agreement_object_cnt:=rec.agreement_object_cnt;
    l_row.estimate_work_cost:=rec.estimate_work_cost;
    l_row.estimate_work_cost_1ch:=rec.estimate_work_cost_1ch;
    l_row.estimate_work_cost_1c:=rec.estimate_work_cost_1c;
    l_row.estimate_work_cost_1h:=rec.estimate_work_cost_1h;
    l_row.estimate_work_cost_1:=rec.estimate_work_cost_1;
    l_row.estimate_work_cost_2h:=rec.estimate_work_cost_2h;
    l_row.estimate_work_cost_2:=rec.estimate_work_cost_2;
    l_row.estimate_work_cost_3h:=rec.estimate_work_cost_3h;
    l_row.estimate_work_cost_3a:=rec.estimate_work_cost_3a;
    l_row.estimate_work_cost_3:=rec.estimate_work_cost_3;
    l_row.estimate_work_cost_other:=rec.estimate_work_cost_other;
    l_row.agreement_cost_sub:=rec.agreement_cost_sub;
    return next l_row;
  end loop;
  return;
end
$$;

