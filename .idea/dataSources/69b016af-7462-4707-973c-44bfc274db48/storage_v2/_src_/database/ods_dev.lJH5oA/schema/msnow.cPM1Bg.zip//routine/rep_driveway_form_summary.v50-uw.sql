CREATE FUNCTION rep_driveway_form_summary(p_summary_type integer, p_driveway_category_id bigint, p_customer_id bigint DEFAULT NULL::bigint, p_fias_district_id bigint DEFAULT NULL::bigint, OUT id bigint, OUT name character varying, OUT approved_last3days_qty bigint, OUT rejected_qty bigint, OUT sent_qty bigint, OUT expired_qty bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Сводка по согласованию паспортов" по заказчикам и по районам
  %param p_summary_type          - Тип формирования сводки:
                                   - 1 - в разрезе заказчиков
                                   - 2 - в разрезе муниципальных районов/городских округов

  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_customer_id           - Заказчик (Ид актуальной версии заказчика)
  %param p_fias_district_id      - Ид муниципального района/городского округа
  */
  l_summary_date date;
  l_workdays_lag_3 date;

  C_CUSTOMER_TYPE constant INTEGER:=1;
  C_FIAS_TYPE constant integer:=2;
begin
  l_summary_date:=current_date;
  l_workdays_lag_3:=msnow.srv_workdays_back(p_workdays_qty   => 3
                                           ,p_date_from      => l_summary_date
                                           );


  if p_summary_type=C_CUSTOMER_TYPE then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                      and (p_fias_district_id is null or lp.id in(select distinct obj.customer_id
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                   join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                   join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                   join ods.fdc_as_addrobj fias on fias.id=p_fias_district_id
                                                                  where /*objs.code='APPROVED'
                                                                    and*/ obj.driveway_category_id=p_driveway_category_id
                                                                  --  and l_summary_date between obj.version_date_from and obj.version_date_to
                                                                    and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                         (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                        )
                                                                 )
                          )
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as driveway_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='ODH'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select maxiter.driveway_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )
          ,dvway as(select odh.id as driveway_id
                          ,cust.id as customer_id
                          ,cust.root_id as customer_root_id
                          ,objs.code as object_state_code
                          ,obj.approval_date
                      from ods.fdc_object obj
                      join ods.fdc_odh odh on obj.id=odh.id
                      join ods.fdc_object_state objs on obj.object_state_id=objs.id
                      join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     where obj.driveway_category_id=p_driveway_category_id
                   )
    select null::bigint as customer_root_id
          ,rcust.customer_short_name
          ,count(distinct case
                            when dvway.object_state_code='APPROVED' and dvway.approval_date between l_workdays_lag_3 and l_summary_date then dvway.driveway_id
                          end
                ) as approved_last3days_qty
          ,count(distinct case
                            when dvway.object_state_code='PROJECT' and maxiter.approval_iteration_status_code='REJECTED' then dvway.driveway_id
                          end
                ) as rejected_qty

          ,count(distinct case
                            when dvway.object_state_code='ON_APPROVAL' then dvway.driveway_id
                          end
                ) as sent_qty
          ,count(distinct case
                            when dvway.object_state_code='ON_APPROVAL' and expired.driveway_id is not null then dvway.driveway_id
                          end
                ) as expired_qty
      from rcust
      left join dvway on rcust.customer_root_id=dvway.customer_root_id
      left join maxiter on dvway.driveway_id=maxiter.driveway_id
      left join expired on maxiter.driveway_id=expired.driveway_id
     group by /*rcust.customer_root_id
             ,*/rcust.customer_short_name;

  elsif p_summary_type=C_FIAS_TYPE then
    return query
      with fias_distr as(select fias.id as fias_district_id
                               ,fias.ao_level
                               ,fias.formal_name||case
                                                    when fias.short_name is not null then ' '||fias.short_name
                                                    else ''
                                                  end as fias_name
                           from ods.fdc_as_addrobj fias
                          where fias.id=p_fias_district_id
                            and fias.live_status
                            and (fias.ao_level=3 or (fias.ao_level in(4,6) and fias.area_code =0))
                         union
                         select fias.id as fias_district_id
                               ,fias.ao_level
                               ,fias.formal_name||case
                                                    when fias.short_name is not null then ' '||fias.short_name
                                                    else ''
                                                  end as fias_name
                           from ods.fdc_as_addrobj fias
                          where fias.live_status
                            and (fias.ao_level=3 or (fias.ao_level in(4,6) and fias.area_code =0))
                            and p_fias_district_id is null
                            and (p_customer_id is null or exists(select null
                                                                   from ods.fdc_object obj
                                                                   join ods.fdc_odh odh on obj.id=odh.id
                                                                   join ods.fdc_object_state objs on obj.object_state_id=objs.id
                                                                   join nsi.fdc_legal_person cst on obj.customer_id=cst.id
                                                                  where /*objs.code='APPROVED'
                                                                    and*/ obj.driveway_category_id=p_driveway_category_id
                                                                   -- and l_year between extract(year from obj.version_date_from) and extract(year from obj.version_date_to)
                                                                    and obj.customer_id=p_customer_id
                                                                    and ((fias.ao_level=3 and obj.as_area_id=fias.id) or
                                                                         (fias.ao_level in(4,6) and obj.as_place_id=fias.id)
                                                                        )
                                                                )
                                )
                        )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as driveway_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='ODH'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select maxiter.driveway_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )
          ,dvway as(select odh.id as driveway_id
                          ,cust.id as customer_id
                          ,cust.root_id as customer_root_id
                          ,objs.code as object_state_code
                          ,obj.approval_date
                          ,obj.as_area_id
                          ,obj.as_place_id
                      from ods.fdc_object obj
                      join ods.fdc_odh odh on obj.id=odh.id
                      join ods.fdc_object_state objs on obj.object_state_id=objs.id
                      join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                     where obj.driveway_category_id=p_driveway_category_id
                       and (p_customer_id is null or obj.customer_id=p_customer_id)
                   )
            select fds.fias_district_id
                  ,fds.fias_name::varchar
                  ,count(distinct case
                                    when fds.object_state_code='APPROVED' and fds.approval_date between l_workdays_lag_3 and l_summary_date then fds.driveway_id
                                  end
                        ) as approved_last3days_qty
                  ,count(distinct case
                                    when fds.object_state_code='PROJECT' and maxiter.approval_iteration_status_code='REJECTED' then fds.driveway_id
                                  end
                        ) as rejected_qty
                  ,count(distinct case
                                    when fds.object_state_code='ON_APPROVAL' then fds.driveway_id
                                  end
                        ) as sent_qty
                  ,count(distinct case
                                    when fds.object_state_code='ON_APPROVAL' and expired.driveway_id is not null then fds.driveway_id
                                  end
                        ) as expired_qty

              from(select fias_distr.fias_district_id
                         ,fias_distr.fias_name
                         ,dvway.customer_root_id
                         ,dvway.driveway_id
                         ,dvway.approval_date
                         ,dvway.object_state_code
                     from fias_distr
                     left join dvway on fias_distr.ao_level=3 and fias_distr.fias_district_id=dvway.as_area_id
                   union
                   select fias_distr.fias_district_id
                         ,fias_distr.fias_name
                         ,dvway.customer_root_id
                         ,dvway.driveway_id
                         ,dvway.approval_date
                         ,dvway.object_state_code
                     from fias_distr
                     left join dvway on fias_distr.ao_level in(4,6) and fias_distr.fias_district_id=dvway.as_place_id
                  ) as fds
              left join maxiter on fds.driveway_id=maxiter.driveway_id
              left join expired on maxiter.driveway_id=expired.driveway_id

             group by fds.fias_district_id
                     ,fds.fias_name;

  end if;
  return;
end
$$;

