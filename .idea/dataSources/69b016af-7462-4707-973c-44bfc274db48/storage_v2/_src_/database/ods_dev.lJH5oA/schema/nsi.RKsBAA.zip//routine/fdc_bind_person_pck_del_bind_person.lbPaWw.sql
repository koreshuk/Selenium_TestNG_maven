CREATE FUNCTION fdc_bind_person_pck_del_bind_person(p_person_id_1 bigint, p_person_id_2 bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Удаление связей между 2 субъектами
  %usage Используется для добавления связей
  %param p_person_id_1     - Ид субъекта 1
  %param p_person_id_2     - Ид субъекта 1
  */
  l_legal_person nsi.fdc_legal_person;
begin
  -- первый субъект
  select *
    into l_legal_person
    from nsi.fdc_legal_person
   where id = p_person_id_1;

  l_legal_person.bind_person_id := null;
  l_legal_person.crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_legal_person);

  update nsi.fdc_legal_person d
     set d.bind_person_id = null
        ,d.crc            = l_legal_person.crc
   where d.id = p_person_id_1;
  -- второй субъект
  select *
    into l_legal_person
    from nsi.fdc_legal_person
   where id = p_person_id_2;

  l_legal_person.bind_person_id := null;
  l_legal_person.crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_legal_person);

  update nsi.fdc_legal_person d
     set d.bind_person_id = null
        ,d.crc            = l_legal_person.crc
   where d.id = p_person_id_2;
end
$$;

