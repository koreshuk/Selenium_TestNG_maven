CREATE VIEW fdc_category_odh_v AS
  SELECT t1.code,
    t1.date_from,
    t1.date_to,
    t1.history_id,
    t2.code AS history_code,
    t2.name AS history_name,
    t1.id,
    t1.name
   FROM (fdc_category_odh t1
     LEFT JOIN fdc_category_odh t2 ON ((t1.history_id = t2.id)));

COMMENT ON VIEW fdc_category_odh_v IS 'Справочник категорий ОДХ';

COMMENT ON COLUMN fdc_category_odh_v.code IS 'Код категории ОДХ';

COMMENT ON COLUMN fdc_category_odh_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_category_odh_v.date_to IS 'Дата по';

COMMENT ON COLUMN fdc_category_odh_v.history_id IS 'Исторический Ид';

COMMENT ON COLUMN fdc_category_odh_v.history_code IS 'Код категории ОДХ';

COMMENT ON COLUMN fdc_category_odh_v.history_name IS 'Наименование категории ОДХ';

COMMENT ON COLUMN fdc_category_odh_v.id IS 'Идентификатор категории ОДХ';

COMMENT ON COLUMN fdc_category_odh_v.name IS 'Наименование категории ОДХ';

