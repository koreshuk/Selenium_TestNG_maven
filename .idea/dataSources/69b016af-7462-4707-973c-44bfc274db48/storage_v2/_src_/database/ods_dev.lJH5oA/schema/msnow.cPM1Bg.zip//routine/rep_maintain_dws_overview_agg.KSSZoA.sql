CREATE FUNCTION rep_maintain_dws_overview_agg(p_session_id character varying, p_period integer, p_work_status_id bigint DEFAULT NULL::bigint, p_driveway_category_id bigint DEFAULT NULL::bigint, p_municipality_id bigint DEFAULT NULL::bigint, p_owner_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, p_performer_id bigint DEFAULT NULL::bigint, p_season_id bigint DEFAULT NULL::bigint, p_work_type_id bigint DEFAULT NULL::bigint, p_maintain_group_id bigint DEFAULT NULL::bigint, p_period_date date DEFAULT NULL::date, p_period_from date DEFAULT NULL::date, p_period_to date DEFAULT NULL::date)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Витрина «Мониторинг выполнения работ по содержанию»
     Агрегирующая таблица

     %param p_session_id             - Ид сессии
     %param p_period                 - Период
                                         - 1 На дату (p_period_date)
                                         - 2 Конкретный период (p_period_from - p_period_to)
     %param p_work_status_id         - Статус работ
     %param p_driveway_category_id   - Балансовая принадлежность
     %param p_municipality_id        - Муниципальное образование
     %param p_owner_id               - Балансодержатель
     %param p_customer_id            - Заказчик
     %param p_performer_id           - Исполнитель
     %param p_season_id              - Сезон
     %param p_work_type_id           - Вид работы
     %param p_maintain_group_id      - Группа по содержанию
     %param p_period_date            - Дата
     %param p_period_from            - Период с
     %param p_period_to              - Период по

  */

  C_NOTEXISTS_ID constant bigint:=-1;

  l_performer_root_id nsi.fdc_legal_person.root_id%type;
  l_owner_root_id nsi.fdc_legal_person.root_id%type;
  l_customer_root_id nsi.fdc_legal_person.root_id%type;
  l_work_status_code msnow.fdc_work_status.code%type;
  l_municipality_root_id nsi.fdc_municipality.root_id%type;

  l_current_date date:=current_date;
begin
   delete from msnow.fdc_rep_maintodh_overview_agg where session_id=p_session_id;
   delete from msnow.fdc_rep_maintodh_overview_agg where set_date < current_date -2;

  if p_performer_id is not null then
    begin
      select root_id
        into strict l_performer_root_id
        from nsi.fdc_legal_person
       where id=p_performer_id;
    exception
      when NO_DATA_FOUND then
        l_performer_root_id:=C_NOTEXISTS_ID;
    end;
  else
    l_performer_root_id:=null;
  end if;

  if p_owner_id is not null then
    begin
      select root_id
        into strict l_owner_root_id
        from nsi.fdc_legal_person
       where id=p_owner_id;
    exception
      when NO_DATA_FOUND then
        l_owner_root_id:=C_NOTEXISTS_ID;
    end;
  else
    l_owner_root_id:=null;
  end if;

  if p_customer_id is not null then
    begin
      select root_id
        into strict l_customer_root_id
        from nsi.fdc_legal_person
       where id=p_customer_id;
    exception
      when NO_DATA_FOUND then
        l_customer_root_id:=C_NOTEXISTS_ID;
    end;
  else
    l_customer_root_id:=null;
  end if;

  if p_work_status_id is not null then
    begin
      select code
        into strict l_work_status_code
        from msnow.fdc_work_status
       where id=p_work_status_id;
    exception
      when NO_DATA_FOUND then
        null;
    end;
  end if;
  if p_municipality_id is not null then
    begin
      select root_id
        into l_municipality_root_id
        from nsi.fdc_municipality
       where id=p_municipality_id;
    exception
      when NO_DATA_FOUND then
        null;
    end;
  end if;

  with odh_mun as(select odhf.id
                    from ods.fdc_object objf
                    join ods.fdc_odh odhf on objf.id=odhf.id
                    join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                    join nsi.fdc_municipality m on fias.municipality_id=m.id
                   where m.root_id=l_municipality_root_id
                  union
                  select odhf.id
                    from ods.fdc_object objf
                    join ods.fdc_odh odhf on objf.id=odhf.id
                    join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                    join nsi.fdc_municipality m on fias.municipality_id=m.id
                   where m.root_id=l_municipality_root_id
                 )
   /*   ,work_cycle as(select tt.work_type_id
                           ,tt.agr_root_id
                           ,tt.driveway_id
                           ,tt.work_date
                           ,row_number() over(partition by tt.work_type_id,tt.agr_root_id,tt.driveway_id order by tt.work_date) cycle_no
                       from(select distinct wwex.work_type_id
                                           ,wagr.agr_root_id
                                           ,wwex.driveway_id
                                           ,date(wwex.work_date) as work_date
                              from msnow.fdc_work_execute wwex
                              join msnow.fdc_agreement wagr on wwex.agreement_id=wagr.id
                           ) tt
                    )*/
      ,v1_7 as(select distodh.odh_id
                     ,count(swp.work_type_id::text||to_char(swpd.performance_date,'yyyymmdd')) as regul_plan_count
                     ,sum(case
                            when mu.code='RKMT' then calc.roadway_area /7000.0
                          end
                         ) as regul_plan_length
                 from msnow.fdc_scheduled_work_plan swp
                 join msnow.fdc_work_type wt on swp.work_type_id=wt.id
                 join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                 join ods.fdc_maintenance_route dist on swp.maintenance_route_id=dist.id
                 join ods.fdc_maintenance_route_odh distodh on dist.id=distodh.maintenance_route_id
                 join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                 join ods.fdc_odh odh on distodh.odh_id=odh.id
                 join ods.fdc_object obj on odh.id=obj.id
                 left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                 left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                 left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                 left join ods.fdc_odh_calculation calc on obj.id=calc.id
                where dist.work_plan_approved
                  and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                  and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                  and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                  and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                  and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                  and(p_work_type_id is null or swp.work_type_id=p_work_type_id)
                  and(p_season_id is null or wt.season_id = p_season_id)
                  and((p_period=1 and (p_period_date is null or swpd.performance_date=p_period_date)) or
                      (p_period=2 and (p_period_from is null or swpd.performance_date>=p_period_from) and
                                      (p_period_to is null or swpd.performance_date<=p_period_to)
                      )
                     )
                  and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
                group by distodh.odh_id
              )
      ,v2_8 as(select tt.driveway_id as odh_id
                     ,count(tt.work_execute_id) as regul_fact_count
                     ,sum(tt.work_volume) as regul_fact_length
                 from(select agr.agr_root_id
                            ,wex.work_type_id
                            ,wex.driveway_id
                            ,date(wex.work_date) as work_date
                            ,max(wex.id) as work_execute_id
                            ,sum(case
                                   when mu.code='RKMT' then wex.work_volume
                                 end
                                ) as work_volume
                        from msnow.fdc_work_execute wex
                        join msnow.fdc_scheduled_work_plan_date swpd on wex.scheduled_work_plan_date_id=swpd.id
                        join msnow.fdc_agreement agr on wex.agreement_id=agr.id
                        join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                        join msnow.fdc_work_type wt on wex.work_type_id=wt.id
                        join msnow.fdc_work_status ws on wex.work_status_id=ws.id
                        join msnow.fdc_work_group wg on wt.work_group_id=wg.id
                        join ods.fdc_odh odh on wex.driveway_id=odh.id
                        join ods.fdc_object obj on odh.id=obj.id
                        left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                        left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                        left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                       where wc.code='MAINTAIN'
                         and wg.code='REGULATION'
                         and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                         and(p_work_type_id is null or wex.work_type_id=p_work_type_id)
                         and(p_season_id is null or wt.season_id = p_season_id)
                         and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                         and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                         and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                         and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                         and(l_work_status_code is null or (l_work_status_code='DONE' and ws.code in('DONE','ACCEPTED'))
                                                        or (l_work_status_code='ACCEPTED' and ws.code='ACCEPTED')
                            )
                         and((p_period=1 and swpd.performance_date=p_period_date) or
                             (p_period=2 and swpd.performance_date between p_period_from and p_period_to)
                            )
                         and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
                       group by agr.agr_root_id
                               ,wex.work_type_id
                               ,wex.driveway_id
                               ,date(wex.work_date)
                            ) tt
                       group by driveway_id
              )
      ,v3_9 as(select att.odh_id
                     ,count(att.id) as actual_plan_count
                     ,sum(att.work_volume) as actual_plan_length
                 from(select pw.driveway_id as odh_id
                            ,pw.id
                            ,case
                               when mu.code='RKMT' then pw.work_volume
                             end as work_volume
                            ,1 as rn
                        from msnow.fdc_planed_work pw
                        join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                        join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                        join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                        join msnow.fdc_work_type wt on pw.work_type_id=wt.id
                        join ods.fdc_odh odh on pw.driveway_id=odh.id
                        join ods.fdc_object obj on odh.id=obj.id
                        left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                        left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                        left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                       where wc.code='MAINTAIN'
                         and pws.code in('APPROVED','DONE')
                         and pw.maintenance_route_id is null
                         and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                         and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                         and(p_season_id is null or wt.season_id = p_season_id)
                         and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                             (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                             (p_period_to is null or pw.work_date<=p_period_to)
                             )
                            )
                         and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                         and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                         and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                         and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                         and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
                       union all
                       select disto.odh_id as odh_id
                             ,pw.id
                             ,case
                                when mu.code='RKMT' and row_number() over(partition by disto.odh_id,pw.id) = 1 then dcalc.roadway_area/7000.0
                              end as work_volume
                             ,row_number() over(partition by disto.odh_id,pw.id) rn
                         from msnow.fdc_planed_work pw
                         join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
                         join msnow.fdc_work_type wt on pw.work_type_id=wt.id--!!
                         join msnow.fdc_agreement agr on pw.agreement_id = agr.id
                         join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                         join ods.fdc_maintenance_route dist on pw.maintenance_route_id=dist.id
                         join msnow.fdc_agreement dagr on dist.agreement_id=dagr.id
                         join ods.fdc_maintenance_route_odh disto on dist.id = disto.maintenance_route_id
                         join ods.fdc_odh dodh on disto.odh_id=dodh.id
                         join ods.fdc_object dobj on dodh.id=dobj.id
                         join msnow.fdc_scheduled_work_plan swp on dist.id=swp.maintenance_route_id
                         join msnow.fdc_work_type swt on swp.work_type_id=swt.id
                         join msnow.fdc_scheduled_work_plan_date swpd on swp.id=swpd.scheduled_work_plan_id
                         left join nsi.fdc_legal_person downr on dobj.owner_id=downr.id
                         left join nsi.fdc_legal_person dcust on dobj.customer_id=dcust.id
                         left join msnow.fdc_measure_unit mu on swt.measure_unit_id=mu.id
                         left join ods.fdc_odh_calculation dcalc on dodh.id=dcalc.id
                        where pw.driveway_id is null
                          and wc.code='MAINTAIN'
                          and pws.code in('APPROVED','DONE')
                          and dist.work_plan_approved
                          and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                          and(l_performer_root_id is null or dagr.performer_id=l_performer_root_id)
                          and(p_driveway_category_id is null or dobj.driveway_category_id=p_driveway_category_id)
                          and(p_maintain_group_id is null or dodh.maintain_group_id=p_maintain_group_id)
                          and(l_owner_root_id is null or downr.root_id=l_owner_root_id)
                          and(l_customer_root_id is null or dcust.root_id=l_customer_root_id)
                          and(l_municipality_root_id is null or dodh.id in(select id from odh_mun))
                          and(p_work_type_id is null or pw.work_type_id=p_work_type_id)
                          and(p_season_id is null or wt.season_id = p_season_id)
                          and((p_period=1 and (p_period_date is null or pw.work_date=p_period_date)) or
                              (p_period=2 and (p_period_from is null or pw.work_date>=p_period_from) and
                                              (p_period_to is null or pw.work_date<=p_period_to)
                              )
                             )
                     ) att
               where rn=1
               group by att.odh_id
              )
     ,v4_10 as(select tt.driveway_id as odh_id
                     ,count(tt.work_execute_id) as actual_fact_count
                     ,sum(tt.work_volume) as actual_fact_length
                 from(select agr.agr_root_id
                            ,wex.work_type_id
                            ,wex.driveway_id
                            ,date(wex.work_date) as work_date
                            ,max(wex.id) as work_execute_id
                            ,sum(case
                                   when mu.code='RKMT' then wex.work_volume
                                 end
                                ) as work_volume
                        from msnow.fdc_work_execute wex
                        join msnow.fdc_planed_work pwk on wex.planed_work_id=pwk.id
                        join msnow.fdc_planed_work_status pwks on pwk.planed_work_status_id=pwks.id
                        join msnow.fdc_agreement agr on wex.agreement_id=agr.id
                        join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                        join msnow.fdc_work_type wt on wex.work_type_id=wt.id
                        join msnow.fdc_work_status ws on wex.work_status_id=ws.id
                        join ods.fdc_odh odh on wex.driveway_id=odh.id
                        join ods.fdc_object obj on odh.id=obj.id
                        left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                        left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                        left join msnow.fdc_work_group wg on wt.work_group_id=wg.id
                        left join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                       where wc.code='MAINTAIN'
                         and pwks.code in ('APPROVED','DONE')
                         and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                         and(p_work_type_id is null or wex.work_type_id=p_work_type_id)
                         and(p_season_id is null or wt.season_id = p_season_id)
                         and(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                         and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                         and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                         and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                         and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
                         and(l_work_status_code is null or (l_work_status_code='DONE' and ws.code in('DONE','ACCEPTED'))
                                                        or (l_work_status_code='ACCEPTED' and ws.code='ACCEPTED')
                            )
                         and((p_period=1 and pwk.work_date=p_period_date) or
                             (p_period=2 and (pwk.work_date between p_period_from and p_period_to))
                            )
                       group by agr.agr_root_id
                               ,wex.work_type_id
                               ,wex.driveway_id
                               ,date(wex.work_date)
                     ) tt
                group by tt.driveway_id
              )

      insert into msnow.FDC_REP_MAINTODH_OVERVIEW_AGG (SESSION_ID
                                                      ,SET_DATE
                                                      ,ID
                                                      ,DRIVEWAY_CATEGORY_ID
                                                      ,ROAD_CATEGORY
                                                      ,REGUL_PLAN_COUNT
                                                      ,REGUL_FACT_COUNT
                                                      ,REGUL_DIFFER_COUNT
                                                      ,ACTUAL_PLAN_COUNT
                                                      ,ACTUAL_FACT_COUNT
                                                      ,ACTUAL_DIFFER_COUNT
                                                      ,REGUL_PLAN_LENGTH
                                                      ,REGUL_FACT_LENGTH
                                                      ,REGUL_DIFFER_LENGTH
                                                      ,ACTUAL_PLAN_LENGTH
                                                      ,ACTUAL_FACT_LENGTH
                                                      ,ACTUAL_DIFFER_LENGTH
                                                      ,record_type
                                                      ,CUSTOMER_ROOT_ID
                                                      ,OWNER_ROOT_ID
                                                      )

        select p_session_id
              ,l_current_date
              ,bodh.id
              ,bobj.driveway_category_id
              ,case bdwc.code
                 when 'LOCAL' then 'Муниципальные'
                 when 'REGION_INTERMUNICIPAL' then 'Региональные'
               end as road_category
              ,coalesce(v1_7.regul_plan_count,0)
              ,coalesce(v2_8.regul_fact_count,0)
              ,coalesce(v2_8.regul_fact_count,0) - coalesce(v1_7.regul_plan_count,0) as regul_differ_count
              ,coalesce(v3_9.actual_plan_count,0)
              ,coalesce(v4_10.actual_fact_count,0)
              ,coalesce(v4_10.actual_fact_count,0) - coalesce(v3_9.actual_plan_count,0) as actual_differ_count
              ,coalesce(v1_7.regul_plan_length,0.0)
              ,coalesce(v2_8.regul_fact_length,0.0)
              ,coalesce(v2_8.regul_fact_length,0.0) - coalesce(v1_7.regul_plan_length,0.0) as regul_differ_length
              ,coalesce(v3_9.actual_plan_length,0.0)
              ,coalesce(v4_10.actual_fact_length,0.0)
              ,coalesce(v4_10.actual_fact_length,0.0) - coalesce(v3_9.actual_plan_length,0.0) as actual_differ_length
              ,1
              ,cust.root_id
              ,ownr.root_id
          from ods.fdc_odh bodh
          join ods.fdc_object bobj on bodh.id=bobj.id
          join msnow.fdc_driveway_category bdwc on bobj.driveway_category_id = bdwc.id
          left join nsi.fdc_legal_person ownr on bobj.owner_id=ownr.id
          left join nsi.fdc_legal_person cust on bobj.customer_id=cust.id
          left join v1_7 on bodh.id=v1_7.odh_id
          left join v2_8 on bodh.id=v2_8.odh_id
          left join v3_9 on bodh.id=v3_9.odh_id
          left join v4_10 on bodh.id=v4_10.odh_id
         where (v1_7.odh_id is not null or
                v2_8.odh_id is not null or
                v3_9.odh_id is not null or
                v4_10.odh_id is not null
               );

  with odh_mun as(select odhf.id
                    from ods.fdc_object objf
                    join ods.fdc_odh odhf on objf.id=odhf.id
                    join nsi.fdc_fias_address_reference_v fias on objf.as_area_id=fias.id
                    join nsi.fdc_municipality m on fias.municipality_id=m.id
                   where m.root_id=l_municipality_root_id
                  union
                  select odhf.id
                    from ods.fdc_object objf
                    join ods.fdc_odh odhf on objf.id=odhf.id
                    join nsi.fdc_fias_address_reference_v fias on objf.as_place_id=fias.id
                    join nsi.fdc_municipality m on fias.municipality_id=m.id
                   where m.root_id=l_municipality_root_id
                 )

      ,estok as(select distinct ae.agreement_id
                  from msnow.fdc_agr_estimate ae
                  join msnow.fdc_work_type aewt on ae.work_type_id=aewt.id
                 where ae.is_estimate_sum
                   and(p_season_id is null or aewt.season_id = p_season_id)
                   and(p_work_type_id is null or ae.work_type_id=p_work_type_id)
               )
      ,agrodhok as(select distinct ao.argeement_id
                     from msnow.fdc_agreement_object ao
                     join ods.fdc_odh odh on ao.driveway_id=odh.id
                     join ods.fdc_object obj on odh.id=obj.id
                     left join nsi.fdc_legal_person ownr on obj.owner_id=ownr.id
                     left join nsi.fdc_legal_person cust on obj.customer_id=cust.id
                    where(p_driveway_category_id is null or obj.driveway_category_id=p_driveway_category_id)
                      and(p_maintain_group_id is null or odh.maintain_group_id=p_maintain_group_id)
                      and(l_owner_root_id is null or ownr.root_id=l_owner_root_id)
                      and(l_customer_root_id is null or cust.root_id=l_customer_root_id)
                      and(l_municipality_root_id is null or odh.id in(select id from odh_mun))
                  )
      ,v5 as(select agr.customer_id
                   ,agr.performer_id
                   ,agr.id as agreement_id
                   ,case
                      when exists(select null
                                    from nsi.fdc_person_role pr
                                    join nsi.fdc_role r on pr.role_id=r.id
                                   where pr.person_id=agr.customer_id
                                     and r.code='RUAD'
                                 ) then 'REGION_INTERMUNICIPAL'
                      else 'LOCAL'
                    end as driveway_category_code
                   ,cdoc.report_period_cost_vat as money_plan
               from msnow.fdc_cost_doc cdoc
               join msnow.fdc_agreement agr on cdoc.agreement_id = agr.id
               join msnow.fdc_work_category wc on agr.work_category_id=wc.id
               join estok on agr.id=estok.agreement_id
               join agrodhok on agr.id=agrodhok.argeement_id
              where wc.code='MAINTAIN'
                and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                and((p_period=1 and (p_period_date is null or ((p_period_date between agr.version_date_from and agr.version_date_to) and
                                                                cdoc.cost_doc_date+10<=p_period_date
                                                              )
                                    )
                    ) or
                    (p_period=2 and (agr.version_date_from<=p_period_to and
                                     agr.version_date_to>=p_period_from
                                    )
                                and cdoc.cost_doc_date+10 between p_period_from and p_period_to
                    )
                   )
            )
      ,v6 as(select agr.customer_id
                   ,agr.performer_id
                   ,agr.id as agreement_id
                   ,case
                      when exists(select null
                                    from nsi.fdc_person_role pr
                                    join nsi.fdc_role r on pr.role_id=r.id
                                   where pr.person_id=agr.customer_id
                                     and r.code='RUAD'
                                 ) then 'REGION_INTERMUNICIPAL'
                      else 'LOCAL'
                    end as driveway_category_code
                   ,p.amount as money_fact
               from msnow.fdc_payment p
               join msnow.fdc_agreement agr on p.agreement_id = agr.id
               join msnow.fdc_work_category wc on agr.work_category_id=wc.id
               join estok on agr.id=estok.agreement_id
               join agrodhok on agr.id=agrodhok.argeement_id
              where wc.code='MAINTAIN'
                and(l_performer_root_id is null or agr.performer_id=l_performer_root_id)
                and((p_period=1 and (p_period_date is null or ((p_period_date between agr.version_date_from and agr.version_date_to) and
                                                                p.payment_date<=p_period_date
                                                              )
                                    )
                    ) or
                    (p_period=2 and (agr.version_date_from<=p_period_to and
                                     agr.version_date_to>=p_period_from
                                    )
                                and p.payment_date between p_period_from and p_period_to
                    )
                   )
            )

      insert into msnow.FDC_REP_MAINTODH_OVERVIEW_AGG (SESSION_ID
                                                      ,SET_DATE
                                                      ,DRIVEWAY_CATEGORY_ID
                                                      ,ROAD_CATEGORY
                                                      ,CUSTOMER_ROOT_ID
                                                      ,PERFORMER_ROOT_ID
                                                      ,AGREEMENT_ROOT_ID
                                                      ,MONEY_PLAN
                                                      ,MONEY_FACT
                                                      ,record_type
                                                      )

         select p_session_id
               ,l_current_date
               ,dwc.id
               ,case dwc.code
                  when 'LOCAL' then 'Муниципальные'
                  when 'REGION_INTERMUNICIPAL' then 'Региональные'
                end as road_category
               ,v5.customer_id
               ,v5.performer_id
               ,v5.agreement_id
               ,coalesce(v5.money_plan,0.0) as money_plan
               ,0 as money_fact
               ,2
           from msnow.fdc_driveway_category dwc
           join v5 on dwc.code=v5.driveway_category_code
          where (p_driveway_category_id is null or dwc.id=p_driveway_category_id)

         union
         select p_session_id
               ,l_current_date
               ,dwc.id
               ,case dwc.code
                  when 'LOCAL' then 'Муниципальные'
                  when 'REGION_INTERMUNICIPAL' then 'Региональные'
                end as road_category
               ,v6.customer_id
               ,v6.performer_id
               ,v6.agreement_id
               ,0 as money_plan
               ,coalesce(v6.money_fact,0.0) as money_fact
               ,2
           from msnow.fdc_driveway_category dwc
           join v6 on dwc.code=v6.driveway_category_code
          where (p_driveway_category_id is null or dwc.id=p_driveway_category_id);

  return;
end
$$;

