CREATE FUNCTION fdc_object_pck_validate_object_geometry(p_object t_object, p_parent_id bigint, p_origin_id bigint)
  RETURNS SETOF t_validate_geometry
LANGUAGE plpgsql
AS $$
declare
  /** Функция валидации геометрии одноуровневого объекта в рамках родителя в дереве
  %param     p_object           Объект
  %param     p_parent_id        Идентификатор объекта, в который входит данный объект по дереву
  %param     p_origin_id        Идентификатор родителя - источника, для которого создается новая версия
  %return                       Коллекция объектов у которых пересекается геометрия
  */
  l_root_id ods.fdc_object.root_id%type;
  l_object_type_code ods.fdc_object_type.code%type;
  l_is_polygon_avail ods.fdc_object_type.is_polygon_avail%type;
  rw_g record;
begin
  if p_object.id is not null then
    select o.root_id
      into strict l_root_id
      from ods.fdc_object o
     where o.id = p_object.id;
  else
    l_root_id := null;
  end if;

  if l_root_id is null and p_origin_id is not null then
    select o.root_id
      into strict l_root_id
      from ods.fdc_object o
     where o.id = p_origin_id;
  else
    l_root_id := null;
  end if;

  if p_parent_id is not null then
    select ot.code
         , ot.is_polygon_avail
      into strict l_object_type_code
                , l_is_polygon_avail
      from ods.fdc_object_type ot
     where ot.id = p_object.obj_type_id;
  end if;

  if l_is_polygon_avail and GeometryType(p_object.geometry) = ods.c_polygon() then
    for rw_g in (select ov.id
                      , ot.name as object_type_name--ov.object_type_name
                      , ov.name
                      , ov.object_type_id
                      , ov.tree_name
                      , ot.code as object_type_code --ov.object_type_code
                      , ot.short_name as object_type_short_name --ov.object_type_short_name
                      , ov.geometry
                   from ods.fdc_object_link ol
                      , ods.fdc_object ov
                      , ods.fdc_object_type ot
                  where ol.object_id_1 = p_parent_id
                    and ov.id = ol.object_id_2
                    and ov.id <> coalesce(p_object.id, -1)
                    and ov.root_id <> coalesce(l_root_id, -1)
                    and ot.id = ov.object_type_id
                    and ot.is_polygon_avail = true
                    and GeometryType(ov.geometry) = ods.c_polygon()
                    and st_relate(ov.geometry, p_object.geometry,'T********')
                  limit 10
                ) loop
      return next rw_g.id
                , rw_g.tree_name
                , rw_g.object_type_id
                , rw_g.object_type_code
                , rw_g.object_type_short_name
                , rw_g.geometry;
    end loop;
  end if;
  return;
end
$$;

