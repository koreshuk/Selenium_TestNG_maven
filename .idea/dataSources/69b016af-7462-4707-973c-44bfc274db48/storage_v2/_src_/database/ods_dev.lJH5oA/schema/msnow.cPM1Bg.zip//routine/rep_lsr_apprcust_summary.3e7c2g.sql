CREATE FUNCTION rep_lsr_apprcust_summary(p_summary_type integer, p_driveway_category_id bigint, p_work_category_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, OUT customer_root_id bigint, OUT customer_short_name character varying, OUT approved_last3days_qty bigint, OUT rejected_qty bigint, OUT sent_qty bigint, OUT expired_qty bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт "Сводка по согласованию Локальных сметных расчетов на <текущая дата>" в разрезе заказчиков

  %param p_summary_type          - Тип сметы
                                   1 - бюджет
                                   2 - контракт/задание
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_work_category_id      - Категория ТС (Ид категории работ)
  %param p_customer_id           - Заказчик (Ид актуальной на текущую дату версии заказчика)

  %return customer_root_id        - ROOT_ID заказчика/органа
  %return customer_short_name     - Заказчик
  %return approved_last3days_qty  - Согласовано за последние 3 дня
  %return rejected_qty            - Отклонено
  %return sent_qty                - Всего на согласовании
  %return expired_qty             - Просрочено на согласовании
  */
  l_summary_date date;
  l_workdays_lag_3 date;

  C_TYPE_OBLIGATION constant integer:=1;
  C_TYPE_AGREEMENT constant INTEGER:=2;
begin
  l_summary_date :=current_date;
  l_workdays_lag_3:=msnow.srv_workdays_back(p_workdays_qty   => 3
                                           ,p_date_from      => l_summary_date
                                           );

  if p_summary_type = C_TYPE_OBLIGATION then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as obligation_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='OBLIGATION'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select maxiter.obligation_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )

          select null::bigint as customer_root_id
                ,rcust.customer_short_name
                ,count(distinct case
                                  when oblst.code='APPROVED' and obl.approval_date between l_workdays_lag_3 and l_summary_date then obl.id
                                end
                      )as approved_last3days_qty
                ,count(distinct case
                                  when oblst.code='PROJECT' and maxiter.approval_iteration_status_code='REJECTED' then obl.id
                                end
                      ) as rejected_qty
                ,count(distinct case
                                  when oblst.code='ON_APPROVAL' then obl.id
                                end
                      ) as sent_qty
                ,count(distinct case
                                  when oblst.code='ON_APPROVAL' and expired.obligation_id is not null then obl.id
                                end
                      ) as expired_qty
            from rcust
            left join msnow.fdc_obligation obl on rcust.customer_root_id=obl.authority_org_id
                                                  and (p_work_category_id is null or obl.work_category_id=p_work_category_id)
            left join msnow.fdc_agreement_obligation_status oblst on obl.obligation_status_id=oblst.id
            left join maxiter on obl.id=maxiter.obligation_id
            left join expired on maxiter.obligation_id=expired.obligation_id
           group by /*rcust.customer_root_id
                   ,*/rcust.customer_short_name;

  elsif p_summary_type = C_TYPE_AGREEMENT then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as agreement_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='AGREEMENT'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select maxiter.agreement_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )

          select null::bigint as customer_root_id
                ,rcust.customer_short_name
                ,count(distinct case
                                  when agrst.code='APPROVED' and agr.approval_date between l_workdays_lag_3 and l_summary_date then agr.id
                                end
                      )as approved_last3days_qty
                ,count(distinct case
                                  when agrst.code='PROJECT' and maxiter.approval_iteration_status_code='REJECTED' then agr.id
                                end
                      ) as rejected_qty
                ,count(distinct case
                                  when agrst.code='ON_APPROVAL' then agr.id
                                end
                      ) as sent_qty
                ,count(distinct case
                                  when agrst.code='ON_APPROVAL' and expired.agreement_id is not null then agr.id
                                end
                      ) as expired_qty
            from rcust
            left join msnow.fdc_agreement agr on rcust.customer_root_id=agr.customer_id
                                                 and (p_work_category_id is null or agr.work_category_id=p_work_category_id)
            left join msnow.fdc_agreement_obligation_status agrst on agr.agreement_status_id=agrst.id
            left join maxiter on agr.id=maxiter.agreement_id
            left join expired on maxiter.agreement_id=expired.agreement_id
           group by /*rcust.customer_root_id
                   ,*/rcust.customer_short_name;
  end if;
  return;
end
$$;

