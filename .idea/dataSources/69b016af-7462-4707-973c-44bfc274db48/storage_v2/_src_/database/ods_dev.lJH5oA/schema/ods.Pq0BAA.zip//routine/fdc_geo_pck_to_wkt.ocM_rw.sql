CREATE FUNCTION fdc_geo_pck_to_wkt(p_geometry geometry, p_null_value text)
  RETURNS text
LANGUAGE plpgsql
AS $$
declare
  /* Представление геометрического объекта в формате Well Known Text
  */
begin
  return COALESCE(st_astext(p_geometry),p_null_value);
end
$$;

