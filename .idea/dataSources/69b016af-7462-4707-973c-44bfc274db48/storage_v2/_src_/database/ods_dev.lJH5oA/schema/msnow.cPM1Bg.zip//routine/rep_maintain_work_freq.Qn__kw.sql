CREATE FUNCTION rep_maintain_work_freq(p_driveway_category_id bigint, p_date_from date, p_date_to date, p_customer_id bigint DEFAULT NULL::bigint, p_work_type_id bigint DEFAULT NULL::bigint, OUT agreement_id bigint, OUT agreement_gui_name character varying, OUT odh_id bigint, OUT odh_name character varying, OUT maintain_group_id bigint, OUT maintain_group_name character varying, OUT customer_root_id bigint, OUT customer_root_name character varying, OUT performer_root_id bigint, OUT performer_name character varying, OUT work_exec_count integer, OUT work_exec_last_date timestamp without time zone)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет о регулярности выполнения работ по содержанию.
     ПЗ: ПЗ Отчеты/ПЗ_Отчет о регулярности выполнения работ по содержанию на участках дорог.docx

     %param p_driveway_category_id - Балансовая принадлежность
     %param p_date_from            - Период с
     %param p_date_to              - Период по
     %param p_customer_id          - Заказчик
     %param p_work_type_id         - Вид работы

     %return agreement_id          - Ид контракта
     %return agreement_gui_name    - Наименование контракта в интерфейсе
     %return odh_id                - Ид участка дороги
     %return odh_name              - Наименование участка дороги
     %return maintain_group_id     - Ид группы по содержанию
     %return maintain_group_name   - Наименование группы по содержанию
     %return customer_root_id      - Сквозной Ид заказчика
     %return customer_root_name    - Наименовние заказчика
     %return performer_root_id     - Сквозной Ид исполнителя
     %return performer_name        - Наименование исполнителя
     %return work_exec_count       - Кол-во записей в журнале работ
     %return work_exec_last_date   - Дата и время выполнения последней работы
  */
  l_customer_root_id nsi.fdc_legal_person.root_id%type;
begin
  begin
    select root_id
      into l_customer_root_id
      from nsi.fdc_legal_person
     where id=p_customer_id;
  exception
    when NO_DATA_FOUND then
      l_customer_root_id:=null;
  end;

  return query
    with agr_lastver as(select distinct on(agr.agr_root_id)
                               agr.agr_root_id
                              ,agr.id
                              ,agr.agreement_status_id
                              ,agr.version_date_from
                              ,agr.version_date_to
                              ,agr.work_date_from
                              ,agr.work_date_to
                              ,agr.work_category_id
                              ,agr.customer_id
                              ,agr.performer_id
                              ,agr.gui_name
                          from msnow.fdc_agreement agr
                          join msnow.fdc_agreement_obligation_status ast on agr.agreement_status_id=ast.id
                         where ast.code='APPROVED'
                         order by agr.agr_root_id
                                 ,agr.version_date_to desc
                                 ,agr.version_date_from desc
                                 ,agr.id desc
                      )
       ,agrest as(select distinct agre.agreement_id
                    from msnow.fdc_agr_estimate agre
                   where agre.work_type_id = p_work_type_id
                     and agre.is_estimate_sum
              )
       ,ruad as(select pr.person_id as customer_root_id
                  from nsi.fdc_person_role pr
                  join nsi.fdc_role r on pr.role_id=r.id
                 where p_date_to between pr.begin_date and pr.end_date
                   and r.code='RUAD'
             )
       ,work_exec as(select weagr.agr_root_id
                           ,weobj.root_id as odh_root_id
                           ,count(we.id) as work_exec_count
                           ,max(we.work_date) as work_exec_last_date
                       from msnow.fdc_work_execute we
                       join msnow.fdc_agreement weagr on we.agreement_id=weagr.id
                       join ods.fdc_object weobj on we.driveway_id=weobj.id
                      where date(we.work_date) between p_date_from and p_date_to
                        and (p_work_type_id is null or we.work_type_id=p_work_type_id)
                      group by weagr.agr_root_id
                              ,weobj.root_id
                 )
       ,odh_appr as(select aobj.root_id as odh_root_id
                          ,aobj.name as odh_name
                          ,aodh.maintain_group_id
                          ,mg.name as maintain_group_name
                      from ods.fdc_object aobj
                      join ods.fdc_object_state aobjs on aobj.object_state_id=aobjs.id
                      join ods.fdc_odh aodh on aobj.id=aodh.id
                      join msnow.fdc_maintain_group mg on aodh.maintain_group_id=mg.id
                     where aobjs.code='APPROVED'
                       and p_date_to between aobj.version_date_from and aobj.version_date_to
                )
         select agr.id as agreement_id
               ,agr.gui_name::varchar as agreement_gui_name

               ,odh.id as odh_id
               ,odh_appr.odh_name::varchar
               ,odh_appr.maintain_group_id
               ,odh_appr.maintain_group_name
               ,agr.customer_id as customer_root_id
               ,cust.short_name as customer_name
               ,agr.performer_id as performer_root_id
               ,perf.short_name as performer_short_name
               ,work_exec.work_exec_count::integer
               ,work_exec.work_exec_last_date
           from agr_lastver agr
           join msnow.fdc_work_category awc on agr.work_category_id = awc.id
           join msnow.fdc_agreement_object agro on agr.id=agro.argeement_id
           join ods.fdc_odh odh on agro.driveway_id=odh.id
           join ods.fdc_object obj on odh.id=obj.id
           join odh_appr on obj.root_id=odh_appr.odh_root_id
           left join agrest on agr.id=agrest.agreement_id
           left join ruad on agr.customer_id=ruad.customer_root_id
           left join nsi.fdc_legal_person cust on agr.customer_id=cust.root_id
                                                  and p_date_to between cust.ver_start_date and cust.ver_end_date
           left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                  and p_date_to between perf.ver_start_date and perf.ver_end_date
     left join work_exec on work_exec.agr_root_id=agr.agr_root_id
                            and work_exec.odh_root_id = obj.root_id
    where awc.code='MAINTAIN'
      and agr.work_date_to>=p_date_from
      and agr.work_date_from <= p_date_to
      and (p_work_type_id is null or agrest.agreement_id is not null)
      and ((p_driveway_category_id=2 and ruad.customer_root_id is not null) or
           (p_driveway_category_id=1 and ruad.customer_root_id is null)
          )
      and (p_customer_id is null or agr.customer_id=l_customer_root_id)
      and (p_work_type_id is null or exists(select null
                                              from msnow.fdc_agr_estimate agres
                                             where agres.driveway_id=odh.id
                                               and agres.work_type_id=p_work_type_id
                                            )
                                  or exists(select null
                                              from msnow.fdc_agr_estimate agres
                                             where agres.odh_group_id=odh.maintain_group_id
                                               and agres.work_type_id=p_work_type_id
                                           )
          );
  return;
end
$$;

