CREATE FUNCTION fdc_ldv_dwrepair_stat(p_municipality_id bigint, OUT municipality_name text, OUT year character varying, OUT obligation_work_cost double precision, OUT agreement_cnt integer, OUT agreement_driveway_cnt integer, OUT agreement_cost_sum double precision, OUT agreement_est_work_cost_sum double precision, OUT saving_sum double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Статистика по местным дорогам муниц. района" - Статистика Текущий ремонт
  %param p_municipality_id - Ид муниципального района/городского округа
  */
begin
  return query select st.municipality_name::text
                     ,st.year::varchar(4)
                     ,coalesce(st.obligation_work_cost,0)::double precision as obligation_work_cost
                     ,coalesce(st.agreement_cnt,0)::integer as agreement_cnt
                     ,coalesce(st.agreement_driveway_cnt,0)::integer as agreement_driveway_cnt
                     ,coalesce(st.agreement_cost_sum,0)::double precision as agreement_cost_sum
                     ,coalesce(st.agreement_est_work_cost_sum,0)::double precision as agreement_est_work_cost_sum
                     ,coalesce(st.obligation_work_cost,0)::double precision  - coalesce(st.agreement_cost_sum,0)::double precision as saving_sum
                 from(select bdg.municipality_name
                            ,bdg.obligation_year as year
                            ,bdg.obligation_work_cost
                            ,count(distinct agrm.agreement_id) as agreement_cnt
                            ,count(distinct agrm.agreement_driveway_id) as agreement_driveway_cnt
                            ,coalesce(sum(agrm.agreement_cost),0) as agreement_cost_sum
                            ,coalesce(sum(agrm.agreement_est_work_cost),0) as agreement_est_work_cost_sum
                        from(select obl.obligation_year
                                   ,mnc.formal_name||case
                                                       when mnc.short_name is not null then ' '||mnc.short_name
                                                       else ''
                                                     end as municipality_name
                                   ,sum(obl.work_cost) as obligation_work_cost
                                from msnow.fdc_obligation obl
                                join msnow.fdc_work_category owc on obl.work_category_id=owc.id
                                join nsi.fdc_person po on obl.authority_org_id=po.id
                                join nsi.fdc_legal_person lpo on po.id=lpo.root_id
                                join ods.fdc_as_addrobj mnc on lpo.fias_district_id=mnc.id
                               where owc.code='REPAIR'
                                 and statement_timestamp() between lpo.ver_start_date and lpo.ver_end_date
                                 and lpo.fias_district_id=p_municipality_id
                               group by obl.obligation_year
                                       ,mnc.formal_name||case
                                                       when mnc.short_name is not null then ' '||mnc.short_name
                                                       else ''
                                                     end
                             ) bdg
                  left join (select agr.id as agreement_id
                                   ,case row_number() over(partition by agr.id order by 1)
                                      when 1 then agr.cost
                                    end as agreement_cost
                                   ,extract('year' from agr.work_date_from)::varchar as agreement_year
                                   ,agro.driveway_id as agreement_driveway_id
                                   ,case row_number() over(partition by agre.id order by 1)
                                      when 1 then agre.work_cost
                                    end as agreement_est_work_cost
                               from msnow.fdc_agreement agr
                               join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
                               join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                               join nsi.fdc_person p on agr.customer_id=p.id
                               join nsi.fdc_legal_person lp on p.id=lp.root_id
                               left join msnow.fdc_agreement_object agro on agr.id=agro.argeement_id
                               left join msnow.fdc_agr_estimate agre on agr.id=agre.agreement_id
                                                                        and agre.is_estimate_sum
                              where agrt.code<>'AGREEMENT'
                                and wc.code='REPAIR'
                                and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                                and agr.work_date_from is not null
                                and lp.fias_district_id=p_municipality_id
                            ) as agrm on bdg.obligation_year=agrm.agreement_year
                      group by bdg.municipality_name
                              ,bdg.obligation_year
                              ,bdg.obligation_work_cost
                     ) st;

  return;
end;
$$;

