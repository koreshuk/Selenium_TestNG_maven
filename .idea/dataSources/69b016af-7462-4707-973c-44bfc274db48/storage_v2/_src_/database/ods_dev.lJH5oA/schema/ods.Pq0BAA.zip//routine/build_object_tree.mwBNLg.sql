CREATE FUNCTION build_object_tree(p_object_id bigint, OUT level integer, OUT object_id bigint, OUT object_root_id bigint, OUT object_name text, OUT object_type_code text, OUT object_state_code text, OUT version_date_from date, OUT version_date_to date)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Функция построения дерева объектов.

    %param p_object_id - Ид версии объекта

    %return level             - 'Уроевень вложенности(>=1). Уровень 1 = Дорога'
    %return id                - 'Ид версии выбранного объекта'
    %return object_id         - 'Ид версии объекта'
    %return object_root_id    - 'Сквозной Ид объекта'
    %return object_name       - 'Наименование объекта'
    %return object_type_code  - 'Код типа объекта'
    %return object_state_code - 'Код статуса объекта'
    %return version_date_from - 'Дата начала действия версии'
    %return version_date_to   - 'Дата окончания действия версии'

  */
  l_object_root_id ods.fdc_object.root_id%type;
  l_object_type_code ods.fdc_object_type.code%type;
  l_dw_version_date_from ods.fdc_object.version_date_from%type;

  l_top_parent_root_id ods.fdc_object.root_id%type;
begin
  select obj.root_id
        ,objt.code
        ,obj.version_date_from
    into l_object_root_id
        ,l_object_type_code
        ,l_dw_version_date_from
    from ods.fdc_object obj
    join ods.fdc_object_type objt on obj.object_type_id=objt.id
   where obj.id=p_object_id;

  if l_object_type_code<>'DRIVEWAY' then
  /*
    with recursive topdrv (parent_id
                          ,child_id
                          ,parent_type_code
                          ,version_date_from
                          ,lvl
                          ) as(select ol.object_id_1 as parent_id
                                     ,ol.object_id_2 as child_id
                                     ,pt.code as parent_type_code
                                     ,p.version_date_from
                                     ,1
                                 from ods.fdc_object_link ol
                                 join ods.fdc_object p on ol.object_id_1=p.id
                                 join ods.fdc_object_type pt on p.object_type_id=pt.id
                                where ol.object_id_2= p_object_id
                                  and current_date between p.version_date_from and p.version_date_to
                               union
                               select prn.object_id_1 as parent_id
                                     ,prn.object_id_2 as child_id
                                     ,pt.code as parent_type_code
                                     ,p.version_date_from
                                     ,lvl+1
                                 from ods.fdc_object_link prn
                                 join topdrv on prn.object_id_2=topdrv.parent_id
                                 join ods.fdc_object p on prn.object_id_1 = p.id
                                 join ods.fdc_object_type pt on p.object_type_id=pt.id
                              )
          select topdrv.version_date_from
            into l_dw_version_date_from
            from topdrv;
    */
    begin
       with recursive rtree(object_id
                           ,level
                           ) as (with roothr as(select distinct parent_root_id
                                                      ,child_root_id
                                                 from(select ol.object_id_1
                                                            ,objt1.code as object_1_type
                                                            ,ol.object_id_2
                                                            ,objt2.code as object_2_type
                                                            ,obj1.root_id as parent_root_id
                                                            ,obj2.root_id as child_root_id
                                                        from ods.fdc_object_link ol
                                                        join ods.fdc_object obj1 on ol.object_id_1=obj1.id
                                                        join ods.fdc_object_type objt1 on obj1.object_type_id=objt1.id
                                                        join ods.fdc_object obj2 on ol.object_id_2=obj2.id
                                                        join ods.fdc_object_type objt2 on obj2.object_type_id=objt2.id
                                                     --  where l_dw_version_date_from between obj1.version_date_from and obj1.version_date_to
                                                     --    and l_dw_version_date_from between obj2.version_date_from and obj2.version_date_to
                                                     ) rr
                                               )

                                   select parent_root_id
                                         ,1
                                     from roothr
                                    where child_root_id=l_object_root_id
                                    union
                                   select rh.parent_root_id
                                         ,rt.level+1
                                     from rtree rt
                                     join roothr rh on  rt.object_id=rh.child_root_id
                                )
                    select rtr.object_id
                      into l_top_parent_root_id
                      from(select rt.object_id
                                 ,dense_rank() OVER(order by rt.level desc) rnk
                             from rtree rt
                          ) rtr
                     where rtr.rnk=1;
    exception
      when NO_DATA_FOUND then
        null;
    end;
  else
    l_top_parent_root_id := l_object_root_id;
  end if;

  return query
       with recursive rtree(object_id
                           ,level
                           ) as (with roothr as(select distinct parent_root_id
                                                      ,child_root_id
                                                 from(select ol.object_id_1
                                                            ,objt1.code as object_1_type
                                                            ,ol.object_id_2
                                                            ,objt2.code as object_2_type
                                                            ,obj1.root_id as parent_root_id
                                                            ,obj2.root_id as child_root_id
                                                        from ods.fdc_object_link ol
                                                        join ods.fdc_object obj1 on ol.object_id_1=obj1.id
                                                        join ods.fdc_object_type objt1 on obj1.object_type_id=objt1.id
                                                        join ods.fdc_object obj2 on ol.object_id_2=obj2.id
                                                        join ods.fdc_object_type objt2 on obj2.object_type_id=objt2.id
                                             --          where l_dw_version_date_from between obj1.version_date_from and obj1.version_date_to
                                             --            and l_dw_version_date_from between obj2.version_date_from and obj2.version_date_to
                                                     ) rr
                                               )

                                   select parent_root_id
                                         ,1
                                     from roothr
                                    where parent_root_id=l_top_parent_root_id--59431002
                                    union
                                   select rh.child_root_id
                                         ,rt.level+1
                                     from rtree rt
                                     join roothr rh on  rt.object_id=rh.parent_root_id
                                )

                select brt.level
                      ,obj.id as object_id
                      ,brt.object_id as object_root_id
                      ,(objt.short_name||'('||obj.root_id::text||')'||obj.name)::text as object_name
                      ,objt.code::text as object_type
                      ,objs.code::text as object_state
                      ,obj.version_date_from
                      ,obj.version_date_to
                  from rtree brt
                  join ods.fdc_object obj on brt.object_id=obj.root_id
                  join ods.fdc_object_state objs on obj.object_state_id=objs.id
                  join ods.fdc_object_type objt on obj.object_type_id=objt.id;
  return;
end
$$;

