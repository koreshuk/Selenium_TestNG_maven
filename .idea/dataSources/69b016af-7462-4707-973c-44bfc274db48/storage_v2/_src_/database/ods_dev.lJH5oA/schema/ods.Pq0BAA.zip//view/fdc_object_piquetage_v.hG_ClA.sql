CREATE VIEW fdc_object_piquetage_v AS
  SELECT op.id,
    op.object_id,
    op.piquetage_type_id,
    pt.code AS piquetage_type_code,
    pt.name AS piquetage_type_name,
    op.value,
    op.odh_location_side_id,
    ls.code AS odh_location_side_code,
    ls.name AS odh_location_side_name,
    op.axes_type_id,
    atv.code AS axes_type_code,
    atv.name AS axes_type_name
   FROM (((fdc_object_piquetage op
     LEFT JOIN fdc_odh_location_side ls ON ((ls.id = op.odh_location_side_id)))
     LEFT JOIN fdc_piquetage_type pt ON ((pt.id = op.piquetage_type_id)))
     LEFT JOIN fdc_axes_type_v atv ON ((atv.id = op.axes_type_id)));

COMMENT ON VIEW fdc_object_piquetage_v IS 'Пикетаж объекта';

COMMENT ON COLUMN fdc_object_piquetage_v.id IS 'Ид записи';

COMMENT ON COLUMN fdc_object_piquetage_v.object_id IS 'Ид версии объекта';

COMMENT ON COLUMN fdc_object_piquetage_v.piquetage_type_id IS 'Ид типа пикетажа';

COMMENT ON COLUMN fdc_object_piquetage_v.piquetage_type_code IS 'Код типа пикетажа';

COMMENT ON COLUMN fdc_object_piquetage_v.piquetage_type_name IS 'Наименование типа пикетажа';

COMMENT ON COLUMN fdc_object_piquetage_v.value IS 'Значение пикетажа';

COMMENT ON COLUMN fdc_object_piquetage_v.odh_location_side_id IS 'Ид Местоположение.Сторона';

COMMENT ON COLUMN fdc_object_piquetage_v.odh_location_side_code IS 'Код Местоположение.Сторона';

COMMENT ON COLUMN fdc_object_piquetage_v.odh_location_side_name IS 'Наименование Местоположение.Сторона';

COMMENT ON COLUMN fdc_object_piquetage_v.axes_type_id IS 'Ид Типа Оси';

COMMENT ON COLUMN fdc_object_piquetage_v.axes_type_code IS 'Код Типа Оси';

COMMENT ON COLUMN fdc_object_piquetage_v.axes_type_name IS 'Наименование Типа Оси';

