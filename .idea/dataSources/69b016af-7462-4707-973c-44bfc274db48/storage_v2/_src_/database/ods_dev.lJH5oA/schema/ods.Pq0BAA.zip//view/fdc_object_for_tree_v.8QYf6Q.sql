CREATE VIEW fdc_object_for_tree_v AS
  SELECT t.id,
    t.root_id,
    t.tree_name,
    t.object_type_id,
    t.version_date_from,
    t.version_date_to,
    ot.code AS object_type_code,
    s.code AS object_state_code
   FROM fdc_object t,
    fdc_object_state s,
    fdc_object_type ot
  WHERE ((t.object_state_id = s.id) AND (t.object_type_id = ot.id));

COMMENT ON VIEW fdc_object_for_tree_v IS 'Инфа по объектам для запроса, который строит дерево вверх';

