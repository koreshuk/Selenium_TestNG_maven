CREATE FUNCTION c_as_sent()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 2::bigint;
$$;

