CREATE FUNCTION srv_get_maintenance_tab_status(p_agr_root_id bigint, OUT registry_tab_code character varying, OUT registry_tab_name character varying, OUT registry_tab_status_code character varying, OUT registry_tab_status_name character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Статусы заполнения вкладок карточки содержания

     %param p_agr_root_id - Сквозной ид контракта

     %return registry_tab_code        - Код вкладки
     %return registry_tab_name        - Наименование вкладки
     %return registry_tab_status_code - Код статуса заполнения
     %return registry_tab_status_name - Наименование статуса заполнения

  */
  C_MT_EXECUTION_DONE constant bit(5):='11111'::bit(5);

  C_WORK_ASSIGNMENT_DONE constant bit(5):='00001'::bit(5);
  C_LABRADOR_DONE constant bit(5):='00010'::bit(5);
  C_KS2_DONE constant bit(5):='00100'::bit(5);
  C_KS3_DONE constant bit(5):='01000'::bit(5);
  C_PAYMENT_DONE constant bit(5):='10000'::bit(5);

  C_BLANK constant bit(5):='00000'::bit(5);

  l_current_mt_execution bit(5);

  rec record;
  rec_month record;

  l_status_empty ods.fdc_dw_segregistry_tab_status%rowtype;
  l_status_filled ods.fdc_dw_segregistry_tab_status%rowtype;
  l_status_undef ods.fdc_dw_segregistry_tab_status%rowtype;

  l_total_cnt integer;
  l_not_present_cnt integer;
  l_present_cnt integer;
begin
  select * into l_status_empty from ods.fdc_dw_segregistry_tab_status where code='EMPTY';
  select * into l_status_filled from ods.fdc_dw_segregistry_tab_status where code='FILLED';
  select * into l_status_undef from ods.fdc_dw_segregistry_tab_status where code='UNDEFINED';

  for rec in(select id
                   ,code
                   ,name
               from ods.fdc_dw_segregistry_tab
              where intent=2
            ) loop
    registry_tab_code:=rec.code;
    registry_tab_name:=rec.name;
    if rec.code='MT_AGREEMENT' then
      registry_tab_status_code :=l_status_filled.code;
      registry_tab_status_name:= l_status_filled.name;
      return next;
    elsif rec.code='MT_ROUTE' then
      with apdobj as(select distinct obj.root_id as object_root_id
                                    ,dist.agreement_id
                        from ods.fdc_maintenance_route_odh dodh
                        join ods.fdc_maintenance_route dist on dodh.maintenance_route_id=dist.id
                        join ods.fdc_odh odh on dodh.odh_id = odh.id
                        join ods.fdc_object obj on odh.id=obj.id
                       where dist.work_plan_approved
                     )

           select count(distinct apdobj.object_root_id
                       )
                 ,count(distinct case
                                   when apdobj.object_root_id is null then obj.root_id
                                 end
                       )
             into l_total_cnt
                 ,l_not_present_cnt
             from msnow.fdc_agreement agr
             join msnow.fdc_agreement_object agro on agr.id=agro.argeement_id
             join ods.fdc_odh odh on agro.driveway_id=odh.id
             join ods.fdc_object obj on odh.id=obj.id
             left join apdobj on obj.root_id=apdobj.object_root_id
                                 and agr.id=apdobj.agreement_id
            where agr.id=agr.agr_root_id
              and agr.agr_root_id = p_agr_root_id;
        if l_total_cnt > 0 and l_not_present_cnt = 0 then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
      return next;
    elsif rec.code='MT_PLANED_WORK' then
      select count(distinct pw.id) as total_cnt
            ,count(distinct case
                              when pws.code = 'WAITING_FOR_APPROVAL' then pw.id
                            end
                  ) as null_cnt
        into l_total_cnt
            ,l_not_present_cnt
        from msnow.fdc_planed_work pw
        join msnow.fdc_planed_work_status pws on pw.planed_work_status_id=pws.id
        join msnow.fdc_agreement agr on pw.agreement_id=agr.id
       where agr.agr_root_id = p_agr_root_id;
       
      if l_total_cnt > 0 and l_not_present_cnt = 0  then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
      return next;
    elsif rec.code='MT_WORK_EXECUTE' then
      select count(distinct we.id)
            ,count(distinct case
                              when ws.code = 'ACCEPTED' then we.id
                            end
                  )
        into l_total_cnt
            ,l_present_cnt
        from msnow.fdc_work_execute we
        join msnow.fdc_work_status ws on we.work_status_id=ws.id
        join msnow.fdc_agreement agr on we.agreement_id=agr.id
       where agr.agr_root_id = p_agr_root_id;

      if l_total_cnt>0 and l_total_cnt=l_present_cnt then
        registry_tab_status_code :=l_status_filled.code;
        registry_tab_status_name:= l_status_filled.name;
      else
        registry_tab_status_code :=l_status_empty.code;
        registry_tab_status_name:= l_status_empty.name;
      end if;
      return next;
    elsif rec.code='MT_EXECUTION' then
      for rec_month in(select m.id as month_id
                             ,m.name as month_name
                             ,m.month_start_date
                             ,m.month_end_date
                         from msnow.fdc_agreement agr
                         join msnow.fdc_month m on m.month_start_date between date_trunc('month',agr.work_date_from)::date and date_trunc('month',agr.work_date_to)::date
                        where agr.agr_root_id= p_agr_root_id
                          and agr.agr_root_id=agr.id
                      ) loop
        l_current_mt_execution:=C_BLANK;
        /* 'Ведомость предписаний' */
        registry_tab_code:=rec_month.month_id::text||'_MT_WORK_ASSIGNMENT';
        registry_tab_name:='Ведомость предписаний';
        select count(distinct wasm.id)
              ,count(distinct case
                                when wasms.code = 'ACCEPTED' then wasm.id
                              end
                    )
          into l_total_cnt
              ,l_present_cnt
          from msnow.fdc_work_execute we
          join msnow.fdc_agreement agr on we.agreement_id=agr.id
          join msnow.fdc_work_assignment wasm on we.id=wasm.work_execute_id
          join msnow.fdc_assignment_status wasms on wasm.assignment_status_id=wasms.id
         where agr.agr_root_id=p_agr_root_id
           and date(we.work_date) between rec_month.month_start_date and rec_month.month_end_date;
        if l_total_cnt>0 and l_total_cnt=l_present_cnt then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
          l_current_mt_execution:=l_current_mt_execution | C_WORK_ASSIGNMENT_DONE;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
        return next;

        /* Заключение о качестве */
        registry_tab_code:=rec_month.month_id::text||'_MT_LABRADOR';
        registry_tab_name:='Заключение о качестве';
        if exists(select null
                    from msnow.fdc_labrador_act lact
                    join msnow.fdc_agreement agr on lact.agreement_id=agr.id
                    join msnow.fdc_lab_analysis_result lres on lact.lab_analysis_result_id=lres.id
                   where lres.code='POSITIVE'
                     and agr.agr_root_id = p_agr_root_id
                     and lact.delivery_date between rec_month.month_start_date and rec_month.month_end_date
                 ) then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
          l_current_mt_execution:=l_current_mt_execution | C_LABRADOR_DONE;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
        return next;

        /* Акты КС-2 */
        registry_tab_code:=rec_month.month_id::text||'_MT_KS2';
        registry_tab_name:='Акты КС-2';
        if exists(select null
                    from msnow.fdc_execute_act ea
                    join msnow.fdc_execute_act_status eas on ea.status_id=eas.id
                    join msnow.fdc_agreement agr on ea.agreement_id=agr.id
                   where eas.code='APPROVED'
                     and agr.agr_root_id=p_agr_root_id
                     and ea.report_end_date between rec_month.month_start_date and rec_month.month_end_date
                 ) then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
          l_current_mt_execution:=l_current_mt_execution | C_KS2_DONE;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
        return next;
        /* Акты КС-3 */
        registry_tab_code:=rec_month.month_id::text||'_MT_KS3';
        registry_tab_name:='Акты КС-3';
        if exists(select null
                    from msnow.fdc_cost_doc cd
                    join msnow.fdc_agreement agr on cd.agreement_id=agr.id
                   where agr.agr_root_id=p_agr_root_id
                     and cd.report_end_date between rec_month.month_start_date and rec_month.month_end_date
                 ) then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
          l_current_mt_execution:=l_current_mt_execution | C_KS3_DONE;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
        return next;
        /* Платежные документы */
        registry_tab_code:=rec_month.month_id::text||'_MT_PAYMENT';
        registry_tab_name:='Платежные документы';
        if exists(with ks3 as(select sum(cd.report_period_cost_vat) as  ammount
                                from msnow.fdc_cost_doc cd
                                join msnow.fdc_agreement agri on cd.agreement_id=agri.id
                               where agri.agr_root_id=p_agr_root_id
                                 and cd.report_end_date between rec_month.month_start_date and rec_month.month_end_date
                             )
                       select null
                         from(select sum(p.amount) as ammount
                                from msnow.fdc_payment p
                                join msnow.fdc_agreement agr on p.agreement_id=agr.id
                               where agr.agr_root_id=p_agr_root_id
                                 and p.period_date_to between rec_month.month_start_date and rec_month.month_end_date
                             ) pmt
                         join ks3 on true
                        where pmt.ammount=ks3.ammount
                 ) then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
          l_current_mt_execution:=l_current_mt_execution | C_PAYMENT_DONE;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
        return next;
        /* <Месяц> <год> */
        registry_tab_code:=rec_month.month_id::text||'_MT_MONTH';
        registry_tab_name:=upper(rec_month.month_name);
        if l_current_mt_execution =  C_MT_EXECUTION_DONE then
          registry_tab_status_code :=l_status_filled.code;
          registry_tab_status_name:= l_status_filled.name;
        else
          registry_tab_status_code :=l_status_empty.code;
          registry_tab_status_name:= l_status_empty.name;
        end if;
        return next;
      end loop;
    else
      registry_tab_status_code := l_status_undef.code;
      registry_tab_status_name := l_status_undef.name;
      return next;
    end if;
  end loop;
  return;
end
$$;

