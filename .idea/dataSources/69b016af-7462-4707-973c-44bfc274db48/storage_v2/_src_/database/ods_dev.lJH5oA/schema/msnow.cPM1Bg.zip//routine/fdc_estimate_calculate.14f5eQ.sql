CREATE FUNCTION fdc_estimate_calculate(p_obligation_id bigint DEFAULT NULL::bigint, p_purchase_lot_id bigint DEFAULT NULL::bigint, p_agreement_id bigint DEFAULT NULL::bigint, OUT driveway_qty integer, OUT driveway_with_estimate_qty integer, OUT estimate_qty integer, OUT estimate_calculated_qty integer, OUT work_type_qty integer, OUT work_type_norate_qty integer)
  RETURNS record
LANGUAGE plpgsql
AS $$
declare
/** Расчет стоимости сметы бюджетного обязательства/закупки/обязательства.
  %param p_obligation_id   -- Ид бюджетного обязательства
  %param p_purchase_lot_id -- Ид закупки
  %param p_agreement_id    -- Ид обязательства

  %return  driveway_qty               -- число дорог объекта
  %return  driveway_with_estimate_qty -- число дорог объекта, по которым есть сметы
  %return  estimate_qty               -- число работ объекта
  %return  estimate_calculated_qty    -- число рассчитанных работ
  %return  work_type_qty              -- число видов работ объекта
  %return  work_type_norate_qty       -- число видов работ без расценок
*/
  l_result int:=1;
  l_sql text;
  l_exist boolean;

  l_pholder1 text;
  l_pholder2 text;
  l_pholder3 text;
  l_pholder4 text;
  l_pholder5 text;
  l_pholder6 text;
  l_pholder7 text;
  l_pholder8 text;

  l_work_cost double precision;
  rec record;

  l_work_type_norate_lst bigint[];
begin
  if p_obligation_id is not null or p_purchase_lot_id is not null or p_agreement_id is not null then
    estimate_calculated_qty:=0;
    work_type_norate_qty:=0;

    l_pholder1:=case
                  when p_obligation_id is not null then 'fdc_obligation_estimate'
                  when p_agreement_id is not null then 'fdc_agr_estimate'
                  when p_purchase_lot_id is not null then 'fdc_purchase_estimate'
                end;
    l_pholder2:=case
                  when p_obligation_id is not null then 'fdc_obligation'
                  when p_agreement_id is not null then 'fdc_agreement'
                  when p_purchase_lot_id is not null then 'fdc_purchase'
                end;
    l_pholder3:=case
                  when p_obligation_id is not null then 'obligation_id'
                  when p_agreement_id is not null then 'agreement_id'
                  when p_purchase_lot_id is not null then 'purchase_lot_id'
                end;
    l_pholder4:=case
                  when p_obligation_id is not null then 'authority_org_id'
                  when p_agreement_id is not null then 'customer_id'
                  when p_purchase_lot_id is not null then 'customer_id'
                end;
    l_pholder5:=case
                  when p_obligation_id is not null then 'obligation_year'
                  when p_agreement_id is not null then 'work_date_from'
                  when p_purchase_lot_id is not null then 'work_date_from'
                end;
    l_pholder6:=l_pholder5;
    l_pholder7:=case
                  when p_obligation_id is not null then 'fdc_obligation_object'
                  when p_agreement_id is not null then 'fdc_agreement_object'
                  when p_purchase_lot_id is not null then 'fdc_purchase_object'
                end;
    l_pholder8:=case
                  when p_obligation_id is not null then 'obligation_id'
                  when p_agreement_id is not null then 'argeement_id'
                  when p_purchase_lot_id is not null then 'purchase_lot_id'
                end;
    -----------------------
    l_sql:=format('select count(driveway_id) from msnow.%I where %I=$1',l_pholder7,l_pholder8);
    execute l_sql into driveway_qty using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
    driveway_qty:=coalesce(driveway_qty,0);

    l_sql:=format('select count(o.driveway_id)
                     from msnow.%I o
                    where o.%I=$1
                      and exists(select null
                                   from msnow.%I oe
                                  where oe.%I=o.%I
                                    and oe.driveway_id=o.driveway_id
                                )'
                 ,l_pholder7,l_pholder8,l_pholder1,l_pholder3,l_pholder8
                 );
    execute l_sql into driveway_with_estimate_qty using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
    driveway_with_estimate_qty:=coalesce(driveway_with_estimate_qty,0);
    l_sql:=format('select count(1)
                     from msnow.%I o
                    where o.%I=$1
                      and o.driveway_id is not null'
                 ,l_pholder1,l_pholder3
                 );
    execute l_sql into estimate_qty using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
    estimate_qty:=coalesce(estimate_qty,0);

    l_sql:=format('select count(distinct coalesce(wt.work_type_uni_id,o.work_type_id))
                     from msnow.%I o
                     join msnow.fdc_work_type wt on wt.id=o.work_type_id
                    where o.%I=$1'
                  ,l_pholder1,l_pholder3
                 );
    execute l_sql into work_type_qty using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id);
    work_type_qty:=coalesce(work_type_qty,0);

    if driveway_with_estimate_qty>0 then
      if p_obligation_id is not null then
        l_sql:='select tt.estimate_id
                      ,case
                         when tt.work_type_rate_id is not null then true
                         else false
                       end rate_found
                      ,(select tt.work_volume*rt.rate
                          from msnow.fdc_work_type_rate rt
                         where rt.id=tt.work_type_rate_id
                       ) work_cost
                      ,coalesce(tt.work_type_uni_id,tt.work_type_id) norate_work_type_id
                  from(select e.id estimate_id
                             ,e.work_volume
                             ,e.work_type_id
                             ,wt.work_type_uni_id
                             ,coalesce((select wtr.id
                                          from msnow.fdc_work_type_rate wtr
                                         where wtr.work_type_id=e.work_type_id
                                           and wtr.organization_id=o.%I --!! 4
                                           and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                           and wtr.odh_group_id=dw.odh_group_id
                                           and to_date(''01.01.''||coalesce(o.%I,''1900''),''dd.mm.yyyy'') between wtr.date_from and wtr.date_to --!! 5
                                           limit 1
                                       )
                                      ,(select wtr.id
                                          from msnow.fdc_work_type_rate wtr
                                         where wtr.work_type_id=wt.work_type_uni_id
                                           and wtr.organization_id=o.%I --!! 4
                                           and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                           and wtr.odh_group_id=dw.odh_group_id
                                           and to_date(''01.01.''||coalesce(o.%I,''1900''),''dd.mm.yyyy'') between wtr.date_from and wtr.date_to --!! 5
                                           limit 1
                                       )
                                      ,(select id
                                          from msnow.fdc_work_type_rate wtr
                                         where wtr.work_type_id=e.work_type_id
                                           and wtr.organization_id is null
                                           and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                           and wtr.odh_group_id=dw.odh_group_id
                                           and to_date(''01.01.''||coalesce(o.%I,''1900''),''dd.mm.yyyy'') between wtr.date_from and wtr.date_to --!! 5
                                           limit 1
                                       )
                                      ,(select id
                                          from msnow.fdc_work_type_rate wtr
                                         where wtr.work_type_id=wt.work_type_uni_id
                                           and wtr.organization_id is null
                                           and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                           and wtr.odh_group_id=dw.odh_group_id
                                           and to_date(''01.01.''||coalesce(o.%I,''1900''),''dd.mm.yyyy'') between wtr.date_from and wtr.date_to --!! 5
                                           limit 1
                                       )
                                      ) work_type_rate_id
                                 from msnow.%I e --!! 1
                                 join msnow.fdc_work_type wt on wt.id=e.work_type_id
                                 join msnow.fdc_driveway dw on dw.id=e.driveway_id
                                 join msnow.%I o on o.id=e.%I --!! 3
                                where o.id=$1
                                  and e.driveway_id is not null
                                  and not e.is_estimate_sum
                       ) tt ';

        l_sql:=format(l_sql,l_pholder4,l_pholder5,l_pholder4,l_pholder5
                     ,l_pholder6,l_pholder6
                     ,l_pholder1,l_pholder2,l_pholder3
                     );
      else
       l_sql:='select tt.estimate_id
                    ,case
                       when tt.work_type_rate_id is not null then true
                       else false
                     end rate_found
                    ,(select tt.work_volume*rt.rate
                        from msnow.fdc_work_type_rate rt
                       where rt.id=tt.work_type_rate_id
                     ) work_cost
                    ,coalesce(tt.work_type_uni_id,tt.work_type_id) norate_work_type_id
                from(select e.id estimate_id
                           ,e.work_volume
                           ,e.work_type_id
                           ,wt.work_type_uni_id
                           ,coalesce((select wtr.id
                                        from msnow.fdc_work_type_rate wtr
                                        join lateral (select true as is_true
                                                        from msnow.fdc_util_get_dates(p_date_from => o.work_date_from
                                                                                     ,p_date_to   => o.work_date_from
                                                                                     ) flt
                                                            ,msnow.fdc_util_get_dates(p_date_from => wtr.date_from
                                                                                     ,p_date_to   => wtr.date_to
                                                                                     ) tbl
                                                       where flt=tbl
                                                       limit 1
                                                     ) as dtc on dtc.is_true=true
                                       where wtr.work_type_id=e.work_type_id
                                         and wtr.organization_id=o.%I --!! 4
                                         and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                         and wtr.odh_group_id=dw.odh_group_id
                                         limit 1
                                     )
                                    ,(select wtr.id
                                        from msnow.fdc_work_type_rate wtr
                                        join lateral (select true as is_true
                                                        from msnow.fdc_util_get_dates(p_date_from => o.work_date_from
                                                                                     ,p_date_to   => o.work_date_from
                                                                                     ) flt
                                                            ,msnow.fdc_util_get_dates(p_date_from => wtr.date_from
                                                                                     ,p_date_to   => wtr.date_to
                                                                                     ) tbl
                                                       where flt=tbl
                                                       limit 1
                                                     ) as dtc on dtc.is_true=true
                                       where wtr.work_type_id=wt.work_type_uni_id
                                         and wtr.organization_id=o.%I --!! 4
                                         and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                         and wtr.odh_group_id=dw.odh_group_id
                                         limit 1
                                     )
                                    ,(select id
                                        from msnow.fdc_work_type_rate wtr
                                        join lateral (select true as is_true
                                                        from msnow.fdc_util_get_dates(p_date_from => o.work_date_from
                                                                                     ,p_date_to   => o.work_date_from
                                                                                     ) flt
                                                            ,msnow.fdc_util_get_dates(p_date_from => wtr.date_from
                                                                                     ,p_date_to   => wtr.date_to
                                                                                     ) tbl
                                                       where flt=tbl
                                                       limit 1
                                                     ) as dtc on dtc.is_true=true
                                       where wtr.work_type_id=e.work_type_id
                                         and wtr.organization_id is null
                                         and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                         and wtr.odh_group_id=dw.odh_group_id
                                         limit 1
                                     )
                                    ,(select id
                                        from msnow.fdc_work_type_rate wtr
                                        join lateral (select true as is_true
                                                        from msnow.fdc_util_get_dates(p_date_from => o.work_date_from
                                                                                     ,p_date_to   => o.work_date_from
                                                                                     ) flt
                                                            ,msnow.fdc_util_get_dates(p_date_from => wtr.date_from
                                                                                     ,p_date_to   => wtr.date_to
                                                                                     ) tbl
                                                       where flt=tbl
                                                       limit 1
                                                     ) as dtc on dtc.is_true=true
                                       where wtr.work_type_id=wt.work_type_uni_id
                                         and wtr.organization_id is null
                                         and (wtr.cover_type_id is null or wtr.cover_type_id=dw.cover_type_id)
                                         and wtr.odh_group_id=dw.odh_group_id
                                         limit 1
                                     )
                                    ) work_type_rate_id
                               from msnow.%I e --!! 1
                               join msnow.fdc_work_type wt on wt.id=e.work_type_id
                               join msnow.fdc_driveway dw on dw.id=e.driveway_id
                               join msnow.%I o on o.id=e.%I --!! 3
                              where o.id=$1
                                and e.driveway_id is not null
                                and not e.is_estimate_sum
                     ) tt ';
        l_sql:=format(l_sql,l_pholder4,l_pholder4
                     ,l_pholder1,l_pholder2,l_pholder3
                     );
      end if;

      for rec in execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id) loop
        l_sql:=format('update msnow.%I set work_cost=$1 where id=$2',l_pholder1);
        if rec.rate_found then
          l_work_cost:=coalesce(rec.work_cost,0);
          estimate_calculated_qty:=estimate_calculated_qty+1;
        else
          l_work_cost:=null;
          if array_position(l_work_type_norate_lst,rec.norate_work_type_id) is null THEN
            l_work_type_norate_lst[coalesce(cardinality(l_work_type_norate_lst),0)+1]:=rec.norate_work_type_id;
          end if;
        end if;
        execute l_sql using round(l_work_cost::numeric,2),rec.estimate_id;
      end loop;
      l_sql:='select e.id estimate_id
                   ,(select sum(COALESCE(es.work_cost,0))
                       from msnow.%I es --!! 1
                       join msnow.fdc_driveway dw on dw.id=es.driveway_id
                      where es.%I=e.%I --!! 3,3
                        and not es.is_estimate_sum
                        and es.driveway_id is not null
                        and dw.odh_group_id=e.odh_group_id
                        and es.work_type_id=e.work_type_id
                    ) work_cost_sum
               from msnow.%I e --!! 1
              where e.odh_group_id is not null
                and not e.is_estimate_sum
                and e.driveway_id is null
                and e.%I=$1'; --!! 3
      l_sql:=format(l_sql,l_pholder1,l_pholder3,l_pholder3,l_pholder1,l_pholder3);
      for rec in execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id) loop
        execute format('update msnow.%I set work_cost=$1 where id=$2',l_pholder1) using round(rec.work_cost_sum::numeric,2),rec.estimate_id;
      end loop;

      l_sql:='select e.id estimate_id
                   ,(select sum(COALESCE(es.work_cost,0))
                       from msnow.%I es --!! 1
                      where es.%I=e.%I --!! 3,3
                        and not es.is_estimate_sum
                        and es.driveway_id is null
                        and es.odh_group_id is not null
                        and es.work_type_id=e.work_type_id
                    ) work_cost_sum
               from msnow.%I e --!! 1
              where e.odh_group_id is null
                and e.is_estimate_sum
                and e.driveway_id is null
                and e.%I=$1'; --!! 3

      l_sql:=format(l_sql,l_pholder1,l_pholder3,l_pholder3,l_pholder1,l_pholder3);
      for rec in execute l_sql using COALESCE(p_obligation_id,p_purchase_lot_id,p_agreement_id) loop
        execute format('update msnow.%I set work_cost=$1 where id=$2',l_pholder1) using round(rec.work_cost_sum::numeric,2),rec.estimate_id;
      end loop;
      work_type_norate_qty:=coalesce(cardinality(l_work_type_norate_lst),0);
    end if;
  end if;
end;
$$;

