CREATE VIEW fdc_person_last_version_v AS
  SELECT tt.id,
    tt.root_id,
    tt.name,
    tt.short_name
   FROM ( SELECT lp.id,
            lp.root_id,
            lp.name,
            lp.short_name,
            row_number() OVER (PARTITION BY lp.root_id ORDER BY lp.ver_start_date DESC) AS rn
           FROM nsi.fdc_legal_person lp) tt
  WHERE (tt.rn = 1);

COMMENT ON VIEW fdc_person_last_version_v IS 'Последняя версия субъекта права';

COMMENT ON COLUMN fdc_person_last_version_v.id IS 'Ид последней версии';

COMMENT ON COLUMN fdc_person_last_version_v.root_id IS 'Сквозной Ид субъекта';

COMMENT ON COLUMN fdc_person_last_version_v.name IS 'Наименование';

COMMENT ON COLUMN fdc_person_last_version_v.short_name IS 'Краткое наименование';

