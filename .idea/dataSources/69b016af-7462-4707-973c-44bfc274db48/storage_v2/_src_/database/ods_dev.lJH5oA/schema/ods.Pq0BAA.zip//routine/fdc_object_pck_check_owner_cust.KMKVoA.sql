CREATE FUNCTION fdc_object_pck_check_owner_cust(p_date_from timestamp without time zone, p_owner_id bigint, p_customer_id bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Процедура проверки актуальности заказчика, балансодержателя
  %param p_date_from             Дата начала действия версии объекта
  %param p_owner_id              Ид балансодержателя
  %param p_customer_id           Ид заказчика
  */
  l_id_cnt int;
begin
  select count(1)
    into l_id_cnt
    from ods.fdc_nsi_owner_v nov
   where p_date_from between nov.person_start_date and nov.person_end_date
     and p_date_from between nov.role_start_date and nov.role_end_date
     and nov.person_id=p_owner_id;
  if l_id_cnt=0 then
    raise exception 'На дату начала действия объекта указанный Балансодержатель неактуален. Выберите актуальное значение.';
  end if;

  if p_customer_id is not null then
    select count(1)
      into l_id_cnt
      from ods.fdc_nsi_customer_v nov
     where p_date_from between nov.person_start_date and nov.person_end_date
       and p_date_from between nov.role_start_date and nov.role_end_date
       and nov.person_id = p_customer_id;
    if l_id_cnt=0 then
      raise exception 'На дату начала действия объекта указанный Заказчик неактуален. Выберите актуальное значение.';
    end if;
  end if;
end
$$;

