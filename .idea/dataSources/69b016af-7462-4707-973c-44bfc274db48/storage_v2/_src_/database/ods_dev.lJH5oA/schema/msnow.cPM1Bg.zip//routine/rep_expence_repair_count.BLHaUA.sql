CREATE FUNCTION rep_expence_repair_count(p_driveway_category_id bigint, OUT total_sum double precision, OUT sum_not_payed double precision, OUT sum_payed double precision, OUT sum_not_started double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Отчет о финансовых затратах на ремонт(суммы)
      %param p_driveway_category_id - Ид балансовой принадлежности

      %return total_sum           - Общая сумма на программу ремонта
      %return sum_not_payed       - Работы завершены, но не оплачены
      %return sum_payed           - Оплачено
      %return sum_not_started     - Работы не завершены или не начаты
  */
  l_driveway_category_code msnow.fdc_driveway_category.code%type;
  l_current_year text;
begin
  select code
    into strict l_driveway_category_code
    from msnow.fdc_driveway_category
   where id=p_driveway_category_id;

   l_current_year:=to_char(current_date,'YYYY');

  return query
  with org_ruad as(select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_role r on pr.role_id=r.id
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and r.code in('RUAD')
                      and l_driveway_category_code='REGION_INTERMUNICIPAL'
                   union all
                   select distinct lp.id as org_ruad_id
                     from nsi.fdc_person_role pr
                     join nsi.fdc_legal_person lp on pr.person_id=lp.root_id
                    where statement_timestamp() between pr.begin_date and pr.end_date
                      and l_driveway_category_code='LOCAL'
                      and not exists(select null
                                       from nsi.fdc_role r
                                       join nsi.fdc_person_role prr on r.id=prr.role_id
                                      where prr.person_id=pr.person_id
                                        and statement_timestamp() between prr.begin_date and prr.end_date
                                        and r.code in('RUAD')
                                    )
                  )
      ,agre as(select agre.driveway_segment_id
                     ,sum(agre.work_cost)  as work_cost
                 from msnow.fdc_agr_estimate agre
                where agre.driveway_segment_id is not null
                group by agre.driveway_segment_id
              )
         select coalesce(sum(sm.total_sum),0)::double precision as total_sum
               ,coalesce(sum(sm.sum_not_payed),0)::double precision as sum_not_payed
               ,coalesce(sum(sm.sum_payed),0)::double precision as sum_payed
               ,coalesce(sum(sm.sum_not_started),0)::double precision as sum_not_started
           from(select case dense_rank() OVER(partition by dws.agreement_id order by dws.id)
                         when 1 then agr.cost
                       end as total_sum
                      ,case
                         when sch.end_date_fact<=current_date then agre.work_cost
                       end as sum_not_payed
                      ,0 as sum_payed
                      ,case
                         when sch.end_date_fact is null then agre.work_cost
                       end as sum_not_started
                  from msnow.fdc_driveway_segment dws
                  join msnow.fdc_agreement agr on dws.agreement_id=agr.id
                  join org_ruad on dws.org_ruad_id=org_ruad.org_ruad_id
                  join msnow.fdc_work_schedule sch on dws.id=sch.driveway_segment_id
                  left join agre on dws.id=agre.driveway_segment_id
                 where to_char(sch.start_date_plan,'YYYY')=l_current_year
               ) sm;
  return;
end
$$;

