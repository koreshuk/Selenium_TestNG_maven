CREATE FUNCTION fdc_object_pck_add_object_address_list(p_object_id bigint, p_object_address_tab t_object_address[], p_biz_event_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Процедура добавления адресов
  %param     p_object_id              Ид версии объекта
  %param     p_t_object_address_tab   Список адресов
  %param     p_biz_event_id           Идентификатор бизнес события
  */
begin
------------------
  insert into ods.fdc_object_address(id
                                    ,object_id
                                    ,address_id
                                    ,address_detail
                                    )
    select nextval('ods.fdc_object_address_seq')
          ,p_object_id
          ,toa.address_id
          ,toa.address_detail
      from unnest(p_object_address_tab) toa
     where not exists(select null
                        from ods.fdc_object_address oa
                       where oa.object_id = p_object_id
                         and oa.address_id = toa.address_id
                         and oa.address_detail = toa.address_detail
                     );
end
$$;

