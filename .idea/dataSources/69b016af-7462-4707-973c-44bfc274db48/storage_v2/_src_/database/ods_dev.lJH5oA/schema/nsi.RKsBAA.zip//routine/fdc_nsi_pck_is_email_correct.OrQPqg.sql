CREATE FUNCTION fdc_nsi_pck_is_email_correct(p_email character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
  /** Проверка email
  %usage Используется в пакете
  %param p_email   - эл почта
  %return true  - заданный адрес эл. почты прошел проверку на корректность
          false - заданный адрес эл. почты не прошел проверку на корректность
  */
begin
  return true;
end
$$;

