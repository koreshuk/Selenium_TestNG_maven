CREATE VIEW fdc_odh_group AS
  SELECT fdc_maintain_group.id,
    fdc_maintain_group.code,
    fdc_maintain_group.name
   FROM msnow.fdc_maintain_group;

COMMENT ON VIEW fdc_odh_group IS 'Временное представление. Название дуюлируется с названием таблицы ods.fdc_odh_group';

