CREATE FUNCTION fdc_nsi_person_group_subgrouporgs(p_group_id bigint, OUT id bigint, OUT group_id bigint, OUT root_id bigint, OUT date_add timestamp without time zone, OUT person_type_id bigint, OUT parent_id bigint, OUT parent_root_id bigint, OUT name character varying, OUT short_name character varying, OUT inn character varying, OUT kpp character varying, OUT ogrn character varying, OUT okpo character varying, OUT postal_address character varying, OUT legal_address character varying, OUT email character varying, OUT phone character varying, OUT fax character varying, OUT off_post character varying, OUT off_name character varying, OUT person_code character varying, OUT reg_date date, OUT issue_dept_code character varying, OUT ver_start_date timestamp without time zone, OUT ver_end_date timestamp without time zone, OUT closing_date timestamp without time zone)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает атрибуты подгрупы группы организации p_group_id.
      Атрибуты самой p_group_id не возвращаются

      %param p_group_id - Ид группы организации

      %return group_id                        - Ид группы
      %return id                              - Ид организации
      %return root_id                         - Сквозной Ид организации
      %return date_add                        - Дата добавления организации в группу
      %return person_type_id                  - Ид типа субъекта права
      %return parent_id                       - Ид вышестоящей организации
      %return parent_root_id                  - Сквозной Ид вышестоящей организации
      %return name                            - Полное наименование
      %return short_name                      - Краткое наименование
      %return inn                             - ИНН
      %return kpp                             - КПП
      %return ogrn                            - ОГРН
      %return okpo                            - ОКПО
      %return postal_address                  - Почтовый адрес
      %return legal_address                   - Юридический адрес
      %return email                           - Электронная почта
      %return phone                           - Телефон
      %return fax                             - Факс
      %return off_post                        - Должность руководителя
      %return off_name                        - ФИО руководителя
      %return person_code                     - Код подразделения
      %return reg_date                        - Дата регистрации
      %return issue_dept_code                 - Код подразделения
      %return ver_start_date                  - Дата начала действия версии
      %return ver_end_date                    - Дата окончания действия версии
      %return closing_date                    - Дата закрытия организации

  */
  rec record;
begin
  for rec in(with recursive h(group_id
                             ,parent_id
                             ,level
                             ) as(select h1.group_id
                                        ,h1.parent_id
                                        ,1
                                    from nsi.fdc_pg_hierarchy_v h1
                                   where h1.group_id=p_group_id
                                  union
                                  select hn.group_id
                                        ,hn.parent_id
                                        ,hn.level+1
                                    from nsi.fdc_pg_hierarchy_v hn
                                    join h on h.group_id=hn.parent_id
                         )
                     select distinct lp.id
                           ,h.group_id
                           ,lp.root_id
                           ,pgl.date_add
                           ,lp.person_type_id
                           ,lp.parent_id
                           ,lp.parent_root_id
                           ,lp.name
                           ,lp.short_name
                           ,lp.inn
                           ,lp.kpp
                           ,lp.ogrn
                           ,lp.okpo
                           ,lp.postal_address
                           ,lp.legal_address
                           ,lp.email
                           ,lp.phone
                           ,lp.fax
                           ,lp.off_post
                           ,lp.off_name
                           ,lp.person_code
                           ,lp.reg_date
                           ,lp.issue_dept_code
                           ,lp.ver_start_date
                           ,lp.ver_end_date
                           ,lp.closing_date
                       from h
                       join nsi.fdc_person_group_link pgl on h.group_id=pgl.group_id
                       join nsi.fdc_person p on pgl.person_id=p.id
                       join nsi.fdc_legal_person lp on p.id=lp.root_id
                      where statement_timestamp() between lp.ver_start_date and coalesce(lp.ver_end_date,to_timestamp('01.01.3000','dd.mm.yyyy')::timestamp)

            ) loop

    group_id:=rec.group_id;
    id:=rec.id;
    root_id:=rec.root_id;
    date_add:=rec.date_add;
    person_type_id:=rec.person_type_id;
    parent_id:=rec.parent_id;
    parent_root_id:=rec.parent_root_id;
    name:=rec.name;
    short_name:=rec.short_name;
    inn:=rec.inn;
    kpp:=rec.kpp;
    ogrn:=rec.ogrn;
    okpo:=rec.okpo;
    postal_address:=rec.postal_address;
    legal_address:=rec.legal_address;
    email:=rec.email;
    phone:=rec.phone;
    fax:=rec.fax;
    off_post:=rec.off_post;
    off_name:=rec.off_name;
    person_code:=rec.person_code;
    reg_date:=rec.reg_date;
    issue_dept_code:=rec.issue_dept_code;
    ver_start_date:=rec.ver_start_date;
    ver_end_date:=rec.ver_end_date;
    closing_date:=rec.closing_date;
    return next;
  end loop;
  return;
end
$$;

