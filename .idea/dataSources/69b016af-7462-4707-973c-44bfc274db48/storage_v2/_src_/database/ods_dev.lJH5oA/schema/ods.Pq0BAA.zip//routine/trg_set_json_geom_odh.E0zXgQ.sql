CREATE FUNCTION trg_set_json_geom_odh()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
/** Только для триггера на ods.fdc_odh

*/
  l_geometrytype text;
begin
 if tg_when='BEFORE' and tg_level='ROW' and tg_op in('INSERT','UPDATE') then
   if new.geometry_json is not null and new.geometry is null then
     new.geometry := ST_GeomFromGeoJSON(new.geometry_json);
   elsif new.geometry is not null and new.geometry_json is null THEN
     new.geometry_json=st_asgeojson(new.geometry);
   end if;

   if st_srid(new.geometry)<>0 then
     new.geometry:=st_setSrid(new.geometry,0);
     new.geometry_json:=st_asgeojson(new.geometry);
   end if;

   if new.geometry is not null THEN
     l_geometrytype:=geometrytype(new.geometry);
     if l_geometrytype='POINT' then
       select st_x((dp).geom)
             ,st_y((dp).geom)
             ,st_x((dp).geom)
             ,st_y((dp).geom)
         into new.latitude_start
             ,new.longitude_start
             ,new.latitude_end
             ,new.longitude_end
         from(select st_dumppoints(new.geometry) as dp
             ) t;
     elsif l_geometrytype='LINESTRING' THEN
       with pts as(select tt.x
                         ,tt.y
                         ,tt.d1
                         ,tt.max_d1
                     from(select st_x((dp).geom) x
                                ,st_y((dp).geom) y
                                ,(dp).path[1] d1
                                ,max((dp).path[1]) over (order by 1) max_d1
                            from(select st_dumppoints(new.geometry) as dp
                                ) t
                         ) tt
                    where tt.d1=1
                       or tt.d1=tt.max_d1
                       or tt.d1=tt.max_d1-1
                  )
           select p1.x latitude_start
                 ,p1.y longitude_start
                 ,coalesce((select x
                              from pts p2
                             where p2.d1=p2.max_d1
                               and (p2.x<>p1.x or p2.y<>p1.y)
                           )
                          ,(select x
                              from pts p2
                             where p2.d1=p2.max_d1-1
                           )
                          ) latitude_end
                 ,coalesce((select y
                              from pts p2
                              where p2.d1=p2.max_d1
                                and (p2.x<>p1.x or p2.y<>p1.y)
                           )
                          ,(select y
                              from pts p2
                             where p2.d1=p2.max_d1-1
                           )
                          ) longitude_end
             into new.latitude_start
                 ,new.longitude_start
                 ,new.latitude_end
                 ,new.longitude_end
             from pts p1
            where p1.d1=1;
     elsif l_geometrytype in('MULTILINESTRING','POLYGON','MULTIPOINT') then
       with pts as(select ttt.x
                         ,ttt.y
                         ,ttt.d1
                         ,ttt.max_d1
                     from(select tt.x
                                ,tt.y
                                ,tt.d1
                                ,max(tt.d1) over(order by 1) max_d1
                            from(select st_x((dp).geom) x
                                       ,st_y((dp).geom) y
                                       ,row_number() over (order by (dp).path[1],(dp).path[2]) d1
                                   from(select st_dumppoints(new.geometry) as dp
                                       ) t
                                ) tt
                         ) ttt
                    where ttt.d1=1
                       or ttt.d1=ttt.max_d1
                       or ttt.d1=ttt.max_d1-1
                  )
           select p1.x latitude_start
                 ,p1.y longitude_start
                 ,coalesce((select x
                              from pts p2
                             where p2.d1=p2.max_d1
                               and (p2.x<>p1.x or p2.y<>p1.y)
                           )
                          ,(select x
                              from pts p2
                             where p2.d1=p2.max_d1-1
                           )
                          ) latitude_end
                 ,coalesce((select y
                              from pts p2
                              where p2.d1=p2.max_d1
                                and (p2.x<>p1.x or p2.y<>p1.y)
                           )
                          ,(select y
                              from pts p2
                             where p2.d1=p2.max_d1-1
                           )
                          ) longitude_end
             into new.latitude_start
                 ,new.longitude_start
                 ,new.latitude_end
                 ,new.longitude_end
             from pts p1
            where p1.d1=1;
     elsif l_geometrytype = 'MULTIPOLYGON' then
       with pts as(select ttt.x
                         ,ttt.y
                         ,ttt.d1
                         ,ttt.max_d1
                     from(select tt.x
                                ,tt.y
                                ,tt.d1
                                ,max(tt.d1) over(order by 1) max_d1
                            from(select st_x((dp).geom) x
                                       ,st_y((dp).geom) y
                                       ,row_number() over (order by (dp).path[1],(dp).path[2],(dp).path[3]) d1
                                   from(select st_dumppoints(new.geometry) as dp
                                       ) t
                                ) tt
                         ) ttt
                    where ttt.d1=1
                       or ttt.d1=ttt.max_d1
                       or ttt.d1=ttt.max_d1-1
                  )
           select p1.x latitude_start
                 ,p1.y longitude_start
                 ,coalesce((select x
                              from pts p2
                             where p2.d1=p2.max_d1
                               and (p2.x<>p1.x or p2.y<>p1.y)
                           )
                          ,(select x
                              from pts p2
                             where p2.d1=p2.max_d1-1
                           )
                          ) latitude_end
                 ,coalesce((select y
                              from pts p2
                              where p2.d1=p2.max_d1
                                and (p2.x<>p1.x or p2.y<>p1.y)
                           )
                          ,(select y
                              from pts p2
                             where p2.d1=p2.max_d1-1
                           )
                          ) longitude_end
             into new.latitude_start
                 ,new.longitude_start
                 ,new.latitude_end
                 ,new.longitude_end
             from pts p1
            where p1.d1=1;
     end if;
   else
     new.latitude_start:=null;
     new.longitude_start:=null;
     new.latitude_end:=null;
     new.longitude_end:=null;
   end if;
 end if;
 return NEW;
end
$$;

