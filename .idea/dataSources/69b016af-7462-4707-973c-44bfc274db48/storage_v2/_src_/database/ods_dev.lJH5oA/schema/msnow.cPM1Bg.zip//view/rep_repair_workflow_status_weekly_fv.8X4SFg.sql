CREATE VIEW rep_repair_workflow_status_weekly_fv AS
  WITH rootwt AS (
         SELECT DISTINCT agr.agr_root_id,
            agre.driveway_segment_id,
            agre.work_type_id,
            wt.is_asphalt,
            mu.code AS measure_unit_code
           FROM (((msnow.fdc_agreement agr
             JOIN msnow.fdc_agr_estimate agre ON ((agr.id = agre.agreement_id)))
             JOIN msnow.fdc_work_type wt ON ((agre.work_type_id = wt.id)))
             LEFT JOIN msnow.fdc_measure_unit mu ON ((wt.measure_unit_id = mu.id)))
        ), wclosed AS (
         SELECT sagr.agr_root_id,
            sdws.id AS driveway_segment_id,
            sum(
                CASE
                    WHEN ((rootwt.measure_unit_code)::text = 'MTK'::text) THEN (ajl.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume,
            max(ajl.work_date) AS max_work_date
           FROM (((msnow.fdc_driveway_segment sdws
             JOIN msnow.fdc_agreement sagr ON ((sdws.agreement_id = sagr.id)))
             JOIN rootwt ON (((sagr.agr_root_id = rootwt.agr_root_id) AND (sdws.id = rootwt.driveway_segment_id))))
             LEFT JOIN msnow.fdc_asphalt_journal ajl ON (((rootwt.work_type_id = ajl.work_type_id) AND (sdws.id = ajl.driveway_segment_id) AND ajl.is_last_work)))
          WHERE rootwt.is_asphalt
          GROUP BY sagr.agr_root_id, sdws.id
         HAVING (count(
                CASE
                    WHEN (ajl.id IS NULL) THEN rootwt.work_type_id
                    ELSE NULL::bigint
                END) = 0)
        ), milling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_milling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), levelling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_levelling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), asph AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_asphalt AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), rside AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_roadside AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), f AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(ceil((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 20))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN levelling ON ((ssch.driveway_segment_id = levelling.driveway_segment_id)))
        ), b AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(ceil((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 50))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN asph ON ((ssch.driveway_segment_id = asph.driveway_segment_id)))
        ), a AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(ceil((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 15))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN rside ON ((ssch.driveway_segment_id = rside.driveway_segment_id)))
        ), e AS (
         SELECT ssch.driveway_segment_id,
            (((COALESCE(ceil((((ssch.end_date_plan + 1) - ssch.start_date_plan))::double precision), (0)::double precision) - (COALESCE(a.day_cnt, (0)::numeric))::double precision) - (COALESCE(f.day_cnt, (0)::numeric))::double precision) - (COALESCE(b.day_cnt, (0)::numeric))::double precision) AS day_cnt
           FROM (((msnow.fdc_work_schedule ssch
             LEFT JOIN a ON ((ssch.driveway_segment_id = a.driveway_segment_id)))
             LEFT JOIN f ON ((ssch.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((ssch.driveway_segment_id = b.driveway_segment_id)))
        ), dates AS (
         SELECT sagr.agr_root_id,
            sagre.driveway_segment_id,
            max(
                CASE
                    WHEN swt.is_asphalt THEN ((((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer)
                    ELSE NULL::date
                END) AS end_date_plan,
            sum(
                CASE
                    WHEN ((mu.code)::text = 'MTK'::text) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume
           FROM ((((((((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
             LEFT JOIN msnow.fdc_measure_unit mu ON ((swt.measure_unit_id = mu.id)))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((ajrn.driveway_segment_id = sagre.driveway_segment_id) AND (ajrn.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_work_schedule sch ON ((sagre.driveway_segment_id = sch.driveway_segment_id)))
             LEFT JOIN e ON ((sagre.driveway_segment_id = e.driveway_segment_id)))
             LEFT JOIN f ON ((sagre.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((sagre.driveway_segment_id = b.driveway_segment_id)))
          WHERE swt.is_asphalt
          GROUP BY sagr.agr_root_id, sagre.driveway_segment_id
        ), cdt AS (
         SELECT (date_part('YEAR'::text, t.cd))::integer AS year,
            (date_trunc('week'::text, (t.cd)::timestamp with time zone))::date AS this_week_from,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 6) AS this_week_to,
            t.cd AS "current_date",
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 7) AS next_week_from,
            ((date_trunc('week'::text, (t.cd)::timestamp with time zone))::date + 13) AS next_week_to
           FROM ( SELECT ('now'::text)::date AS cd) t
        ), ingrs AS (
         SELECT irg.driveway_segment_id,
            count(irg.id) AS reg_qty
           FROM (msnow.fdc_ingress_registration irg
             JOIN cdt ON (true))
          WHERE ((irg.registration_date)::date = cdt."current_date")
          GROUP BY irg.driveway_segment_id
        ), asphjrn AS (
         SELECT ajrn.driveway_segment_id,
            sum(
                CASE
                    WHEN ((mu.code)::text = 'MTK'::text) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_work_volume,
            sum(
                CASE
                    WHEN ((ajrn.work_date = ('now'::text)::date) AND ((mu.code)::text = 'MTK'::text)) THEN (ajrn.work_volume / (1000.0)::double precision)
                    ELSE NULL::double precision
                END) AS mtk_today_work_volume
           FROM ((msnow.fdc_asphalt_journal ajrn
             JOIN msnow.fdc_work_type swt ON ((ajrn.work_type_id = swt.id)))
             JOIN msnow.fdc_measure_unit mu ON ((swt.measure_unit_id = mu.id)))
          GROUP BY ajrn.driveway_segment_id
        )
 SELECT dwct.code AS driveway_category,
    dwct.id AS driveway_category_id,
    dtl.driveway_segment_id,
    dtl.driveway_segment_volume,
    dtl.closed_works_id,
    dtl.mtk_work_volume,
    dtl.inwork_year_id,
    dtl.inwork_year_volume,
    dtl.clplan_id,
    dtl.clplan_work_volume,
    dtl.finished_fact_id,
    dtl.finished_fact_volume,
    dtl.inwork_year_plan_id,
    dtl.inwork_year_plan_volume,
    dtl.in_work_id,
    dtl.in_work_volume,
    dtl.planned_start_id,
    dtl.planned_start_volume,
    dtl.planned_finish_id,
    dtl.planned_finish_volume,
    dtl.driveway_segment_id AS id
   FROM (msnow.fdc_driveway_category dwct
     LEFT JOIN ( SELECT dwc.id AS driveway_category_id,
            dws.id AS driveway_segment_id,
            dws.asphalt_area AS driveway_segment_volume,
                CASE
                    WHEN (wclosed.driveway_segment_id IS NOT NULL) THEN dws.id
                    ELSE NULL::bigint
                END AS closed_works_id,
            wclosed.mtk_work_volume,
                CASE
                    WHEN ((wsch.start_date_fact <= cdt."current_date") AND (wsch.end_date_fact IS NULL)) THEN dws.id
                    ELSE NULL::bigint
                END AS inwork_year_id,
                CASE
                    WHEN ((wsch.start_date_fact <= cdt."current_date") AND (wsch.end_date_fact IS NULL)) THEN asphjrn.mtk_work_volume
                    ELSE NULL::double precision
                END AS inwork_year_volume,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.this_week_from) AND (clplan.end_date_plan <= cdt.this_week_to)) THEN dws.id
                    ELSE NULL::bigint
                END AS clplan_id,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.this_week_from) AND (clplan.end_date_plan <= cdt.this_week_to)) THEN asphjrn.mtk_work_volume
                    ELSE NULL::double precision
                END AS clplan_work_volume,
                CASE
                    WHEN ((wclosed.max_work_date >= cdt.this_week_from) AND (wclosed.max_work_date <= cdt.this_week_to)) THEN dws.id
                    ELSE NULL::bigint
                END AS finished_fact_id,
                CASE
                    WHEN ((wclosed.max_work_date >= cdt.this_week_from) AND (wclosed.max_work_date <= cdt.this_week_to)) THEN wclosed.mtk_work_volume
                    ELSE NULL::double precision
                END AS finished_fact_volume,
                CASE
                    WHEN ((cdt."current_date" >= wsch.start_date_plan) AND (cdt."current_date" <= wsch.end_date_plan)) THEN dws.id
                    ELSE NULL::bigint
                END AS inwork_year_plan_id,
                CASE
                    WHEN ((cdt."current_date" >= wsch.start_date_plan) AND (cdt."current_date" <= wsch.end_date_plan)) THEN (dws.asphalt_area / (1000.0)::double precision)
                    ELSE NULL::double precision
                END AS inwork_year_plan_volume,
                CASE
                    WHEN (ingrs.reg_qty > 0) THEN dws.id
                    ELSE NULL::bigint
                END AS in_work_id,
                CASE
                    WHEN (ingrs.reg_qty > 0) THEN asphjrn.mtk_today_work_volume
                    ELSE NULL::double precision
                END AS in_work_volume,
                CASE
                    WHEN ((wsch.start_date_plan >= cdt.next_week_from) AND (wsch.start_date_plan <= cdt.next_week_to)) THEN dws.id
                    ELSE NULL::bigint
                END AS planned_start_id,
                CASE
                    WHEN ((wsch.start_date_plan >= cdt.next_week_from) AND (wsch.start_date_plan <= cdt.next_week_to)) THEN dws.asphalt_area
                    ELSE NULL::double precision
                END AS planned_start_volume,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.next_week_from) AND (clplan.end_date_plan <= cdt.next_week_to)) THEN dws.id
                    ELSE NULL::bigint
                END AS planned_finish_id,
                CASE
                    WHEN ((clplan.end_date_plan >= cdt.next_week_from) AND (clplan.end_date_plan <= cdt.next_week_to)) THEN asphjrn.mtk_work_volume
                    ELSE NULL::double precision
                END AS planned_finish_volume
           FROM ((((((((((((msnow.fdc_segment s
             JOIN msnow.fdc_driveway_segment dws ON ((s.id = dws.id)))
             JOIN fdc_driveway dw ON ((dws.driveway_id = dw.id)))
             JOIN fdc_object dwobj ON ((dw.id = dwobj.id)))
             JOIN msnow.fdc_driveway_category dwc ON ((dwobj.driveway_category_id = dwc.id)))
             JOIN msnow.fdc_work_schedule wsch ON ((dws.id = wsch.driveway_segment_id)))
             JOIN msnow.fdc_dw_segment_status dwss ON ((dws.status_id = dwss.id)))
             JOIN cdt ON (true))
             LEFT JOIN asphjrn ON ((dws.id = asphjrn.driveway_segment_id)))
             LEFT JOIN msnow.fdc_agreement agr ON ((dws.agreement_id = agr.id)))
             LEFT JOIN wclosed ON (((agr.agr_root_id = wclosed.agr_root_id) AND (dws.id = wclosed.driveway_segment_id))))
             LEFT JOIN dates clplan ON (((agr.agr_root_id = clplan.agr_root_id) AND (dws.id = clplan.driveway_segment_id))))
             LEFT JOIN ingrs ON ((dws.id = ingrs.driveway_segment_id)))
          WHERE (((date_part('year'::text, wsch.start_date_plan))::integer = cdt.year) AND (wsch.start_date_plan IS NOT NULL) AND (wsch.end_date_plan IS NOT NULL) AND ((dwss.code)::text <> ALL ((ARRAY['FUTURE_PLANNED'::character varying, 'ON_VOTE'::character varying, 'ESTIMATED_RESULT'::character varying])::text[])))) dtl ON ((dwct.id = dtl.driveway_category_id)));

COMMENT ON VIEW rep_repair_workflow_status_weekly_fv IS 'Отчет "Сведения о ходе работ по ремонту за неделю" без агрегации';

