CREATE FUNCTION rep_titlelist_apprhold_summary(p_driveway_category_id bigint, p_work_category_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, OUT title_id bigint, OUT title_name character varying, OUT work_category_name character varying, OUT title_type_name character varying, OUT customer_short_name character varying, OUT holder_fio character varying, OUT holder_org_name character varying, OUT holder_occupation character varying, OUT date_plan date, OUT date_fact date, OUT expiration_days integer)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт "Сводка по согласованию Титульных списков на <текущая дата>" в разрезе заказчиков

  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_work_category_id      - Категория ТС (Ид категории работ)
  %param p_customer_id           - Заказчик (Ид актуальной на начало выбранного года версии заказчика)

  %return title_id            - Ид ТС
  %return title_name          - Наименование ТС
  %return work_category_name  - Категория ТС
  %return title_type_name     - Тип списка
  %return customer_short_name - Заказчик
  %return holder_fio          - ФИО задерживающего согласование
  %return holder_org_name     - Организация задерживающего согласование
  %return holder_occupation   - Должность задерживающего согласование
  %return date_plan           - Планируемая дата согласования
  %return date_fact           - Фактическая дата согласования
  %return expiration_days     - Дней просрочки

  */
  l_summary_date date;
begin
  l_summary_date :=current_date;

  return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as title_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='TS'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,tlist as(select tl.id as title_id
                          ,tl.name as title_name
                          ,tlwc.name as work_category_name
                          ,tltp.name as title_type_name
                          ,tlcust.customer_short_name
                          ,mi.approval_iteration_id
                          ,tls.code as title_status_code
                      from maxiter mi
                      join ods.fdc_title tl on mi.title_id=tl.id
                      join ods.fdc_title_status tls on tl.title_status_id=tls.id
                      join rcust tlcust on tl.customer_id=tlcust.customer_id

                      left join msnow.fdc_work_category tlwc on tl.work_category_id=tlwc.id
                      left join ods.fdc_title_type tltp on tl.title_type_id=tltp.id
                     where (p_work_category_id is null or tl.work_category_id=p_work_category_id)
                   )
          ,tlwflow as(select tlist.title_id
                            ,tlist.title_name
                            ,tlist.work_category_name
                            ,tlist.title_type_name
                            ,tlist.customer_short_name
                            ,awf.date_plan
                            ,awf.date_fact
                            ,l_summary_date - awf.date_plan as expiration_days
                            ,coalesce(awf.official_id::text
                                     ,(select string_agg(u.id::text,';')
                                         from secr.fdc_user_md u
                                        where u.responsible_for_approve
                                          and coalesce(u.person_id,-1) = coalesce(awfo.root_id,-1)
                                          --and coalesce(u.division_id,-1) = coalesce(awfd.root_id,-1)
                                          --and coalesce(u.occupation_id,-1) = coalesce(awf.occupation_id,-1)
                                          --limit 1--на всякий случай
                                      )
                                     ) as holder_user_id
                        from tlist
                        join ods.fdc_approval_workflow awf on tlist.approval_iteration_id=awf.approval_iteration_id
                        join ods.fdc_approval_status ast on awf.approval_status_id=ast.id

                        left join nsi.fdc_legal_person awfo on awf.organization_id=awfo.id
                        left join nsi.fdc_legal_person awfd on awf.division_id=awfd.id
                       where ast.code = 'SENT'
                         and tlist.title_status_code='ON_APPROVAL'
                         and(awf.is_obligatory or
                              (awf.date_fact is not null and exists(select null
                                                                      from ods.fdc_approval_temp_part atp
                                                                      join ods.fdc_approval_temp_stage ats on atp.approval_temp_stage_id=ats.id
                                                                     where atp.id=awf.approval_template_detail_id
                                                                       and ats.rule_stage=2
                                                                   )
                              )
                            )
                         and awf.date_plan < l_summary_date
                     )
                     ,holder_user_list as (SELECT unnest(string_to_array(tlwflow.holder_user_id,';'))::bigint as holder_user_id,
                                                  tlwflow.title_id
                                             FROM tlwflow)

           select twf.title_id
                 ,twf.title_name
                 ,twf.work_category_name
                 ,twf.title_type_name
                 ,twf.customer_short_name
                 ,(hu.family||case
                                when hu.first_name is not null then ' '||hu.first_name
                                else ''
                              end||case
                                     when hu.second_name is not null then ' '||hu.second_name
                                     else ''
                                   end
                  )::varchar as holder_fio
                 ,huorg.short_name as holder_org_name
                 ,ocp.name as holder_occupation
                 ,twf.date_plan
                 ,twf.date_fact
                 ,twf.expiration_days
             from tlwflow twf
             left join holder_user_list hul on hul.title_id = twf.title_id
             left join secr.fdc_user_md hu on hul.holder_user_id=hu.id
             left join nsi.fdc_legal_person huorg on hu.person_id=huorg.root_id
                                                     and statement_timestamp() between huorg.ver_start_date and huorg.ver_end_date
             left join nsi.fdc_occupation ocp on hu.occupation_id=ocp.id;
  return;
end
$$;

