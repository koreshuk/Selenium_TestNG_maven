CREATE VIEW fdc_competitive_sheet_v AS
  WITH ajws AS (
         SELECT aj.driveway_segment_id,
            aj.work_type_id,
            sum(aj.work_volume) AS work_volume
           FROM (msnow.fdc_asphalt_journal aj
             JOIN msnow.fdc_work_status ws ON ((aj.work_status_id = ws.id)))
          WHERE (((ws.code)::text = 'ACCEPTED'::text) AND (aj.driveway_segment_id IS NOT NULL))
          GROUP BY aj.driveway_segment_id, aj.work_type_id
        ), wexws AS (
         SELECT wex.driveway_segment_id,
            wex.work_type_id,
            sum(wex.work_volume) AS work_volume
           FROM (msnow.fdc_work_execute wex
             JOIN msnow.fdc_work_status ws ON ((wex.work_status_id = ws.id)))
          WHERE (((ws.code)::text = 'ACCEPTED'::text) AND (wex.driveway_segment_id IS NOT NULL))
          GROUP BY wex.driveway_segment_id, wex.work_type_id
        ), dwsa AS (
         SELECT dws.id AS driveway_segment_id,
            dws.agreement_id,
            agre.work_type_id,
            sum(agre.work_volume) AS agreement_work_volume
           FROM (msnow.fdc_driveway_segment dws
             JOIN msnow.fdc_agr_estimate agre ON (((dws.agreement_id = agre.agreement_id) AND (dws.id = agre.driveway_segment_id))))
          GROUP BY dws.id, dws.agreement_id, agre.work_type_id
        )
 SELECT dwsa.driveway_segment_id,
    dwsa.agreement_id,
    dwsa.work_type_id,
    wt.measure_unit_id,
    COALESCE(dwsa.agreement_work_volume, (0)::double precision) AS agreement_work_volume,
    (COALESCE(ajws.work_volume, (0)::double precision) + COALESCE(wexws.work_volume, (0)::double precision)) AS fact_work_volume,
    ((COALESCE(ajws.work_volume, (0)::double precision) + COALESCE(wexws.work_volume, (0)::double precision)) - COALESCE(dwsa.agreement_work_volume, (0)::double precision)) AS diff_work_volume,
    dwsa.driveway_segment_id AS id
   FROM (((dwsa
     JOIN msnow.fdc_work_type wt ON ((dwsa.work_type_id = wt.id)))
     LEFT JOIN ajws ON (((dwsa.driveway_segment_id = ajws.driveway_segment_id) AND (dwsa.work_type_id = ajws.work_type_id))))
     LEFT JOIN wexws ON (((dwsa.driveway_segment_id = wexws.driveway_segment_id) AND (dwsa.work_type_id = wexws.work_type_id))));

COMMENT ON VIEW fdc_competitive_sheet_v IS 'Сравнительная ведомость участков ремонта';

COMMENT ON COLUMN fdc_competitive_sheet_v.driveway_segment_id IS 'Ид участка ремонта';

COMMENT ON COLUMN fdc_competitive_sheet_v.agreement_id IS 'Ид договора';

COMMENT ON COLUMN fdc_competitive_sheet_v.work_type_id IS 'Ид вида работы';

COMMENT ON COLUMN fdc_competitive_sheet_v.measure_unit_id IS 'Ид единицы измерения';

COMMENT ON COLUMN fdc_competitive_sheet_v.agreement_work_volume IS 'Объем работы по контракту';

COMMENT ON COLUMN fdc_competitive_sheet_v.fact_work_volume IS 'Фактически выполненный объем работы';

COMMENT ON COLUMN fdc_competitive_sheet_v.diff_work_volume IS 'Разница';

