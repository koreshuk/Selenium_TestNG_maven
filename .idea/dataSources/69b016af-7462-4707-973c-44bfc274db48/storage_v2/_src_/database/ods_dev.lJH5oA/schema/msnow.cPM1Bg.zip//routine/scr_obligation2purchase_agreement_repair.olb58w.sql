CREATE FUNCTION scr_obligation2purchase_agreement_repair(p_obligation_id bigint, p_agreement_id bigint DEFAULT NULL::bigint, p_purchase_id bigint DEFAULT NULL::bigint, p_driveway_list text DEFAULT NULL::text)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /* Скрипт по переносу участков ремонта и смет из бюджета в закупку или обязательство
  %param p_obligation_id - Ид бюджета
  %param p_agreement_id  - Ид обязательства
  %param p_purchase_id   - Ид закупки
  %param p_driveway_list - Список участков ремонта из бюджета
  */
  l_obligation_id msnow.fdc_obligation.id%type;

  l_agreement_id msnow.fdc_agreement.id%type;
  l_agreement_type_code msnow.fdc_agreement_type.code%type;
  l_agreement_work_date_from msnow.fdc_agreement.work_date_from%type;

  l_purchase_work_date_from msnow.fdc_purchase.work_date_from%type;

  l_purchase_id msnow.fdc_purchase.id%type;

  l_driveway_list bigint[];

  l_obligation_object_qty integer;
  l_copy_all boolean;

  rec record;
begin
  if p_driveway_list is not null then
    begin
      l_driveway_list:=string_to_array(p_driveway_list,',');
    exception
      when others then
        raise exception 'Некорректный формат списка идентификаторов участков ремонта.';
    end;
  end if;

  if p_obligation_id is null then
    raise exception 'Не указан Ид бюджета (p_obligation_id).';
  else
    begin
      select id
        into strict l_obligation_id
        from msnow.fdc_obligation
       where id=p_obligation_id;
    exception
      when NO_DATA_FOUND then
        raise exception 'Не найдено бюджетное обязательство с идентификатором %',p_obligation_id;
    end;
  end if;

  if p_agreement_id is null and p_purchase_id is null then
    raise exception 'Необходимо указать хотя бы один из параметров Ид закупки(p_purchase_id) / Ид обязательства(p_agreement_id).';
  end if;

  select count(distinct driveway_segment_id)
    into l_obligation_object_qty
    from msnow.fdc_obligation_object
   where obligation_id=l_obligation_id;

  l_copy_all:=case
                when p_driveway_list is null then true
                when l_obligation_object_qty = cardinality(l_driveway_list) then true
                else false
              end;

  if p_purchase_id is not null then
    begin
      select id
            ,work_date_from
        into strict l_purchase_id
            ,l_purchase_work_date_from
        from msnow.fdc_purchase
       where id=p_purchase_id;
    exception
      when NO_DATA_FOUND then
        raise exception 'Не найдена закупка с идентификатором %',p_purchase_id;
    end;
    delete from msnow.fdc_purchase_estimate where purchase_lot_id=l_purchase_id;
    delete from msnow.fdc_purchase_object where purchase_lot_id=l_purchase_id;

    -- копируем участки
    insert into msnow.fdc_purchase_object(id,purchase_lot_id,driveway_segment_id)
      select nextval('ods.fdc_common_seq')
            ,l_purchase_id
            ,oo.driveway_segment_id
        from msnow.fdc_obligation_object oo
       where oo.obligation_id=l_obligation_id
         and(l_copy_all or oo.driveway_segment_id in(select unnest(l_driveway_list)));

    -- копируем все сметы на уровне участка:
    insert into msnow.fdc_purchase_estimate(id,purchase_lot_id,driveway_segment_id,work_type_id,work_volume
                                           ,measure_unit_id,work_cost,is_estimate_sum,odh_group_id)
      select nextval('ods.fdc_common_seq')
            ,l_purchase_id
            ,oe.driveway_segment_id
            ,oe.work_type_id
            ,oe.work_volume
            ,oe.measure_unit_id
            ,oe.work_cost
            ,oe.is_estimate_sum
            ,oe.odh_group_id
        from msnow.fdc_obligation_estimate oe
       where oe.obligation_id=l_obligation_id
         and not oe.is_estimate_sum
         and ((l_copy_all and oe.driveway_segment_id is not null) or
              ((not l_copy_all) and oe.driveway_segment_id in(select unnest(l_driveway_list)))
             );

    -- вычисляем сводные сметы
    insert into msnow.fdc_purchase_estimate(id,purchase_lot_id,work_type_id
                                           ,measure_unit_id,work_volume,work_cost,is_estimate_sum)
      select nextval('ods.fdc_common_seq')
            ,pe.purchase_lot_id
            ,pe.work_type_id
            ,wt.measure_unit_id
            ,round(sum(pe.work_volume)::numeric,3) work_volume
            ,round(sum(pe.work_cost)::numeric,2) work_cost
            ,true
        from msnow.fdc_purchase_estimate pe
        join msnow.fdc_work_type wt on pe.work_type_id=wt.id
       where pe.purchase_lot_id=l_purchase_id
         and pe.driveway_segment_id is not null
         and not pe.is_estimate_sum
       group by pe.purchase_lot_id
               ,pe.work_type_id
               ,wt.measure_unit_id;
  end if;

  if p_agreement_id is not null then
    begin
      select agr.id
            ,agrt.code
            ,agr.work_date_from
        into strict l_agreement_id
            ,l_agreement_type_code
            ,l_agreement_work_date_from
        from msnow.fdc_agreement agr
        join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
       where agr.id=p_agreement_id;
    exception
      when NO_DATA_FOUND then
        raise exception 'Не найдено обязательство с идентификатором %',p_agreement_id;
    end;

    if l_agreement_type_code not in('STATE_ASSIGN','MUNICIPAL_ASSIGN') then
      raise exception 'Недопустимый тип обязательства %',l_agreement_type_code;
    end if;

    delete from msnow.fdc_agr_estimate where agreement_id=l_agreement_id;
    delete from msnow.fdc_agreement_object where argeement_id=l_agreement_id;

    -- копируем участки
    update msnow.fdc_driveway_segment
       set agreement_id=l_agreement_id
     where id in(select distinct oo.driveway_segment_id
                   from msnow.fdc_obligation_object oo
                  where oo.obligation_id=l_obligation_id
                    and(l_copy_all or oo.driveway_segment_id in(select unnest(l_driveway_list)))
                );

    insert into msnow.fdc_agreement_object(id,argeement_id,driveway_segment_id)
      select nextval('ods.fdc_common_seq')
            ,l_agreement_id
            ,oo.driveway_segment_id
        from msnow.fdc_obligation_object oo
       where oo.obligation_id=l_obligation_id
         and(l_copy_all or oo.driveway_segment_id in(select unnest(l_driveway_list)));

    -- копируем все сметы на уровне участка:
    insert into msnow.fdc_agr_estimate(id,agreement_id,driveway_segment_id,work_type_id,work_volume
                                      ,measure_unit_id,work_cost,is_estimate_sum,odh_group_id)
      select nextval('ods.fdc_common_seq')
            ,l_agreement_id
            ,oe.driveway_segment_id
            ,oe.work_type_id
            ,oe.work_volume
            ,oe.measure_unit_id
            ,oe.work_cost
            ,oe.is_estimate_sum
            ,oe.odh_group_id
        from msnow.fdc_obligation_estimate oe
       where oe.obligation_id=l_obligation_id
         and not oe.is_estimate_sum
         and ((l_copy_all and oe.driveway_segment_id is not null) or
              ((not l_copy_all) and oe.driveway_segment_id in(select unnest(l_driveway_list)))
             );

    -- вычисляем сводные сметы
    insert into msnow.fdc_agr_estimate(id,agreement_id,work_type_id
                                       ,measure_unit_id,work_volume,work_cost,is_estimate_sum)
      select nextval('ods.fdc_common_seq')
            ,oe.agreement_id
            ,oe.work_type_id
            ,wt.measure_unit_id
            ,round(sum(oe.work_volume)::numeric,3) work_volume
            ,round(sum(oe.work_cost)::numeric,2) work_cost
            ,true
        from msnow.fdc_agr_estimate oe
        join msnow.fdc_work_type wt on oe.work_type_id=wt.id
       where oe.agreement_id=l_agreement_id
         and oe.driveway_segment_id is not null
         and not oe.is_estimate_sum
       group by oe.agreement_id
               ,oe.work_type_id
               ,wt.measure_unit_id;
  end if;
end
$$;

