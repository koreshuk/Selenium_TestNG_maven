CREATE FUNCTION fdc_object_pck_check_geometry_area(p_area double precision, p_geometry geometry)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /*
    Сравнивает площадь объекта и площадь геометрию.
    Генерирует ошибку, если разница превышает допустимый максимум
  */
  l_geometry_area double precision;
  l_delta_percent double precision;
  l_max_delta_percent double precision;
begin
  l_geometry_area:=st_area(p_geometry);
  if least(p_area,l_geometry_area)>0 then
    l_delta_percent := abs(p_area - l_geometry_area)/least(p_area, l_geometry_area)*100;
    l_max_delta_percent :=parameter.fdc_parameter_pck_get_param('MAX_GEOMETRY_DELTA_PERCENT');
    if l_delta_percent > l_max_delta_percent then
      raise exception 'Указанная площадь объекта % м. кв не соответствует рассчитаной по геометрии %',p_area,l_geometry_area;
    end if;
  end if;
end
$$;

