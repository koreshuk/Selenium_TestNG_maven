CREATE VIEW fdc_nsi_bti_address_v AS
  SELECT NULL::bigint AS id,
    NULL::bigint AS location_id,
    NULL::bigint AS street_id,
    NULL::character varying(255) AS street_name,
    NULL::bigint AS district_id,
    NULL::bigint AS district_name,
    NULL::character varying(4) AS district_code,
    NULL::bigint AS okrug_id,
    NULL::character varying(4) AS okrug_code,
    NULL::character varying(255) AS okrug_name,
    NULL::character varying(255) AS okrug_short_name,
    NULL::character varying(255) AS name,
    NULL::character varying(255) AS short_name,
    NULL::character varying(1024) AS address_name,
    NULL::boolean AS is_actual;

COMMENT ON VIEW fdc_nsi_bti_address_v IS 'БТИ. Классификатор адресов';

COMMENT ON COLUMN fdc_nsi_bti_address_v.id IS 'ИД адреса';

COMMENT ON COLUMN fdc_nsi_bti_address_v.location_id IS 'ИД расположения улицы';

COMMENT ON COLUMN fdc_nsi_bti_address_v.street_id IS 'ИД улицы';

COMMENT ON COLUMN fdc_nsi_bti_address_v.street_name IS 'Наименование улицы';

COMMENT ON COLUMN fdc_nsi_bti_address_v.district_id IS 'ИД района';

COMMENT ON COLUMN fdc_nsi_bti_address_v.district_name IS 'Наименование района';

COMMENT ON COLUMN fdc_nsi_bti_address_v.district_code IS 'Код района';

COMMENT ON COLUMN fdc_nsi_bti_address_v.okrug_id IS 'ИД округа';

COMMENT ON COLUMN fdc_nsi_bti_address_v.okrug_code IS 'Код округа';

COMMENT ON COLUMN fdc_nsi_bti_address_v.okrug_name IS 'Наименование округа';

COMMENT ON COLUMN fdc_nsi_bti_address_v.okrug_short_name IS 'Краткое наименование округа';

COMMENT ON COLUMN fdc_nsi_bti_address_v.name IS 'Наименование адреса';

COMMENT ON COLUMN fdc_nsi_bti_address_v.short_name IS 'Краткое наименование адреса';

COMMENT ON COLUMN fdc_nsi_bti_address_v.address_name IS 'Наименование адреса';

COMMENT ON COLUMN fdc_nsi_bti_address_v.is_actual IS 'Признак актуальности: 0 - нет; 1 - да';

