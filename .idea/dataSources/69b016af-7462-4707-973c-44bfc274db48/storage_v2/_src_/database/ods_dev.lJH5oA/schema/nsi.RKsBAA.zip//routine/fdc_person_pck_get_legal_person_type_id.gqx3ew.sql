CREATE FUNCTION fdc_person_pck_get_legal_person_type_id(p_event_id bigint, p_is_ip boolean DEFAULT false, p_is_filial boolean DEFAULT false)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
begin
  if p_is_filial is null then
    raise exception 'Не указан Признак филиала';
    --fdc_event_pck.error_handler(p_event_id => p_event_id, p_err_code => -20100, p_err_params => 'Признак филиала',p_err_raise=>fdc_event_pck.c_err_finish);
  end if;
  if p_is_IP is null then
    raise exception 'Не указан признак ИП';
    --fdc_event_pck.error_handler(p_event_id => p_event_id, p_err_code => -20100, p_err_params => 'Признак ИП',p_err_raise=>fdc_event_pck.c_err_finish);
  end if;
  if p_is_IP and p_is_filial then
    raise exception 'ЮЛ не может быть одновременно ИП и филиалом.';
  end if;

  return case
           when p_is_IP then nsi.c_sl_declarant()
           when p_is_filial then nsi.c_sl_branch()
           else nsi.c_sl_organization()
         end;
end
$$;

