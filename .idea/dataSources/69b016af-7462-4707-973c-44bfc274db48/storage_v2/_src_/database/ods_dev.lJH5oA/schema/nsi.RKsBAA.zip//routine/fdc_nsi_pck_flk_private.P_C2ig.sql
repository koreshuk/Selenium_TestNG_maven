CREATE FUNCTION fdc_nsi_pck_flk_private(p_person_type_id bigint, p_root_id bigint, p_last_name character varying, p_first_name character varying, p_patronymic character varying, p_occupation character varying, p_inn character varying, p_snils character varying, p_email character varying, p_parent_id bigint, p_identity_doctype_id bigint, p_docseries character varying, p_docnumber character varying, p_issue_date date, p_issue_department character varying, p_department_code character varying, p_check_inn boolean DEFAULT true, p_occupation_id bigint DEFAULT NULL::bigint, p_event_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Процедура проводит проверку ФКЛ физических лиц
  %param p_event_id        - ID события
  %param p_person_type_id  - Ид типа субъекта
  %param p_root_id         - Ид организации
  %param p_last_name       - Фамилия
  %param p_first_name      - Имя
  %param p_patronymic      - Отчество
  %param p_occupation      - Должность
  %param p_inn             - ИНН
  %param p_snils           - СНИЛС
  %param p_email           - Адрес эклектронной почты
  %param p_parent_id       - Ид организации
  %param p_identity_doctype_id - Тип документа
  %param p_docseries           - Серия
  %param p_docnumber           - номер
  %param p_issue_date          - Дата выдачи
  %param p_issue_department    - подразделение
  %param p_department_code     - код подразделения
  %param p_check_inn           - Признак проверки ИНН (1 - проверять, 0 - нет (для ГИБДД))
  %param p_occupation_id       - Ид должности
  */
  l_exists       integer;
begin
  -- Проверки на обязательность
  -- общие
  if p_last_name is null then
    raise exception 'Поле Фамилия обязательно для заполнения';
  end if;
  if p_first_name is null then
    raise exception 'Поле Имя обязательно для заполнения';
  end if;
  if p_patronymic is null then
    raise exception 'Поле Отчество обязательно для заполнения';
  end if;
  -- по типам
  if p_person_type_id is null then
    raise exception 'Поле Тип субъекта обязательно для заполнения';
  elsif p_person_type_id = nsi.c_sl_employee() then
  -- Должн.Л
    if p_parent_id is null then
      raise exception 'Поле Наименование организации обязательно для заполнения';
    end if;
    if (p_occupation_id is null and p_occupation is null) then
      raise exception 'Поле Должность обязательно для заполнения';
    end if;
  elsif p_person_type_id = nsi.c_sl_private() then
    -- Физ.Л
    if p_check_inn and p_inn is null and p_docnumber is null then
      raise exception 'Поле ИНН или Номер документа обязательно для заполнения';
    end if;
    --
  end if;

  -- Проверки на корректность полей Документа
  perform nsi.fdc_nsi_pck_ch_iddoc(p_event_id            => p_event_id
                                 , p_root_id             => p_root_id
                                 , p_identity_doctype_id => p_identity_doctype_id
                                 , p_docseries           => p_docseries
                                 , p_docnumber           => p_docnumber
                                 , p_issue_date          => p_issue_date
                                 , p_issue_department    => p_issue_department
                                 , p_department_code     => p_department_code
                                  );

  -- Другие проверки на корректность
  if p_inn is not null and not nsi.fdc_nsi_pck_is_inn_correct(p_inn            => p_inn
                                                            , p_event_id       => p_event_id
                                                            , p_person_type_id => nsi.c_sl_private()
                                                            --, p_err_raise => fdc_event_pck.c_err_finish
                                                             ) then
     null;--fdc_event_pck.error_handler(p_event_id => l_event_id, p_err_code => -20132, p_source_id => null,p_err_raise=>fdc_event_pck.c_err_finish);
  end if;
  if p_snils is not null and not nsi.fdc_nsi_pck_is_snils_correct(p_snils    => p_snils
                                                                , p_event_id => p_event_id
                                                                --, fdc_event_pck.c_err_finish
                                                                 ) then
    null;--fdc_event_pck.error_handler(p_event_id => p_event_id, p_err_code => -20155, p_source_id => null,p_err_raise=>fdc_event_pck.c_err_finish);
  end if;
  if p_email is not null and not nsi.fdc_nsi_pck_is_email_correct(p_email => p_email) then
    --fdc_event_pck.error_handler(p_event_id => p_event_id, p_err_code => -20138, p_source_id => null,p_err_raise=>fdc_event_pck.c_err_finish);
    raise exception 'Эл. почта не соответствует алгоритму проверки';
  end if;

  -- Уникальность ИНН
  select count(1)
    into l_exists
    from nsi.fdc_person_version_v lp
    where lp.person_type_id in (nsi.c_sl_private(), nsi.c_sl_employee())
      and lp.inn = p_inn
      and (lp.root_id <> p_root_id or p_root_id is null)
      and lp.ver_end_date is null;
  if l_exists > 0 then
    raise exception 'Субъект с таким значением «ИНН» уже существует';
  end if;

  -- Уникальность СНИЛС
  select count(1)
    into l_exists
    from nsi.fdc_person_version_v lp
   where /*lp.person_type_id in (const.c_sl_private, const.c_sl_employee)
     and */lp.snils = p_snils
     and (lp.root_id <> p_root_id or p_root_id is null)
     and lp.ver_end_date is null;
  if l_exists > 0 then
    raise exception 'Субъект с таким значением «СНИЛС» уже существует';
  end if;
end
$$;

