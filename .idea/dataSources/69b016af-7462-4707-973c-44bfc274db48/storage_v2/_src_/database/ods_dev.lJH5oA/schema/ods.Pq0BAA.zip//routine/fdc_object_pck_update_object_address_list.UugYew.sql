CREATE FUNCTION fdc_object_pck_update_object_address_list(p_object t_object, p_object_address_tab t_object_address[])
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Процедура обновления адресов
  %param     p_object_id              ИД Объекта
  %param     p_object_address_tab   Список адресов
  */
begin
  delete from ods.fdc_object_address
   where object_id = p_object.id
     and address_id not in (select t.address_id
                              from unnest(p_object_address_tab) t
                             where t.address_id is not null
                           );

  insert into ods.fdc_object_address(id,object_id,address_detail,address_id)
    select nextval('ods.fdc_object_address_seq') id
          ,p_object.id object_id
          ,s.address_detail
          ,s.address_id
      from unnest(p_object_address_tab) s
    on conflict(object_id,address_id) do update set address_detail=excluded.address_detail;

  return p_object.id;
end;
$$;

