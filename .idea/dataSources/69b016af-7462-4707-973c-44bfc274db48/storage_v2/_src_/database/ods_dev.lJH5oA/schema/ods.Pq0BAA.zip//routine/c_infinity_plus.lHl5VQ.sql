CREATE FUNCTION c_infinity_plus()
  RETURNS timestamp without time zone
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select to_date('01.01.3000','dd.mm.yyyy')::timestamp;
$$;

