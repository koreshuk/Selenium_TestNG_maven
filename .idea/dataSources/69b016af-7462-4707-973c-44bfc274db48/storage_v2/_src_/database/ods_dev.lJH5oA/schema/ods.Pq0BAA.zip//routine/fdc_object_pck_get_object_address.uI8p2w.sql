CREATE FUNCTION fdc_object_pck_get_object_address(p_object_id bigint)
  RETURNS SETOF t_object_address
LANGUAGE plpgsql
AS $$
declare
  /*Получить Адреса объекта ОДТИ
  %param      p_object_id    ИД версии объекта
  %return     Адреса объекта ОДТИ
  */
begin
  return query select a.address_id
                     ,a.address_detail
                 from ods.fdc_object_address a
                where a.object_id = p_object_id;

  return;
end
$$;

