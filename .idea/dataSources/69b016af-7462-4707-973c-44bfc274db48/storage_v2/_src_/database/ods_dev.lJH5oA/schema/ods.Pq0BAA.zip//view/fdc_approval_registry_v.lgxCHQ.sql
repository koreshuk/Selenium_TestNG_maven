CREATE VIEW fdc_approval_registry_v AS
  WITH odh AS (
         SELECT odh_1.id AS object_id,
            obj.name AS object_name,
            obj.object_state_id AS object_status_id,
            objs.code AS object_status_code,
            objs.name AS object_status_name,
            obj.owner_id,
            onr.name AS owner_name,
            obj.customer_id,
            cust.name AS customer_name,
            obj.reason_type_id,
            condo.name AS reason_type_name,
            obj.as_area_id AS fias_district_id,
            (farea.ao_guid)::text AS fias_district_ao_guid,
            obj.as_place_id AS fias_place_id,
            (fplace.ao_guid)::text AS fias_place_ao_guid,
            'ОДХ'::text AS object_type_name
           FROM (((((((fdc_odh odh_1
             JOIN fdc_object obj ON ((odh_1.id = obj.id)))
             JOIN fdc_object_state objs ON ((obj.object_state_id = objs.id)))
             LEFT JOIN nsi.fdc_legal_person onr ON ((obj.owner_id = onr.id)))
             LEFT JOIN nsi.fdc_legal_person cust ON ((obj.customer_id = cust.id)))
             LEFT JOIN fdc_condition_obligatory condo ON ((obj.reason_type_id = condo.id)))
             LEFT JOIN fdc_as_addrobj farea ON ((obj.as_area_id = farea.id)))
             LEFT JOIN fdc_as_addrobj fplace ON ((obj.as_place_id = fplace.id)))
        ), ttl AS (
         SELECT t.id AS title_id,
            t.name AS title_name,
            t.title_status_id,
            ts.code AS title_status_code,
            ts.name AS title_status_name,
            t.customer_id,
            cust.name AS customer_name,
            t.title_reason_type_id AS reason_type_id,
            condo.name AS reason_type_name,
            NULL::text AS object_type_name
           FROM (((fdc_title t
             JOIN fdc_title_status ts ON ((t.title_status_id = ts.id)))
             LEFT JOIN nsi.fdc_legal_person cust ON ((t.customer_id = cust.id)))
             LEFT JOIN fdc_condition_obligatory condo ON ((t.title_reason_type_id = condo.id)))
        ), agr AS (
         SELECT a.id AS agreement_id,
            a.name AS agreement_name,
            a.agreement_status_id,
            aos.code AS agreement_status_code,
            aos.name AS agreement_status_name,
            a.customer_id,
            cust.name AS customer_name,
            a.reason_type_id,
            condo.name AS reason_type_name,
            NULL::text AS object_type_name
           FROM (((msnow.fdc_agreement a
             JOIN msnow.fdc_agreement_obligation_status aos ON ((aos.id = a.agreement_status_id)))
             LEFT JOIN nsi.fdc_legal_person cust ON (((a.customer_id = cust.root_id) AND ((statement_timestamp() >= cust.ver_start_date) AND (statement_timestamp() <= cust.ver_end_date)))))
             LEFT JOIN fdc_condition_obligatory condo ON ((a.reason_type_id = condo.id)))
        ), obl AS (
         SELECT o.id AS obligation_id,
            (((((((o.obligation_year)::text || ' '::text) || (org.name)::text) || ': '::text) || (wc.name)::text) || ' '::text) || ((o.work_cost)::character varying)::text) AS obligation_name,
            o.obligation_status_id,
            aost.code AS obligation_status_code,
            aost.name AS obligation_status_name,
            o.authority_org_id AS customer_id,
            org.name AS customer_name,
            NULL::text AS object_type_name
           FROM (((msnow.fdc_obligation o
             LEFT JOIN msnow.fdc_agreement_obligation_status aost ON ((o.obligation_status_id = aost.id)))
             LEFT JOIN nsi.fdc_legal_person org ON (((o.authority_org_id = org.root_id) AND ((statement_timestamp() >= org.ver_start_date) AND (statement_timestamp() <= org.ver_end_date)))))
             LEFT JOIN msnow.fdc_work_category wc ON ((o.work_category_id = wc.id)))
        ), aprwf AS (
         SELECT awf.date_plan,
            awf.id,
            awf.approval_iteration_id,
            awf.date_fact,
            awf.comments,
            awf.approval_status_id,
            awf.approval_template_detail_id,
            awf.approval_stage,
            awf.is_obligatory,
            awf.organization_id,
            awf.division_id,
            awf.occupation_id,
            awf.official_id,
            awf.organization_group_id,
            awf.send_by_user_id,
            awf.send_by_person_id,
            org.root_id AS root_organization_id,
            sbp.root_id AS root_send_by_person_id
           FROM (((fdc_approval_workflow awf
             JOIN fdc_approval_status aps ON ((awf.approval_status_id = aps.id)))
             LEFT JOIN nsi.fdc_legal_person org ON ((awf.organization_id = org.id)))
             LEFT JOIN nsi.fdc_legal_person sbp ON ((awf.send_by_person_id = sbp.id)))
          WHERE ((aps.code)::text <> 'PROJECT'::text)
        )
 SELECT
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.object_status_name
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.title_status_name
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.agreement_status_name
            WHEN ((aprtt.code)::text = 'OBLIGATION'::text) THEN obl.obligation_status_name
            ELSE NULL::character varying
        END AS object_status_name,
    aprtt.short_name AS template_type_name,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.object_type_name
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.object_type_name
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.object_type_name
            WHEN ((aprtt.code)::text = 'OBLIGATION'::text) THEN obl.object_type_name
            ELSE NULL::text
        END AS object_type_name,
    apr.main_object_id AS object_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.object_name
            WHEN ((aprtt.code)::text = 'TS'::text) THEN (ttl.title_name)::text
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN (agr.agreement_name)::text
            WHEN ((aprtt.code)::text = 'OBLIGATION'::text) THEN obl.obligation_name
            ELSE NULL::text
        END AS object_name,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.owner_name
            ELSE NULL::character varying
        END AS owner_name,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.customer_name
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.customer_name
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.customer_name
            WHEN ((aprtt.code)::text = 'OBLIGATION'::text) THEN obl.customer_name
            ELSE NULL::character varying
        END AS customer_name,
    aprs.name AS approval_status_name,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.reason_type_name
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.reason_type_name
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.reason_type_name
            ELSE NULL::character varying
        END AS reason_type_name,
    aprwf.date_plan,
    aprwf.date_fact,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.customer_id
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.customer_id
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.customer_id
            WHEN ((aprtt.code)::text = 'OBLIGATION'::text) THEN obl.customer_id
            ELSE NULL::bigint
        END AS customer_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.owner_id
            ELSE NULL::bigint
        END AS owner_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.fias_district_id
            ELSE NULL::bigint
        END AS fias_district_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.fias_place_id
            ELSE NULL::bigint
        END AS fias_place_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.object_status_id
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.title_status_id
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.agreement_status_id
            WHEN ((aprtt.code)::text = 'OBLIGATION'::text) THEN obl.obligation_status_id
            ELSE NULL::bigint
        END AS object_status_id,
    apr.approval_status_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.reason_type_id
            WHEN ((aprtt.code)::text = 'TS'::text) THEN ttl.reason_type_id
            WHEN ((aprtt.code)::text = 'AGREEMENT'::text) THEN agr.reason_type_id
            ELSE NULL::bigint
        END AS reason_type_id,
    apr.id AS approval_id,
    apri.id AS approval_iteration_id,
    aprwf.id,
    aprwf.official_id,
    aprwf.send_by_user_id,
    aprwf.organization_id,
    aprwf.root_organization_id,
    aprwf.send_by_person_id,
    aprwf.root_send_by_person_id,
    aprtt.id AS approval_template_type_id,
    aprwf.approval_status_id AS wf_approval_status_id,
    aprwf.division_id,
    aprwf.occupation_id,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.fias_district_ao_guid
            ELSE NULL::text
        END AS fias_district_ao_guid,
        CASE
            WHEN ((aprtt.code)::text = 'ODH'::text) THEN odh.fias_place_ao_guid
            ELSE NULL::text
        END AS fias_place_ao_guid
   FROM (((((((((fdc_approval apr
     JOIN fdc_approval_status aprs ON ((apr.approval_status_id = aprs.id)))
     JOIN fdc_approval_template aprt ON ((apr.approval_template_id = aprt.id)))
     JOIN fdc_approval_template_type aprtt ON ((aprt.approval_template_type_id = aprtt.id)))
     LEFT JOIN fdc_max_approval_iteration_v apri ON ((apr.id = apri.approval_id)))
     LEFT JOIN aprwf ON ((apri.id = aprwf.approval_iteration_id)))
     LEFT JOIN odh ON ((apr.main_object_id = odh.object_id)))
     LEFT JOIN ttl ON ((apr.main_object_id = ttl.title_id)))
     LEFT JOIN agr ON ((apr.main_object_id = agr.agreement_id)))
     LEFT JOIN obl ON ((apr.main_object_id = obl.obligation_id)));

COMMENT ON VIEW fdc_approval_registry_v IS 'Реестр согласований';

COMMENT ON COLUMN fdc_approval_registry_v.object_status_name IS 'Статус Объекта ОДХ/ТС/Контракта/Бюджета (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.template_type_name IS 'Тип списка (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.object_type_name IS 'Тип объекта (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.object_id IS 'Ид Объекта ОДХ/ТС/Контракта/Бюджета (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.object_name IS 'Наименование Объекта ОДХ/ТС/Контракта/Бюджета (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.owner_name IS 'Наименование балансодержателя (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.customer_name IS 'Наименование заказчика (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.approval_status_name IS 'Состояние согласования (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.reason_type_name IS 'Причина изменения (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.date_plan IS 'Дата план (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.date_fact IS 'Дата факт (для отображения)';

COMMENT ON COLUMN fdc_approval_registry_v.customer_id IS 'Ид заказчика (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.owner_id IS 'Ид балансодержателя (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.fias_district_id IS 'Ид муниципального района (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.fias_place_id IS 'Ид населенного пункта (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.object_status_id IS 'Ид статуса объекта (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.approval_status_id IS 'Ид состояния согласования (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.reason_type_id IS 'Ид причины изменения (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.approval_id IS 'Ид согласования (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.approval_iteration_id IS 'Ид итерации согласования (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.id IS 'Ид хода согласования (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.official_id IS 'Ид согласующего ДЛ (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.send_by_user_id IS 'Ид пользователя передавшего на согласование (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.organization_id IS 'Ид организации согласующего (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.root_organization_id IS 'ROOT Ид организации согласующего (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.send_by_person_id IS 'Ид ЮЛ передавшей на согласование (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.root_send_by_person_id IS 'ROOT Ид ЮЛ передавшей на согласование (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.approval_template_type_id IS 'Ид типа списка (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.fias_district_ao_guid IS 'ГУИД муниципального района (для фильтра)';

COMMENT ON COLUMN fdc_approval_registry_v.fias_place_ao_guid IS 'ГУИД населенного пункта (для фильтра)';

