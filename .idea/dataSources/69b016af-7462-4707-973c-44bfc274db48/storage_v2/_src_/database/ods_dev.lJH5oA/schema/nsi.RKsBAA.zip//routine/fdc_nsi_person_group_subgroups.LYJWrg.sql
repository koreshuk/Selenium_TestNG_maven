CREATE FUNCTION fdc_nsi_person_group_subgroups(p_group_id bigint, OUT id bigint, OUT parent_id bigint, OUT name character varying, OUT date_created date, OUT person_group_purpose_id bigint)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /** Возвращает атрибуты подгрупы группы организации p_group_id.
      Атрибуты самой p_group_id не возвращаются

      %param p_group_id - Ид группы организации

      %return id                        - Ид подчиненной группы
      %return parent_id                 - Ид непосредственного родителя подчиненной группы
      %return name                      - Наименование подчиненной группы
      %return date_created              - Дата создания подчиненной группы
      %return person_group_purpose_id   - Ид назначения подчиненной группы

  */
  rec record;
begin
  for rec in(with recursive h(group_id
                             ,parent_id
                             ,level
                             ) as(select h1.group_id
                                        ,h1.parent_id
                                        ,1
                                    from nsi.fdc_pg_hierarchy_v h1
                                   where h1.group_id=p_group_id
                                  union
                                  select hn.group_id
                                        ,hn.parent_id
                                        ,hn.level+1
                                    from nsi.fdc_pg_hierarchy_v hn
                                    join h on h.group_id=hn.parent_id
                         )
                  select distinct pg.id
                        ,h.parent_id
                        ,pg.name
                        ,pg.date_created
                        ,pg.person_group_purpose_id
                    from h
                    join nsi.fdc_person_group pg on h.group_id=pg.id
                   where h.group_id<>p_group_id
            ) loop
    id:=rec.id;
    parent_id:=rec.parent_id;
    name:=rec.name;
    date_created:=rec.date_created;
    person_group_purpose_id:=rec.person_group_purpose_id;
    return next;
  end loop;
  return;
end
$$;

