CREATE VIEW fdc_object_link_v AS
  SELECT l.id,
    l.object_id_1,
    l.object_id_2,
    l.object_link_rule_id,
    r.link_name_id,
    r.link_type_id,
    n.code AS link_name_code,
    lt1.code AS link_type_code,
    n.name AS link_name,
    lt1.name AS link_type_name,
    lt2.code AS reverse_link_type_code,
    lt2.name AS reverse_link_type_name
   FROM fdc_object_link l,
    fdc_object_link_rule r,
    fdc_link_name n,
    fdc_link_type lt1,
    fdc_link_type lt2
  WHERE ((l.object_link_rule_id = r.id) AND (r.link_name_id = n.id) AND (r.link_type_id = lt1.id) AND (lt1.reverse_link_type_id = lt2.id));

COMMENT ON VIEW fdc_object_link_v IS 'Связь объектов';

COMMENT ON COLUMN fdc_object_link_v.id IS 'Ид связи';

COMMENT ON COLUMN fdc_object_link_v.object_id_1 IS 'Ид родительского объекта';

COMMENT ON COLUMN fdc_object_link_v.object_id_2 IS 'Ид объекта';

COMMENT ON COLUMN fdc_object_link_v.object_link_rule_id IS 'ID сущности Связь';

COMMENT ON COLUMN fdc_object_link_v.link_name_id IS 'Ид Имени связи';

COMMENT ON COLUMN fdc_object_link_v.link_type_id IS 'Ид типа связи';

COMMENT ON COLUMN fdc_object_link_v.link_name_code IS 'Код Имени связи';

COMMENT ON COLUMN fdc_object_link_v.link_type_code IS 'Код типа связи';

COMMENT ON COLUMN fdc_object_link_v.link_name IS 'Наименование Имени связи';

COMMENT ON COLUMN fdc_object_link_v.link_type_name IS 'Наименование типа связи';

COMMENT ON COLUMN fdc_object_link_v.reverse_link_type_code IS 'Код типа обратной(реверсной) связи';

COMMENT ON COLUMN fdc_object_link_v.reverse_link_type_name IS 'Наименование типа обратной(реверсной) связи';

