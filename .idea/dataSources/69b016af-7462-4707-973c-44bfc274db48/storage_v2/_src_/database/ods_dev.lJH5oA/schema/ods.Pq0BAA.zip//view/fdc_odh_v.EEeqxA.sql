CREATE VIEW fdc_odh_v AS
  SELECT t1.bord_begin,
    t1.bord_end,
    t1.category_detail_id_summer,
    t2.code AS category_detail_code_summer,
    t2.name AS category_detail_name_summer,
    t1.category_detail_id_winter,
    t3.code AS category_detail_code_winter,
    t3.name AS category_detail_name_winter,
    t1.category_odh_id,
    t4.code AS category_odh_code,
    t4.name AS category_odh_name,
    t1.clean_category_id,
    t5.code AS clean_category_code,
    t5.name AS clean_category_name,
    t1.clean_subcategory_id,
    t6.code AS clean_subcategory_code,
    t6.name AS clean_subcategory_name,
    t1.distance,
    t1.geometry,
    t1.glonass_no_check,
    t1.id,
    t1.is_include_title_list,
    t1.is_orphan_object,
    t1.name,
    t1.object_group_id,
    t7.code AS object_group_code,
    t7.name AS object_group_name,
    t1.passport_author,
    t1.passport_author_id,
    (((((t8.name)::text || ' '::text) || (t8.short_name)::text) || ' '::text) || (t8.patronymic)::text) AS passport_author_name,
    t8.short_name AS passport_author_short_name,
    t1.passport_date,
    t1.passport_developer_id,
    (((((t9.name)::text || ' '::text) || (t9.short_name)::text) || ' '::text) || (t9.patronymic)::text) AS passport_developer_name,
    t9.short_name AS passport_developer_short_name,
    t1.passport_num,
    t1.register_code,
    t1.register_num
   FROM ((((((((fdc_odh t1
     LEFT JOIN fdc_clean_category_detail t2 ON ((t2.id = t1.category_detail_id_summer)))
     LEFT JOIN fdc_clean_category_detail t3 ON ((t3.id = t1.category_detail_id_winter)))
     LEFT JOIN fdc_category_odh t4 ON ((t4.id = t1.category_odh_id)))
     LEFT JOIN fdc_clean_category t5 ON ((t5.id = t1.clean_category_id)))
     LEFT JOIN fdc_clean_category t6 ON ((t6.id = t1.clean_subcategory_id)))
     LEFT JOIN fdc_odh_group t7 ON ((t7.id = t1.object_group_id)))
     LEFT JOIN nsi.fdc_legal_person t8 ON ((t8.id = t1.passport_author_id)))
     LEFT JOIN nsi.fdc_legal_person t9 ON ((t9.id = t1.passport_developer_id)));

COMMENT ON VIEW fdc_odh_v IS 'Объект дорожного хозяйства (ОДХ)';

COMMENT ON COLUMN fdc_odh_v.bord_begin IS 'Граница объекта начало';

COMMENT ON COLUMN fdc_odh_v.bord_end IS 'Граница объекта окончание';

COMMENT ON COLUMN fdc_odh_v.category_detail_id_summer IS 'Ид детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.category_detail_code_summer IS 'Код детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.category_detail_name_summer IS 'Наименование детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.category_detail_id_winter IS 'Ид детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.category_detail_code_winter IS 'Код детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.category_detail_name_winter IS 'Наименование детализации категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.category_odh_id IS 'Идентификатор категории ОДХ';

COMMENT ON COLUMN fdc_odh_v.category_odh_code IS 'Код категории ОДХ';

COMMENT ON COLUMN fdc_odh_v.category_odh_name IS 'Наименование категории ОДХ';

COMMENT ON COLUMN fdc_odh_v.clean_category_id IS 'Ид категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.clean_category_code IS 'Код категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.clean_category_name IS 'Наименование категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.clean_subcategory_id IS 'Ид категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.clean_subcategory_code IS 'Код категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.clean_subcategory_name IS 'Наименование категории объекта по уборке';

COMMENT ON COLUMN fdc_odh_v.distance IS 'Протяженность по оси, м2';

COMMENT ON COLUMN fdc_odh_v.geometry IS 'Геометрия';

COMMENT ON COLUMN fdc_odh_v.glonass_no_check IS 'Признак Не контролируется ГЛОНАСС';

COMMENT ON COLUMN fdc_odh_v.id IS 'Ид версии объекта';

COMMENT ON COLUMN fdc_odh_v.is_include_title_list IS 'Признак Включить в ТС';

COMMENT ON COLUMN fdc_odh_v.is_orphan_object IS 'Признак Бесхозный объект';

COMMENT ON COLUMN fdc_odh_v.name IS 'Наименование ОДХ';

COMMENT ON COLUMN fdc_odh_v.object_group_id IS 'Ид группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_v.object_group_code IS 'Код группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_v.object_group_name IS 'Наименование группы объекта ОДХ';

COMMENT ON COLUMN fdc_odh_v.passport_author IS 'Составитель паспорта';

COMMENT ON COLUMN fdc_odh_v.passport_author_id IS 'Составитель паспорта';

COMMENT ON COLUMN fdc_odh_v.passport_author_name IS 'Полное наименование/Фамилия';

COMMENT ON COLUMN fdc_odh_v.passport_author_short_name IS 'Краткое наименование/Имя';

COMMENT ON COLUMN fdc_odh_v.passport_date IS 'Дата паспорта';

COMMENT ON COLUMN fdc_odh_v.passport_developer_id IS 'Разработчик паспорта';

COMMENT ON COLUMN fdc_odh_v.passport_developer_name IS 'Полное наименование/Фамилия';

COMMENT ON COLUMN fdc_odh_v.passport_developer_short_name IS 'Краткое наименование/Имя';

COMMENT ON COLUMN fdc_odh_v.passport_num IS 'Номер паспорта';

COMMENT ON COLUMN fdc_odh_v.register_code IS 'Код объекта';

COMMENT ON COLUMN fdc_odh_v.register_num IS 'Регистрационный номер БТИ';

