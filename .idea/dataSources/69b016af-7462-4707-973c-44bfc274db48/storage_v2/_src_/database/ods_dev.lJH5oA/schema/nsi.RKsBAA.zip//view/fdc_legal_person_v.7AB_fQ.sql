CREATE VIEW fdc_legal_person_v AS
  SELECT lpr.id,
    lpr.root_id,
    lpr.person_type_id,
    lpr.code,
    lpr.name,
    lpr.short_name,
    lpr.inn,
    lpr.kpp,
    lpr.ogrn,
    lpr.okpo,
    lpr.account,
    lpr.postal_address,
    lpr.legal_address,
    lpr.email,
    lpr.phone,
    lpr.fax,
    lpr.off_post,
    lpr.off_name,
    lpr.bik,
    lpr.bank,
    lpr.suppress_asur_sync,
    lpr.reg_date,
    lpr.work_length,
    lpr.parent_id,
    lpr.cbr_bank_id,
    lpr.is_small_medium,
    lpr.sro_flag,
    lpr.sro_org_id,
    lpr.sro_regnum,
    lpr.person_code,
    lpr.person_code_name,
    lpr.ver_start_date AS start_date,
    lpr.ver_end_date AS end_date,
    lpr.is_local_version
   FROM nsi.fdc_person_version_v lpr
  WHERE (lpr.person_type_id = ANY (ARRAY[(1)::bigint, (2)::bigint, (3)::bigint]));

COMMENT ON VIEW fdc_legal_person_v IS 'Юр лица без локальныйх версий и запросов';

COMMENT ON COLUMN fdc_legal_person_v.id IS 'ИД организации';

COMMENT ON COLUMN fdc_legal_person_v.root_id IS 'Сквозной Ид организации';

COMMENT ON COLUMN fdc_legal_person_v.person_type_id IS 'ИД родительской организации для филиалов';

COMMENT ON COLUMN fdc_legal_person_v.code IS 'Код в АС Управления Реестрами';

COMMENT ON COLUMN fdc_legal_person_v.name IS 'Полное наименование';

COMMENT ON COLUMN fdc_legal_person_v.short_name IS 'Краткое наименование';

COMMENT ON COLUMN fdc_legal_person_v.inn IS 'Идентификационный номер налогоплательщика';

COMMENT ON COLUMN fdc_legal_person_v.kpp IS 'Код причины постановки на учёт';

COMMENT ON COLUMN fdc_legal_person_v.ogrn IS 'Основной государственный регистрационный номер';

COMMENT ON COLUMN fdc_legal_person_v.okpo IS 'Общероссийский классификатор предприятий и организаций';

COMMENT ON COLUMN fdc_legal_person_v.account IS 'Расчётный счёт (текущий счёт)';

COMMENT ON COLUMN fdc_legal_person_v.postal_address IS 'Почтовый адрес';

COMMENT ON COLUMN fdc_legal_person_v.legal_address IS 'Юридический адрес';

COMMENT ON COLUMN fdc_legal_person_v.email IS 'Электронная почта';

COMMENT ON COLUMN fdc_legal_person_v.phone IS 'Телефон организации или ответственного лица';

COMMENT ON COLUMN fdc_legal_person_v.fax IS 'Факс организации';

COMMENT ON COLUMN fdc_legal_person_v.off_post IS 'Должность руководителя';

COMMENT ON COLUMN fdc_legal_person_v.off_name IS 'ФИО руководителя';

COMMENT ON COLUMN fdc_legal_person_v.bik IS 'БИК';

COMMENT ON COLUMN fdc_legal_person_v.bank IS 'Банк';

COMMENT ON COLUMN fdc_legal_person_v.suppress_asur_sync IS 'Запретить синхронизацию с АСУР (0 - не запрещать, 1 - запретить)';

COMMENT ON COLUMN fdc_legal_person_v.reg_date IS 'Дата регистрации';

COMMENT ON COLUMN fdc_legal_person_v.work_length IS 'Стаж работы';

COMMENT ON COLUMN fdc_legal_person_v.parent_id IS 'Ид головной организации';

COMMENT ON COLUMN fdc_legal_person_v.cbr_bank_id IS 'Ид банк';

COMMENT ON COLUMN fdc_legal_person_v.is_small_medium IS 'Признак малого или среднего бизнеса';

COMMENT ON COLUMN fdc_legal_person_v.sro_flag IS 'Признак СРО';

COMMENT ON COLUMN fdc_legal_person_v.sro_org_id IS 'Ид СРО';

COMMENT ON COLUMN fdc_legal_person_v.sro_regnum IS 'Оегистрационный номер СРО';

COMMENT ON COLUMN fdc_legal_person_v.person_code IS 'Код поразделения';

COMMENT ON COLUMN fdc_legal_person_v.person_code_name IS 'Вид подразделения';

COMMENT ON COLUMN fdc_legal_person_v.start_date IS 'Дата начала версии';

COMMENT ON COLUMN fdc_legal_person_v.end_date IS 'Дата окончания версии с учетом закрытия организации';

