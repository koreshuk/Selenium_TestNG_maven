CREATE FUNCTION srv_workdays_back(p_workdays_qty integer, p_date_from date)
  RETURNS date
LANGUAGE plpgsql
AS $$
declare
  /* Функция возвращает дату, отстоящую на p_workdays_qty рабочих дней от p_date_from
  */
  l_return_date date;
begin
  select dt
   into l_return_date
   from(select dt
              ,row_number() over(order by dt desc) rn
         from generate_series((p_date_from-interval '1' year)::timestamp
                              ,p_date_from::timestamp
                              ,'1 days'
                             ) dt
        where extract(dow from dt) not in(0,6)
      ) dtbl
 where rn=abs(p_workdays_qty)+1;

  return l_return_date;
end
$$;

