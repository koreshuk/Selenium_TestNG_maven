CREATE FUNCTION fdc_person_pck_add_version(p_old_ver_id bigint, p_legal_person nsi.fdc_legal_person, p_start_date timestamp without time zone, p_event_id bigint, p_with_flk boolean, p_is_local boolean, p_t_legal_address nsi.t_legal_person_address, p_t_postal_address nsi.t_legal_person_address, p_bind_ver_id bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция создания версии была создана для обвязки существующих create_version и create_local
  %usage Используется внутри пакета
  %param p_old_version_id  - ид редактируемой версии
  %param p_legal_person    - данные fdc_legal_person
  %param p_start_date      - дата начала действия организации = min дате начала версии
  %param p_event_id        - Ид события
  %param p_with_flk        - Признак необходимости ФЛК (1 - флк нужен)
  %param p_is_local        - Признак локальной версии
  %param p_t_legal_address - Атрибуты адреса в формате КЛАДР юр
  %param p_t_postal_address - Атрибуты адреса в формате КЛАДР факт
  %param p_bind_ver_id     - Ид версии с которой необходимо связать новую версию
  %return Ид новой версии
  */
  l_new_ver_id          nsi.fdc_legal_person.id%type;
  l_old_legal_person    nsi.fdc_legal_person;
  l_legal_person        nsi.fdc_legal_person;
  l_new_bind_ver_id     nsi.fdc_legal_person.id%type;  
  l_is_version_exists   BOOLEAN:=false;
  l_t_legal_address     nsi.t_legal_person_address;
  l_t_postal_address    nsi.t_legal_person_address;
  l_crc                 nsi.fdc_legal_person.crc%type;
begin
  l_legal_person:=p_legal_person;
  --Присваиваем новым данным ид связанного субъета
  --т.к. этого не было сделано в API процедурах
  l_legal_person.bind_person_id:= p_bind_ver_id;

  if not p_is_local then
    --берем старые данные
    begin
      select d.*
        into l_old_legal_person
        from nsi.fdc_legal_person d
       where d.id = p_old_ver_id;
    exception
      when no_data_found then
        null;
    end;

    --Создаем новую версию
    l_new_ver_id := nsi.fdc_person_pck_create_version(p_old_ver_id   => p_old_ver_id
                                                     ,p_legal_person => l_legal_person
                                                     ,p_start_date   => p_start_date
                                                     ,p_event_id     => p_event_id
                                                     ,p_with_flk     => p_with_flk
                                                     );

    -------------------------------------------------------------------------------------------------------------
    /*                                     Блок для работы со связями                                           */
    -------------------------------------------------------------------------------------------------------------
    if (p_bind_ver_id is not null or l_old_legal_person.bind_person_id is not null) and 
       (l_new_ver_id <> coalesce(p_old_ver_id,0))  then
      if (p_bind_ver_id is not null and l_old_legal_person.bind_person_id is null) or
            (p_bind_ver_id = l_old_legal_person.bind_person_id) then

        l_new_bind_ver_id := nsi.fdc_person_pck_add_bind_version(p_person_id      => p_bind_ver_id
                                                                ,p_start_date     => p_start_date
                                                                ,p_inn            => l_legal_person.inn
                                                                ,p_bind_person_id => l_new_ver_id
                                                                );

        perform nsi.fdc_bind_person_pck_set_bind_person(p_person_id_1 => l_new_ver_id
                                                       ,p_person_id_2 => l_new_bind_ver_id
                                                       ); 

      elsif (p_bind_ver_id <> l_old_legal_person.bind_person_id) then
        --закрываем старую
        l_new_bind_ver_id := nsi.fdc_person_pck_add_bind_version(p_person_id      => l_old_legal_person.bind_person_id
                                                                ,p_start_date     => p_start_date
                                                                ,p_inn            => null
                                                                ,p_bind_person_id => null
                                                                );
        --создаем новое
        l_new_bind_ver_id := nsi.fdc_person_pck_add_bind_version(p_person_id      => p_bind_ver_id
                                                                ,p_start_date     => p_start_date
                                                                ,p_inn            => l_legal_person.inn
                                                                ,p_bind_person_id => l_new_ver_id
                                                                );

        --связываем
        perform nsi.fdc_bind_person_pck_set_bind_person(p_person_id_1 => l_new_ver_id
                                                       ,p_person_id_2 => l_new_bind_ver_id
                                                       ); 


      elsif (l_old_legal_person.bind_person_id is not null and p_bind_ver_id is null) then
        l_new_bind_ver_id := nsi.fdc_person_pck_add_bind_version(p_person_id      => l_old_legal_person.bind_person_id
                                                                ,p_start_date     => p_start_date
                                                                ,p_inn            => null
                                                                ,p_bind_person_id => l_new_ver_id
                                                                );

        perform nsi.fdc_bind_person_pck_del_bind_person(p_person_id_1 => l_new_ver_id
                                                       ,p_person_id_2 => l_new_bind_ver_id
                                                       ); 

      end if;
    end if;
  else
    --локальная версия
    l_legal_person.bind_person_id := null;

    l_crc := nsi.fdc_person_pck_get_legal_crc(p_legal_person => l_legal_person);
    
    select case
             when count(1)>0 then true
             else false
           end  
      into l_is_version_exists
      from nsi.fdc_legal_person l
     where l.root_id = l_legal_person.root_id
       and l.crc = l_crc
       and l.is_local_version = true;
       
    l_new_ver_id := nsi.fdc_person_pck_create_local(p_event_id     => p_event_id
                                                   ,p_old_ver_id   => p_old_ver_id
                                                   ,p_legal_person => l_legal_person
                                                   ); 
  end if;

  --получение адреса если в объект передали нулл,для того чтобы скопировать предыдущие значения ЮР.
  if p_t_legal_address is null then
    l_t_legal_address := nsi.fdc_person_address_pck_get_address(p_person_id    => p_old_ver_id
                                                               ,p_address_type => 1 -- legal address
                                                               );
  else
    l_t_legal_address := p_t_legal_address;
  end if;

  --получение адреса если в объект передали нулл,для того чтобы скопировать предыдущие значения ФАКТ.
  if p_t_postal_address is null then
    l_t_postal_address := nsi.fdc_person_address_pck_get_address(p_person_id    => p_old_ver_id
                                                                ,p_address_type => 0 -- postal address
                                                                );
  else
    l_t_postal_address := p_t_postal_address;
  end if;

  --Добавляем расширенный адрес если ИД Версии изменилось
  if l_new_ver_id <> coalesce(p_old_ver_id,0) and not l_is_version_exists then
    perform nsi.fdc_person_address_pck_add_address(p_person_id            => l_new_ver_id
                                                  ,p_legal_person_address => l_t_legal_address
                                                  );

    perform nsi.fdc_person_address_pck_add_address(p_person_id            => l_new_ver_id
                                                  ,p_legal_person_address => l_t_postal_address
                                                  );
  end if;
  
  return l_new_ver_id;
end
$$;

