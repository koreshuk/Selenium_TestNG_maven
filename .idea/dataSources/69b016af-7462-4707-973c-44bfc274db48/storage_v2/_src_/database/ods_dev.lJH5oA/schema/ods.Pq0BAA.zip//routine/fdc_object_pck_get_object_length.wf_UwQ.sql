CREATE FUNCTION fdc_object_pck_get_object_length(p_geometry geometry)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
  /**
    Функция вычисления длинны по геометрии
    %param p_geometry - геометрия объекта
    %return вычисленная длинна, либо 0
  */
  l_geometry_type text;
  l_object_length double precision;
begin
  l_geometry_type:=geometrytype(p_geometry);
  if l_geometry_type in(ods.c_polygon(),ods.c_multipolygon()) THEN
    l_object_length:=st_perimeter(p_geometry);
  elsif l_geometry_type in(ods.c_linestring(),ods.c_multilinestring()) then
    l_object_length:=st_length(p_geometry);
  else
    l_geometry_type:=0;
  end if;
  return l_object_length;
end;
$$;

