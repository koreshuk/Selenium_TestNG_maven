CREATE VIEW fdc_reason_type_v AS
  SELECT oc.id,
    oc.history_id,
    oc.code,
    oc.name,
    oc.date_from,
    oc.date_to
   FROM fdc_reason_type oc;

COMMENT ON VIEW fdc_reason_type_v IS 'Справочник Причина изменения объекта';

COMMENT ON COLUMN fdc_reason_type_v.id IS 'Ид причины изменения объекта';

COMMENT ON COLUMN fdc_reason_type_v.history_id IS 'Исторический ИД';

COMMENT ON COLUMN fdc_reason_type_v.code IS 'Код причины изменения объекта';

COMMENT ON COLUMN fdc_reason_type_v.name IS 'Наименование причины изменения объекта';

COMMENT ON COLUMN fdc_reason_type_v.date_from IS 'Дата с';

COMMENT ON COLUMN fdc_reason_type_v.date_to IS 'Дата по';

