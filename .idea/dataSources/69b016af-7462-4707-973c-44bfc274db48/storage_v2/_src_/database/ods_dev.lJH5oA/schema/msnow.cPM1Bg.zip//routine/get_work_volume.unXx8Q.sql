CREATE FUNCTION get_work_volume(p_work_type_id bigint, p_driveway_id bigint)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
  /* Возвращает значение для заполнения поля Объем выполненных работ
    %param p_work_type_id - Ид вида работы
    %param p_driveway_id  - Ид дороги

    %return  - Объем выполненных работ
  */
  l_work_volume double precision;
begin
  if p_work_type_id is not null and p_driveway_id is not null then
    select case wtc.work_type_code
             when 'ROAD_DEICING' then dw.reduced_distance
             when 'SNOWPLUPH_CLN' then dw.reduced_distance
             when 'TRASHCAN_CLN' then dw.stop_count::double precision
             else NULL::double precision
           end
      into l_work_volume
      from msnow.fdc_driveway dw
          ,(select case
                     when wt.organization_id is null then wt.code
                     else wtu.code
                   end work_type_code
              from msnow.fdc_work_type wt
         left join msnow.fdc_work_type wtu on wtu.id=wt.work_type_uni_id
             where wt.id=p_work_type_id
           ) wtc
     where dw.id=p_driveway_id;
  end if;
  return round(l_work_volume::numeric,3)::double precision;
end;
$$;

