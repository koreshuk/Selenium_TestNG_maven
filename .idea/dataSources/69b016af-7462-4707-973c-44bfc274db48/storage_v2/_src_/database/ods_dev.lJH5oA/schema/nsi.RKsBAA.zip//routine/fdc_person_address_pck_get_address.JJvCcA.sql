CREATE FUNCTION fdc_person_address_pck_get_address(p_person_id bigint, p_address_type bigint)
  RETURNS nsi.t_legal_person_address
LANGUAGE plpgsql
AS $$
declare
  /** Получить адрес в формате КЛАДР
  %param p_person_id      - ИД организации
  %param p_address_type   - Тип адреса (фактический\юридический)
  %return t_legal_person_address (объект - адрес в структуре КЛАДР)
  */
  l_legal_person_address nsi.t_legal_person_address;
begin
  return null;
end
$$;

