CREATE VIEW fdc_srv_obj_tree_v AS
  SELECT t.id,
    t.root_id,
    t.tree_name,
    t.object_type_id,
    t.object_type_code,
    t.object_state_code,
    l.object_id_1 AS parent_id,
    p.object_state_code AS par_object_state_code
   FROM ((fdc_object_for_tree_v t
     LEFT JOIN fdc_object_link_v l ON (((l.object_id_2 = t.id) AND ((l.link_type_code)::text = 'OT_INCLUSION_ODS_FULL'::text))))
     LEFT JOIN fdc_object_for_tree_v p ON (((p.id = l.object_id_1) AND ((p.object_state_code)::text = ANY (ARRAY[('PROJECT'::character varying)::text, ('ON_APPROVAL'::character varying)::text, ('APPROVED'::character varying)::text])) AND ((('now'::text)::timestamp without time zone >= p.version_date_from) AND (('now'::text)::timestamp without time zone <= p.version_date_to)))))
  WHERE ((('now'::text)::timestamp without time zone >= t.version_date_from) AND (('now'::text)::timestamp without time zone <= t.version_date_to));

