CREATE VIEW fdc_max_approval_iteration_v AS
  SELECT t.id,
    t.approval_id,
    t.iteration_number AS max_iteration_number
   FROM ( SELECT fdc_approval_iteration.id,
            fdc_approval_iteration.approval_id,
            fdc_approval_iteration.iteration_number,
            row_number() OVER (PARTITION BY fdc_approval_iteration.approval_id ORDER BY fdc_approval_iteration.iteration_number DESC) AS rn
           FROM fdc_approval_iteration) t
  WHERE (t.rn = 1);

COMMENT ON VIEW fdc_max_approval_iteration_v IS 'Итерация с наибольшим номером в рамках согласования';

COMMENT ON COLUMN fdc_max_approval_iteration_v.id IS 'Ид итерации согласования';

COMMENT ON COLUMN fdc_max_approval_iteration_v.approval_id IS 'Ид согласования';

COMMENT ON COLUMN fdc_max_approval_iteration_v.max_iteration_number IS 'Номер итерации';

