CREATE FUNCTION fdc_workplan_get_planed_work_card_32()
  RETURNS msnow.t_srv_planed_work_card[]
LANGUAGE plpgsql
AS $$
declare
  l_array msnow.t_srv_planed_work_card[];
begin
  l_array:=array[row('SNOWPLUPH_CLN','TWO_H','IMPROVED',1,null,3,null,true)
                ,row('SNOWPLUPH_CLN','TWO_H','TRANSIT',1,null,3,null,true)
                ,row('SNOWPLUPH_CLN','TWO','IMPROVED',1,null,3,null,true)
                ,row('SNOWPLUPH_CLN','TWO','TRANSIT',1,null,3,null,true)
                ,row('TRASHCAN_CLN','ONE_CH',null,1,null,null,null,true)
                ,row('TRASHCAN_CLN','ONE_H',null,1,null,null,null,true)
                ,row('TRASHCAN_CLN','TWO_H','IMPROVED',1,null,null,null,true)
                ,row('TRASHCAN_CLN','TWO_H','TRANSIT',1,null,null,null,true)
                ,row('TRASHCAN_CLN','ONE_C',null,2,9,null,null,true)
                ,row('TRASHCAN_CLN','ONE',null,2,9,null,null,true)
                ,row('TRASHCAN_CLN','TWO','IMPROVED',2,9,null,null,true)
                ,row('TRASHCAN_CLN','TWO','TRANSIT',2,9,null,null,true)
                ,row('TRASHCAN_CLN','THREE_H','IMPROVED',2,9,null,null,true)
                ,row('TRASHCAN_CLN','THREE_H','TRANSIT',2,9,null,null,true)
                ,row('TRASHCAN_CLN','THREE_H','DIRT_ROAD',2,9,null,null,true)
                ,row('TRASHCAN_CLN','THREE_A','IMPROVED',2,9,null,null,true)
                ,row('TRASHCAN_CLN','THREE_A','TRANSIT',2,9,null,null,true)
                ,row('TRASHCAN_CLN','THREE_A','DIRT_ROAD',2,9,null,null,true)
                ,row('LANDING_DEICING','TWO','IMPROVED',1,null,null,null,true)
                ,row('LANDING_DEICING','TWO','TRANSIT',1,null,null,null,true)
                ];
  return l_array;
end
$$;

