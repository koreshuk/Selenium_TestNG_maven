CREATE FUNCTION fdc_object_pck_validate_geometry(p_object t_object, p_origin_id bigint)
  RETURNS SETOF t_validate_geometry
LANGUAGE plpgsql
AS $$
declare
  /** Функция валидации геометрии объекта
  %param     p_object           Объект
  %param     p_origin_id        Идентификатор родителя - источника, для которого создается новая версия
  %return                       Коллекция объектоа у которых пересекается геометрия
  */
  l_root_id ods.fdc_object.root_id%type;
  l_geometry_area double precision;
  l_object_type_code ods.fdc_object_type.code%type;
  rw_g record;
begin
  begin
    if p_object.id is not null then
      select o.root_id
        into strict l_root_id
        from ods.fdc_object o
       where o.id = p_object.id;
    end if;

    if l_root_id is null and p_origin_id is not null then
      select o.root_id
        into strict l_root_id
        from ods.fdc_object o
       where o.id = p_origin_id;
    end if;
  exception
    when no_data_found then null;
  end;

  l_geometry_area := st_area(p_object.geometry);
  select ot.code
    into l_object_type_code
    from ods.fdc_object_type ot
   where ot.id = p_object.obj_type_id;

  if l_object_type_code in (ods.c_at_yard()
                           ,ods.c_at_odh()
                           ,ods.c_at_ozn_cat_1_2()
                           ) then
    for rw_g in (select ov.id
                       ,ov.name
                       ,ov.tree_name
                       ,ov.object_type_id
                       ,ov.object_type_code
                       ,ov.object_type_short_name
                       ,ov.geometry
                       ,st_area(st_intersection(ov.geometry,p_object.geometry)) area_inter
                       ,st_area(ov.geometry) area
                   from ods.fdc_object_v ov
                  where ov.object_type_code in(ods.c_at_yard()
                                              ,ods.c_at_odh()
                                              ,ods.c_at_ozn_cat_1_2()
                                              )
                    and ov.root_id <> coalesce(l_root_id,-1)
                    and ov.id <> coalesce(p_origin_id,-1)
                    and p_object.version_date_from between ov.version_date_from and ov.version_date_to
                    and ov.object_state_id = ods.c_os_approved()
                    and st_relate(ov.geometry, p_object.geometry,'T********')
                    limit 10
                ) loop

      if least(l_geometry_area, rw_g.area) > 0 then
        if rw_g.area_inter/ least(l_geometry_area, rw_g.area) * 100 > 0	 then -- Пока пересечений быть не должно вообще
          return next rw_g.id, rw_g.tree_name, rw_g.object_type_id,
                             rw_g.object_type_code, rw_g.object_type_short_name, rw_g.geometry;
        end if;
      end if;
    end loop;
  end if;
  return;
end
$$;

