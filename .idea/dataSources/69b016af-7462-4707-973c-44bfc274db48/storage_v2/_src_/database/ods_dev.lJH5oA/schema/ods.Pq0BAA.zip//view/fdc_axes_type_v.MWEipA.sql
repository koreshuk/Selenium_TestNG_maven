CREATE VIEW fdc_axes_type_v AS
  SELECT (1)::bigint AS id,
    '1'::character varying(50) AS code,
    'Основная'::character varying(255) AS name
UNION ALL
 SELECT (2)::bigint AS id,
    '2'::character varying(50) AS code,
    'Дополнительная'::character varying(255) AS name;

COMMENT ON VIEW fdc_axes_type_v IS 'Справочник "Тип оси" для параметра пикетажа';

