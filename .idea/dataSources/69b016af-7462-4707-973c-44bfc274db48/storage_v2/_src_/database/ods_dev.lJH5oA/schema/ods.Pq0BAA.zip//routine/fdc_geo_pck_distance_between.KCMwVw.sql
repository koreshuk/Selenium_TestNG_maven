CREATE FUNCTION fdc_geo_pck_distance_between(p_object_id_1 bigint, p_object_id_2 bigint)
  RETURNS double precision
LANGUAGE plpgsql
AS $$
declare
  /** Функция расчета растояния между двумя ОДТИ */
begin

  return st_distance((select o.geometry
                        from ods.fdc_object o
                       where o.id = p_object_id_1
                     )
                    ,(select o.geometry
                        from ods.fdc_object o
                       where o.id = p_object_id_2
                     )
                    );

end
$$;

