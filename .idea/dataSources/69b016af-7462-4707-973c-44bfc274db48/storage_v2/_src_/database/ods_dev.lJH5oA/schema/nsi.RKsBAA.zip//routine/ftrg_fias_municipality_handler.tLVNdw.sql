CREATE FUNCTION ftrg_fias_municipality_handler()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
declare
  /* Выполняется в триггере на nsi.fdc_fias_municipality
     Обновляет МО в ods.fdc_as_addrobj_loc после добавления/изменения/удаления строк в nsi.fdc_fias_municipality
  */
  l_cnt integer;
begin
  if TG_LEVEL='STATEMENT' and TG_WHEN='BEFORE' then
  /*  if not exists(select null
                    from pg_class c
                   where c.relpersistence = 't'
                     and c.relname='tmp_fias_municipality_change'
                 ) then*/
      create temporary table if not exists tmp_fias_municipality_change(fias_municipality_change_id bigint) on commit delete rows;
  --  end if;
   /* if not exists(select null
                    from pg_class c
                   where c.relpersistence = 't'
                     and c.relname='tmp_fias_municipality_change_del'
                 ) then*/
      create temporary table if not exists tmp_fias_municipality_change_del(id bigint,municipality_id bigint,fias_id bigint,start_date date, end_date date) on commit delete rows;
   -- end if;
  elsif TG_LEVEL='ROW' and TG_WHEN='AFTER' then
    if TG_OP in('INSERT','UPDATE') then
      insert into tmp_fias_municipality_change(fias_municipality_change_id) values(new.id);
    end if;
    if TG_OP in('UPDATE','DELETE') then
      insert into tmp_fias_municipality_change_del(id,municipality_id,fias_id,start_date,end_date) values
        (old.id,old.municipality_id,old.fias_id,old.start_date,old.end_date);
    end if;
  elsif TG_LEVEL='STATEMENT' and TG_WHEN='AFTER' then
    if TG_OP in('UPDATE','DELETE') then
      with mo_name as(select distinct ao.ao_guid
                            ,fm.start_date
                            ,fm.end_date
                            ,m.short_name as municipality_name
                            ,m.id as municipality_id
                        from tmp_fias_municipality_change_del fm
                       -- join tmp_fias_municipality_change tmp on fm.id=tmp.fias_municipality_change_id -- !!
                        join nsi.fdc_municipality m on fm.municipality_id=m.id
                        join ods.fdc_as_addrobj_loc ao on fm.fias_id=ao.id
                       where fm.start_date is not null
                         and fm.end_date is not null
                     )
          ,mo as(select adr.ao_guid
                       ,mo_name.municipality_id
                       ,mo_name.municipality_name
                       ,mo_name.start_date
                       ,mo_name.end_date
                   from nsi.fdc_as_addrobj_hierarchy_mv as adr
                   join mo_name on adr.top_ao_guid=mo_name.ao_guid
                )
       update ods.fdc_as_addrobj_loc aol
          set municipality_id=null
             ,municipality_name = null
         from(select tt.id
                    ,tt.municipality_id
                    ,tt.municipality_name
                from(select mo.municipality_id
                           ,mo.municipality_name
                           ,row_number() over(partition by ao.id order by mo.end_date,mo.municipality_id desc) rn
                           ,ao.id
                       from ods.fdc_as_addrobj_loc ao
                       join mo on ao.ao_guid=mo.ao_guid
                                  and mo.start_date<=ao.end_date
                                  and mo.end_date >=ao.start_date
                    ) tt
               where tt.rn=1
             ) chg
        where aol.id=chg.id;
    end if;
    if TG_OP in('INSERT','UPDATE') then
      with mo_name as(select distinct ao.ao_guid
                            ,fm.start_date
                            ,fm.end_date
                            ,m.short_name as municipality_name
                            ,m.id as municipality_id
                        from nsi.fdc_fias_municipality fm
                        join tmp_fias_municipality_change tmp on fm.id=tmp.fias_municipality_change_id -- !!
                        join nsi.fdc_municipality m on fm.municipality_id=m.id
                        join ods.fdc_as_addrobj_loc ao on fm.fias_id=ao.id
                       where fm.start_date is not null
                         and fm.end_date is not null
                     )
          ,mo as(select adr.ao_guid
                       ,mo_name.municipality_id
                       ,mo_name.municipality_name
                       ,mo_name.start_date
                       ,mo_name.end_date
                   from nsi.fdc_as_addrobj_hierarchy_mv as adr
                   join mo_name on adr.top_ao_guid=mo_name.ao_guid
                )
       update ods.fdc_as_addrobj_loc aol
          set municipality_id=chg.municipality_id
             ,municipality_name = chg.municipality_name
         from(select tt.id
                    ,tt.municipality_id
                    ,tt.municipality_name
                from(select mo.municipality_id
                           ,mo.municipality_name
                           ,row_number() over(partition by ao.id order by mo.end_date,mo.municipality_id desc) rn
                           ,ao.id
                       from ods.fdc_as_addrobj_loc ao
                       join mo on ao.ao_guid=mo.ao_guid
                                  and mo.start_date<=ao.end_date
                                  and mo.end_date >=ao.start_date
                    ) tt
               where tt.rn=1
             ) chg
        where aol.id=chg.id;
    end if;
  end if;
  return null;
end
$$;

