CREATE FUNCTION rep_lsr_apprhold_summary(p_summary_type integer, p_driveway_category_id bigint, p_work_category_id bigint DEFAULT NULL::bigint, p_customer_id bigint DEFAULT NULL::bigint, OUT id bigint, OUT name character varying, OUT work_category_name character varying, OUT customer_short_name character varying, OUT performer_short_name character varying, OUT holder_fio character varying, OUT holder_org_name character varying, OUT holder_occupation character varying, OUT date_plan date, OUT date_fact date, OUT expiration_days integer)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчёт "Сводка по согласованию Локальных сметных расчетов на <текущая дата>" в разрезе заказчиков

  %param p_summary_type          - Тип сметы
                                   1 - бюджет
                                   2 - контракт/задание
  %param p_driveway_category_id  - Балансовая прнадлежность
  %param p_work_category_id      - Ид категории работ
  %param p_customer_id           - Заказчик (Ид актуальной версии заказчика)

  %return id                   - Ид бюджета или контракта
  %return name                 - Наименование бюджета или контракта
  %return work_category_name   - Категория работ
  %return customer_short_name  - Заказчик/Орган
  %return performer_short_name - Исполнитель
  %return holder_fio           - ФИО задерживающего согласование
  %return holder_org_name      - Организация задерживающего согласование
  %return holder_occupation    - Должность задерживающего согласование
  %return date_plan            - Планируемая дата согласования
  %return date_fact            - Фактическая дата согласования
  %return expiration_days      - Дней просрочки

  */
  l_summary_date date;

  C_TYPE_OBLIGATION constant integer:=1;
  C_TYPE_AGREEMENT constant INTEGER:=2;
begin
  l_summary_date :=current_date;

  if p_summary_type=C_TYPE_OBLIGATION then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as obligation_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='OBLIGATION'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )
          ,expired as (select maxiter.obligation_id
                             ,maxiter.approval_iteration_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )

          ,obl as(select o.id as obligation_id
                        ,o.name as obligation_name
                        ,owc.name as work_category_name
                        ,ocust.customer_short_name
                        ,mi.approval_iteration_id
                    from expired mi
                    join msnow.fdc_obligation o on mi.obligation_id=o.id
                    join msnow.fdc_agreement_obligation_status oblst on o.obligation_status_id=oblst.id
                    join rcust ocust on o.authority_org_id=ocust.customer_root_id
                    left join msnow.fdc_work_category owc on o.work_category_id=owc.id
                   where (p_work_category_id is null or o.work_category_id=p_work_category_id)
                     and oblst.code='ON_APPROVAL'
                 )

          ,obwflow as(select obl.obligation_id
                            ,obl.obligation_name
                            ,obl.work_category_name
                            ,obl.customer_short_name
                            ,awf.date_plan
                            ,awf.date_fact
                            ,l_summary_date - awf.date_plan as expiration_days
                            ,coalesce(awf.official_id::text
                                     ,(select string_agg(u.id::text,';')
                                         from secr.fdc_user_md u
                                        where u.responsible_for_approve
                                          and coalesce(u.person_id,-1) = coalesce(awfo.root_id,-1)
                                          --and coalesce(u.division_id,-1) = coalesce(awfd.root_id,-1)
                                          --and coalesce(u.occupation_id,-1) = coalesce(awf.occupation_id,-1)
                                          --limit 1--на всякий случай
                                      )
                                     ) as holder_user_id
                        from obl
                        join ods.fdc_approval_workflow awf on obl.approval_iteration_id=awf.approval_iteration_id
                        join ods.fdc_approval_status ast on awf.approval_status_id=ast.id

                        left join nsi.fdc_legal_person awfo on awf.organization_id=awfo.id
                        left join nsi.fdc_legal_person awfd on awf.division_id=awfd.id
                       where ast.code = 'SENT'
                         and(awf.is_obligatory or
                              (awf.date_fact is not null and exists(select null
                                                                      from ods.fdc_approval_temp_part atp
                                                                      join ods.fdc_approval_temp_stage ats on atp.approval_temp_stage_id=ats.id
                                                                     where atp.id=awf.approval_template_detail_id
                                                                       and ats.rule_stage=2
                                                                   )
                              )
                            )
                         and awf.date_plan < l_summary_date
                     )
          ,holder_user_list as (SELECT unnest(string_to_array(obwflow.holder_user_id,';'))::bigint as holder_user_id,
                                              obwflow.obligation_id
                                             FROM obwflow)

           select twf.obligation_id as id
                 ,twf.obligation_name::varchar as name
                 ,twf.work_category_name
                 ,twf.customer_short_name
                 ,null::varchar as performer_short_name
                 ,(hu.family||case
                                when hu.first_name is not null then ' '||hu.first_name
                                else ''
                              end||case
                                     when hu.second_name is not null then ' '||hu.second_name
                                     else ''
                                   end
                  )::varchar as holder_fio
                 ,huorg.short_name as holder_org_name
                 ,ocp.name as holder_occupation
                 ,twf.date_plan
                 ,twf.date_fact
                 ,twf.expiration_days
             from obwflow twf
             left join holder_user_list hul on hul.obligation_id = twf.obligation_id
             left join secr.fdc_user_md hu on hul.holder_user_id=hu.id
             left join nsi.fdc_legal_person huorg on hu.person_id=huorg.root_id
                                                     and statement_timestamp() between huorg.ver_start_date and huorg.ver_end_date
             left join nsi.fdc_occupation ocp on hu.occupation_id=ocp.id;
  elsif p_summary_type=C_TYPE_AGREEMENT then
    return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and l_summary_date between lp.ver_start_date and lp.ver_end_date
                      and l_summary_date between pr.begin_date and pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='OMSU'
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                      from cust
                     where p_customer_id is not null
                   )
          ,maxiter as(select distinct on(ait.approval_id)
                             ait.approval_id
                            ,ait.iteration_number
                            ,a.main_object_id as agreement_id
                            ,ast.code as approval_iteration_status_code
                            ,ait.id as approval_iteration_id
                        from ods.fdc_approval_template_type atpt
                        join ods.fdc_approval_template atp on atpt.id=atp.approval_template_type_id
                        join ods.fdc_approval a on atp.id=a.approval_template_id
                        join ods.fdc_approval_iteration ait on a.id=ait.approval_id
                        join ods.fdc_approval_status ast on ait.approval_status_id=ast.id
                       where atpt.code='AGREEMENT'
                       order by ait.approval_id
                               ,ait.iteration_number desc
                     )

          ,expired as (select maxiter.agreement_id
                             ,maxiter.approval_iteration_id
                         from maxiter
                         join ods.fdc_approval_workflow awf on maxiter.approval_iteration_id=awf.approval_iteration_id
                        where awf.date_plan < l_summary_date
                      )

          ,agr as(select agr.id as agreement_id
                        ,agr.name as agreement_name
                        ,awc.name as work_category_name
                        ,acust.customer_short_name
                        ,perf.short_name as performer_short_name
                        ,mi.approval_iteration_id
                    from expired mi
                    join msnow.fdc_agreement agr on mi.agreement_id=agr.id
                    join msnow.fdc_agreement_obligation_status agrst on agr.agreement_status_id=agrst.id
                    join rcust acust on agr.customer_id=acust.customer_root_id
                    left join nsi.fdc_legal_person perf on agr.performer_id=perf.root_id
                                                           and l_summary_date between perf.ver_start_date and perf.ver_end_date
                    left join msnow.fdc_work_category awc on agr.work_category_id=awc.id
                   where (p_work_category_id is null or agr.work_category_id=p_work_category_id)
                     and agrst.code='ON_APPROVAL'
                 )
          ,agwflow as(select agr.agreement_id
                            ,agr.agreement_name
                            ,agr.work_category_name
                            ,agr.customer_short_name
                            ,agr.performer_short_name
                            ,awf.date_plan
                            ,awf.date_fact
                            ,l_summary_date - awf.date_plan as expiration_days
                            ,coalesce(awf.official_id::text
                                     ,(select string_agg(u.id::text,';')
                                         from secr.fdc_user_md u
                                        where u.responsible_for_approve
                                          and coalesce(u.person_id,-1) = coalesce(awfo.root_id,-1)
                                          --and coalesce(u.division_id,-1) = coalesce(awfd.root_id,-1)
                                          --and coalesce(u.occupation_id,-1) = coalesce(awf.occupation_id,-1)
                                          --limit 1--на всякий случай
                                      )
                                     ) as holder_user_id
                        from agr
                        join ods.fdc_approval_workflow awf on agr.approval_iteration_id=awf.approval_iteration_id
                        join ods.fdc_approval_status ast on awf.approval_status_id=ast.id

                        left join nsi.fdc_legal_person awfo on awf.organization_id=awfo.id
                        left join nsi.fdc_legal_person awfd on awf.division_id=awfd.id
                       where ast.code = 'SENT'
                         and(awf.is_obligatory or
                              (awf.date_fact is not null and exists(select null
                                                                      from ods.fdc_approval_temp_part atp
                                                                      join ods.fdc_approval_temp_stage ats on atp.approval_temp_stage_id=ats.id
                                                                     where atp.id=awf.approval_template_detail_id
                                                                       and ats.rule_stage=2
                                                                   )
                              )
                            )
                         and awf.date_plan < l_summary_date
                     )
          ,holder_user_list as (SELECT unnest(string_to_array(agwflow.holder_user_id,';'))::bigint as holder_user_id,
                                                  agwflow.agreement_id
                                             FROM agwflow)

           select twf.agreement_id as id
                 ,twf.agreement_name as name
                 ,twf.work_category_name
                 ,twf.customer_short_name
                 ,twf.performer_short_name
                 ,(hu.family||case
                                when hu.first_name is not null then ' '||hu.first_name
                                else ''
                              end||case
                                     when hu.second_name is not null then ' '||hu.second_name
                                     else ''
                                   end
                  )::varchar as holder_fio
                 ,huorg.short_name as holder_org_name
                 ,ocp.name as holder_occupation
                 ,twf.date_plan
                 ,twf.date_fact
                 ,twf.expiration_days
             from agwflow twf
             left join holder_user_list hul on hul.agreement_id = twf.agreement_id
             left join secr.fdc_user_md hu on hul.holder_user_id=hu.id
             left join nsi.fdc_legal_person huorg on hu.person_id=huorg.root_id
                                                     and statement_timestamp() between huorg.ver_start_date and huorg.ver_end_date
             left join nsi.fdc_occupation ocp on hu.occupation_id=ocp.id;
  end if;
  return;
end
$$;

