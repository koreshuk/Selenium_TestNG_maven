CREATE FUNCTION fdc_ldv_agreement_stat(p_municipality_id bigint, OUT municipality_name text, OUT agreement_id bigint, OUT agreement_type text, OUT reg_num text, OUT work_date_from date, OUT work_date_to date, OUT work_category text, OUT driveway_cnt integer, OUT work_cost double precision, OUT estimate_work_cost double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет "Статистика по местным дорогам муниц. района" - Реестр контрактов
  %param p_municipality_id - Ид муниципального района/городского округа
  */
begin
  return query select mnc.formal_name||case
                                         when mnc.short_name is not null then ' '||mnc.short_name
                                         else ''
                                       end::text as municipality_name
                     ,agr.id as agreement_id
                     ,agrt.name::text as agreement_type
                     ,agr.reg_num::text
                     ,agr.work_date_from
                     ,agr.work_date_to
                     ,wc.name::text as work_category
                     ,coalesce((select count(distinct agro.driveway_id)
                                   from msnow.fdc_agreement_object agro
                                  where agro.argeement_id=agr.id
                                )
                               ,0)::integer as driveway_cnt
                     ,coalesce(agr.cost,0) as work_cost
                     ,coalesce((select sum(agre.work_cost)
                                  from msnow.fdc_agr_estimate agre
                                 where agre.agreement_id=agr.id
                                   and agre.is_estimate_sum
                               )
                               ,0
                              ) as estimate_work_cost
                 from msnow.fdc_agreement agr
                 join msnow.fdc_agreement_type agrt on agr.agr_type_id=agrt.id
                 join msnow.fdc_work_category wc on agr.work_category_id=wc.id
                 join nsi.fdc_person p on agr.customer_id=p.id
                 join nsi.fdc_legal_person lp on p.id=lp.root_id
                 join ods.fdc_as_addrobj mnc on lp.fias_district_id=mnc.id
                where agrt.code<>'AGREEMENT'
                  and wc.code in('MAINTAIN','REPAIR')
                  and statement_timestamp() between lp.ver_start_date and lp.ver_end_date
                  and agr.work_date_from is not null
                  and mnc.id=p_municipality_id;

  return;
end
$$;

