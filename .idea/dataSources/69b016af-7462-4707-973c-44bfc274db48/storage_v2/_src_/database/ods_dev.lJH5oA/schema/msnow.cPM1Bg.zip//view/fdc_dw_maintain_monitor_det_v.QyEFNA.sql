CREATE VIEW fdc_dw_maintain_monitor_det_v AS
  WITH agrgrp AS (
         SELECT DISTINCT odh.maintenance_route_id,
            agrt.agreement_group_id,
            perf.short_name AS performer_name,
            cust.short_name AS customer_name
           FROM (((((((msnow.fdc_agreement_object ao
             JOIN fdc_odh odh ON ((ao.driveway_id = odh.id)))
             JOIN msnow.fdc_agreement agr ON ((ao.argeement_id = agr.id)))
             JOIN msnow.fdc_agreement_type agrt ON ((agr.agr_type_id = agrt.id)))
             JOIN msnow.fdc_agreement_group agrg ON ((agrt.agreement_group_id = agrg.id)))
             JOIN msnow.fdc_work_category awc ON ((agr.work_category_id = awc.id)))
             LEFT JOIN nsi.fdc_legal_person perf ON (((agr.performer_id = perf.root_id) AND ((statement_timestamp() >= perf.ver_start_date) AND (statement_timestamp() <= perf.ver_end_date)))))
             LEFT JOIN nsi.fdc_legal_person cust ON (((agr.customer_id = cust.root_id) AND ((statement_timestamp() >= cust.ver_start_date) AND (statement_timestamp() <= cust.ver_end_date)))))
          WHERE ((ao.driveway_id IS NOT NULL) AND ((awc.code)::text = 'MAINTAIN'::text) AND ((('now'::text)::date >= agr.version_date_from) AND (('now'::text)::date <= agr.version_date_to)))
        ), mp_inwork AS (
         SELECT we.driveway_id,
            we.work_type_id
           FROM msnow.fdc_work_execute we
          WHERE ((we.external_id IS NOT NULL) AND (we.work_volume IS NOT NULL) AND (we.work_date = statement_timestamp()))
        ), mp_done AS (
         SELECT we.driveway_id,
            sum(we.work_volume) AS driveway_work_volume
           FROM msnow.fdc_work_execute we
          WHERE ((we.external_id IS NOT NULL) AND (we.work_volume IS NOT NULL) AND (we.work_date = statement_timestamp()))
          GROUP BY we.driveway_id
        ), mp_auto AS (
         SELECT we.driveway_id,
            we.work_type_id
           FROM msnow.fdc_work_execute we
          WHERE ((we.regnum_auto IS NOT NULL) AND (we.work_date = statement_timestamp()))
        ), agg AS (
         SELECT tt.distance_id,
            tt.driveway_category_id,
            tt.work_type_id,
            tt.driveway_id,
            tt.agreement_group_id,
            tt.distance_name,
            tt.performer_name,
            tt.customer_name,
            tt.plan_distance_id,
            tt.plan_distance_bid,
            tt.inwork_distance_id,
            tt.inwork_distance_bid,
                CASE
                    WHEN (tt.plan_distance_bid AND (NOT tt.inwork_distance_bid) AND (NOT
                    CASE min(tt.done_distance_flag) OVER (PARTITION BY tt.distance_id)
                        WHEN 0 THEN false
                        ELSE true
                    END)) THEN true
                    ELSE false
                END AS notinwork_distance_bid,
                CASE min(tt.done_distance_flag) OVER (PARTITION BY tt.distance_id)
                    WHEN 0 THEN NULL::bigint
                    ELSE tt.distance_id
                END AS done_distance_id,
                CASE min(tt.done_distance_flag) OVER (PARTITION BY tt.distance_id)
                    WHEN 0 THEN false
                    ELSE true
                END AS done_distance_bid,
                CASE max(tt.auto_distance_flag) OVER (PARTITION BY tt.distance_id)
                    WHEN 0 THEN NULL::bigint
                    ELSE tt.distance_id
                END AS auto_distance_id,
                CASE max(tt.auto_distance_flag) OVER (PARTITION BY tt.distance_id)
                    WHEN 0 THEN false
                    ELSE true
                END AS auto_distance_bid
           FROM ( SELECT dist.id AS distance_id,
                    dist.name AS distance_name,
                    agrgrp.performer_name,
                    agrgrp.customer_name,
                    obj.driveway_category_id,
                    swp.work_type_id,
                    obj.id AS driveway_id,
                    agrgrp.agreement_group_id,
                    dist.id AS plan_distance_id,
                    true AS plan_distance_bid,
                        CASE
                            WHEN (EXISTS ( SELECT NULL::unknown
                               FROM mp_inwork mpa
                              WHERE ((mpa.driveway_id = obj.id) AND (mpa.work_type_id = swp.work_type_id)))) THEN dist.id
                            ELSE NULL::bigint
                        END AS inwork_distance_id,
                        CASE
                            WHEN (EXISTS ( SELECT NULL::unknown
                               FROM mp_inwork mpa
                              WHERE ((mpa.driveway_id = obj.id) AND (mpa.work_type_id = swp.work_type_id)))) THEN true
                            ELSE false
                        END AS inwork_distance_bid,
                        CASE dense_rank() OVER (PARTITION BY dist.id, obj.id ORDER BY swp.id, swpd.id)
                            WHEN 1 THEN
                            CASE
                                WHEN (EXISTS ( SELECT NULL::unknown
                                   FROM mp_done mpd
                                  WHERE ((mpd.driveway_id = obj.id) AND (mpd.driveway_work_volume >= odh.distance)))) THEN 1
                                ELSE 0
                            END
                            ELSE NULL::integer
                        END AS done_distance_flag,
                        CASE dense_rank() OVER (PARTITION BY dist.id, obj.id ORDER BY swp.id, swpd.id)
                            WHEN 1 THEN
                            CASE
                                WHEN (EXISTS ( SELECT NULL::unknown
                                   FROM mp_auto mpa
                                  WHERE ((mpa.driveway_id = obj.id) AND (mpa.work_type_id = swp.work_type_id)))) THEN 1
                                ELSE 0
                            END
                            ELSE NULL::integer
                        END AS auto_distance_flag
                   FROM ((((((fdc_maintenance_route dist
                     JOIN fdc_odh odh ON ((dist.id = odh.maintenance_route_id)))
                     JOIN fdc_object obj ON ((odh.id = obj.id)))
                     JOIN fdc_odh_calculation ocalc ON ((obj.id = ocalc.id)))
                     JOIN msnow.fdc_scheduled_work_plan swp ON ((dist.id = swp.maintenance_route_id)))
                     JOIN msnow.fdc_scheduled_work_plan_date swpd ON ((swp.id = swpd.scheduled_work_plan_id)))
                     LEFT JOIN agrgrp ON ((dist.id = agrgrp.maintenance_route_id)))
                  WHERE (swpd.performance_date = ('now'::text)::date)) tt
        ), alldist AS (
         SELECT dist.id AS distance_id,
            dist.name AS distance_name,
            sum(ocalc.stat_axes_length) AS dist_stat_axes_length
           FROM (((fdc_maintenance_route dist
             JOIN fdc_odh odh ON ((dist.id = odh.maintenance_route_id)))
             JOIN fdc_object obj ON ((odh.id = obj.id)))
             JOIN fdc_odh_calculation ocalc ON ((obj.id = ocalc.id)))
          GROUP BY dist.id, dist.name
        )
(
         SELECT alldist.distance_id AS id,
            alldist.distance_id,
            agg.driveway_category_id,
            agg.work_type_id,
            agg.driveway_id,
            agg.agreement_group_id,
            alldist.distance_name,
            agg.performer_name,
            agg.customer_name,
            agg.plan_distance_id,
            agg.inwork_distance_id,
            agg.done_distance_id,
            agg.auto_distance_id,
            'distance_qty'::text AS pquantity
           FROM (alldist
             LEFT JOIN agg ON ((alldist.distance_id = agg.distance_id)))
        UNION
         SELECT agg.distance_id AS id,
            agg.distance_id,
            agg.driveway_category_id,
            agg.work_type_id,
            agg.driveway_id,
            agg.agreement_group_id,
            agg.distance_name,
            agg.performer_name,
            agg.customer_name,
            agg.plan_distance_id,
            agg.inwork_distance_id,
            agg.done_distance_id,
            agg.auto_distance_id,
                CASE
                    WHEN agg.plan_distance_bid THEN 'plan_distance_qty'::text
                    ELSE NULL::text
                END AS pquantity
           FROM agg
) UNION ALL
 SELECT agg.distance_id AS id,
    agg.distance_id,
    agg.driveway_category_id,
    agg.work_type_id,
    agg.driveway_id,
    agg.agreement_group_id,
    agg.distance_name,
    agg.performer_name,
    agg.customer_name,
    agg.plan_distance_id,
    agg.inwork_distance_id,
    agg.done_distance_id,
    agg.auto_distance_id,
        CASE
            WHEN agg.inwork_distance_bid THEN 'inwork_distance_qty'::text
            ELSE NULL::text
        END AS pquantity
   FROM agg
UNION ALL
 SELECT agg.distance_id AS id,
    agg.distance_id,
    agg.driveway_category_id,
    agg.work_type_id,
    agg.driveway_id,
    agg.agreement_group_id,
    agg.distance_name,
    agg.performer_name,
    agg.customer_name,
    agg.plan_distance_id,
    agg.inwork_distance_id,
    agg.done_distance_id,
    agg.auto_distance_id,
        CASE
            WHEN agg.notinwork_distance_bid THEN 'notinwork_distance_qty'::text
            ELSE NULL::text
        END AS pquantity
   FROM agg
UNION ALL
 SELECT agg.distance_id AS id,
    agg.distance_id,
    agg.driveway_category_id,
    agg.work_type_id,
    agg.driveway_id,
    agg.agreement_group_id,
    agg.distance_name,
    agg.performer_name,
    agg.customer_name,
    agg.plan_distance_id,
    agg.inwork_distance_id,
    agg.done_distance_id,
    agg.auto_distance_id,
        CASE
            WHEN agg.done_distance_bid THEN 'done_distance_qty'::text
            ELSE NULL::text
        END AS pquantity
   FROM agg
UNION ALL
 SELECT agg.distance_id AS id,
    agg.distance_id,
    agg.driveway_category_id,
    agg.work_type_id,
    agg.driveway_id,
    agg.agreement_group_id,
    agg.distance_name,
    agg.performer_name,
    agg.customer_name,
    agg.plan_distance_id,
    agg.inwork_distance_id,
    agg.done_distance_id,
    agg.auto_distance_id,
        CASE
            WHEN agg.auto_distance_bid THEN 'auto_distance_qty'::text
            ELSE NULL::text
        END AS pquantity
   FROM agg;

COMMENT ON VIEW fdc_dw_maintain_monitor_det_v IS 'Отчет по мониторингу содержания. Детализирующая таблица';

