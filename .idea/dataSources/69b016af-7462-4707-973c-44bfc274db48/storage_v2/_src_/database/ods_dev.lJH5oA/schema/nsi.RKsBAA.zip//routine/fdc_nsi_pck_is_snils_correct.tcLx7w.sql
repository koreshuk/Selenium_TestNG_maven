CREATE FUNCTION fdc_nsi_pck_is_snils_correct(p_snils character varying, p_event_id bigint DEFAULT NULL::bigint, p_err_raise character varying DEFAULT NULL::character varying)
  RETURNS boolean
LANGUAGE plpgsql
AS $$
declare
 /** Проверка СНИЛС
  %usage Используется в пакете
  %param p_snils - страховой номер индивидуального лицевого счета
  %return true  - заданный СНИЛС прошел проверку на корректность
          false - заданный СНИЛС не прошел проверку на корректность
 */
begin
  return true;
end
$$;

