CREATE VIEW fdc_subdivision_v AS
  SELECT s.id,
    s.root_id,
    s.parent_id,
    s.parent_root_id,
    s.name,
    s.short_name,
    s.person_code AS code,
    s.person_code_name AS code_name,
    s.legal_address,
    s.phone,
    s.fax,
    s.email,
    s.off_post,
    s.off_name,
    s.ver_start_date,
    s.ver_end_date,
    s.postal_address,
    org.id AS org_id,
    org.name AS org_name,
    org.inn AS org_inn,
    org.kpp AS org_kpp,
    org.ogrn AS org_ogrn
   FROM nsi.fdc_person_version_v s,
    nsi.fdc_person_version_v org
  WHERE ((s.person_type_id = 6) AND (s.parent_id = org.id));

COMMENT ON VIEW fdc_subdivision_v IS 'Подразделения';

COMMENT ON COLUMN fdc_subdivision_v.id IS 'ИД субъекта';

COMMENT ON COLUMN fdc_subdivision_v.root_id IS 'ИД организации';

COMMENT ON COLUMN fdc_subdivision_v.parent_id IS 'Ид родительского субъекта';

COMMENT ON COLUMN fdc_subdivision_v.parent_root_id IS 'Наименование родительского субъекта';

COMMENT ON COLUMN fdc_subdivision_v.name IS 'Полное наименование';

COMMENT ON COLUMN fdc_subdivision_v.short_name IS 'Краткое наименование';

COMMENT ON COLUMN fdc_subdivision_v.code IS 'Код подразделения';

COMMENT ON COLUMN fdc_subdivision_v.code_name IS 'Вид подразделения';

COMMENT ON COLUMN fdc_subdivision_v.legal_address IS 'Юридический адрес';

COMMENT ON COLUMN fdc_subdivision_v.phone IS 'Телефон организации или ответственного лица';

COMMENT ON COLUMN fdc_subdivision_v.fax IS 'Факс организации';

COMMENT ON COLUMN fdc_subdivision_v.email IS 'Электронная почта';

COMMENT ON COLUMN fdc_subdivision_v.off_post IS 'Должность руководителя';

COMMENT ON COLUMN fdc_subdivision_v.off_name IS 'ФИО руководителя';

COMMENT ON COLUMN fdc_subdivision_v.ver_start_date IS 'Дата начала действия версии (min = дата появления орг. в системе (ред. пользов.))';

COMMENT ON COLUMN fdc_subdivision_v.ver_end_date IS 'Дата окончания действия версии (NULL - вресия актуальна)';

COMMENT ON COLUMN fdc_subdivision_v.postal_address IS 'Фактический адрес';

COMMENT ON COLUMN fdc_subdivision_v.org_id IS 'ИД юридического лица';

COMMENT ON COLUMN fdc_subdivision_v.org_name IS 'Полное наименование юридического лица';

COMMENT ON COLUMN fdc_subdivision_v.org_inn IS 'ИНН юридического лица';

COMMENT ON COLUMN fdc_subdivision_v.org_kpp IS 'КПП юридического лица';

COMMENT ON COLUMN fdc_subdivision_v.org_ogrn IS 'ОГРН юридического лица';

