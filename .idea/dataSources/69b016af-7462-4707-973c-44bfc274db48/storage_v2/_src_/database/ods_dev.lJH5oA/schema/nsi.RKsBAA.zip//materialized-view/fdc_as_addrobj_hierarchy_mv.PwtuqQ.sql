CREATE MATERIALIZED VIEW fdc_as_addrobj_hierarchy_mv AS WITH RECURSIVE adr(id, ao_id, ao_guid, top_ao_guid, name, ao_level, start_date, end_date, level, parent_guid, area_code, city_code, place_code) AS (
         WITH ao_last_ver AS (
                 SELECT DISTINCT ON (ao.ao_guid) ao.ao_guid,
                    ao.start_date,
                    ao.end_date,
                    ao.id,
                    ao.ao_id,
                    ao.formal_name,
                    ao.short_name,
                    ao.ao_level,
                    ao.parent_guid,
                    ao.area_code,
                    ao.city_code,
                    ao.place_code
                   FROM fdc_as_addrobj_loc ao
                  ORDER BY ao.ao_guid, ao.start_date DESC, ao.end_date DESC, ao.id DESC
                )
         SELECT ao.id,
            ao.ao_id,
            ao.ao_guid,
            ao.ao_guid,
            (((ao.formal_name)::text || ' '::text) || (ao.short_name)::text),
            ao.ao_level,
            ao.start_date,
            ao.end_date,
            1,
            ao.parent_guid,
            ao.area_code,
            ao.city_code,
            ao.place_code
           FROM ao_last_ver ao
          WHERE (ao.ao_level = ANY (ARRAY[3, 4, 6]))
        UNION
         SELECT aoch.id,
            aoch.ao_id,
            aoch.ao_guid,
            adr_1.top_ao_guid,
            ((((adr_1.name || '/'::text) || (aoch.formal_name)::text) || ' '::text) || (aoch.short_name)::text),
            aoch.ao_level,
            aoch.start_date,
            aoch.end_date,
            (adr_1.level + 1),
            aoch.parent_guid,
            aoch.area_code,
            aoch.city_code,
            aoch.place_code
           FROM (adr adr_1
             JOIN ao_last_ver aoch ON ((adr_1.ao_guid = aoch.parent_guid)))
        )
 SELECT adr.id,
    adr.ao_id,
    adr.ao_guid,
    adr.top_ao_guid,
    adr.name,
    adr.ao_level,
    adr.start_date,
    adr.end_date,
    adr.level,
    adr.parent_guid,
    adr.area_code,
    adr.city_code,
    adr.place_code
   FROM adr;

COMMENT ON MATERIALIZED VIEW fdc_as_addrobj_hierarchy_mv IS 'Иерархия адресов ФИАС по уровням ao_level, начиная с уровнями 3,4,6';

