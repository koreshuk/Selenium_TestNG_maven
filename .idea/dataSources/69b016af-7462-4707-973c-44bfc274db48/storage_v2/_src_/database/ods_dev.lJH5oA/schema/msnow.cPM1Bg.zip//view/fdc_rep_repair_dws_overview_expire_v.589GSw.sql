CREATE VIEW fdc_rep_repair_dws_overview_expire_v AS
  WITH milling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_milling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), levelling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_levelling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), asph AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_asphalt AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), rside AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_roadside AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), f AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 20))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN levelling ON ((ssch.driveway_segment_id = levelling.driveway_segment_id)))
        ), b AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 50))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN asph ON ((ssch.driveway_segment_id = asph.driveway_segment_id)))
        ), a AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 15))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN rside ON ((ssch.driveway_segment_id = rside.driveway_segment_id)))
        ), e AS (
         SELECT ssch.driveway_segment_id,
            (((COALESCE(round((((ssch.end_date_plan + 1) - ssch.start_date_plan))::double precision), (0)::double precision) - (COALESCE(a.day_cnt, (0)::numeric))::double precision) - (COALESCE(f.day_cnt, (0)::numeric))::double precision) - (COALESCE(b.day_cnt, (0)::numeric))::double precision) AS day_cnt
           FROM ((((msnow.fdc_work_schedule ssch
             JOIN milling ON ((ssch.driveway_segment_id = milling.driveway_segment_id)))
             LEFT JOIN a ON ((ssch.driveway_segment_id = a.driveway_segment_id)))
             LEFT JOIN f ON ((ssch.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((ssch.driveway_segment_id = b.driveway_segment_id)))
        ), dates AS (
         SELECT sagre.driveway_segment_id,
            (
                CASE
                    WHEN swt.is_milling THEN 'Работы по фрезерованию'::text
                    WHEN swt.is_levelling THEN 'Работы по устройству выравнивающего слоя'::text
                    WHEN swt.is_asphalt THEN 'Работы по укладке асфальтобетона'::text
                    WHEN swt.is_roadside THEN 'Работы по обустройству обочин'::text
                    ELSE NULL::text
                END)::character varying(255) AS work_type_name,
            max(GREATEST(
                CASE
                    WHEN wex.is_last_work THEN date(wex.work_date)
                    ELSE NULL::date
                END,
                CASE
                    WHEN ajrn.is_last_work THEN ajrn.work_date
                    ELSE NULL::date
                END)) AS end_date_fact,
            max(
                CASE
                    WHEN swt.is_milling THEN GREATEST(((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer),
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        ELSE sch.start_date_plan
                    END)
                    WHEN swt.is_levelling THEN GREATEST(((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer),
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        ELSE (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                    END)
                    WHEN swt.is_asphalt THEN ((((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer)
                    WHEN swt.is_roadside THEN sch.end_date_plan
                    ELSE NULL::date
                END) AS end_date_plan
           FROM ((((((((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
             LEFT JOIN msnow.fdc_work_execute wex ON (((wex.driveway_segment_id = sagre.driveway_segment_id) AND (wex.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((ajrn.driveway_segment_id = sagre.driveway_segment_id) AND (ajrn.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_work_schedule sch ON ((sagre.driveway_segment_id = sch.driveway_segment_id)))
             LEFT JOIN e ON ((sagre.driveway_segment_id = e.driveway_segment_id)))
             LEFT JOIN f ON ((sagre.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((sagre.driveway_segment_id = b.driveway_segment_id)))
          WHERE (NOT swt.is_additional_work)
          GROUP BY sagre.driveway_segment_id,
                CASE
                    WHEN swt.is_milling THEN 'Работы по фрезерованию'::text
                    WHEN swt.is_levelling THEN 'Работы по устройству выравнивающего слоя'::text
                    WHEN swt.is_asphalt THEN 'Работы по укладке асфальтобетона'::text
                    WHEN swt.is_roadside THEN 'Работы по обустройству обочин'::text
                    ELSE NULL::text
                END
        ), dates_flag AS (
         SELECT dates.driveway_segment_id,
                CASE
                    WHEN (max((dates.end_date_fact - dates.end_date_plan)) > 0) THEN max((dates.end_date_fact - dates.end_date_plan))
                    WHEN (max(dates.end_date_fact) IS NULL) THEN
                    CASE
                        WHEN (max((('now'::text)::date - dates.end_date_plan)) > 0) THEN max((('now'::text)::date - dates.end_date_plan))
                        ELSE 0
                    END
                    ELSE 0
                END AS expiration_days
           FROM dates
          GROUP BY dates.driveway_segment_id
        )
 SELECT dws.id,
        CASE
            WHEN (dates_flag.driveway_segment_id IS NOT NULL) THEN dates_flag.expiration_days
            ELSE GREATEST((COALESCE(wsch.end_date_fact, ('now'::text)::date) - wsch.end_date_plan), 0)
        END AS expiration_days
   FROM (((msnow.fdc_driveway_segment dws
     JOIN msnow.fdc_dw_segment_status dwss ON ((dws.status_id = dwss.id)))
     JOIN msnow.fdc_work_schedule wsch ON ((dws.id = wsch.driveway_segment_id)))
     LEFT JOIN dates_flag ON ((dws.id = dates_flag.driveway_segment_id)))
  WHERE (((dwss.code)::text <> ALL ((ARRAY['FUTURE_PLANNED'::character varying, 'ON_VOTE'::character varying, 'ESTIMATED_RESULT'::character varying])::text[])) AND (wsch.start_date_plan IS NOT NULL) AND (wsch.end_date_plan IS NOT NULL));

COMMENT ON VIEW fdc_rep_repair_dws_overview_expire_v IS 'Дней просрочки плана работ. Рассчитывается аналогично msnow.fdc_dw_segment_monitor_a_v';

