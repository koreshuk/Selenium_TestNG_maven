CREATE FUNCTION fdc_object_pck_get_object(p_object_id bigint, p_object_update_date timestamp without time zone)
  RETURNS fdc_object
LANGUAGE plpgsql
AS $$
declare
  /**
  Получить Объект ОДТИ
  %param      p_object_id    ИД версии объекта
  %param      p_update_date  Дата обновления записи
  %return     Строка объекта ОДТИ
  */
  l_object ods.fdc_object;
begin
  select o.*
    into strict l_object
    from ods.fdc_object o
   where o.id = p_object_id
     and (p_object_update_date is null or COALESCE(o.update_date,to_date('01.01.1900','dd.mm.yyyy'))<=p_object_update_date);

  return l_object;

exception
  when no_data_found then
    select o.*
      into l_object
      from ods.fdc_object o
     where o.id = p_object_id;

    raise exception 'Версия объекта не актуальна. ID=%, дата %, сохраненная дата %',p_object_id,to_char(p_object_update_date,'dd.mm.yyyy hh24:mi:ss'),to_char(l_object.update_date,'dd.mm.yyyy hh24:mi:ss');
end
$$;

