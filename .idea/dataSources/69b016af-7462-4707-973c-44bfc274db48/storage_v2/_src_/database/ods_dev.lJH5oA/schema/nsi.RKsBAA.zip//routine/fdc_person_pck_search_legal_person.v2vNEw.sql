CREATE FUNCTION fdc_person_pck_search_legal_person(p_root_id bigint DEFAULT NULL::bigint, p_code character varying DEFAULT NULL::character varying, p_anyname character varying DEFAULT NULL::character varying, p_name character varying DEFAULT NULL::character varying, p_short_name character varying DEFAULT NULL::character varying, p_inn character varying DEFAULT NULL::character varying, p_ogrn character varying DEFAULT NULL::character varying, p_kpp character varying DEFAULT NULL::character varying, p_okpo character varying DEFAULT NULL::character varying, p_is_ip boolean DEFAULT NULL::boolean, p_legal_address character varying DEFAULT NULL::character varying, p_data_state bigint DEFAULT NULL::bigint, p_role_id_tab bigint[] DEFAULT NULL::bigint[], p_okved_id bigint DEFAULT NULL::bigint)
  RETURNS SETOF nsi.t_legal_person
LANGUAGE plpgsql
AS $$
declare
  l_anyname       nsi.fdc_legal_person.name%type := '%'||lower(replace(trim(p_anyname),' ','%'))||'%';
  l_name          nsi.fdc_legal_person.name%type := '%'||lower(replace(trim(p_name),' ','%'))||'%';
  l_short_name    nsi.fdc_legal_person.name%type := '%'||lower(replace(trim(p_short_name),' ','%'))||'%';
  l_legal_address nsi.fdc_legal_person.legal_address%type := '%'||lower(replace(trim(p_legal_address),' ','%'))||'%';
  l_code          nsi.fdc_person.code%type       := '%'||lower(trim(p_code))||'%';
  l_sysdate       timestamp := current_timestamp;
begin
  /** Осуществляет простой и расширенный поиск ЮЛ по параметрам
  %usage В форме поиск Юридических лиц
  %param p_root_id         - Идентификатор НСИ организации
  %param p_code            - Код АС УР
  %param p_anyname         - Поиск по полному или краткому наименованию
  %param p_name            - Наименование организации
  %param p_short_name      - Краткое наименование
  %param p_inn             - ИНН
  %param p_ogrn            - ОГРН
  %param p_kpp             - КПП
  %param p_okpo            - ОКПО
  %param p_is_IP           - Признак ИП
  %param p_legal_address   - Юридический адрес
  %param p_data_state      -- Состояние данных (fdc_legal_person_data_state_v)
  %param p_role_id_tab     -- список ролей
  %param p_okved_id        -- Ид ОКВЕД
  %return t_legal_person_tab
  */
  return query select l.id::bigint
                     ,l.root_id::bigint
                     ,l.code::varchar(38)
                     ,l.name::varchar(1024)
                     ,l.short_name::varchar(512)
                     ,l.inn::varchar(12)
                     ,l.kpp::varchar(9)
                     ,l.ogrn::varchar(15)
                     ,l.okpo::varchar(10)
                     ,l.account::varchar(20)
                     ,l.postal_address::varchar(512)
                     ,l.legal_address::varchar(512)
                     ,l.email::varchar(64)
                     ,l.phone::varchar(64)
                     ,l.fax::varchar(64)
                     ,l.off_post::varchar(255)
                     ,l.off_name::varchar(255)
                     ,l.bik::varchar(20)
                     ,l.bank::varchar(255)
                     ,case
                        when l.person_type_id = nsi.c_sl_branch() then true
                        else false
                      end is_filial
                     ,l.data_state_id::bigint
                     ,l.data_state::varchar(255)
                     ,l.fns_sync_date::timestamp
                     ,l.fns_validate::boolean
                 from nsi.fdc_legal_person_card_v l
                where (p_root_id is null or l.root_id=p_root_id)
                  and (p_code is null or lower(trim(l.code)) like l_code)
                  and (p_anyname is null or lower(trim(l.name)) like l_anyname or lower(trim(l.short_name)) like l_anyname)
                  and (p_name is null or lower(trim(l.name)) like l_name)
                  and (p_short_name is null or lower(trim(l.short_name)) like l_short_name)
                  and (p_legal_address is null or lower(trim(l.legal_address)) like l_legal_address)
                  and (p_ogrn is null or l.ogrn=p_ogrn)
                  and (p_inn is null or l.inn=p_inn)
                  and (p_kpp is null or l.kpp=p_kpp)
                  and (p_okpo is null or l.okpo=p_okpo)
                  and (p_data_state is null or l.data_state_id = p_data_state)
                  and (
                       (p_is_ip is null and l.person_type_id in (nsi.c_sl_organization(), nsi.c_sl_branch(), nsi.c_sl_declarant())) or
                       (p_is_ip and l.person_type_id =   nsi.c_sl_declarant()) or
                       (not p_is_ip and l.person_type_id in (nsi.c_sl_organization(), nsi.c_sl_branch()))
                      )
                  and (p_role_id_tab is null or exists(select 1
                                                        from nsi.fdc_person_role pr
                                                            ,unnest(p_role_id_tab) rl
                                                       where pr.role_id = rl
                                                         and pr.person_id = l.root_id --<<-- по сковозному ид орг
                                                         and pr.begin_date <= l_sysdate
                                                         and pr.end_date >= l_sysdate
                                                     )
                      )
                  and (p_okved_id is null or l.okved_id = p_okved_id)
                  and (
                       (l_sysdate between l.ver_start_date and l.ver_end_date)
                       or
                       (p_data_state = 3 and l.data_state_id = p_data_state and l.end_date is not null)
                      );
  return;
end
$$;

