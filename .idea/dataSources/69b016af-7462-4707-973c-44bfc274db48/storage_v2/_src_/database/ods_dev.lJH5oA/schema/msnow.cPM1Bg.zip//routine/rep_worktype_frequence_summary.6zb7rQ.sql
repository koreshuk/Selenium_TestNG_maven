CREATE FUNCTION rep_worktype_frequence_summary(p_date_from date, p_date_to date, p_driveway_category_id bigint, p_customer_id bigint DEFAULT NULL::bigint, p_work_category_id bigint DEFAULT NULL::bigint, p_season_id bigint DEFAULT NULL::bigint, p_work_type_id bigint DEFAULT NULL::bigint, OUT customer_short_name text, OUT work_type_name text, OUT measure_unit_name text, OUT work_category_name text, OUT season_name text, OUT lsr_use_frequency integer, OUT average_rate double precision)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
declare
  /* Отчет Справка о частоте использования вдов работ и действующих расценок
  %param p_date_from date        - Дата с
  %param p_date_to date          - Дата по
  %param p_driveway_category_id  - Балансовая принадлежность
  %param p_customer_id           - Заказчик
  %param p_work_category_id      - Категория работ
  %param p_season_id             - Сезон
  %param p_work_type_id          - Вид работ

  %return customer_short_name    - Муниц. район/городской округ (Заказчик)
  %return work_type_name         - Вид работ
  %return measure_unit_name      - Единица измерения
  %return work_category_name     - Категория работ
  %return season_name            - Сезон
  %return lsr_use_frequency      - Частота использования в ЛСР
  %return average_rate           - Средняя расценка за ед. объема работ, руб

  */
begin
  return query
      with cust as(select lp.id as customer_id
                         ,lp.root_id as customer_root_id
                         ,lp.fias_district_id
                         ,lp.short_name as customer_short_name
                     from nsi.fdc_legal_person lp
                     join nsi.fdc_person_role pr on lp.root_id=pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where lp.person_type_id in(1,3)
                      and p_date_to >= lp.ver_start_date
                      and p_date_from<=lp.ver_end_date
                      and p_date_to >= pr.begin_date
                      and p_date_from<=pr.end_date
                      and r.code='CUSTOMER'
                      and (p_customer_id is null or lp.id=p_customer_id)
                  )
          ,omsu as(select cust.customer_id
                         ,cust.customer_root_id
                         ,cust.customer_short_name
                         ,cust.fias_district_id
                         ,cust.customer_root_id as omsu_root_id
                     from cust
                     join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                     join nsi.fdc_role r on pr.role_id=r.id
                    where r.code='OMSU'
                  )
          ,rcust as(select cust.customer_id -- Заказчики
                          ,cust.customer_root_id
                          ,cust.customer_short_name
                          ,cust.customer_root_id as omsu_root_id
                      from cust
                      join nsi.fdc_person_role pr on cust.customer_root_id = pr.person_id
                      join nsi.fdc_role r on pr.role_id=r.id
                     where r.code='RUAD'
                       and p_driveway_category_id = 2
                       and p_customer_id is null
                    union
                    select omsu.customer_id
                          ,omsu.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from omsu
                     where p_driveway_category_id = 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,omsu.customer_short_name
                          ,omsu.omsu_root_id
                      from cust
                      join omsu on cust.fias_district_id=omsu.fias_district_id
                     where cust.fias_district_id is not null
                       and cust.customer_root_id not in(select pr.person_id
                                                          from nsi.fdc_person_role pr
                                                          join nsi.fdc_role r on pr.role_id=r.id
                                                         where r.code in('OMSU','RUAD','MA','TO','KO')
                                                       )
                       and p_driveway_category_id= 1
                       and p_customer_id is null
                    union
                    select cust.customer_id
                          ,cust.customer_root_id
                          ,case
                             when omsu.customer_id is not null then omsu.customer_short_name
                             else cust.customer_short_name
                           end
                          ,case
                             when omsu.customer_id is not null then omsu.omsu_root_id
                             else cust.customer_root_id
                           end omsu_root_id
                      from cust
                      left join omsu on cust.customer_id=omsu.customer_id
                     where p_customer_id is not null
                   )
          ,wtype as(select wt.id as work_type_id
                      from msnow.fdc_work_type wt
                     where wt.organization_id is null
                       and (p_work_category_id is null or wt.work_category_id=p_work_category_id)
                       and (p_season_id is null or wt.season_id=p_season_id)
                       and p_work_type_id is null
                    union
                    select wt.work_type_uni_id as work_type_id
                      from msnow.fdc_work_type wt
                     where wt.organization_id is null
                       and (p_work_category_id is null or wt.work_category_id=p_work_category_id)
                       and (p_season_id is null or wt.season_id=p_season_id)
                       and p_work_type_id  is null
                    union
                    select wt.id as work_type_id
                      from msnow.fdc_work_type wt
                     where wt.id=p_work_type_id
                   )
          ,agrm as(select distinct on(agr.agr_root_id)
                          agr.agr_root_id as agreement_root_id
                         ,agr.id as agreement_id
                         ,agre.work_type_id
                         ,wt.name as work_type_name
                         ,mu.name as measure_unit_name
                         ,wc.name as work_category_name
                         ,s.name as season_name
                         ,rcust.customer_short_name
                         ,case
                            when agre.work_volume <> 0.0 then
                              agre.work_cost / agre.work_volume
                            else 0
                          end as rate
                     from msnow.fdc_agreement agr
                     join msnow.fdc_agreement_obligation_status agrs on agr.agreement_status_id=agrs.id
                     join rcust on agr.customer_id=rcust.customer_root_id
                     join msnow.fdc_agr_estimate agre on agr.id=agre.agreement_id
                     join wtype on agre.work_type_id=wtype.work_type_id
                     join msnow.fdc_work_type wt on wtype.work_type_id=wt.id
                     join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                     join msnow.fdc_work_category wc on wt.work_category_id=wc.id
                     join msnow.fdc_season s on wt.season_id=s.id
                    where agrs.code='APPROVED'
                      and p_date_to >= agr.version_date_from
                      and p_date_from<=agr.version_date_to
                      and agre.is_estimate_sum
                    order by agr.agr_root_id
                            ,agr.version_date_from desc
                            ,agr.version_date_to desc
                  )
          ,obl as(select o.id as obligation_id
                        ,oest.work_type_id
                        ,wt.name as work_type_name
                        ,mu.name as measure_unit_name
                        ,wc.name as work_category_name
                        ,s.name as season_name
                        ,rcust.customer_short_name
                        ,case
                           when oest.work_volume <> 0.0 then
                             oest.work_cost / oest.work_volume
                           else 0
                         end as rate
                    from msnow.fdc_obligation o
                    join msnow.fdc_agreement_obligation_status ost on o.obligation_status_id=ost.id
                    join rcust on o.authority_org_id=rcust.customer_root_id
                    join msnow.fdc_obligation_estimate oest on o.id=oest.obligation_id
                    join wtype on oest.work_type_id=wtype.work_type_id
                    join msnow.fdc_work_type wt on wtype.work_type_id=wt.id
                    join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                    join msnow.fdc_work_category wc on wt.work_category_id=wc.id
                    join msnow.fdc_season s on wt.season_id=s.id
                  where ost.code='APPROVED'
                    and oest.is_estimate_sum
                 )
          ,purch as(select p.id as purchase_id
                        ,pest.work_type_id
                        ,wt.name as work_type_name
                        ,mu.name as measure_unit_name
                        ,wc.name as work_category_name
                        ,s.name as season_name
                        ,rcust.customer_short_name
                        ,case
                           when pest.work_volume <> 0.0 then
                             pest.work_cost / pest.work_volume
                           else 0
                         end as rate
                    from msnow.fdc_purchase p
                    join rcust on p.customer_id=rcust.customer_root_id
                    join msnow.fdc_purchase_estimate pest on p.id=pest.purchase_lot_id
                    join wtype on pest.work_type_id=wtype.work_type_id
                    join msnow.fdc_work_type wt on wtype.work_type_id=wt.id
                    join msnow.fdc_measure_unit mu on wt.measure_unit_id=mu.id
                    join msnow.fdc_work_category wc on wt.work_category_id=wc.id
                    join msnow.fdc_season s on wt.season_id=s.id
                  where pest.is_estimate_sum
                 )

       select agg.customer_short_name::text
             ,agg.work_type_name::text
             ,agg.measure_unit_name::text
             ,agg.work_category_name::text
             ,agg.season_name::text
             ,count(distinct agg.lsr_id)::integer as lsr_use_frequency
             ,round(avg(agg.rate)::numeric,3)::double precision  as average_rate
         from (select agrm.agreement_root_id as lsr_id --
                     ,agrm.customer_short_name
                     ,agrm.work_type_name
                     ,agrm.measure_unit_name
                     ,agrm.work_category_name
                     ,agrm.season_name
                     ,agrm.rate
                 from agrm
               union
               select obl.obligation_id as lsr_id --
                     ,obl.customer_short_name
                     ,obl.work_type_name
                     ,obl.measure_unit_name
                     ,obl.work_category_name
                     ,obl.season_name
                     ,obl.rate
                 from obl
               union
               select purch.purchase_id as lsr_id --
                     ,purch.customer_short_name
                     ,purch.work_type_name
                     ,purch.measure_unit_name
                     ,purch.work_category_name
                     ,purch.season_name
                     ,purch.rate
                 from purch
              ) agg
        group by agg.customer_short_name
                ,agg.work_type_name
                ,agg.measure_unit_name
                ,agg.work_category_name
                ,agg.season_name;
  return;
end
$$;

