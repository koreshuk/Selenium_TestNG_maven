CREATE VIEW rep_repair_operational_agg_v AS
  SELECT
        CASE GROUPING(rep_repair_operational_v.driveway_category)
            WHEN 0 THEN rep_repair_operational_v.driveway_category
            ELSE 'Итого'::text
        END AS driveway_category,
    (COALESCE(sum((rep_repair_operational_v.planed_work_yesterday_qty)::numeric), (0)::numeric))::bigint AS planed_work_yesterday_qty,
    (round(COALESCE(sum((rep_repair_operational_v.planed_work_yesterday_vol)::numeric), 0.0), 2))::double precision AS planed_work_yesterday_vol,
    (COALESCE(sum((rep_repair_operational_v.planed_work_today_qty)::numeric), (0)::numeric))::bigint AS planed_work_today_qty,
    (round(COALESCE(sum((rep_repair_operational_v.planed_work_today_vol)::numeric), 0.0), 2))::double precision AS planed_work_today_vol,
    count(DISTINCT rep_repair_operational_v.driveway_segment_id) AS driveway_segment_id,
    (round(COALESCE(sum((rep_repair_operational_v.asphalt_area_vol)::numeric), 0.0), 2))::double precision AS asphalt_area_vol,
    count(DISTINCT rep_repair_operational_v.inwork_plan_qty) AS inwork_plan_qty,
    (round(COALESCE(sum((rep_repair_operational_v.inwork_plan_vol)::numeric), 0.0), 2))::double precision AS inwork_plan_vol,
    count(DISTINCT rep_repair_operational_v.inwork_qty) AS inwork_qty,
    (round(COALESCE(sum((rep_repair_operational_v.inwork_vol)::numeric), 0.0), 2))::double precision AS inwork_vol,
    count(DISTINCT rep_repair_operational_v.complete_plan_qty) AS complete_plan_qty,
    (round(COALESCE(sum((rep_repair_operational_v.complete_plan_vol)::numeric), 0.0), 2))::double precision AS complete_plan_vol,
    count(DISTINCT rep_repair_operational_v.closed_works_qty) AS closed_works_qty,
    (round(COALESCE(sum((rep_repair_operational_v.closed_works_vol)::numeric), 0.0), 2))::double precision AS closed_works_vol,
    count(DISTINCT rep_repair_operational_v.closed_yesterday_qty) AS closed_yesterday_qty,
    (round(COALESCE(sum((rep_repair_operational_v.closed_yesterday_vol)::numeric), 0.0), 2))::double precision AS closed_yesterday_vol,
    count(DISTINCT rep_repair_operational_v.inwork_today_qty) AS inwork_today_qty,
    (round(COALESCE(sum((rep_repair_operational_v.inwork_today_vol)::numeric), 0.0), 2))::double precision AS inwork_today_vol
   FROM msnow.rep_repair_operational_v
  GROUP BY ROLLUP(rep_repair_operational_v.driveway_category);

COMMENT ON VIEW rep_repair_operational_agg_v IS 'Оперативная сводка по ремонту (агрегированная таблица)';

COMMENT ON COLUMN rep_repair_operational_agg_v.driveway_category IS 'Сеть';

COMMENT ON COLUMN rep_repair_operational_agg_v.planed_work_yesterday_qty IS 'Итог за день (вчера)(план)';

COMMENT ON COLUMN rep_repair_operational_agg_v.planed_work_yesterday_vol IS 'Итог за день (вчера)(план), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.planed_work_today_qty IS 'В работе сегодня(план)';

COMMENT ON COLUMN rep_repair_operational_agg_v.planed_work_today_vol IS 'В работе сегодня(план), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.driveway_segment_id IS 'План на 2017';

COMMENT ON COLUMN rep_repair_operational_agg_v.asphalt_area_vol IS 'План на 2017, тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.inwork_plan_qty IS 'Начали работы(план)';

COMMENT ON COLUMN rep_repair_operational_agg_v.inwork_plan_vol IS 'Начали работы(план), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.inwork_qty IS 'Начали работы(факт)';

COMMENT ON COLUMN rep_repair_operational_agg_v.inwork_vol IS 'Начали работы(факт), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.complete_plan_qty IS 'Завершены работы(уложен асфальт)(план)';

COMMENT ON COLUMN rep_repair_operational_agg_v.complete_plan_vol IS 'Завершены работы(уложен асфальт)(план), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.closed_works_qty IS 'Завершены работы(уложен асфальт)(факт)';

COMMENT ON COLUMN rep_repair_operational_agg_v.closed_works_vol IS 'Завершены работы(уложен асфальт)(факт), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.closed_yesterday_qty IS 'Итог за день (вчера)(факт)';

COMMENT ON COLUMN rep_repair_operational_agg_v.closed_yesterday_vol IS 'Итог за день (вчера)(факт), тыс. кв. км';

COMMENT ON COLUMN rep_repair_operational_agg_v.inwork_today_qty IS 'В работе сегодня(факт выхода)';

COMMENT ON COLUMN rep_repair_operational_agg_v.inwork_today_vol IS 'В работе сегодня(факт выхода), тыс. кв. км';

