CREATE VIEW rep_driveway_odh_cust_v AS
  SELECT dt.dt AS report_date,
    dwc.dwc AS driveway_category_id,
    f.customer_name,
    f.object_id AS id,
    f.stat_axes_length,
    f.internal_area,
    f.roadway_area,
    f.footway_area,
    f.cleaning_area
   FROM ((generate_series(1, 2) dwc(dwc)
     JOIN generate_series((('now'::text)::date - '1 year'::interval year), (('now'::text)::date)::timestamp without time zone, '1 day'::interval) dt(dt) ON (true))
     JOIN LATERAL rep_driveway_odh_cust(p_report_date => (dt.dt)::date, p_driveway_category_id => (dwc.dwc)::bigint) f(customer_name, object_id, stat_axes_length, internal_area, roadway_area, footway_area, cleaning_area) ON (true));

COMMENT ON VIEW rep_driveway_odh_cust_v IS 'Сводка по паспортам АД в разрезе заказчиков';

COMMENT ON COLUMN rep_driveway_odh_cust_v.report_date IS 'Дата отчета';

COMMENT ON COLUMN rep_driveway_odh_cust_v.driveway_category_id IS 'Ид балансовой принадлежности';

COMMENT ON COLUMN rep_driveway_odh_cust_v.customer_name IS 'Наименование заказчика';

COMMENT ON COLUMN rep_driveway_odh_cust_v.id IS 'Ид участка ОДХ';

COMMENT ON COLUMN rep_driveway_odh_cust_v.stat_axes_length IS 'Протяженность по пикетажам';

COMMENT ON COLUMN rep_driveway_odh_cust_v.internal_area IS 'Площадь дороги, тыс.м2';

COMMENT ON COLUMN rep_driveway_odh_cust_v.roadway_area IS 'Площадь проезжей части, тыс.м2';

COMMENT ON COLUMN rep_driveway_odh_cust_v.footway_area IS 'Площадь тротуаров, тыс.м2';

COMMENT ON COLUMN rep_driveway_odh_cust_v.cleaning_area IS 'Площадь уборки, тыс.м2';

