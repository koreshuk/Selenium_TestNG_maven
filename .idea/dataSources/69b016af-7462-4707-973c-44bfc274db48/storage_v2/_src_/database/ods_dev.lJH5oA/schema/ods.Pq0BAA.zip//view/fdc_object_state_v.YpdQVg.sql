CREATE VIEW fdc_object_state_v AS
  SELECT t1.id,
    t1.code,
    t1.name
   FROM fdc_object_state t1;

COMMENT ON VIEW fdc_object_state_v IS 'Справочник Статус ОГХ';

COMMENT ON COLUMN fdc_object_state_v.id IS 'Ид статуса ОГХ';

COMMENT ON COLUMN fdc_object_state_v.code IS 'Код статуса ОГХ';

COMMENT ON COLUMN fdc_object_state_v.name IS 'Наименование статуса ОГХ';

