CREATE FUNCTION c_os_approved()
  RETURNS bigint
IMMUTABLE
COST 1
LANGUAGE SQL
AS $$
select 3::bigint;
$$;

