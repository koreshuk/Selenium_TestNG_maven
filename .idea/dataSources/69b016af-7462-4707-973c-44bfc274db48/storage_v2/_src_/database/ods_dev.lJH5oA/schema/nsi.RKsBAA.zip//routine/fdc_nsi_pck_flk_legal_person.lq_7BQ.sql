CREATE FUNCTION fdc_nsi_pck_flk_legal_person(p_code character varying, p_person_type_id bigint, p_root_id bigint, p_name character varying, p_short_name character varying, p_inn character varying, p_ogrn character varying, p_okpo character varying, p_kpp character varying, p_email character varying, p_bik character varying, p_account character varying, p_parent_id bigint, p_event_id bigint DEFAULT NULL::bigint)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Процедура проводит проверку ФКЛ организации (ЮЛ, ИП и Структырные подразделения)
  %usage Используется в fdc_person_pck.create_version
  %param p_event_id        - ID события
  %param p_code            - код в асур
  %param p_person_type_id  - Ид типа субъекта
  %param p_root_id         - Ид организации
  %param p_name            - наименование
  %param p_short_name      - короткое наименование
  %param p_inn             - ИНН
  %param p_ogrn            - ОГРН
  %param p_okpo            - ОКПО
  %param p_kpp             - КПП
  %param p_email           - адрес электронной почты
  %param p_bik             - БИК
  %param p_account         - Расчетный счет
  %param p_parent_id       - Ид головной организации для филиалов
  */
  l_exists integer;
begin
  -- проверки
  if p_person_type_id = nsi.c_sl_branch() and p_parent_id is null then
    raise exception 'Не указан Ид головной организации';
  elsif p_person_type_id is null then
    raise exception 'Не указан Тип субъекта';
  end if;
  if p_name is null then
    raise exception 'Не указано Наименование';
  end if;
  if p_short_name is null then
    raise exception 'Не указано Краткое наименование';
  end if;
  if p_inn is null then
    raise exception 'Не указан ИНН';
  end if;

  if not nsi.fdc_nsi_pck_is_inn_correct(p_inn            => p_inn
                                       ,p_event_id       => p_event_id
                                       ,p_person_type_id => p_person_type_id
                                       ) then
    raise exception 'Код ИНН не прошел проверку на корректность.';
  end if;
  if not nsi.fdc_nsi_pck_is_ogrn_correct(p_ogrn           => p_ogrn
                                        ,p_event_id       => p_event_id
                                        ,p_person_type_id => p_person_type_id
                                        ) then
    raise exception 'Код ОГРН не прошел проверку на корректность.';
  end if;
  if not nsi.fdc_nsi_pck_is_okpo_correct(p_okpo           => p_okpo
                                        ,p_event_id       => p_event_id
                                        ,p_person_type_id => p_person_type_id
                                        ) then
    raise exception 'Код ОКПО не прошел проверку на корректность.';
  end if;

  if p_kpp is not null and not nsi.fdc_nsi_pck_is_kpp_correct(p_kpp) then
    raise exception 'КПП должно состоять из 9 цифр';
  end if;
  if p_email is not null and not nsi.fdc_nsi_pck_is_email_correct(p_email) then
    raise exception 'E-MAIL имеет неверный формат';
  end if;
  if p_bik is not null and not nsi.fdc_nsi_pck_is_bik_correct(p_bik) then
    raise exception 'БИК должно состоять из 9 цифр';
  end if;
  if p_account is not null and not nsi.fdc_nsi_pck_is_account_correct(p_account) then
    raise exception 'РАСЧЕТНЫЙ СЧЕТ должно состоять из 20 цифр';
  end if;

  -- Если не филиал, то проверяем уникальность
  if p_person_type_id <> nsi.c_sl_branch() then
    select count(1)
      into l_exists
      from nsi.fdc_person_version_v l
     where l.code = p_code
       and l.root_id <> coalesce(p_root_id, -1) -- когда запись новая -1
       and l.ver_end_date is null;
    if l_exists>0 then
      raise exception 'Субъект с таким значением кода АСУР уже существует';
    end if;
    --if p_person_type_id != const.c_sl_branch then
    select count(1)
      into l_exists
      from nsi.fdc_person_version_v lp
     where lp.inn = p_inn
       and (lp.root_id <> p_root_id or p_root_id is null)
       and lp.person_type_id not in (nsi.c_sl_branch()
                                    ,nsi.c_sl_private()
                                    ,nsi.c_sl_employee()
                                    ) -- != const.c_sl_branch--= p_person_type_id
       and lp.ver_end_date is null;
    if l_exists>0 then
      raise exception 'Субъект с таким значением «ИНН» уже существует';
    end if;
    select count(1)
      into l_exists
      from nsi.fdc_person_version_v lp
     where lp.ogrn = p_ogrn
       and (lp.root_id <> p_root_id or p_root_id is null)
       and lp.person_type_id <> nsi.c_sl_branch()--= p_person_type_id
       and lp.ver_end_date is null;
    if l_exists>0 then
      raise exception 'Субъект с таким значением «ОГРН» уже существует';
    end if;
    --end if; -- филиал
  end if;
end
$$;

