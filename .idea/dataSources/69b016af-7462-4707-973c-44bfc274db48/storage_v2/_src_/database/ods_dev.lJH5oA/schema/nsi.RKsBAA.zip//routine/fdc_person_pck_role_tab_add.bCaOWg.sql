CREATE FUNCTION fdc_person_pck_role_tab_add(p_id bigint, p_person_role_tab bigint[], p_start_date timestamp without time zone)
  RETURNS void
LANGUAGE plpgsql
AS $$
declare
  /** Процедура добавления ролей
  %usage Используется внутри пакета
  %param p_id Ид субъекта
  %param p_person_role_tab Список ид ролей
  %param p_start_date Дата начала действия
  */
begin
  null;
end
$$;

