CREATE FUNCTION fdc_odh_pck_add_odh(p_object t_object, p_attribute fdc_odh, p_object_address_tab t_object_address[], p_object_piquetage_tab t_object_piquetage[], p_biz_event_id bigint DEFAULT NULL::bigint)
  RETURNS bigint
LANGUAGE plpgsql
AS $$
declare
  /** Функция добавления объекта Объект дорожного хозяйства
  %param     p_object                        Объект
  %param     p_attribute                     Атрибуты Объект
  %param     p_object_address_tab            Список адресов
  %param     p_object_piquetage_tab          Список параметров пикетажа
  %return    p_object_id               Ид объекта
  */
  l_object ods.t_object;
  l_object_id bigint;
begin
  l_object := p_object;
  if p_object.parent_version_id is not null then
    l_object_id := ods.fdc_odh_pck_create_project(p_object_id => l_object.parent_version_id
                                                 ,p_project_date => l_object.version_date_from
                                                 );
    l_object.id := l_object_id;

    l_object_id := ods.fdc_odh_pck_edit_odh(p_object => l_object
                                           ,p_attribute => p_attribute
                                           ,p_object_address_tab => p_object_address_tab
                                           ,p_object_piquetage_tab => p_object_piquetage_tab
                                           );
  else
    /* Геометрия и адреса БТИ пока не реализованы
    -- Геометрия приходит только в p_object
    p_attribute.geometry := p_object.geometry;
    */

    /* Проверим на наличие точно такого же объекта. Если уже есть - эксепшен с сообщением */
    /* Для системы ОДС эта проверка не выполняется.
    fdc_odh_pck.check_unique( l_object, p_attribute, p_object_address_tab);
    */

    /* Добавляем объект */
    l_object.id := ods.fdc_object_pck_add_object(p_object => l_object);

    /* Добавляем атрибуты */
    perform ods.fdc_odh_pck_update_obj_attribute_list(p_object_id      => l_object.id
                                                     ,p_attribute_tab  => p_attribute
                                                     ,p_prev_object_id => null
                                                     );

    perform ods.fdc_object_pck_add_object_address_list(p_object_id          => l_object.id
                                                      ,p_object_address_tab => p_object_address_tab
                                                      );
    perform ods.fdc_object_pck_add_object_piquetage_list(p_object_id            => l_object.id
                                                        ,p_object_piquetage_tab => p_object_piquetage_tab
                                                        );

    /* Обновляем название объекта в дереве*/
    perform ods.fdc_odh_pck_update_tree_name(p_object_id => l_object.id
                                            );
    /* Обновляем хэш-сумму объекта
      Пока хэширование не реализовано. Возможно будет выполняться в Java
    --fdc_object_pck.update_hash_sum( p_id => l_object.id, p_hash_sum => get_hash( l_object.id ));
    */
  end if;
  return l_object.id;
end
$$;

