CREATE VIEW fdc_dw_segment_monitor_a_v AS
  WITH milling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_milling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), levelling AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_levelling AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), asph AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_asphalt AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), rside AS (
         SELECT DISTINCT sagre.driveway_segment_id
           FROM ((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
          WHERE (swt.is_roadside AND (sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
        ), f AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 20))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN levelling ON ((ssch.driveway_segment_id = levelling.driveway_segment_id)))
        ), b AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 50))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN asph ON ((ssch.driveway_segment_id = asph.driveway_segment_id)))
        ), a AS (
         SELECT ssch.driveway_segment_id,
            COALESCE(round((((((ssch.end_date_plan + 1) - ssch.start_date_plan) * 15))::numeric / 100.0)), (0)::numeric) AS day_cnt
           FROM (msnow.fdc_work_schedule ssch
             JOIN rside ON ((ssch.driveway_segment_id = rside.driveway_segment_id)))
        ), e AS (
         SELECT ssch.driveway_segment_id,
            (((COALESCE(round((((ssch.end_date_plan + 1) - ssch.start_date_plan))::double precision), (0)::double precision) - (COALESCE(a.day_cnt, (0)::numeric))::double precision) - (COALESCE(f.day_cnt, (0)::numeric))::double precision) - (COALESCE(b.day_cnt, (0)::numeric))::double precision) AS day_cnt
           FROM ((((msnow.fdc_work_schedule ssch
             JOIN milling ON ((ssch.driveway_segment_id = milling.driveway_segment_id)))
             LEFT JOIN a ON ((ssch.driveway_segment_id = a.driveway_segment_id)))
             LEFT JOIN f ON ((ssch.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((ssch.driveway_segment_id = b.driveway_segment_id)))
        ), exeact AS (
         SELECT DISTINCT exa.driveway_segment_id
           FROM (msnow.fdc_execute_act exa
             JOIN msnow.fdc_execute_act_status exas ON ((exa.status_id = exas.id)))
          WHERE ((exas.code)::text = 'APPROVED'::text)
        ), docs AS (
         SELECT sagre.driveway_segment_id,
            sum(
                CASE
                    WHEN ((hid.id IS NOT NULL) AND (NOT swt.is_additional_work)) THEN 0
                    ELSE 1
                END) AS act_not_present,
            max(GREATEST(date(wex.work_date), ajrn.work_date)) AS end_date_fact,
            count(
                CASE
                    WHEN ((wex.id IS NULL) AND (ajrn.id IS NULL)) THEN sagre.driveway_segment_id
                    ELSE NULL::bigint
                END) AS end_date_fact_flag
           FROM (((((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
             LEFT JOIN msnow.fdc_hidden_work_act hid ON (((hid.driveway_segment_id = sagre.driveway_segment_id) AND (hid.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_work_execute wex ON (((wex.driveway_segment_id = sagre.driveway_segment_id) AND (wex.work_type_id = swt.id) AND wex.is_last_work)))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((ajrn.driveway_segment_id = sagre.driveway_segment_id) AND (ajrn.work_type_id = swt.id) AND ajrn.is_last_work)))
          WHERE ((sagre.driveway_segment_id IS NOT NULL) AND (NOT swt.is_additional_work))
          GROUP BY sagre.driveway_segment_id
        ), dates AS (
         SELECT sagre.driveway_segment_id,
            (
                CASE
                    WHEN swt.is_milling THEN 'Работы по фрезерованию'::text
                    WHEN swt.is_levelling THEN 'Работы по устройству выравнивающего слоя'::text
                    WHEN swt.is_asphalt THEN 'Работы по укладке асфальтобетона'::text
                    WHEN swt.is_roadside THEN 'Работы по обустройству обочин'::text
                    ELSE NULL::text
                END)::character varying(255) AS work_type_name,
            min(COALESCE(date(wex.work_date), ajrn.work_date)) AS start_date_fact,
            max(GREATEST(
                CASE
                    WHEN wex.is_last_work THEN date(wex.work_date)
                    ELSE NULL::date
                END,
                CASE
                    WHEN ajrn.is_last_work THEN ajrn.work_date
                    ELSE NULL::date
                END)) AS end_date_fact,
            max(
                CASE
                    WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                    WHEN swt.is_milling THEN sch.start_date_plan
                    WHEN swt.is_levelling THEN (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                    WHEN swt.is_asphalt THEN GREATEST(((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer), sch.start_date_plan)
                    WHEN swt.is_roadside THEN LEAST((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer), sch.end_date_plan)
                    ELSE NULL::date
                END) AS start_date_plan,
            max(
                CASE
                    WHEN swt.is_milling THEN GREATEST(((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer),
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        ELSE sch.start_date_plan
                    END)
                    WHEN swt.is_levelling THEN GREATEST(((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer),
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        ELSE (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                    END)
                    WHEN (swt.is_asphalt AND (rside.driveway_segment_id IS NOT NULL)) THEN ((((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer)
                    WHEN (swt.is_asphalt AND (rside.driveway_segment_id IS NULL)) THEN sch.end_date_plan
                    WHEN swt.is_roadside THEN sch.end_date_plan
                    ELSE NULL::date
                END) AS end_date_plan,
            sum(
                CASE
                    WHEN ((
                    CASE
                        WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                        WHEN swt.is_milling THEN sch.start_date_plan
                        WHEN swt.is_levelling THEN (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                        WHEN swt.is_asphalt THEN GREATEST(((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer), sch.start_date_plan)
                        WHEN swt.is_roadside THEN LEAST((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer), sch.end_date_plan)
                        ELSE NULL::date
                    END < COALESCE(COALESCE(date(wex.work_date), ajrn.work_date), ('now'::text)::date)) OR (
                    CASE
                        WHEN swt.is_milling THEN GREATEST(((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer),
                        CASE
                            WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                            ELSE sch.start_date_plan
                        END)
                        WHEN swt.is_levelling THEN GREATEST(((((sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer) - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer),
                        CASE
                            WHEN ((sch.start_date_plan IS NULL) OR (sch.end_date_plan IS NULL)) THEN NULL::date
                            ELSE (sch.start_date_plan + (COALESCE(e.day_cnt, (0)::double precision))::integer)
                        END)
                        WHEN swt.is_asphalt THEN ((((sch.start_date_plan - 1) + (COALESCE(e.day_cnt, (0)::double precision))::integer) + (COALESCE(f.day_cnt, (0)::numeric))::integer) + (COALESCE(b.day_cnt, (0)::numeric))::integer)
                        WHEN swt.is_roadside THEN sch.end_date_plan
                        ELSE NULL::date
                    END < COALESCE(
                    CASE
                        WHEN wex.is_last_work THEN date(wex.work_date)
                        WHEN ajrn.is_last_work THEN ajrn.work_date
                        ELSE NULL::date
                    END, ('now'::text)::date))) THEN 1
                    ELSE 0
                END) AS stage_delay_flag
           FROM (((((((((msnow.fdc_agreement sagr
             JOIN msnow.fdc_agr_estimate sagre ON ((sagr.id = sagre.agreement_id)))
             JOIN msnow.fdc_work_type swt ON ((sagre.work_type_id = swt.id)))
             LEFT JOIN msnow.fdc_work_execute wex ON (((wex.driveway_segment_id = sagre.driveway_segment_id) AND (wex.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_asphalt_journal ajrn ON (((ajrn.driveway_segment_id = sagre.driveway_segment_id) AND (ajrn.work_type_id = swt.id))))
             LEFT JOIN msnow.fdc_work_schedule sch ON ((sagre.driveway_segment_id = sch.driveway_segment_id)))
             LEFT JOIN e ON ((sagre.driveway_segment_id = e.driveway_segment_id)))
             LEFT JOIN f ON ((sagre.driveway_segment_id = f.driveway_segment_id)))
             LEFT JOIN b ON ((sagre.driveway_segment_id = b.driveway_segment_id)))
             LEFT JOIN rside ON ((sagre.driveway_segment_id = rside.driveway_segment_id)))
          WHERE (NOT swt.is_additional_work)
          GROUP BY sagre.driveway_segment_id,
                CASE
                    WHEN swt.is_milling THEN 'Работы по фрезерованию'::text
                    WHEN swt.is_levelling THEN 'Работы по устройству выравнивающего слоя'::text
                    WHEN swt.is_asphalt THEN 'Работы по укладке асфальтобетона'::text
                    WHEN swt.is_roadside THEN 'Работы по обустройству обочин'::text
                    ELSE NULL::text
                END
        ), dates_flag AS (
         SELECT dates.driveway_segment_id,
            max(
                CASE
                    WHEN (((dates.start_date_plan < ('now'::text)::date) AND (dates.start_date_fact IS NULL)) OR (dates.end_date_plan < dates.end_date_fact) OR ((dates.end_date_plan < ('now'::text)::date) AND (dates.end_date_fact IS NULL))) THEN 1
                    ELSE 0
                END) AS delay_flag,
                CASE
                    WHEN (max((dates.end_date_fact - dates.end_date_plan)) > 0) THEN max((dates.end_date_fact - dates.end_date_plan))
                    WHEN (max(dates.end_date_fact) IS NULL) THEN
                    CASE
                        WHEN (max((('now'::text)::date - dates.end_date_plan)) > 0) THEN max((('now'::text)::date - dates.end_date_plan))
                        ELSE 0
                    END
                    ELSE 0
                END AS expiration_days,
            sum(dates.stage_delay_flag) AS stage_delay_flag
           FROM dates
          GROUP BY dates.driveway_segment_id
        ), photo AS (
         SELECT DISTINCT ON (fagre.driveway_segment_id) fagre.driveway_segment_id,
            COALESCE(fwexp.file_id, fajrnp.file_id) AS photo_file_id
           FROM ((((((msnow.fdc_agreement fagr
             JOIN msnow.fdc_agr_estimate fagre ON ((fagr.id = fagre.agreement_id)))
             JOIN msnow.fdc_work_type fwt ON ((fagre.work_type_id = fwt.id)))
             LEFT JOIN msnow.fdc_work_execute fwex ON (((fwex.driveway_segment_id = fagre.driveway_segment_id) AND (fwex.work_type_id = fwt.id))))
             LEFT JOIN msnow.fdc_work_execute_photo fwexp ON ((fwex.id = fwexp.work_execute_id)))
             LEFT JOIN msnow.fdc_asphalt_journal fajrn ON (((fajrn.driveway_segment_id = fagre.driveway_segment_id) AND (fajrn.work_type_id = fwt.id))))
             LEFT JOIN msnow.fdc_asphalt_journal_photo fajrnp ON ((fajrn.id = fajrnp.asphalt_journal_id)))
          WHERE ((fagre.driveway_segment_id IS NOT NULL) AND (COALESCE(fwexp.file_id, fajrnp.file_id) IS NOT NULL) AND (NOT fwt.is_additional_work))
          ORDER BY fagre.driveway_segment_id, COALESCE(fwex.work_date, (fajrn.work_date)::timestamp without time zone) DESC NULLS LAST, COALESCE(fwexp.id, fajrnp.id) DESC NULLS LAST
        ), ingreg_fact AS (
         SELECT fdc_ingress_registration.driveway_segment_id,
            min(fdc_ingress_registration.registration_date) AS registration_date
           FROM msnow.fdc_ingress_registration
          WHERE ((fdc_ingress_registration.registration_date)::date = ('now'::text)::date)
          GROUP BY fdc_ingress_registration.driveway_segment_id
        )
 SELECT dws.id,
    dws.name,
    dwobj.driveway_category_id,
    agrt.agreement_group_id,
    agr.customer_id,
    cust.name AS customer_name,
    agr.performer_id,
    perf.name AS performer_name,
    wsch.start_date_plan,
    wsch.end_date_plan,
    (date_part('year'::text, wsch.start_date_plan))::integer AS plan_year,
        CASE
            WHEN (exeact.driveway_segment_id IS NOT NULL) THEN 'Принято'::text
            WHEN ((dwss.code)::text = 'COMPLETED'::text) THEN 'Выполнено'::text
            WHEN ((wsch.end_date_plan < ('now'::text)::date) AND ((wsch.end_date_fact IS NOT NULL) AND (wsch.end_date_fact > wsch.end_date_plan))) THEN 'Отставание по контракту'::text
            WHEN ((wsch.start_date_fact IS NOT NULL) AND (dates_flag.stage_delay_flag > (0)::numeric)) THEN 'Отставание по этапу'::text
            WHEN (wsch.start_date_fact IS NOT NULL) THEN 'В работе'::text
            WHEN ((wsch.start_date_plan < ('now'::text)::date) AND (wsch.start_date_fact IS NULL) AND (ingreg_fact.driveway_segment_id IS NULL)) THEN 'Не приступили (по плану)'::text
            ELSE NULL::text
        END AS status,
    wsch.start_date_fact,
    agr.work_date_to AS end_date_agreement,
        CASE
            WHEN (dates_flag.driveway_segment_id IS NOT NULL) THEN dates_flag.expiration_days
            ELSE GREATEST((COALESCE(wsch.end_date_fact, ('now'::text)::date) - wsch.end_date_plan), 0)
        END AS expiration_days,
        CASE
            WHEN (docs.end_date_fact_flag = 0) THEN docs.end_date_fact
            ELSE NULL::date
        END AS end_date_fact,
    photo.photo_file_id,
        CASE
            WHEN (ingreg_fact.driveway_segment_id IS NOT NULL) THEN true
            ELSE false
        END AS ingress_registered
   FROM ((((((((((((((msnow.fdc_driveway_segment dws
     JOIN fdc_driveway dw ON ((dws.driveway_id = dw.id)))
     JOIN fdc_object dwobj ON ((dw.id = dwobj.id)))
     JOIN msnow.fdc_segment s ON ((s.id = dws.id)))
     JOIN msnow.fdc_dw_segment_status dwss ON ((dws.status_id = dwss.id)))
     JOIN msnow.fdc_work_schedule wsch ON ((dws.id = wsch.driveway_segment_id)))
     LEFT JOIN msnow.fdc_agreement agr ON ((dws.agreement_id = agr.id)))
     LEFT JOIN msnow.fdc_agreement_type agrt ON ((agr.agr_type_id = agrt.id)))
     LEFT JOIN nsi.fdc_legal_person cust ON (((agr.customer_id = cust.root_id) AND ((statement_timestamp() >= cust.ver_start_date) AND (statement_timestamp() <= cust.ver_end_date)))))
     LEFT JOIN nsi.fdc_legal_person perf ON (((agr.performer_id = perf.root_id) AND ((statement_timestamp() >= perf.ver_start_date) AND (statement_timestamp() <= perf.ver_end_date)))))
     LEFT JOIN docs ON ((dws.id = docs.driveway_segment_id)))
     LEFT JOIN dates_flag ON ((dws.id = dates_flag.driveway_segment_id)))
     LEFT JOIN photo ON ((dws.id = photo.driveway_segment_id)))
     LEFT JOIN ingreg_fact ON ((dws.id = ingreg_fact.driveway_segment_id)))
     LEFT JOIN exeact ON ((dws.id = exeact.driveway_segment_id)))
  WHERE (((dwss.code)::text <> ALL ((ARRAY['FUTURE_PLANNED'::character varying, 'ON_VOTE'::character varying, 'ESTIMATED_RESULT'::character varying])::text[])) AND (wsch.start_date_plan IS NOT NULL) AND (wsch.end_date_plan IS NOT NULL));

COMMENT ON VIEW fdc_dw_segment_monitor_a_v IS 'Все участки ремонта для витрины Мониторинг работ по ремонту';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.id IS 'Ид участка ремонта';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.name IS 'Наименование учкстка ремонта';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.driveway_category_id IS 'Ид балансовой принадлежности';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.agreement_group_id IS 'Ид группы контракта';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.customer_id IS 'Ид заказчика';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.customer_name IS 'Наименование заказчика';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.performer_id IS 'Ид исполнителя';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.performer_name IS 'Наименование исполнителя';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.start_date_plan IS 'Плановая дата работ(начало)';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.end_date_plan IS 'Плановая дата работ(окончание)';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.plan_year IS 'Год';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.status IS 'Статус';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.start_date_fact IS 'Фактическая дата работ(начало)';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.end_date_agreement IS 'Дата окончания работ по контракту';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.expiration_days IS 'Дней просрочки';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.photo_file_id IS 'Ид фотографии';

COMMENT ON COLUMN fdc_dw_segment_monitor_a_v.ingress_registered IS 'Факт выхода на объект';

